# Ops Skill

Standalone copy of the `ops` Codex skill.
The stable package/folder path remains `universal-install-ops` for compatibility.

The skill routes operational software and system work through the lightest safe path, records reusable proven/failed/unclear learnings, and keeps risky work observable through case notes.

## Layout

- `SKILL.md` - main routing and operating instructions.
- `references/shelf-index.json` - compact shelf router for small models.
- `references/hot-routes.json` - tiny ready route cards for frequent tasks.
- `references/activation-eval.json` - prompts that prove routing still works.
- `scripts/catalog.json` - machine-readable script index for weak agents.
- `scripts/find_script.py` - finds the right helper without browsing every folder.
- `references/` - modular knowledge tree.
- `scripts/` - segmented helper folders by task family.
- `agents/` - agent-facing prompt configuration.

## Health Check

```powershell
python .\scripts\find_script.py "skill health"
python .\scripts\skill\skill_health.py
python .\scripts\skill\validate_skill_package.py . --strict
python .\scripts\routing\evaluate_activation.py
```

## Sync Gate

```powershell
python .\scripts\skill\sync_skill_copy.py --codex --project-root D:\Klavdiya\klava-bot
python .\scripts\skill\skill_health.py --copy-root D:\Klavdiya\klava-bot\tools\mcp\skills\universal-install-ops --copy-root $env:USERPROFILE\.codex\skills\universal-install-ops --strict
```

`--project-root` also syncs `apps/agent/bundled-core/machine-skills/universal-install-ops` when that bundled copy exists.
