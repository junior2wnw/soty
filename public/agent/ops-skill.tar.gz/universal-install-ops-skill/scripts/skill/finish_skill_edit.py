from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))

from skill_paths import skill_root as find_skill_root

SKILL_NAME = "universal-install-ops"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="One-command finish gate for ops skill edits.")
    parser.add_argument("--copy-root", action="append", default=[], help="Extra required skill copy root. Repeatable.")
    parser.add_argument("--project-root", action="append", default=[], help="Project root with bundled skill copies. Repeatable.")
    parser.add_argument("--codex-home", default="", help="Override Codex home for the installed copy.")
    parser.add_argument("--no-codex", action="store_true", help="Do not sync or check the installed Codex copy.")
    parser.add_argument("--skip-tests", action="store_true", help="Skip the full regression test file.")
    parser.add_argument("--skip-sync", action="store_true", help="Do not update metadata or sync copies.")
    parser.add_argument("--skip-installed-check", action="store_true", help="Skip self_check/evaluate_activation inside synced copies.")
    parser.add_argument("--dry-run", action="store_true", help="Print the planned commands without running them.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser.parse_args()


def root() -> Path:
    return find_skill_root(__file__).resolve()


def codex_home(args: argparse.Namespace) -> Path:
    if args.codex_home.strip():
        return Path(args.codex_home).expanduser().resolve()
    return Path(os.environ.get("CODEX_HOME") or os.environ.get("PANEL_CODEX_HOME") or Path.home() / ".codex").resolve()


def use_codex(args: argparse.Namespace) -> bool:
    return not args.no_codex


def planned_copy_roots(args: argparse.Namespace) -> list[Path]:
    copies = [Path(item).expanduser().resolve() for item in args.copy_root if item.strip()]
    for item in args.project_root:
        project = Path(item).expanduser().resolve()
        copies.append(project / "tools" / "mcp" / "skills" / SKILL_NAME)
        bundled = project / "apps" / "agent" / "bundled-core" / "machine-skills" / SKILL_NAME
        if bundled.exists():
            copies.append(bundled)
    if use_codex(args):
        copies.append(codex_home(args) / "skills" / SKILL_NAME)
    seen: set[str] = set()
    result: list[Path] = []
    source = root()
    for copy in copies:
        key = str(copy).casefold()
        if key in seen or copy == source:
            continue
        seen.add(key)
        result.append(copy)
    return result


def clean_generated(path: Path) -> int:
    removed = 0
    if not path.exists():
        return removed
    for directory in list(path.rglob("__pycache__")):
        if directory.is_dir():
            shutil.rmtree(directory)
            removed += 1
    for suffix in [".pyc", ".pyo"]:
        for file_path in path.rglob(f"*{suffix}"):
            if file_path.is_file():
                file_path.unlink()
                removed += 1
    return removed


def run_command(label: str, command: list[str], cwd: Path, allow_fail: bool = False) -> dict[str, Any]:
    started = time.perf_counter()
    result = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    elapsed = round(time.perf_counter() - started, 3)
    ok = result.returncode == 0 or allow_fail
    return {
        "label": label,
        "ok": ok,
        "critical": not allow_fail,
        "returncode": result.returncode,
        "seconds": elapsed,
        "command": " ".join(f'"{part}"' if " " in part else part for part in command),
        "stdout_tail": tail(result.stdout),
        "stderr_tail": tail(result.stderr),
    }


def tail(value: str, lines: int = 12) -> str:
    parts = value.strip().splitlines()
    return "\n".join(parts[-lines:])


def python_script(source: Path, relative: str, *args: str) -> list[str]:
    return [sys.executable, str(source / relative), *args]


def copy_tool_args(copies: list[Path], flag: str) -> list[str]:
    values: list[str] = []
    for copy in copies:
        values.extend([flag, str(copy)])
    return values


def sync_args(copies: list[Path]) -> list[str]:
    return copy_tool_args(copies, "--target")


def doctor_args(copies: list[Path]) -> list[str]:
    values = copy_tool_args(copies, "--copy-root")
    values.append("--json")
    return values


def memory_merge_args(copies: list[Path]) -> list[str]:
    values: list[str] = ["--write", "--json"]
    values.extend(copy_tool_args(copies, "--copy-root"))
    return values


def health_copy_args(copies: list[Path]) -> list[str]:
    args: list[str] = []
    for copy in copies:
        args.extend(["--copy-root", str(copy)])
    return args


def build_plan(args: argparse.Namespace) -> list[tuple[str, list[str], bool]]:
    source = root()
    copies = planned_copy_roots(args)
    plan: list[tuple[str, list[str], bool]] = [
        ("validate package", python_script(source, "scripts/skill/validate_skill_package.py", ".", "--strict"), False),
        ("self check", python_script(source, "scripts/skill/self_check.py"), False),
        ("activation eval", python_script(source, "scripts/routing/evaluate_activation.py"), False),
    ]
    if not args.skip_tests:
        plan.append(("full regression", python_script(source, "scripts/tests/test_universal_install_ops.py"), False))
    if copies:
        plan.append(("merge memory queues", python_script(source, "scripts/skill/merge_skill_memory.py", *memory_merge_args(copies)), False))
    plan.append(("learning review", python_script(source, "scripts/learning/learning_review.py", "--json"), False))
    if not args.skip_sync:
        if copies:
            plan.append(("pre-sync doctor", python_script(source, "scripts/skill/sync_doctor.py", *doctor_args(copies)), True))
        plan.append(("update metadata", python_script(source, "scripts/skill/update_skill_metadata.py", "."), False))
        if copies:
            plan.append(("sync copies", python_script(source, "scripts/skill/sync_skill_copy.py", *sync_args(copies)), False))
    plan.append(("health", python_script(source, "scripts/skill/skill_health.py", *health_copy_args(copies), "--strict"), False))
    if not args.skip_installed_check:
        for copy in copies:
            plan.append(("copy self check", [sys.executable, str(copy / "scripts" / "skill" / "self_check.py"), "--skill-root", str(copy)], False))
            plan.append(("copy activation eval", [sys.executable, str(copy / "scripts" / "routing" / "evaluate_activation.py")], False))
    if not args.skip_sync and copies:
        plan.append(("final sync doctor", python_script(source, "scripts/skill/sync_doctor.py", *doctor_args(copies)), False))
    plan.append(("final validate", python_script(source, "scripts/skill/validate_skill_package.py", ".", "--strict"), False))
    return plan


def run(args: argparse.Namespace) -> dict[str, Any]:
    source = root()
    copies = planned_copy_roots(args)
    plan = build_plan(args)
    if args.dry_run:
        return {
            "ok": True,
            "dry_run": True,
            "skill_root": str(source),
            "copy_roots": [str(copy) for copy in copies],
            "steps": [{"label": label, "command": " ".join(command), "allow_fail": allow_fail} for label, command, allow_fail in plan],
        }

    steps: list[dict[str, Any]] = []
    removed_before = clean_generated(source)
    for label, command, allow_fail in plan:
        steps.append(run_command(label, command, source, allow_fail=allow_fail))
        clean_generated(source)
        for copy in copies:
            clean_generated(copy)
        if not steps[-1]["ok"] and not allow_fail:
            break
    removed_after = clean_generated(source) + sum(clean_generated(copy) for copy in copies)
    failed = [step for step in steps if not step["ok"] and step["critical"]]
    return {
        "ok": not failed,
        "dry_run": False,
        "skill_root": str(source),
        "copy_roots": [str(copy) for copy in copies],
        "removed_generated_before": removed_before,
        "removed_generated_after": removed_after,
        "steps": steps,
        "failed_step": failed[0]["label"] if failed else "",
        "final_line": "finish_skill_edit=ok" if not failed else f"finish_skill_edit=failed:{failed[0]['label']}",
    }


def print_text(report: dict[str, Any]) -> None:
    print("Ops Skill Finish")
    print(f"- skill_root: {report['skill_root']}")
    print(f"- copy_count: {len(report.get('copy_roots', []))}")
    for copy in report.get("copy_roots", []):
        print(f"  - {copy}")
    for step in report["steps"]:
        status = "ok" if step.get("ok", True) else "FAIL"
        label = step["label"]
        if report.get("dry_run"):
            print(f"- plan {label}: {step['command']}")
        else:
            print(f"- {status} {label}: exit={step.get('returncode')} seconds={step.get('seconds')}")
            if not step.get("ok", True):
                if step.get("stdout_tail"):
                    print(f"  stdout: {step['stdout_tail']}")
                if step.get("stderr_tail"):
                    print(f"  stderr: {step['stderr_tail']}")
    print(f"- final_line: {report.get('final_line', 'finish_skill_edit=planned')}")


def main() -> int:
    args = parse_args()
    report = run(args)
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
