from __future__ import annotations

import argparse
import json
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))

from skill_paths import skill_root as find_skill_root


SCENARIOS: list[dict[str, Any]] = [
    {
        "id": "audio-mute-ru",
        "prompt": "выключи звук",
        "expected_shelf": "control-surfaces",
        "expected_hot_route": "windows-audio-mute",
        "expected_script": "windows-audio-mute",
        "script_shelf": "control-surfaces",
        "run_contains": ["-Action Mute"],
        "run_excludes": ["-Muted"],
    },
    {
        "id": "audio-unmute-repair-ru",
        "prompt": "ты не включил звук, верни звук",
        "expected_shelf": "control-surfaces",
        "expected_hot_route": "windows-audio-unmute",
        "expected_script": "windows-audio-unmute",
        "script_shelf": "control-surfaces",
        "run_contains": ["-Action Unmute"],
        "run_excludes": ["-Muted"],
    },
    {
        "id": "audio-state-ru",
        "prompt": "проверь выключен ли звук",
        "expected_shelf": "control-surfaces",
        "expected_hot_route": "windows-audio-state",
        "expected_script": "windows-audio-get-state",
        "script_shelf": "control-surfaces",
        "run_contains": ["-Action Get"],
        "run_excludes": ["-Muted"],
    },
    {
        "id": "ops-self-check-ru",
        "prompt": "проверь ops скилл самопроверкой и установленную копию",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-self-check",
        "expected_script": "ops-self-check",
        "script_shelf": "agent-runtime-skill-ops",
        "run_contains": ["scripts/skill/self_check.py"],
    },
    {
        "id": "skill-finish-gate-ru",
        "prompt": "не гениально и не просто, с трудом; заверши правку скилла одной командой",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "skill-finish-gate",
        "expected_script": "finish-skill-edit",
        "script_shelf": "agent-runtime-skill-ops",
        "run_contains": ["scripts/skill/finish_skill_edit.py"],
    },
    {
        "id": "copy-drift-ru",
        "prompt": "синхронизируй канонический скилл установленную и проектную копию",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "skill-copy-sync-gate",
        "expected_script": "sync-skill-copy",
        "script_shelf": "agent-runtime-skill-ops",
        "run_contains": ["sync_skill_copy.py"],
    },
    {
        "id": "sync-doctor-ru",
        "prompt": "проверь рассинхрон копий перед синхронизацией через sync doctor",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "skill-copy-sync-gate",
        "expected_script": "sync-doctor",
        "script_shelf": "agent-runtime-skill-ops",
        "run_contains": ["sync_doctor.py"],
    },
    {
        "id": "skill-memory-merge-en",
        "prompt": "merge skill memory queues because the agent wrote memory in the installed copy and sync must not overwrite it",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "skill-memory-merge-gate",
        "expected_script": "merge-skill-memory",
        "script_shelf": "agent-runtime-skill-ops",
        "run_contains": ["scripts/skill/merge_skill_memory.py"],
    },
    {
        "id": "codex-session-locator-en",
        "prompt": "find Codex chat links from local session files and avoid useless line 1 links",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "codex-session-locator",
        "expected_script": "codex-session-locator",
        "script_shelf": "agent-runtime-skill-ops",
        "run_contains": ["scripts/skill/codex_session_locator.py"],
        "action_do_contains": "run helper codex-session-locator",
    },
    {
        "id": "memory-loop-ru",
        "prompt": "посмотри в память перед задачей и реши что запомнить после результата",
        "expected_shelf": "learning-memory",
        "expected_hot_route": "memory-loop",
        "expected_script": "memory-loop",
        "script_shelf": "learning-memory",
        "run_contains": ["scripts/learning/memory_loop.py"],
    },
    {
        "id": "learning-review-ru",
        "prompt": "покажи что скилл выучил и сколько времени или токенов сэкономили профили",
        "expected_shelf": "learning-memory",
        "expected_hot_route": "knowledge-conveyor-gate",
        "expected_script": "learning-review",
        "script_shelf": "learning-memory",
        "run_contains": ["scripts/learning/learning_review.py"],
    },
    {
        "id": "soty-teacher-review-ru",
        "prompt": "\u0442\u0438\u0447\u0435\u0440 \u0440\u0435\u0432\u044c\u044e \u0438 \u043c\u0435\u0440\u0436 \u0432 ops",
        "expected_shelf": "learning-memory",
        "expected_hot_route": "soty-teacher-review-gate",
        "expected_script": "ingest-teacher-report",
        "script_shelf": "learning-memory",
        "run_contains": ["scripts/learning/ingest_teacher_report.py", "teacher-report.json"],
    },
    {
        "id": "windows-fast-lane-ru",
        "prompt": "переустановка винды слишком долгая, спец делает за 5-10 минут, не пиши много скриптов",
        "expected_shelf": "windows-reinstall-recovery",
        "expected_hot_route": "windows-reinstall-fast-lane",
    },
    {
        "id": "memory-reconsideration-en",
        "prompt": "memory became dogma; the remembered best route is not best anymore",
        "expected_shelf": "learning-memory",
        "expected_hot_route": "memory-reconsideration-gate",
        "expected_script": "review-memory",
        "script_shelf": "learning-memory",
        "run_contains": ["scripts/learning/review_memory.py"],
    },
    {
        "id": "route-branch-en",
        "prompt": "current situation proves written rule is not best; make a controlled branch",
        "expected_shelf": "learning-memory",
        "expected_hot_route": "situational-branch-gate",
        "expected_script": "route-branch",
        "script_shelf": "learning-memory",
        "run_contains": ["scripts/learning/route_branch.py"],
    },
    {
        "id": "ops-mission-ru",
        "prompt": "задача скилла быстро оптимально универсально делать работу и уменьшать стоимость токенов",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
    },
    {
        "id": "ops-fix-merge-commit-ru",
        "prompt": "что-то не то со скиллом, проверь, поправь, смержи скиллы и закоммить",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
    },
    {
        "id": "ops-top-state-upgrade-ru",
        "prompt": "улучши скилл любыми современными методами в десятки раз до топ состояния",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
    },
    {
        "id": "ops-not-universal-ru",
        "prompt": "что-то не то и почему-то не универсально все в скилле",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-universalization-gate",
    },
    {
        "id": "ops-genius-simplicity-ru",
        "prompt": "сделай скилл гораздо лучше по принципу гениальной простоты, самое простое решение с максимальным результатом",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
    },
    {
        "id": "ops-quality-simplicity-ru",
        "prompt": "сделай скилл гораздо лучше как будто для себя, самое качественное решение с максимальными шансами на успех",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
    },
    {
        "id": "ops-not-best-before-ru",
        "prompt": "сделай скилл гораздо лучше как будто для себя, до этого были не самые лучшие решения",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
        "expected_helper_fit": "candidate",
        "action_do_contains": "follow hot route ops-mission-optimization",
    },
    {
        "id": "ops-improve-rest-ru",
        "prompt": "тогда улучши все остальное в ops skill",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
        "action_do_contains": "follow hot route ops-mission-optimization",
    },
    {
        "id": "ops-self-improvement-sink-ru",
        "prompt": "теперь каждый раз когда ты работаешь со скиллом, скилл должен становиться лучше, экономить время и токены; что-то не то поправь",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-self-improvement-sink",
        "action_do_contains": "follow hot route ops-self-improvement-sink",
    },
    {
        "id": "ops-continuity-checkpoint-ru",
        "prompt": "агент по мере работы забывает про скилл и перестает им пользоваться и улучшать ветки",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-continuity-checkpoint",
        "expected_script": "ops-checkpoint",
        "script_shelf": "agent-runtime-skill-ops",
        "run_contains": ["--checkpoint"],
        "action_do_contains": "run helper ops-checkpoint",
    },
    {
        "id": "execution-contour-target-ru",
        "prompt": "ты зачем на этом компе что-то делаешь, надо переустановить винду на том компе под ключ",
        "expected_shelf": "general-routing",
        "expected_hot_route": "execution-contour-correction",
    },
    {
        "id": "ops-universalization-ru",
        "prompt": "доведи ops skill до идеала и универсальности",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-universalization-gate",
        "action_do_contains": "follow hot route ops-universalization-gate",
    },
    {
        "id": "package-service-ru",
        "prompt": "поставь cli пакет и проверь что сервис запустился",
        "expected_shelf": "package-service-stack",
        "expected_hot_route": "package-service-repair",
    },
    {
        "id": "console-touch-ru",
        "prompt": "надо зайти в терминал и выполнить команду на этом компьютере",
        "expected_shelf": "general-routing",
        "expected_hot_route": "",
    },
]

NO_MATCH_QUERIES = [
    "zzqv unmatched qqqx",
    "случайная фраза без операционного смысла qqqx",
]

SMALL_MODEL_SCENARIOS: list[dict[str, str]] = [
    {
        "id": "qwen-audio-mute",
        "prompt": "выключи звук",
        "expected_shelf": "control-surfaces",
        "expected_hot_route": "windows-audio-mute",
        "expected_helper": "windows-audio-mute",
    },
    {
        "id": "qwen-skill-edit",
        "prompt": "упрости ops skill и проверь installed copy",
        "expected_shelf": "agent-runtime-skill-ops",
    },
    {
        "id": "qwen-package-service",
        "prompt": "поставь cli пакет и проверь что сервис работает",
        "expected_shelf": "package-service-stack",
        "expected_hot_route": "package-service-repair",
    },
    {
        "id": "qwen-windows-fast-lane",
        "prompt": "Windows reinstall is too slow across devices; make ops fast",
        "expected_shelf": "windows-reinstall-recovery",
        "expected_hot_route": "windows-reinstall-fast-lane",
    },
    {
        "id": "qwen-ops-mission",
        "prompt": "ops should remember problems and successes, improve methods, and lower token cost",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
    },
    {
        "id": "qwen-top-state",
        "prompt": "improve ops skill to top state with modern methods and merge after",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
    },
    {
        "id": "qwen-genius-simplicity",
        "prompt": "make ops skill better with genius simplicity, the simplest solution with maximum result",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-mission-optimization",
        "expected_helper_fit": "candidate",
        "action_do_contains": "follow hot route ops-mission-optimization",
    },
    {
        "id": "qwen-self-improvement-sink",
        "prompt": "why does the skill not improve every time; fix it so each skill use has a learning_delta",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-self-improvement-sink",
        "action_do_contains": "follow hot route ops-self-improvement-sink",
    },
    {
        "id": "qwen-codex-session-locator",
        "prompt": "find Codex session file links for chat ids without useless line 1 transcript links",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "codex-session-locator",
        "action_do_contains": "run helper codex-session-locator",
    },
    {
        "id": "qwen-execution-contour",
        "prompt": "why are you working on this computer when the target machine has internet and should download faster",
        "expected_shelf": "general-routing",
        "expected_hot_route": "execution-contour-correction",
    },
    {
        "id": "qwen-universalization",
        "prompt": "bring ops to ideal universal self-improvement with route profiles and learning conveyor",
        "expected_shelf": "agent-runtime-skill-ops",
        "expected_hot_route": "ops-universalization-gate",
        "action_do_contains": "follow hot route ops-universalization-gate",
    },
    {
        "id": "qwen-memory-reconsideration",
        "prompt": "memory became dogma; old best route is not best anymore",
        "expected_shelf": "learning-memory",
        "expected_hot_route": "memory-reconsideration-gate",
        "action_do_contains": "follow hot route memory-reconsideration-gate",
    },
    {
        "id": "qwen-route-branch",
        "prompt": "current situation proves written rule is not best; make a controlled branch",
        "expected_shelf": "learning-memory",
        "expected_hot_route": "situational-branch-gate",
        "action_do_contains": "follow hot route situational-branch-gate",
    },
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run real prompt smoke checks against an ops skill copy.")
    parser.add_argument(
        "--skill-root",
        default="",
        help="Skill root to test. Defaults to the skill that contains this script.",
    )
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    parser.add_argument(
        "--live-audio-get",
        action="store_true",
        help="On Windows, run the audio helper in read-only Get mode and require JSON output.",
    )
    return parser.parse_args()


def resolve_skill_root(raw: str) -> Path:
    root = Path(raw).expanduser().resolve() if raw.strip() else find_skill_root(__file__).resolve()
    required = [
        root / "SKILL.md",
        root / "scripts" / "find_script.py",
        root / "scripts" / "routing" / "route_shelf.py",
        root / "scripts" / "routing" / "route_hot.py",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(f"not an ops skill root or missing files: {', '.join(missing)}")
    return root


def run_python(skill_root: Path, relative_script: str, *args: str) -> subprocess.CompletedProcess[str]:
    script_path = skill_root / relative_script
    with tempfile.TemporaryDirectory() as temp:
        return subprocess.run(
            [sys.executable, str(script_path), *args],
            cwd=temp,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )


def parse_json_result(result: subprocess.CompletedProcess[str]) -> Any:
    if result.returncode != 0:
        raise AssertionError(f"exit={result.returncode}; stderr={result.stderr.strip()}; stdout={result.stdout.strip()}")
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as error:
        raise AssertionError(f"expected JSON output: {error}; stdout={result.stdout.strip()}") from error


def first_id(rows: list[dict[str, Any]], key: str) -> str:
    if not rows:
        return ""
    return str(rows[0].get(key, ""))


def check_scenario(skill_root: Path, scenario: dict[str, Any]) -> dict[str, Any]:
    failures: list[str] = []
    prompt = str(scenario["prompt"])

    shelf_data = parse_json_result(
        run_python(skill_root, "scripts/routing/route_shelf.py", prompt, "--top", "1", "--json")
    )
    actual_shelf = first_id(shelf_data.get("shelves", []), "id")
    if actual_shelf != scenario.get("expected_shelf"):
        failures.append(f"shelf expected {scenario.get('expected_shelf')!r}, got {actual_shelf!r}")

    hot_data = parse_json_result(run_python(skill_root, "scripts/routing/route_hot.py", prompt, "--top", "1", "--json"))
    actual_hot = first_id(hot_data.get("routes", []), "id")
    if actual_hot != scenario.get("expected_hot_route", ""):
        failures.append(f"hot route expected {scenario.get('expected_hot_route')!r}, got {actual_hot!r}")

    script_report: dict[str, Any] = {}
    expected_script = str(scenario.get("expected_script", ""))
    if expected_script:
        script_args = [prompt, "--top", "1", "--json"]
        if scenario.get("script_shelf"):
            script_args.extend(["--shelf", str(scenario["script_shelf"])])
        script_data = parse_json_result(run_python(skill_root, "scripts/find_script.py", *script_args))
        scripts = script_data.get("scripts", [])
        actual_script = first_id(scripts, "id")
        if actual_script != expected_script:
            failures.append(f"script expected {expected_script!r}, got {actual_script!r}")
        if scripts:
            top = scripts[0]
            absolute_path = Path(str(top.get("absolute_path", "")))
            run_line = str(top.get("run", ""))
            script_report = {
                "actual_script": actual_script,
                "absolute_path": str(absolute_path),
                "run": run_line,
            }
            if not absolute_path.is_absolute():
                failures.append("script absolute_path is not absolute")
            if not absolute_path.exists():
                failures.append(f"script absolute_path does not exist: {absolute_path}")
            if str(absolute_path) not in run_line and absolute_path.as_posix() not in run_line:
                failures.append("script run line does not contain the absolute path")
            for needle in scenario.get("run_contains", []):
                if str(needle) not in run_line.replace("\\", "/"):
                    failures.append(f"script run line missing {needle!r}")
            for needle in scenario.get("run_excludes", []):
                if str(needle) in run_line:
                    failures.append(f"script run line must not contain {needle!r}")

    return {
        "id": scenario["id"],
        "prompt": prompt,
        "actual_shelf": actual_shelf,
        "actual_hot_route": actual_hot,
        "script": script_report,
        "ok": not failures,
        "failures": failures,
    }


def check_no_match(skill_root: Path, query: str) -> dict[str, Any]:
    failures: list[str] = []
    script_data = parse_json_result(run_python(skill_root, "scripts/find_script.py", query, "--top", "1", "--json"))
    hot_data = parse_json_result(run_python(skill_root, "scripts/routing/route_hot.py", query, "--top", "1", "--json"))
    scripts = script_data.get("scripts", [])
    routes = hot_data.get("routes", [])
    if scripts:
        failures.append(f"find_script returned {scripts[0].get('id')!r} for no-match query")
    if routes:
        failures.append(f"route_hot returned {routes[0].get('id')!r} for no-match query")
    return {"query": query, "ok": not failures, "failures": failures}


def check_small_model_surface(skill_root: Path) -> dict[str, Any]:
    failures: list[str] = []
    raw = (skill_root / "SKILL.md").read_text(encoding="utf-8")
    body = raw.split("---", 2)[2] if raw.startswith("---") and len(raw.split("---", 2)) == 3 else raw
    body_lines = len(body.splitlines())
    if body_lines > 120:
        failures.append(f"SKILL.md body is {body_lines} lines; keep the weak-model entry short")
    if "python scripts/ops.py" not in raw:
        failures.append("SKILL.md does not present scripts/ops.py as the one-command front door")
    if "## Ready Gate" not in raw:
        failures.append("SKILL.md does not define the Ready Gate for weak-model stop/go control")
    if "action_packet" not in raw:
        failures.append("SKILL.md does not name action_packet as the compact next-action surface")
    if "helper_fit" not in raw:
        failures.append("SKILL.md does not document helper_fit for executable helper gating")
    if "finish_skill_edit.py" not in raw:
        failures.append("SKILL.md does not expose the one-command skill edit finish gate")
    if "Learning is a reflex" not in raw:
        failures.append("SKILL.md does not make reusable learning a hard reflex")
    if "close with proof plus `learning_delta`" not in raw:
        failures.append("SKILL.md does not state the close reflex in the entry surface")
    agents_yaml = skill_root / "agents" / "openai.yaml"
    if not agents_yaml.exists():
        failures.append("agents/openai.yaml is missing")
    else:
        agents_raw = agents_yaml.read_text(encoding="utf-8")
        for term in ["scripts/ops.py", "action_packet", "--checkpoint", "--branch", "--remember", "--close"]:
            if term not in agents_raw:
                failures.append(f"agents/openai.yaml does not preserve the {term} runtime cue")
    if not (skill_root / "scripts" / "ops.py").exists():
        failures.append("scripts/ops.py is missing")
    brief = run_python(skill_root, "scripts/ops.py", "optimize ops skill token usage without losing quality")
    if brief.returncode != 0:
        failures.append(f"ops.py brief route failed: {brief.stderr.strip()}")
    else:
        brief_lines = brief.stdout.splitlines()
        if len(brief_lines) > 14:
            failures.append(f"ops.py brief route is {len(brief_lines)} lines; keep default output token-light")
        if "- voice:" in brief.stdout or "- ready_gate:" in brief.stdout:
            failures.append("ops.py default text output printed full checklist; require --detail for that")
        if "--detail" not in brief.stdout:
            failures.append("ops.py default text output does not point to --detail for full output")
        if "source_state:" not in brief.stdout or "metrics=" not in brief.stdout:
            failures.append("ops.py default text output does not expose source_state and compact route metrics")
        if "- reflex:" not in brief.stdout:
            failures.append("ops.py default text output does not expose the compact reflex line")
    detail = run_python(skill_root, "scripts/ops.py", "optimize ops skill token usage without losing quality", "--detail")
    if detail.returncode != 0:
        failures.append(f"ops.py detail route failed: {detail.stderr.strip()}")
    elif "- voice:" not in detail.stdout or "- ready_gate:" not in detail.stdout:
        failures.append("ops.py --detail did not print the full checklist")
    with tempfile.TemporaryDirectory() as temp:
        close = run_python(
            skill_root,
            "scripts/ops.py",
            "skill close learning delta",
            "--close",
            "--actual",
            "self_check close gate",
            "--success",
            "final line printed",
            "--env",
            "skill self check",
            "--queue",
            str(Path(temp) / "self-check-candidates.jsonl"),
        )
    if close.returncode != 0:
        failures.append(f"ops.py --close failed: {close.stderr.strip()}")
    elif "Ops Close" not in close.stdout or "final_line: learning_delta=" not in close.stdout:
        failures.append("ops.py --close did not print a concrete learning_delta final_line")
    explicit_close = run_python(
        skill_root,
        "scripts/ops.py",
        "skill explicit patch close gate",
        "--close",
        "--actual",
        "patch",
        "--success",
        "self_check explicit close proof",
        "--env",
        "skill self check",
        "--json",
    )
    if explicit_close.returncode != 0:
        failures.append(f"ops.py explicit --close failed: {explicit_close.stderr.strip()}")
    else:
        explicit_close_data = parse_json_result(explicit_close)
        if explicit_close_data.get("learning_delta") != "patch" or explicit_close_data.get("written") is not False:
            failures.append("ops.py explicit --close did not preserve learning_delta=patch without writing a marker")
    checkpoint = run_python(skill_root, "scripts/ops.py", "skill runtime continuity", "--checkpoint", "--json")
    if checkpoint.returncode != 0:
        failures.append(f"ops.py --checkpoint failed: {checkpoint.stderr.strip()}")
    else:
        checkpoint_data = parse_json_result(checkpoint)
        if checkpoint_data.get("mode") != "checkpoint":
            failures.append("ops.py --checkpoint did not return checkpoint mode")
        if not checkpoint_data.get("checkpoint", {}).get("branch_check"):
            failures.append("ops.py --checkpoint did not return branch_check")
        if "missing proof/env is not improvement" not in str(checkpoint_data.get("checkpoint", {}).get("memory_check", "")):
            failures.append("ops.py --checkpoint does not warn that missing proof/env is not improvement")
    broad_quality = run_python(
        skill_root,
        "scripts/ops.py",
        "why is the ops skill not working as needed; assess its behavior and fix the desire mismatch",
        "--json",
    )
    if broad_quality.returncode != 0:
        failures.append(f"ops.py broad quality route failed: {broad_quality.stderr.strip()}")
    else:
        broad_quality_data = parse_json_result(broad_quality)
        profile = broad_quality_data.get("route_profile") or {}
        if profile and profile.get("profile_id") != "ops-universal-improvement-contract":
            failures.append(f"broad ops quality prompt reused unrelated route profile {profile.get('profile_id')!r}")
        if "learning_delta" not in str((broad_quality_data.get("reflex_card") or {}).get("done", "")):
            failures.append("ops.py broad quality route does not expose the done learning_delta reflex")
        if "final_line" not in str((broad_quality_data.get("reflex_card") or {}).get("done", "")):
            failures.append("ops.py broad quality route does not expose the final_line close receipt")
    reflex_mismatch = run_python(
        skill_root,
        "scripts/ops.py",
        "Почему же скилл ops не работает так как нужно? Оцени рефлексы всех аспектов скилла",
        "--json",
    )
    if reflex_mismatch.returncode != 0:
        failures.append(f"ops.py reflex mismatch route failed: {reflex_mismatch.stderr.strip()}")
    else:
        reflex_mismatch_data = parse_json_result(reflex_mismatch)
        if (reflex_mismatch_data.get("hot_route") or {}).get("id") != "ops-mission-optimization":
            failures.append("Russian ops reflex mismatch prompt does not route to ops-mission-optimization")
    return {"id": "small-model-surface", "body_lines": body_lines, "ok": not failures, "failures": failures}


def check_small_model_scenario(skill_root: Path, scenario: dict[str, str]) -> dict[str, Any]:
    failures: list[str] = []
    prompt = scenario["prompt"]
    data = parse_json_result(run_python(skill_root, "scripts/ops.py", prompt, "--json"))
    shelf = data.get("shelf") or {}
    hot_route = data.get("hot_route") or {}
    helper = data.get("helper") or {}
    actual_shelf = str(shelf.get("id", ""))
    actual_hot_route = str(hot_route.get("id", ""))
    actual_helper = str(helper.get("id", ""))

    if actual_shelf != scenario.get("expected_shelf", ""):
        failures.append(f"shelf expected {scenario.get('expected_shelf')!r}, got {actual_shelf!r}")
    expected_hot = scenario.get("expected_hot_route", "")
    if expected_hot and actual_hot_route != expected_hot:
        failures.append(f"hot route expected {expected_hot!r}, got {actual_hot_route!r}")
    expected_helper = scenario.get("expected_helper", "")
    if expected_helper and actual_helper != expected_helper:
        failures.append(f"helper expected {expected_helper!r}, got {actual_helper!r}")
    expected_helper_fit = scenario.get("expected_helper_fit", "")
    if expected_helper_fit and data.get("helper_fit") != expected_helper_fit:
        failures.append(f"helper_fit expected {expected_helper_fit!r}, got {data.get('helper_fit')!r}")
    if not data.get("source_state"):
        failures.append("ops.py JSON did not report source_state")
    metrics = data.get("route_metrics") or {}
    if not isinstance(metrics, dict) or "read_count" not in metrics or "helper_fit" not in metrics:
        failures.append("ops.py JSON did not report compact route_metrics")
    if len(data.get("read", [])) > 3:
        failures.append("ops.py returned too many read targets for a small model")
    if not data.get("verify"):
        failures.append("ops.py did not return a verify instruction")
    if not data.get("fallback"):
        failures.append("ops.py did not return a fallback instruction")
    if not data.get("scorecard"):
        failures.append("ops.py did not return the top-state scorecard")
    ready_gate = data.get("ready_gate", [])
    if not ready_gate:
        failures.append("ops.py did not return the Ready Gate")
    elif not any(str(item).startswith("stop:") for item in ready_gate):
        failures.append("Ready Gate does not contain stop conditions")
    action_packet = data.get("action_packet", {})
    if not action_packet:
        failures.append("ops.py did not return an action_packet")
    else:
        for key in ["do_now", "stop_if", "prove", "checkpoint", "branch", "remember", "close"]:
            if not action_packet.get(key):
                failures.append(f"action_packet missing {key!r}")
        if "final_line" not in str(action_packet.get("close", "")):
            failures.append("action_packet close does not require carrying the --close final_line")
        action_do_contains = scenario.get("action_do_contains", "")
        if action_do_contains and action_do_contains not in str(action_packet.get("do_now", "")):
            failures.append(f"action_packet do_now missing {action_do_contains!r}")
    if len(data.get("next", [])) > 4:
        failures.append("ops.py returned too many next steps for a small model")

    return {
        "id": scenario["id"],
        "prompt": prompt,
        "actual_shelf": actual_shelf,
        "actual_hot_route": actual_hot_route,
        "actual_helper": actual_helper,
        "ok": not failures,
        "failures": failures,
    }


def check_memory_capture_surface(skill_root: Path) -> dict[str, Any]:
    failures: list[str] = []
    with tempfile.TemporaryDirectory() as temp:
        memory_dir = Path(temp)
        candidate_queue = memory_dir / "candidate-facts.jsonl"
        cases = [
            [
                "install service",
                "--mode",
                "after",
                "--result",
                "works",
                "--actual",
                "python scripts/ops.py routed to package-service-repair",
                "--success",
                "service health check passed",
                "--env",
                "windows host, package-service-stack",
                "--queue",
                str(candidate_queue),
                "--json",
            ],
            [
                "install service",
                "--mode",
                "during",
                "--result",
                "failed",
                "--expected",
                "foreground remote command",
                "--actual",
                "HTTP timeout; background job artifact required",
                "--success",
                "foreground command timed out before artifact appeared",
                "--env",
                "remote browser bridge, long command",
                "--queue",
                str(candidate_queue),
                "--json",
            ],
        ]
        for index, args in enumerate(cases, start=1):
            data = parse_json_result(run_python(skill_root, "scripts/learning/memory_loop.py", *args))
            if not data.get("should_record"):
                failures.append(f"memory case {index} did not request recording")
            if not data.get("marker"):
                failures.append(f"memory case {index} did not produce a marker")
            if data.get("questions"):
                failures.append(f"memory case {index} has unexpected missing questions: {data.get('questions')}")
        conveyor = parse_json_result(run_python(skill_root, "scripts/learning/learning_conveyor.py", "--memory-dir", str(memory_dir), "--json"))
        if not conveyor.get("ok"):
            failures.append("learning_conveyor.py did not pass on an empty memory directory")
        review = parse_json_result(run_python(skill_root, "scripts/learning/learning_review.py", "--memory-dir", str(memory_dir), "--json"))
        if not review.get("ok"):
            failures.append("learning_review.py did not pass on an empty memory directory")
        profile = parse_json_result(run_python(skill_root, "scripts/learning/route_profile.py", "--action", "summary", "--store", str(memory_dir / "profiles.jsonl"), "--json"))
        if profile.get("profile_count") != 0:
            failures.append("route_profile.py empty summary returned unexpected profiles")
    return {"id": "memory-capture-surface", "ok": not failures, "failures": failures}


def run_live_audio_get(skill_root: Path) -> dict[str, Any]:
    if platform.system().lower() != "windows":
        return {"ok": True, "skipped": True, "reason": "not Windows"}
    powershell = shutil.which("powershell") or shutil.which("pwsh")
    if not powershell:
        return {"ok": False, "skipped": False, "failures": ["PowerShell executable not found"]}
    helper = skill_root / "scripts" / "control" / "windows-set-audio-mute.ps1"
    result = subprocess.run(
        [powershell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(helper), "-Action", "Get"],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    failures: list[str] = []
    parsed: dict[str, Any] = {}
    if result.returncode != 0:
        failures.append(f"audio Get failed exit={result.returncode}; stderr={result.stderr.strip()}")
    else:
        try:
            parsed = json.loads(result.stdout)
        except json.JSONDecodeError:
            failures.append(f"audio Get did not return JSON: {result.stdout.strip()}")
        if parsed.get("Action") != "Get" or "Muted" not in parsed:
            failures.append(f"audio Get JSON missing expected fields: {parsed!r}")
    return {"ok": not failures, "skipped": False, "result": parsed, "failures": failures}


def build_report(skill_root: Path, live_audio_get: bool) -> dict[str, Any]:
    scenario_results = [check_scenario(skill_root, scenario) for scenario in SCENARIOS]
    no_match_results = [check_no_match(skill_root, query) for query in NO_MATCH_QUERIES]
    small_model_surface = check_small_model_surface(skill_root)
    small_model_results = [check_small_model_scenario(skill_root, scenario) for scenario in SMALL_MODEL_SCENARIOS]
    memory_capture = check_memory_capture_surface(skill_root)
    live_audio = run_live_audio_get(skill_root) if live_audio_get else {"ok": True, "skipped": True}
    failures = [
        *[item for item in scenario_results if not item["ok"]],
        *[item for item in no_match_results if not item["ok"]],
        *([] if small_model_surface["ok"] else [small_model_surface]),
        *[item for item in small_model_results if not item["ok"]],
        *([] if memory_capture["ok"] else [memory_capture]),
    ]
    if not live_audio["ok"]:
        failures.append({"id": "live-audio-get", **live_audio})
    return {
        "skill_root": str(skill_root),
        "scenario_count": len(scenario_results),
        "no_match_count": len(no_match_results),
        "small_model_surface": small_model_surface,
        "small_model_count": len(small_model_results),
        "small_model": small_model_results,
        "memory_capture": memory_capture,
        "live_audio_get": live_audio,
        "failures": failures,
        "failure_count": len(failures),
        "scenarios": scenario_results,
        "no_match": no_match_results,
        "ok": not failures,
    }


def print_text(report: dict[str, Any]) -> None:
    print("Ops Self Check")
    print(f"- skill_root: {report['skill_root']}")
    print(f"- scenario_count: {report['scenario_count']}")
    print(f"- no_match_count: {report['no_match_count']}")
    print(
        f"- small_model_surface: {'ok' if report['small_model_surface']['ok'] else 'FAIL'} "
        f"body_lines={report['small_model_surface']['body_lines']}"
    )
    print(f"- small_model_count: {report['small_model_count']}")
    print(f"- memory_capture: {'ok' if report['memory_capture']['ok'] else 'FAIL'}")
    print(f"- failure_count: {report['failure_count']}")
    live = report["live_audio_get"]
    if live.get("skipped"):
        print("- live_audio_get: skipped")
    else:
        print(f"- live_audio_get: {'ok' if live.get('ok') else 'FAIL'}")
    for item in report["scenarios"]:
        print(f"- {'ok' if item['ok'] else 'FAIL'} {item['id']}: shelf={item['actual_shelf']} hot={item['actual_hot_route'] or 'none'}")
    for item in report["no_match"]:
        print(f"- {'ok' if item['ok'] else 'FAIL'} no-match: {item['query']}")
    for item in report["small_model"]:
        print(
            f"- {'ok' if item['ok'] else 'FAIL'} {item['id']}: "
            f"shelf={item['actual_shelf']} hot={item['actual_hot_route'] or 'none'} helper={item['actual_helper'] or 'none'}"
        )
    if report["failures"]:
        print("- failures:")
        for item in report["failures"]:
            label = item.get("id") or item.get("query") or "failure"
            for failure in item.get("failures", []):
                print(f"  - {label}: {failure}")


def main() -> int:
    args = parse_args()
    try:
        root = resolve_skill_root(args.skill_root)
        report = build_report(root, live_audio_get=args.live_audio_get)
    except Exception as error:
        report = {"ok": False, "failure_count": 1, "failures": [{"id": "self-check", "failures": [str(error)]}]}
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0 if report.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
