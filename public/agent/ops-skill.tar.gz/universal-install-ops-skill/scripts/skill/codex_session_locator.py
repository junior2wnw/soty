from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SESSION_ID_RE = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Locate Codex local session files without dumping raw transcripts.")
    parser.add_argument("query", nargs="*", help="Words to search in session titles and user-message lines.")
    parser.add_argument("--id", action="append", default=[], help="Exact Codex session/thread id. Repeatable.")
    parser.add_argument("--codex-home", default="", help="Override Codex home; defaults to CODEX_HOME, PANEL_CODEX_HOME, or ~/.codex.")
    parser.add_argument("--since", default="", help="Optional YYYY-MM-DD lower bound for updated_at.")
    parser.add_argument("--limit", type=int, default=10)
    parser.add_argument("--include-snippets", action="store_true", help="Include short user-message snippets for matched lines.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def codex_home(raw: str) -> Path:
    if raw.strip():
        return Path(raw).expanduser().resolve()
    return Path(os.environ.get("CODEX_HOME") or os.environ.get("PANEL_CODEX_HOME") or Path.home() / ".codex").resolve()


def compact(value: str, limit: int = 180) -> str:
    text = " ".join(value.strip().split())
    return text if len(text) <= limit else text[: limit - 3].rstrip() + "..."


def tokens(value: str) -> set[str]:
    return {item.casefold() for item in re.findall(r"[\w.+-]{2,}", value, flags=re.UNICODE)}


def read_jsonl(path: Path) -> list[tuple[int, dict[str, Any]]]:
    if not path.exists():
        return []
    rows: list[tuple[int, dict[str, Any]]] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict):
            rows.append((line_number, data))
    return rows


def read_index(home: Path) -> list[dict[str, Any]]:
    index_path = home / "session_index.jsonl"
    rows: list[dict[str, Any]] = []
    for line_number, data in read_jsonl(index_path):
        session_id = str(data.get("id", ""))
        if not SESSION_ID_RE.fullmatch(session_id):
            continue
        rows.append(
            {
                "id": session_id,
                "thread_name": str(data.get("thread_name", "")),
                "updated_at": str(data.get("updated_at", "")),
                "index_path": str(index_path),
                "index_line": line_number,
            }
        )
    return rows


def session_files(home: Path) -> list[Path]:
    sessions_root = home / "sessions"
    if not sessions_root.exists():
        return []
    return sorted(path for path in sessions_root.rglob("*.jsonl") if path.is_file())


def file_for_id(files: list[Path], session_id: str) -> Path | None:
    return next((path for path in files if session_id in path.name), None)


def message_text(payload: dict[str, Any]) -> tuple[str, str]:
    if payload.get("type") == "thread_name_updated":
        return "thread_name", str(payload.get("thread_name", ""))
    if payload.get("type") == "user_message":
        return "user_message", str(payload.get("message", ""))
    if payload.get("type") == "message" and payload.get("role") == "user":
        parts: list[str] = []
        for item in payload.get("content", []):
            if isinstance(item, dict):
                value = item.get("text") or item.get("input_text")
                if isinstance(value, str):
                    parts.append(value)
        return "user_message", "\n".join(parts)
    return "", ""


def inspect_session_file(path: Path | None, query_tokens: set[str], include_snippets: bool) -> dict[str, Any]:
    result: dict[str, Any] = {
        "session_path": str(path) if path else "",
        "session_meta_line": None,
        "thread_name_line": None,
        "first_user_line": None,
        "last_user_line": None,
        "first_match_line": None,
        "matched_user_lines": [],
    }
    if path is None or not path.exists():
        return result
    matches: list[dict[str, Any]] = []
    for line_number, data in read_jsonl(path):
        payload = data.get("payload", {})
        if not isinstance(payload, dict):
            continue
        if data.get("type") == "session_meta" or payload.get("type") == "session_meta":
            result["session_meta_line"] = result["session_meta_line"] or line_number
        kind, text = message_text(payload)
        if kind == "thread_name":
            result["thread_name_line"] = line_number
        if kind == "user_message" and text.strip():
            result["first_user_line"] = result["first_user_line"] or line_number
            result["last_user_line"] = line_number
            overlap = query_tokens & tokens(text) if query_tokens else set()
            if overlap:
                item: dict[str, Any] = {"line": line_number, "score": len(overlap)}
                if include_snippets:
                    item["snippet"] = compact(text)
                matches.append(item)
    matches.sort(key=lambda item: (-int(item["score"]), int(item["line"])))
    if matches:
        result["first_match_line"] = matches[0]["line"]
        result["matched_user_lines"] = matches[:5]
    return result


def score_index_row(row: dict[str, Any], query_tokens: set[str]) -> int:
    if not query_tokens:
        return 0
    return 6 * len(query_tokens & tokens(str(row.get("thread_name", ""))))


def build_match(row: dict[str, Any], path: Path | None, query_tokens: set[str], include_snippets: bool) -> dict[str, Any]:
    inspected = inspect_session_file(path, query_tokens, include_snippets)
    score = score_index_row(row, query_tokens)
    score += sum(int(item.get("score", 0)) for item in inspected.get("matched_user_lines", []))
    link_line = (
        inspected.get("first_match_line")
        or inspected.get("thread_name_line")
        or inspected.get("first_user_line")
        or inspected.get("session_meta_line")
        or 1
    )
    return {
        **row,
        **inspected,
        "session_line": link_line,
        "score": score,
    }


def wanted_ids(args: argparse.Namespace) -> set[str]:
    found = set(args.id)
    for item in args.query:
        found.update(SESSION_ID_RE.findall(item))
    return found


def run(args: argparse.Namespace) -> dict[str, Any]:
    home = codex_home(args.codex_home)
    index_rows = read_index(home)
    files = session_files(home)
    query_text = " ".join(item for item in args.query if not SESSION_ID_RE.fullmatch(item))
    query_tokens = tokens(query_text)
    ids = wanted_ids(args)
    by_id = {row["id"]: row for row in index_rows}
    rows: list[dict[str, Any]]
    if ids:
        rows = [
            by_id.get(session_id)
            or {
                "id": session_id,
                "thread_name": "",
                "updated_at": "",
                "index_path": str(home / "session_index.jsonl"),
                "index_line": None,
            }
            for session_id in sorted(ids)
        ]
    else:
        rows = index_rows
    if args.since.strip():
        rows = [row for row in rows if str(row.get("updated_at", "")) >= args.since.strip()]
    matches = [build_match(row, file_for_id(files, str(row["id"])), query_tokens, args.include_snippets) for row in rows]
    if not ids and query_tokens:
        matches = [item for item in matches if int(item.get("score", 0)) > 0]
    matches.sort(key=lambda item: (int(item.get("score", 0)), str(item.get("updated_at", "")), str(item.get("id", ""))), reverse=True)
    return {
        "ok": True,
        "codex_home": str(home),
        "index_path": str(home / "session_index.jsonl"),
        "web_links_available": False,
        "web_links_reason": "local Codex session data exposes ids and JSONL files, not direct web URLs",
        "query": query_text,
        "match_count": len(matches[: max(1, args.limit)]),
        "matches": matches[: max(1, args.limit)],
    }


def print_text(report: dict[str, Any]) -> None:
    print("Codex Session Locator")
    print(f"- codex_home: {report['codex_home']}")
    print(f"- web_links: unavailable ({report['web_links_reason']})")
    if not report["matches"]:
        print("- matches: none")
        return
    for item in report["matches"]:
        title = compact(str(item.get("thread_name", ""))) or "(untitled)"
        print(f"- match: {title}")
        print(f"  id: {item.get('id', '')}")
        print(f"  updated_at: {item.get('updated_at', '')}")
        print(f"  index: {item.get('index_path', '')}:{item.get('index_line') or 1}")
        print(f"  session: {item.get('session_path', '')}:{item.get('session_line') or 1}")
        if item.get("thread_name_line"):
            print(f"  thread_name_line: {item['thread_name_line']}")
        if item.get("first_user_line") or item.get("last_user_line"):
            print(f"  user_lines: first={item.get('first_user_line')} last={item.get('last_user_line')}")
        for match in item.get("matched_user_lines", []):
            suffix = f" {match['snippet']}" if "snippet" in match else ""
            print(f"  matched_user_line: {match['line']}{suffix}")
    print("- note: line 1 is usually session metadata; prefer index plus thread/user lines for handoff.")


def main() -> int:
    args = parse_args()
    report = run(args)
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
