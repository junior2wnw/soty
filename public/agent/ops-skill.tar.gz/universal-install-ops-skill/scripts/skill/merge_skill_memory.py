from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))

from skill_paths import skill_root as find_skill_root

SKILL_NAME = "universal-install-ops"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Merge local .skill-memory JSONL queues across skill copies.")
    parser.add_argument("--source-root", default="", help="Canonical skill root. Defaults to the current skill tree.")
    parser.add_argument("--copy-root", action="append", default=[], help="Skill copy root to merge. Repeatable.")
    parser.add_argument("--project-root", action="append", default=[], help="Project root with bundled skill copies. Repeatable.")
    parser.add_argument("--codex", action="store_true", help="Merge the installed Codex skill copy.")
    parser.add_argument("--codex-home", default="", help="Override Codex home when using --codex.")
    parser.add_argument("--write", action="store_true", help="Write the union back to every existing memory root.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def source_root(raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else find_skill_root(__file__).resolve()


def codex_home(args: argparse.Namespace) -> Path:
    if args.codex_home.strip():
        return Path(args.codex_home).expanduser().resolve()
    return Path(os.environ.get("CODEX_HOME") or os.environ.get("PANEL_CODEX_HOME") or Path.home() / ".codex").resolve()


def dedupe(paths: list[Path]) -> list[Path]:
    seen: set[str] = set()
    result: list[Path] = []
    for path in paths:
        key = str(path).casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(path)
    return result


def planned_roots(args: argparse.Namespace, source: Path) -> list[Path]:
    roots = [source]
    roots.extend(Path(item).expanduser().resolve() for item in args.copy_root if item.strip())
    for item in args.project_root:
        project = Path(item).expanduser().resolve()
        roots.append(project / "tools" / "mcp" / "skills" / SKILL_NAME)
        bundled = project / "apps" / "agent" / "bundled-core" / "machine-skills" / SKILL_NAME
        if bundled.exists():
            roots.append(bundled)
    if args.codex:
        roots.append(codex_home(args) / "skills" / SKILL_NAME)
    return dedupe(roots)


def require_skill_root(path: Path, label: str) -> None:
    if not (path / "SKILL.md").exists():
        raise ValueError(f"{label} is not a skill root with SKILL.md: {path}")
    if path.anchor == str(path):
        raise ValueError(f"refusing filesystem root as {label}: {path}")


def memory_files(root: Path) -> list[Path]:
    memory_root = root / ".skill-memory"
    if not memory_root.exists():
        return []
    return sorted(path for path in memory_root.rglob("*.jsonl") if path.is_file())


def row_signature(line: str, path: Path, line_number: int, relative: str) -> tuple[str, str]:
    text = line.strip()
    if not text:
        return "", ""
    try:
        data = json.loads(text)
    except json.JSONDecodeError as error:
        raise ValueError(f"{path}:{line_number}: invalid JSONL row: {error.msg}") from error
    marker = str(data.get("marker", "")).strip()
    if Path(relative).name == "candidate-facts.jsonl" and marker:
        return f"candidate-marker:{marker}", json.dumps(data, ensure_ascii=False, sort_keys=True)
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")), json.dumps(
        data, ensure_ascii=False, sort_keys=True
    )


def collect_rows(root: Path) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    memory_root = root / ".skill-memory"
    for path in memory_files(root):
        relative = path.relative_to(memory_root).as_posix()
        signatures: dict[str, str] = {}
        lines = path.read_text(encoding="utf-8-sig").splitlines()
        for index, line in enumerate(lines, start=1):
            signature, normalized = row_signature(line, path, index, relative)
            if not signature:
                continue
            signatures.setdefault(signature, normalized)
        result[relative] = {
            "path": path,
            "row_count": len(signatures),
            "rows": signatures,
        }
    return result


def newer_profile(candidate: dict[str, Any], existing: dict[str, Any] | None) -> bool:
    if existing is None:
        return True
    candidate_time = str(candidate.get("updated_at", ""))
    existing_time = str(existing.get("updated_at", ""))
    if candidate_time != existing_time:
        return candidate_time > existing_time
    return len(json.dumps(candidate, sort_keys=True)) >= len(json.dumps(existing, sort_keys=True))


def collapse_route_profiles(rows: dict[str, str]) -> dict[str, str]:
    latest: dict[str, tuple[dict[str, Any], str, str]] = {}
    passthrough: dict[str, str] = {}
    for signature, normalized in rows.items():
        data = json.loads(normalized)
        profile_id = str(data.get("profile_id", ""))
        if not profile_id:
            passthrough[signature] = normalized
            continue
        current = latest.get(profile_id)
        if current is None or newer_profile(data, current[0]):
            latest[profile_id] = (data, signature, normalized)
    collapsed = dict(passthrough)
    for _data, signature, normalized in latest.values():
        collapsed[signature] = normalized
    return collapsed


def collapse_rows(relative: str, rows: dict[str, str]) -> dict[str, str]:
    if Path(relative).name == "route-profiles.jsonl":
        return collapse_route_profiles(rows)
    return rows


def write_jsonl(path: Path, rows: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = "\n".join(rows)
    path.write_text((payload + "\n") if payload else "", encoding="utf-8")


def run(args: argparse.Namespace) -> dict[str, Any]:
    source = source_root(args.source_root)
    require_skill_root(source, "source-root")
    roots = planned_roots(args, source)
    existing_roots = [root for root in roots if (root / "SKILL.md").exists()]
    missing_roots = [root for root in roots if not (root / "SKILL.md").exists()]

    collected: dict[str, dict[str, str]] = {}
    before_counts: dict[str, dict[str, int]] = {}
    for root in existing_roots:
        rows_by_file = collect_rows(root)
        before_counts[str(root)] = {relative: int(item["row_count"]) for relative, item in rows_by_file.items()}
        for relative, item in rows_by_file.items():
            bucket = collected.setdefault(relative, {})
            bucket.update(item["rows"])

    collected = {relative: collapse_rows(relative, rows) for relative, rows in collected.items()}
    merged_counts = {relative: len(rows) for relative, rows in sorted(collected.items())}
    wrote: list[dict[str, Any]] = []
    if args.write:
        for root in existing_roots:
            memory_root = root / ".skill-memory"
            for relative, rows in sorted(collected.items()):
                ordered = [rows[key] for key in sorted(rows)]
                write_jsonl(memory_root / relative, ordered)
                wrote.append({"root": str(root), "path": relative, "row_count": len(ordered)})

    return {
        "ok": True,
        "write": bool(args.write),
        "source": str(source),
        "root_count": len(existing_roots),
        "roots": [str(root) for root in existing_roots],
        "missing_roots": [str(root) for root in missing_roots],
        "before_counts": before_counts,
        "merged_counts": merged_counts,
        "wrote": wrote,
    }


def print_text(report: dict[str, Any]) -> None:
    print("Skill Memory Merge")
    print(f"- source: {report['source']}")
    print(f"- root_count: {report['root_count']}")
    for root in report["roots"]:
        print(f"  - {root}")
    if report["missing_roots"]:
        print("- missing_roots:")
        for root in report["missing_roots"]:
            print(f"  - {root}")
    print("- merged_counts:")
    if not report["merged_counts"]:
        print("  - none")
    for path, count in report["merged_counts"].items():
        print(f"  - {path}: {count}")
    print(f"- wrote: {len(report['wrote'])}")


def main() -> int:
    args = parse_args()
    try:
        report = run(args)
    except Exception as error:
        print(f"error: {error}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
