from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "learning"))

from skill_paths import skill_root as find_skill_root
from maintain_field_notes import build_report
import learning_review

METADATA_FILE = ".klava-canonical-skill.json"
REPO_WRAPPER_FILES = {".gitignore", "README.md"}
GENERATED_PATTERNS = {".pyc", ".pyo"}
GENERATED_DIRS = {"__pycache__"}
LOCAL_STATE_DIRS = {".skill-memory"}
SKILL_DESCRIPTION_LIMIT = 1024
SHELF_INDEX = "references/shelf-index.json"
HOT_ROUTES = "references/hot-routes.json"
SCRIPT_CATALOG = "scripts/catalog.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run lightweight health checks for the universal-install-ops skill.",
    )
    parser.add_argument("--strict", action="store_true", help="Return non-zero on warnings as well as errors.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON instead of text.")
    parser.add_argument("--skip-powershell", action="store_true", help="Skip PowerShell parser checks.")
    parser.add_argument(
        "--copy-root",
        action="append",
        default=[],
        help="Required skill copy directory that must match the canonical source hash. Repeatable.",
    )
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__)


def workspace_root(root: Path) -> Path | None:
    for candidate in root.parents:
        if (candidate / "tools" / "mcp" / "skills").exists() and (candidate / "apps" / "agent").exists():
            return candidate
    return None


def collect_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for item in root.rglob("*"):
        if ".git" in item.parts:
            continue
        if any(part in LOCAL_STATE_DIRS for part in item.parts):
            continue
        if item.name == METADATA_FILE:
            continue
        if item.name in REPO_WRAPPER_FILES:
            continue
        if any(part in GENERATED_DIRS for part in item.parts):
            continue
        if item.is_file():
            files.append(item)
    return sorted(files, key=lambda item: item.relative_to(root).as_posix())


def hash_skill(root: Path) -> str:
    digest = hashlib.sha256()
    for file_path in collect_files(root):
        relative = file_path.relative_to(root).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(file_path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any] | None:
    try:
        raw = path.read_text(encoding="utf-8")
        parsed = json.loads(raw)
    except Exception:
        return None
    return parsed if isinstance(parsed, dict) else None


def read_skill_description(root: Path) -> str:
    raw = (root / "SKILL.md").read_text(encoding="utf-8")
    if not raw.startswith("---"):
        return ""
    parts = raw.split("---", 2)
    if len(parts) < 3:
        return ""

    lines = parts[1].splitlines()
    description_parts: list[str] = []
    in_description = False
    for line in lines:
        if line.startswith("description:"):
            in_description = True
            value = line.split(":", 1)[1].strip()
            if value and value not in {">", ">-", "|", "|-"}:
                description_parts.append(value.strip("\"'"))
            continue
        if in_description:
            if line.startswith("  "):
                description_parts.append(line.strip())
                continue
            break
    return " ".join(part for part in description_parts if part)


def find_skill_links(root: Path) -> list[str]:
    raw = (root / "SKILL.md").read_text(encoding="utf-8")
    links: list[str] = []
    for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", raw):
        target = match.group(1).strip()
        if not target or "://" in target or target.startswith("#"):
            continue
        links.append(target.split("#", 1)[0])
    return links


def validate_skill_links(root: Path) -> list[str]:
    errors: list[str] = []
    for target in find_skill_links(root):
        target_path = (root / target).resolve()
        try:
            target_path.relative_to(root)
        except ValueError:
            errors.append(f"SKILL.md link escapes skill root: {target}")
            continue
        if not target_path.exists():
            errors.append(f"SKILL.md link target is missing: {target}")
    return errors


def validate_shelf_index(root: Path) -> tuple[dict[str, Any], list[str], list[str]]:
    index_path = root / SHELF_INDEX
    errors: list[str] = []
    warnings: list[str] = []
    if not index_path.exists():
        return {"shelf_count": 0}, [f"missing {SHELF_INDEX}"], warnings

    try:
        parsed = json.loads(index_path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"shelf_count": 0}, [f"{SHELF_INDEX} is not valid JSON: {error}"], warnings

    shelves = parsed.get("shelves")
    if not isinstance(shelves, list) or not shelves:
        return {"shelf_count": 0}, [f"{SHELF_INDEX} has no shelves"], warnings

    seen: set[str] = set()
    for shelf in shelves:
        if not isinstance(shelf, dict):
            errors.append("shelf entry is not an object")
            continue
        shelf_id = shelf.get("id")
        if not isinstance(shelf_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,80}", shelf_id):
            errors.append(f"invalid shelf id: {shelf_id!r}")
            continue
        if shelf_id in seen:
            errors.append(f"duplicate shelf id: {shelf_id}")
        seen.add(shelf_id)
        if not shelf.get("keywords"):
            warnings.append(f"shelf has no keywords: {shelf_id}")
        for key in ["read", "scripts"]:
            values = shelf.get(key, [])
            if not isinstance(values, list):
                errors.append(f"shelf {shelf_id} {key} is not a list")
                continue
            for value in values:
                if not isinstance(value, str):
                    errors.append(f"shelf {shelf_id} {key} item is not a string")
                    continue
                target = (root / value).resolve()
                try:
                    target.relative_to(root)
                except ValueError:
                    errors.append(f"shelf {shelf_id} {key} escapes skill root: {value}")
                    continue
                if not target.exists():
                    errors.append(f"shelf {shelf_id} {key} target is missing: {value}")
    default_shelf = parsed.get("default_shelf")
    if default_shelf not in seen:
        errors.append(f"default_shelf is missing from shelves: {default_shelf!r}")

    aliases = parsed.get("aliases", {})
    if aliases is None:
        aliases = {}
    if not isinstance(aliases, dict):
        errors.append("aliases is not an object")
        aliases = {}
    for alias, target in aliases.items():
        if not isinstance(alias, str) or not alias.strip():
            errors.append(f"invalid shelf alias: {alias!r}")
        if target not in seen:
            errors.append(f"shelf alias {alias!r} points to missing shelf: {target!r}")

    deprecated = parsed.get("deprecated_shelves", [])
    if deprecated is None:
        deprecated = []
    if not isinstance(deprecated, list):
        errors.append("deprecated_shelves is not a list")
        deprecated = []
    for shelf_id in deprecated:
        if shelf_id in seen:
            warnings.append(f"deprecated shelf is still active: {shelf_id}")

    return {
        "shelf_count": len(seen),
        "shelf_ids": sorted(seen),
        "default_shelf": default_shelf,
        "alias_count": len(aliases),
        "deprecated_count": len(deprecated),
    }, errors, warnings


def validate_hot_routes(root: Path, shelf_ids: set[str]) -> tuple[dict[str, Any], list[str], list[str]]:
    routes_path = root / HOT_ROUTES
    errors: list[str] = []
    warnings: list[str] = []
    if not routes_path.exists():
        return {"route_count": 0}, [f"missing {HOT_ROUTES}"], warnings

    try:
        parsed = json.loads(routes_path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"route_count": 0}, [f"{HOT_ROUTES} is not valid JSON: {error}"], warnings

    routes = parsed.get("routes")
    if not isinstance(routes, list) or not routes:
        return {"route_count": 0}, [f"{HOT_ROUTES} has no routes"], warnings

    seen: set[str] = set()
    for route in routes:
        if not isinstance(route, dict):
            errors.append("hot route entry is not an object")
            continue
        route_id = route.get("id")
        if not isinstance(route_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,80}", route_id):
            errors.append(f"invalid hot route id: {route_id!r}")
            continue
        if route_id in seen:
            errors.append(f"duplicate hot route id: {route_id}")
        seen.add(route_id)
        shelf = route.get("shelf")
        if shelf not in shelf_ids:
            errors.append(f"hot route {route_id} points to missing shelf: {shelf!r}")
        triggers = route.get("triggers")
        if not isinstance(triggers, list) or not triggers:
            warnings.append(f"hot route has no triggers: {route_id}")
        steps = route.get("steps")
        if not isinstance(steps, list) or not steps:
            errors.append(f"hot route has no steps: {route_id}")
        elif len(steps) > 5:
            warnings.append(f"hot route has more than five steps: {route_id}")
        for key in ["verify", "fallback"]:
            if not isinstance(route.get(key), str) or not route.get(key, "").strip():
                errors.append(f"hot route {route_id} missing {key}")

    return {"route_count": len(seen)}, errors, warnings


def validate_script_catalog(root: Path, shelf_ids: set[str]) -> tuple[dict[str, Any], list[str], list[str]]:
    catalog_path = root / SCRIPT_CATALOG
    errors: list[str] = []
    warnings: list[str] = []
    if not catalog_path.exists():
        return {"script_count": 0, "category_count": 0}, [f"missing {SCRIPT_CATALOG}"], warnings

    try:
        parsed = json.loads(catalog_path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"script_count": 0, "category_count": 0}, [f"{SCRIPT_CATALOG} is not valid JSON: {error}"], warnings

    categories = parsed.get("categories", {})
    if not isinstance(categories, dict) or not categories:
        errors.append(f"{SCRIPT_CATALOG} has no categories")
        categories = {}
    for category_id, category in categories.items():
        if not isinstance(category_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,80}", category_id):
            errors.append(f"invalid script category id: {category_id!r}")
        if not isinstance(category, dict):
            errors.append(f"script category is not an object: {category_id!r}")
            continue
        category_path = category.get("path")
        if not isinstance(category_path, str) or not (root / category_path).exists():
            errors.append(f"script category path is missing: {category_id!r} -> {category_path!r}")

    scripts = parsed.get("scripts", [])
    if not isinstance(scripts, list) or not scripts:
        errors.append(f"{SCRIPT_CATALOG} has no scripts")
        scripts = []

    seen: set[str] = set()
    cataloged_paths: set[str] = set()
    for script in scripts:
        if not isinstance(script, dict):
            errors.append("script catalog entry is not an object")
            continue
        script_id = script.get("id")
        if not isinstance(script_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,100}", script_id):
            errors.append(f"invalid script id: {script_id!r}")
            continue
        if script_id in seen:
            errors.append(f"duplicate script id: {script_id}")
        seen.add(script_id)
        category_id = script.get("category")
        if category_id not in categories:
            errors.append(f"script {script_id} points to missing category: {category_id!r}")
        shelf = script.get("shelf")
        if shelf and shelf not in shelf_ids:
            errors.append(f"script {script_id} points to missing shelf: {shelf!r}")
        path_value = script.get("path")
        if not isinstance(path_value, str):
            errors.append(f"script {script_id} path is not a string")
            continue
        cataloged_paths.add(path_value.replace("\\", "/"))
        path = (root / path_value).resolve()
        try:
            path.relative_to(root)
        except ValueError:
            errors.append(f"script {script_id} path escapes skill root: {path_value}")
            continue
        if not path.exists():
            errors.append(f"script {script_id} path is missing: {path_value}")
        if not isinstance(script.get("purpose"), str) or not script.get("purpose", "").strip():
            warnings.append(f"script {script_id} has no purpose")
        command = script.get("command")
        if not isinstance(command, str) or not command.strip():
            warnings.append(f"script {script_id} has no command")
        else:
            for reference in re.findall(r"scripts[\\/][^\s\"']+\.(?:py|ps1|cmd|bat|sh)", command):
                command_target = (root / reference.replace("\\", "/")).resolve()
                try:
                    command_target.relative_to(root)
                except ValueError:
                    errors.append(f"script {script_id} command reference escapes skill root: {reference}")
                    continue
                if not command_target.exists():
                    errors.append(f"script {script_id} command references missing path: {reference}")

    executable_suffixes = {".py", ".ps1", ".cmd", ".bat", ".sh"}
    for path in sorted((root / "scripts").rglob("*")):
        if not path.is_file() or path.suffix.lower() not in executable_suffixes:
            continue
        relative = path.relative_to(root).as_posix()
        if relative.startswith("scripts/lib/"):
            continue
        if relative not in cataloged_paths:
            errors.append(f"script is missing from catalog: {relative}")

    return {"script_count": len(seen), "category_count": len(categories)}, errors, warnings


def find_generated_files(root: Path) -> list[str]:
    found: list[str] = []
    for item in root.rglob("*"):
        if ".git" in item.parts:
            continue
        if any(part in LOCAL_STATE_DIRS for part in item.parts):
            continue
        if any(part in GENERATED_DIRS for part in item.parts):
            found.append(str(item.relative_to(root)))
            continue
        if item.is_file() and item.suffix in GENERATED_PATTERNS:
            found.append(str(item.relative_to(root)))
    return sorted(set(found))


def parse_maintenance_counts(report: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for line in report.splitlines():
        if not line.startswith("- "):
            continue
        if ": `" not in line:
            continue
        label, raw_value = line[2:].split(": `", 1)
        value = raw_value.split("`", 1)[0]
        try:
            counts[label] = int(value)
        except ValueError:
            continue
    return counts


def powershell_executable() -> str | None:
    return shutil.which("pwsh") or shutil.which("powershell")


def check_powershell_scripts(root: Path) -> tuple[list[str], list[str]]:
    executable = powershell_executable()
    if not executable:
        return [], ["PowerShell parser unavailable; skipped .ps1 syntax checks"]

    errors: list[str] = []
    script = (
        "$path = [Environment]::GetEnvironmentVariable('UISO_PARSE_FILE'); "
        "$tokens=$null; $errors=$null; "
        "[System.Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$errors) | Out-Null; "
        "if ($errors.Count -gt 0) { $errors | ForEach-Object { $_.Message }; exit 1 }"
    )
    for file_path in sorted((root / "scripts").rglob("*.ps1")):
        env = {**os.environ, "UISO_PARSE_FILE": str(file_path)}
        result = subprocess.run(
            [executable, "-NoProfile", "-NonInteractive", "-Command", script],
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        if result.returncode != 0:
            detail = (result.stdout or result.stderr).strip().replace("\n", "; ")
            errors.append(f"{file_path.relative_to(root)}: {detail or 'parse failed'}")
    return errors, []


def compare_copy(source_hash: str, copy_root: Path) -> dict[str, Any]:
    if not copy_root.exists():
        return {"path": str(copy_root), "exists": False, "matches": False, "hash": ""}
    copy_hash = hash_skill(copy_root)
    return {
        "path": str(copy_root),
        "exists": True,
        "matches": copy_hash == source_hash,
        "hash": copy_hash,
    }


def validate_required_copies(source_hash: str, copy_roots: list[str]) -> tuple[list[dict[str, Any]], list[str]]:
    copies: list[dict[str, Any]] = []
    errors: list[str] = []
    seen: set[str] = set()
    for raw_path in copy_roots:
        if not str(raw_path).strip():
            continue
        copy_root = Path(raw_path).expanduser().resolve()
        key = str(copy_root).casefold()
        if key in seen:
            continue
        seen.add(key)
        copy_report = compare_copy(source_hash, copy_root)
        copies.append(copy_report)
        if not copy_report["exists"]:
            errors.append(f"required skill copy is missing: {copy_root}")
        elif not copy_report["matches"]:
            errors.append(f"required skill copy differs from canonical source: {copy_root}")
    return copies, errors


def build_health(skip_powershell: bool, copy_roots: list[str] | None = None) -> dict[str, Any]:
    root = skill_root()
    source_hash = hash_skill(root)
    metadata = read_json(root / METADATA_FILE) or {}
    skill_description = read_skill_description(root)
    notes_file = root / "references" / "field-notes.md"
    maintenance_report, _action_count = build_report(notes_file, stale_days=120)
    maintenance_counts = parse_maintenance_counts(maintenance_report)
    learning = learning_review.run(
        argparse.Namespace(
            memory_dir=str(root / ".skill-memory"),
            notes_file=str(notes_file),
            profile_store="",
            limit=5,
            branch_review_days=30,
            strict=False,
            json=True,
        )
    )
    generated_files = find_generated_files(root)
    shelf_index, shelf_errors, shelf_warnings = validate_shelf_index(root)
    hot_routes, hot_errors, hot_warnings = validate_hot_routes(root, set(shelf_index.get("shelf_ids", [])))
    script_catalog, script_errors, script_warnings = validate_script_catalog(root, set(shelf_index.get("shelf_ids", [])))

    errors: list[str] = []
    warnings: list[str] = []

    for label in ["Malformed note lines", "Orphan note fragments", "Duplicate signatures"]:
        if maintenance_counts.get(label, 0):
            errors.append(f"field-notes has {maintenance_counts[label]} {label.lower()}")

    for label in ["Missing `env:`", "Missing `scope:` or `evidence:`", "Stale `unclear` older than 120 days"]:
        if maintenance_counts.get(label, 0):
            warnings.append(f"field-notes has {maintenance_counts[label]} {label.lower()}")

    if generated_files:
        warnings.append(f"generated files are present in the skill tree: {', '.join(generated_files[:5])}")

    if len(skill_description) > SKILL_DESCRIPTION_LIMIT:
        errors.append(
            f"SKILL.md description is {len(skill_description)} characters; Codex CLI limit is {SKILL_DESCRIPTION_LIMIT}"
        )
    errors.extend(validate_skill_links(root))
    if learning.get("errors"):
        errors.extend(f"learning review: {item}" for item in learning["errors"])
    errors.extend(shelf_errors)
    errors.extend(hot_errors)
    errors.extend(script_errors)
    warnings.extend(shelf_warnings)
    warnings.extend(hot_warnings)
    warnings.extend(script_warnings)

    metadata_hash = metadata.get("appliedHash")
    if isinstance(metadata_hash, str) and metadata_hash and metadata_hash != source_hash:
        warnings.append("canonical metadata hash does not match current skill contents; run sync after edits")

    workspace = workspace_root(root)
    if workspace is not None:
        bundle_root = workspace / "apps" / "agent" / "bundled-core" / "machine-skills" / "universal-install-ops"
        bundled = compare_copy(source_hash, bundle_root)
    else:
        bundled = {"path": "", "exists": False, "matches": True, "hash": "", "checked": False}
    if bundled["exists"] and not bundled["matches"]:
        warnings.append("bundled agent skill copy differs from canonical source")

    codex_home = os.environ.get("CODEX_HOME") or os.environ.get("PANEL_CODEX_HOME") or str(Path.home() / ".codex")
    local_copy = None
    if codex_home:
        local_copy = compare_copy(source_hash, Path(codex_home).expanduser() / "skills" / "universal-install-ops")
        if local_copy["exists"] and not local_copy["matches"]:
            warnings.append("installed Codex skill copy differs from canonical source")

    checked_copies, copy_errors = validate_required_copies(source_hash, copy_roots or [])
    errors.extend(copy_errors)

    ps_errors: list[str] = []
    ps_warnings: list[str] = []
    if not skip_powershell:
        ps_errors, ps_warnings = check_powershell_scripts(root)
        errors.extend(ps_errors)
        warnings.extend(ps_warnings)

    return {
        "skill_root": str(root),
        "source_hash": source_hash,
        "skill_description_length": len(skill_description),
        "skill_description_limit": SKILL_DESCRIPTION_LIMIT,
        "metadata_hash": metadata_hash if isinstance(metadata_hash, str) else "",
        "metadata_matches_source": metadata_hash == source_hash,
        "maintenance": maintenance_counts,
        "learning_review": {
            "counts": learning.get("counts", {}),
            "action_required": learning.get("action_required", False),
            "review_action_count": len(learning.get("review_actions", [])),
        },
        "shelf_index": shelf_index,
        "hot_routes": hot_routes,
        "script_catalog": script_catalog,
        "generated_files": generated_files,
        "bundled_copy": bundled,
        "local_codex_copy": local_copy,
        "checked_copies": checked_copies,
        "powershell_parse_errors": ps_errors,
        "errors": errors,
        "warnings": warnings,
        "ok": not errors,
    }


def print_text(health: dict[str, Any]) -> None:
    print("Universal Install Ops Health")
    print(f"- skill_root: {health['skill_root']}")
    print(f"- source_hash: {health['source_hash']}")
    print(f"- skill_description_length: {health['skill_description_length']}/{health['skill_description_limit']}")
    print(f"- shelf_count: {health['shelf_index'].get('shelf_count', 0)}")
    print(f"- hot_route_count: {health['hot_routes'].get('route_count', 0)}")
    print(f"- script_count: {health['script_catalog'].get('script_count', 0)}")
    print(f"- metadata_matches_source: {health['metadata_matches_source']}")
    print(f"- bundled_copy_matches: {health['bundled_copy'].get('matches')}")
    if health.get("local_codex_copy") is not None:
        print(f"- local_codex_copy_matches: {health['local_codex_copy'].get('matches')}")
    if health.get("checked_copies"):
        print("- checked_copies:")
        for copy in health["checked_copies"]:
            print(f"  - {copy['path']}: matches={copy.get('matches')} exists={copy.get('exists')}")
    print("- maintenance:")
    for key, value in health["maintenance"].items():
        print(f"  - {key}: {value}")
    print("- learning_review:")
    print(f"  - action_required: {health['learning_review'].get('action_required')}")
    print(f"  - review_action_count: {health['learning_review'].get('review_action_count')}")
    print("- errors:")
    if health["errors"]:
        for item in health["errors"]:
            print(f"  - {item}")
    else:
        print("  - none")
    print("- warnings:")
    if health["warnings"]:
        for item in health["warnings"]:
            print(f"  - {item}")
    else:
        print("  - none")


def main() -> int:
    args = parse_args()
    health = build_health(skip_powershell=args.skip_powershell, copy_roots=args.copy_root)
    if args.json:
        print(json.dumps(health, indent=2))
    else:
        print_text(health)
    if health["errors"]:
        return 1
    if args.strict and health["warnings"]:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
