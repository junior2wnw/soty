from __future__ import annotations

import json
import sys

sys.dont_write_bytecode = True


def main() -> int:
    report = {
        "ok": False,
        "removed": True,
        "reason": "package-file merging between skill copies was removed to prevent accidental cross-copy overwrites",
        "safe_path": [
            "Use sync_doctor.py for read-only drift diagnostics.",
            "Port reviewed package changes into the canonical skill tree with an explicit patch.",
            "Merge only .skill-memory queues with merge_skill_memory.py.",
            "Run sync_skill_copy.py after proof; use --force-canonical only for a reviewed divergent copy with backup.",
        ],
    }
    if "--json" in sys.argv:
        print(json.dumps(report, indent=2))
    else:
        print("Skill package merge is removed.")
        print("- reason: package-file merging between skill copies can overwrite reviewed behavior accidentally")
        print("- safe path: sync_doctor.py -> explicit patch in canonical source -> merge_skill_memory.py if needed -> sync_skill_copy.py")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
