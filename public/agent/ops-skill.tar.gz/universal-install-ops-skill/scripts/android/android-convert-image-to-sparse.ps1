param(
  [Parameter(Mandatory = $true)]
  [string]$InputImage,
  [string]$OutputImage = "",
  [string]$Img2SimgPath = ""
)

$ErrorActionPreference = "Stop"

function Resolve-NormalizedPath {
  param([string]$PathValue)

  return (Resolve-Path -LiteralPath $PathValue).Path
}

function Convert-ToWslPath {
  param([string]$WindowsPath)

  if ($WindowsPath -notmatch "^[A-Za-z]:\\") {
    throw "WSL conversion currently supports drive-letter paths only: $WindowsPath"
  }

  $drive = $WindowsPath.Substring(0, 1).ToLowerInvariant()
  $rest = $WindowsPath.Substring(2).Replace("\", "/")
  return "/mnt/$drive$rest"
}

function Get-DefaultOutputPath {
  param([string]$ResolvedInputPath)

  $directory = Split-Path -Parent $ResolvedInputPath
  $name = [System.IO.Path]::GetFileNameWithoutExtension($ResolvedInputPath)
  $extension = [System.IO.Path]::GetExtension($ResolvedInputPath)
  return Join-Path $directory "$name.sparse$extension"
}

$resolvedInput = Resolve-NormalizedPath -PathValue $InputImage
if (-not $OutputImage) {
  $OutputImage = Get-DefaultOutputPath -ResolvedInputPath $resolvedInput
}

$resolvedOutput = [System.IO.Path]::GetFullPath($OutputImage)
$outputDirectory = Split-Path -Parent $resolvedOutput
if (-not (Test-Path -LiteralPath $outputDirectory)) {
  New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null
}

if ($Img2SimgPath) {
  $resolvedImg2Simg = Resolve-NormalizedPath -PathValue $Img2SimgPath
  & $resolvedImg2Simg $resolvedInput $resolvedOutput
} else {
  $localImg2Simg = Get-Command img2simg.exe,img2simg -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($localImg2Simg) {
    & $localImg2Simg.Source $resolvedInput $resolvedOutput
  } else {
    $wsl = Get-Command wsl.exe -ErrorAction SilentlyContinue
    if (-not $wsl) {
      throw "img2simg was not found locally and WSL is unavailable."
    }

    $wslInput = Convert-ToWslPath -WindowsPath $resolvedInput
    $wslOutput = Convert-ToWslPath -WindowsPath $resolvedOutput
    & $wsl.Source bash -lc "command -v img2simg >/dev/null 2>&1 && img2simg '$wslInput' '$wslOutput'"
  }
}

if (-not (Test-Path -LiteralPath $resolvedOutput)) {
  throw "Sparse output was not created: $resolvedOutput"
}

$result = Get-Item -LiteralPath $resolvedOutput
Write-Output "sparse_image=$($result.FullName)"
Write-Output "size_bytes=$($result.Length)"
