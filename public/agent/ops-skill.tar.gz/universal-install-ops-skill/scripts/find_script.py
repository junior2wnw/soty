from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
from skill_paths import skill_root

WORD_CHARS = r"0-9A-Za-zА-Яа-яЁё._+-"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Find the smallest script entry point for a task.")
    parser.add_argument("query", help="Task summary, desired action, or user wording.")
    parser.add_argument("--shelf", default="", help="Optional shelf filter.")
    parser.add_argument("--category", default="", help="Optional script category filter.")
    parser.add_argument("--top", type=int, default=3, help="Number of scripts to print.")
    parser.add_argument("--min-score", type=int, default=8, help="Minimum score for default results.")
    parser.add_argument("--show-zero", action="store_true", help="Show zero-score catalog entries.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser.parse_args()


def catalog_path() -> Path:
    return skill_root(__file__) / "scripts" / "catalog.json"


def tokens(value: str) -> set[str]:
    return {
        part
        for part in re.split(rf"[^{WORD_CHARS}]+", value.lower())
        if len(part) >= 2
    }


def phrase_in_query(phrase: str, query: str) -> bool:
    if not phrase:
        return False
    pattern = rf"(?<![{WORD_CHARS}]){re.escape(phrase)}(?![{WORD_CHARS}])"
    return re.search(pattern, query, flags=re.IGNORECASE) is not None


def load_catalog() -> dict[str, Any]:
    return json.loads(catalog_path().read_text(encoding="utf-8"))


def score_script(query: str, query_tokens: set[str], script: dict[str, Any]) -> int:
    score = 0
    trigger_texts = [str(item).lower() for item in script.get("triggers", [])]
    fields = [
        str(script.get("id", "")),
        str(script.get("category", "")),
        str(script.get("shelf", "")),
        str(script.get("purpose", "")),
        str(script.get("path", "")),
        " ".join(trigger_texts),
    ]
    haystack = " ".join(fields).lower()
    matched_trigger_tokens: set[str] = set()
    for trigger in trigger_texts:
        trigger_tokens = tokens(trigger)
        if phrase_in_query(trigger, query):
            score += 10 + len(trigger_tokens)
            continue
        overlap = query_tokens & trigger_tokens
        if overlap:
            matched_trigger_tokens.update(overlap)
    score += 3 * len(matched_trigger_tokens)
    for token in query_tokens:
        if token in haystack:
            score += 1
    return score


def quote_path(path: Path) -> str:
    return f'"{path}"'


def compact(value: str) -> str:
    return " ".join(value.strip().split())


def quote_argument(value: str) -> str:
    value = compact(value)
    if not value:
        return '""'
    if "'" not in value:
        return f"'{value}'"
    return f'"{value.replace("`", "``").replace(chr(34), "`" + chr(34))}"'


def render_placeholders(command: str, query: str) -> str:
    if not query.strip():
        return command
    quoted = quote_argument(query)
    raw = compact(query)
    for placeholder in ["<task>", "<query>"]:
        command = command.replace(f'"{placeholder}"', quoted)
        command = command.replace(f"'{placeholder}'", quoted)
        command = command.replace(placeholder, raw)
    return command


def absolute_command(root: Path, script: dict[str, Any], query: str = "") -> str:
    command = str(script.get("command", "")).strip()
    path_value = str(script.get("path", "")).strip()
    if not command or not path_value:
        return render_placeholders(command, query)

    absolute = quote_path((root / path_value).resolve())
    windows_path = path_value.replace("/", "\\")
    variants = [f'"{path_value}"', f"'{path_value}'", f'"{windows_path}"', f"'{windows_path}'", path_value, windows_path]
    for variant in variants:
        if variant in command:
            command = command.replace(variant, absolute, 1)
            break
    return render_placeholders(command, query)


def enrich_script(root: Path, script: dict[str, Any], query: str = "") -> dict[str, Any]:
    item = dict(script)
    path_value = str(item.get("path", "")).strip()
    absolute_path = (root / path_value).resolve() if path_value else root
    item["run_from"] = str(root)
    item["absolute_path"] = str(absolute_path)
    item["run"] = absolute_command(root, item, query)
    return item


def rank_scripts(
    query: str,
    catalog: dict[str, Any],
    shelf: str = "",
    category: str = "",
    top: int = 3,
    min_score: int = 8,
    show_zero: bool = False,
) -> list[dict[str, Any]]:
    root = skill_root(__file__)
    query_tokens = tokens(query)
    shelf = shelf.strip()
    category = category.strip()
    scored: list[dict[str, Any]] = []
    for script in catalog.get("scripts", []):
        if not isinstance(script, dict):
            continue
        if shelf and script.get("shelf") != shelf:
            continue
        if category and script.get("category") != category:
            continue
        item = enrich_script(root, script, query)
        item["score"] = score_script(query, query_tokens, script)
        scored.append(item)
    scored.sort(key=lambda item: (-int(item.get("score", 0)), str(item.get("id", ""))))
    if not show_zero:
        scored = [item for item in scored if int(item.get("score", 0)) >= min_score]
    return scored[: max(1, top)]


def print_text(query: str, result: list[dict[str, Any]]) -> None:
    print(f"query: {query}")
    if not result:
        print("- no scripts matched")
        return
    for item in result:
        print(f"- {item['id']} score={item['score']} category={item.get('category', '')} shelf={item.get('shelf', '')}")
        print(f"  path: {item.get('path', '')}")
        print(f"  absolute_path: {item.get('absolute_path', '')}")
        print(f"  run_from: {item.get('run_from', '')}")
        print(f"  run: {item.get('run', '')}")
        print(f"  command_from_skill_root: {item.get('command', '')}")
        print(f"  purpose: {item.get('purpose', '')}")


def main() -> int:
    args = parse_args()
    catalog = load_catalog()
    result = rank_scripts(
        args.query,
        catalog,
        shelf=args.shelf,
        category=args.category,
        top=args.top,
        min_score=args.min_score,
        show_zero=args.show_zero,
    )
    if args.json:
        print(json.dumps({"query": args.query, "scripts": result}, indent=2, ensure_ascii=False))
    else:
        print_text(args.query, result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
