param(
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string] $RunLabel = "",
  [switch] $IncludeUserFiles = $true,
  [string] $ArchivePath = ""
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Copy-Tree([string] $Source, [string] $Destination) {
  if ([string]::IsNullOrWhiteSpace($Source) -or -not (Test-Path -LiteralPath $Source)) {
    return
  }
  New-Dir $Destination
  & robocopy.exe $Source $Destination /E /FFT /R:1 /W:1 /XJ /COPY:DAT /DCOPY:DAT /NFL /NDL /NJH /NJS /NP | Out-Null
  if ($LASTEXITCODE -ge 8) {
    throw ("robocopy failed for " + $Source + " -> " + $Destination + " with exit code " + $LASTEXITCODE)
  }
}

function Resolve-ProfileRecords {
  $skipNames = @("Public", "Default", "Default User", "All Users")
  $profilesByPath = @{}
  try {
    foreach ($profile in @(Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue)) {
      if ($profile -and $profile.LocalPath) {
        $profilesByPath[[string]$profile.LocalPath] = $profile
      }
    }
  } catch {}
  $records = @()
  foreach ($entry in @(Get-ChildItem C:\Users -Directory -ErrorAction SilentlyContinue)) {
    if ($skipNames -contains $entry.Name) {
      continue
    }
    $matchedProfile = if ($profilesByPath.ContainsKey($entry.FullName)) { $profilesByPath[$entry.FullName] } else { $null }
    $records += [pscustomobject]@{
      Name = $entry.Name
      FullName = $entry.FullName
      Sid = if ($matchedProfile -and $matchedProfile.SID) { [string]$matchedProfile.SID } else { $null }
    }
  }
  return $records
}

function Get-LeafUserName([string] $Identity) {
  if ([string]::IsNullOrWhiteSpace($Identity)) {
    return $null
  }
  $leaf = [string]$Identity
  if ($leaf.Contains("\")) {
    $leaf = $leaf.Split("\")[-1]
  }
  if ($leaf.Contains("/")) {
    $leaf = $leaf.Split("/")[-1]
  }
  return $leaf.Trim()
}

function Resolve-PrincipalSid([string] $UserName, [string] $UserSid = "") {
  if (-not [string]::IsNullOrWhiteSpace($UserSid)) {
    return $UserSid.TrimStart("*")
  }
  if ([string]::IsNullOrWhiteSpace($UserName)) {
    return $null
  }
  try {
    return ([System.Security.Principal.NTAccount]$UserName).Translate([System.Security.Principal.SecurityIdentifier]).Value
  } catch {}
  try {
    $account = Get-CimInstance Win32_UserAccount -ErrorAction SilentlyContinue |
      Where-Object { $_.LocalAccount -and [string]$_.Name -eq $UserName } |
      Select-Object -First 1
    if ($account -and $account.SID) {
      return [string]$account.SID
    }
  } catch {}
  return $null
}

function Test-LocalAdministratorMember([string] $UserName, [string] $UserSid = "") {
  $principalSid = Resolve-PrincipalSid -UserName $UserName -UserSid $UserSid
  if ([string]::IsNullOrWhiteSpace($principalSid)) { return $false }
  $principalPattern = 'SID="' + [regex]::Escape($principalSid) + '"'
  try {
    foreach ($membership in @(Get-CimInstance Win32_GroupUser -ErrorAction SilentlyContinue)) {
      $groupComponent = [string]$membership.GroupComponent
      $partComponent = [string]$membership.PartComponent
      if ($groupComponent -match 'SID="S-1-5-32-544"' -and $partComponent -match $principalPattern) {
        return $true
      }
    }
  } catch {}
  return $false
}

function Export-WifiProfiles([string] $Destination) {
  New-Dir $Destination
  try {
    & netsh.exe wlan export profile key=clear folder="$Destination" | Out-Null
  } catch {
    Log ("WARN wifi export failed: " + $_.Exception.Message)
  }
}

function Export-Drivers([string] $Destination) {
  New-Dir $Destination
  try {
    & dism.exe /online /export-driver "/destination:$Destination" | Out-Null
    if ($LASTEXITCODE -ne 0) {
      Log ("WARN driver export exited with code " + $LASTEXITCODE)
    }
  } catch {
    Log ("WARN driver export failed: " + $_.Exception.Message)
  }
}

function Capture-CommandOutput([string] $LiteralPath, [scriptblock] $Block) {
  try {
    $result = & $Block 2>&1 | Out-String
    Set-Content -LiteralPath $LiteralPath -Value $result -Encoding UTF8
  } catch {
    Set-Content -LiteralPath $LiteralPath -Value $_.Exception.ToString() -Encoding UTF8
  }
}

$RunId = Get-Date -Format "yyyyMMdd-HHmmss"
$RunSlug = if ([string]::IsNullOrWhiteSpace($RunLabel)) { $RunId } else { $RunId + "-" + ($RunLabel -replace "[^A-Za-z0-9_-]+", "-") }
$RunRoot = Join-Path $WorkspaceRoot ("stage-bundles\" + $RunSlug)
$BackupRoot = Join-Path $RunRoot "backup"
$ManifestRoot = Join-Path $RunRoot "manifests"
$LogRoot = Join-Path $RunRoot "logs"
$RestoreRoot = Join-Path $RunRoot "restore"
$UserDataRoot = Join-Path $BackupRoot "user-files"
$NetworkRoot = Join-Path $BackupRoot "network"
$WifiRoot = Join-Path $NetworkRoot "wifi"
$DriverRoot = Join-Path $BackupRoot "drivers"
$SshRoot = Join-Path $BackupRoot "ssh"
$ProgramDataSshRoot = Join-Path $SshRoot "programdata_ssh"
$UserSshRoot = Join-Path $SshRoot "user_ssh"
$LegacyUserSshRoot = Join-Path $SshRoot "users"
$AppStateRoot = Join-Path $BackupRoot "app-state"

foreach ($path in @($RunRoot, $BackupRoot, $ManifestRoot, $LogRoot, $RestoreRoot, $UserDataRoot, $NetworkRoot, $WifiRoot, $DriverRoot, $SshRoot, $ProgramDataSshRoot, $UserSshRoot, $LegacyUserSshRoot, $AppStateRoot)) {
  New-Dir $path
}

$script:LogPath = Join-Path $LogRoot "stage.log"
Log ("Stage bundle root: " + $RunRoot)

$currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$currentNtAccount = [string]$currentIdentity.Name
$preferredReturnUserName = Get-LeafUserName $currentNtAccount
$preferredReturnUserSid = if ($currentIdentity.User) { [string]$currentIdentity.User.Value } else { $null }

$profileRecords = Resolve-ProfileRecords
$profileManifest = @()
$sshUsers = @()
$personalFolderNames = @("Desktop", "Documents", "Downloads", "Pictures", "Videos", "Music", "Favorites")

foreach ($profile in @($profileRecords)) {
  $profileItem = [ordered]@{
    user = $profile.Name
    path = $profile.FullName
    sid = $profile.Sid
    isAdministrator = (Test-LocalAdministratorMember -UserName $profile.Name -UserSid $profile.Sid)
    copiedFolders = @()
    sshCopied = $false
  }

  if ($IncludeUserFiles) {
    foreach ($folderName in $personalFolderNames) {
      $sourceFolder = Join-Path $profile.FullName $folderName
      if (-not (Test-Path -LiteralPath $sourceFolder)) {
        continue
      }
      $destinationFolder = Join-Path (Join-Path $UserDataRoot $profile.Name) $folderName
      Log ("Copying user folder " + $sourceFolder)
      Copy-Tree -Source $sourceFolder -Destination $destinationFolder
      $profileItem.copiedFolders += $folderName
    }
  }

  $userSshSource = Join-Path $profile.FullName ".ssh"
  if (Test-Path -LiteralPath $userSshSource) {
    $userSshDestination = Join-Path $UserSshRoot $profile.Name
    $legacyUserSshDestination = Join-Path (Join-Path $LegacyUserSshRoot $profile.Name) ".ssh"
    Log ("Copying user SSH state " + $userSshSource)
    Copy-Tree -Source $userSshSource -Destination $userSshDestination
    Copy-Tree -Source $userSshSource -Destination $legacyUserSshDestination
    $profileItem.sshCopied = $true
    $sshUsers += [pscustomobject]@{
      userName = $profile.Name
      profileDirName = $profile.Name
      sid = $profile.Sid
      archivePath = [string](Join-Path "backup\ssh\user_ssh" $profile.Name)
      legacyArchivePath = [string](Join-Path (Join-Path "backup\ssh\users" $profile.Name) ".ssh")
      authorizedKeysPresent = [bool](Test-Path -LiteralPath (Join-Path $userSshSource "authorized_keys"))
      isLocalAdministrator = [bool](Test-LocalAdministratorMember -UserName $profile.Name -UserSid $profile.Sid)
    }
  }

  $profileManifest += [pscustomobject]$profileItem
}

if (Test-Path -LiteralPath "C:\ProgramData\ssh") {
  Log "Copying ProgramData SSH state"
  Copy-Tree -Source "C:\ProgramData\ssh" -Destination $ProgramDataSshRoot
}

$candidateAppPaths = @(
  (Join-Path $env:LOCALAPPDATA "Soty Agent"),
  (Join-Path $env:APPDATA "@klava"),
  (Join-Path $env:APPDATA "Soty Agent")
)
foreach ($candidate in @($candidateAppPaths | Select-Object -Unique)) {
  if (-not (Test-Path -LiteralPath $candidate)) {
    continue
  }
  $leafName = Split-Path -Leaf $candidate
  $destination = Join-Path $AppStateRoot $leafName
  Log ("Copying app state " + $candidate)
  Copy-Tree -Source $candidate -Destination $destination
}

try {
  $operatorExport = Invoke-RestMethod -Uri "http://127.0.0.1:49424/operator/export" -Headers @{ Origin = "https://xn--n1afe0b.online" } -TimeoutSec 10
  if ($operatorExport.ok -and $operatorExport.text) {
    Set-Content -LiteralPath (Join-Path $AppStateRoot "soty-pwa-operator-export.json") -Value ([string]$operatorExport.text) -Encoding UTF8
    Log "Captured Soty PWA operator export"
  } else {
    Log "WARN Soty PWA operator export did not return payload"
  }
} catch {
  Log ("WARN Soty PWA operator export failed: " + $_.Exception.Message)
}

Export-WifiProfiles -Destination $WifiRoot
Export-Drivers -Destination $DriverRoot

Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "computer-info.txt") -Block { powershell -NoProfile -Command "Get-ComputerInfo | Format-List *" }
Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "volumes.txt") -Block { powershell -NoProfile -Command "Get-Volume | Format-Table -AutoSize" }
Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "disks.txt") -Block { powershell -NoProfile -Command "Get-Disk | Format-Table -AutoSize" }
Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "bitlocker.txt") -Block { powershell -NoProfile -Command "Get-BitLockerVolume | Format-Table -AutoSize" }
Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "reagentc-info.txt") -Block { reagentc /info }
Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "ipconfig-all.txt") -Block { ipconfig /all }
Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "route-print.txt") -Block { route print }
Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "whoami-groups.txt") -Block { whoami /groups }
Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "sshd-service.txt") -Block { powershell -NoProfile -Command "Get-Service sshd | Format-List *" }
Capture-CommandOutput -LiteralPath (Join-Path $ManifestRoot "slmgr-dlv.txt") -Block { cscript.exe //nologo C:\Windows\System32\slmgr.vbs /dlv }

if (Test-Path -LiteralPath (Join-Path $env:SystemRoot "System32\drivers\etc\hosts")) {
  Copy-Item -LiteralPath (Join-Path $env:SystemRoot "System32\drivers\etc\hosts") -Destination (Join-Path $ManifestRoot "hosts") -Force
}

$postInstall = @'
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$logRoot = 'C:\ProgramData\Soty\WindowsReinstall\logs'
New-Item -ItemType Directory -Force -Path $logRoot | Out-Null
$log = Join-Path $logRoot 'postinstall.log'
function Log([string]$Message) { Add-Content -LiteralPath $log -Value ('[' + (Get-Date).ToString('o') + '] ' + $Message) -Encoding UTF8 }
Log 'postinstall started'

try {
  powercfg.exe /change standby-timeout-ac 0 | Out-Null
  powercfg.exe /change standby-timeout-dc 0 | Out-Null
  powercfg.exe /change hibernate-timeout-ac 0 | Out-Null
  powercfg.exe /change hibernate-timeout-dc 0 | Out-Null
  powercfg.exe /change monitor-timeout-ac 0 | Out-Null
  powercfg.exe /change monitor-timeout-dc 0 | Out-Null
  Log 'sleep and display timeouts disabled for restore'
} catch { Log ('powercfg warning: ' + $_.Exception.Message) }

$usbRoot = $null
foreach ($letter in 'D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') {
  $candidate = $letter + ':\Soty-Reinstall'
  if ((Test-Path -LiteralPath (Join-Path $candidate 'backup')) -and (Test-Path -LiteralPath (Join-Path $candidate 'restore'))) {
    $usbRoot = $candidate
    break
  }
}
if (-not $usbRoot) { Log 'USB Soty-Reinstall not found'; exit 1 }
$backupRoot = Join-Path $usbRoot 'backup'
Log ('usbRoot=' + $usbRoot + ' backupRoot=' + $backupRoot)

try {
  Add-Content -LiteralPath 'C:\Windows\System32\drivers\etc\hosts' -Value "`r`n95.105.53.126 xn--n1afe0b.online`r`n" -Encoding ASCII
} catch { Log ('hosts warning: ' + $_.Exception.Message) }

$wifiRoot = Join-Path $backupRoot 'network\wifi'
if (Test-Path -LiteralPath $wifiRoot) {
  Get-ChildItem -LiteralPath $wifiRoot -Filter '*.xml' -File -ErrorAction SilentlyContinue | ForEach-Object {
    Log ('import wifi ' + $_.Name)
    & netsh.exe wlan add profile filename="$($_.FullName)" user=all | Out-Null
  }
}

$driversRoot = Join-Path $backupRoot 'drivers'
if (Test-Path -LiteralPath $driversRoot) {
  Log 'adding exported drivers'
  & pnputil.exe /add-driver "$driversRoot\*.inf" /subdirs /install | Out-File -LiteralPath (Join-Path $logRoot 'pnputil-add-driver.log') -Encoding UTF8
}

try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $dir = Join-Path $env:ProgramData 'Soty\agent-install'
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $installer = Join-Path $dir 'install-windows.ps1'
  Invoke-WebRequest -Uri 'https://xn--n1afe0b.online/agent/install-windows.ps1' -UseBasicParsing -OutFile $installer
  & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $installer -Scope Machine -LaunchAppAtLogon | Out-File -LiteralPath (Join-Path $logRoot 'soty-agent-install.log') -Encoding UTF8
  Log 'soty machine agent install invoked'
} catch { Log ('soty install warning: ' + $_.Exception.ToString()) }

[pscustomobject]@{
  ok = $true
  finishedAt = (Get-Date).ToString('o')
  usbRoot = $usbRoot
  backupRoot = $backupRoot
  rawBrowserStateRestored = $false
} | ConvertTo-Json -Compress | Set-Content -LiteralPath (Join-Path $logRoot 'postinstall-result.json') -Encoding UTF8
Log 'postinstall finished'
'@
Set-Content -LiteralPath (Join-Path $RestoreRoot "postinstall.ps1") -Value $postInstall -Encoding UTF8
Save-Json -Path (Join-Path $RestoreRoot "restore-config.json") -Value ([ordered]@{
  schema = "soty.windows-reinstall.restore.v2"
  rawBrowserStateRestore = $false
  pwaReturn = "clean-repair-or-repair-url"
  createdAt = (Get-Date).ToString("o")
})

$wifiExports = @()
foreach ($item in @(Get-ChildItem -LiteralPath $WifiRoot -File -ErrorAction SilentlyContinue)) {
  $wifiExports += $item.FullName
}

$sshManifest = [ordered]@{
  programDataSshPresent = (Test-Path -LiteralPath "C:\ProgramData\ssh")
  administratorsAuthorizedKeysPresent = (Test-Path -LiteralPath "C:\ProgramData\ssh\administrators_authorized_keys")
  preferredReturnNtAccount = $currentNtAccount
  preferredReturnUserName = $preferredReturnUserName
  preferredReturnUserSid = $preferredReturnUserSid
  users = $sshUsers
  profiles = $profileManifest | Select-Object user, sid, isAdministrator, sshCopied
}

$summary = [ordered]@{
  status = "staged"
  runRoot = $RunRoot
  backupRoot = $BackupRoot
  restoreRoot = $RestoreRoot
  manifestsRoot = $ManifestRoot
  logsRoot = $LogRoot
  includeUserFiles = [bool]$IncludeUserFiles
  userProfiles = $profileManifest
  wifiExports = $wifiExports
  driversRoot = $DriverRoot
  sshManifestPath = (Join-Path $ManifestRoot "ssh-manifest.json")
  createdAt = (Get-Date).ToString("o")
}

Save-Json -Path (Join-Path $ManifestRoot "user-profile-manifest.json") -Value $profileManifest
Save-Json -Path (Join-Path $ManifestRoot "ssh-manifest.json") -Value $sshManifest
Save-Json -Path (Join-Path $RunRoot "stage-result.json") -Value $summary

if (-not [string]::IsNullOrWhiteSpace($ArchivePath)) {
  $archiveParent = Split-Path -Parent $ArchivePath
  if (-not [string]::IsNullOrWhiteSpace($archiveParent)) {
    New-Dir $archiveParent
  }
  if (Test-Path -LiteralPath $ArchivePath) {
    Remove-Item -LiteralPath $ArchivePath -Force
  }
  Log ("Creating archive " + $ArchivePath)
  Compress-Archive -Path (Join-Path $RunRoot "*") -DestinationPath $ArchivePath -CompressionLevel Optimal -Force
  $summary["archivePath"] = $ArchivePath
  Save-Json -Path (Join-Path $RunRoot "stage-result.json") -Value $summary
}

Write-Output ("STAGE_RESULT_JSON=" + (Join-Path $RunRoot "stage-result.json"))
