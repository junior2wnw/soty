param(
  [string] $IsoPath = "",
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string] $StageBundleRoot = "",
  [string] $UsbDriveLetter = "D",
  [string] $UsbLabel = "SOTYWIN",
  [string] $ComputerName = "",
  [string] $ManagedUserName = "Soty",
  [string] $ManagedUserPassword = "",
  [string] $PanelSiteUrl = "https://xn--n1afe0b.online",
  [string] $PanelSiteFallbackIp = "95.105.53.126",
  [string] $PanelSiteFallbackHost = "xn--n1afe0b.online",
  [switch] $AllowTemporaryManagedPassword,
  [switch] $NoTemporaryManagedPassword
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

if ([string]::IsNullOrWhiteSpace($IsoPath)) {
  throw "IsoPath is required."
}

$builderPath = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "windows-build-bootable-usb.ps1"
if (-not (Test-Path -LiteralPath $builderPath)) {
  throw "windows-build-bootable-usb.ps1 is missing next to this launcher."
}
if (-not (Test-Path -LiteralPath $IsoPath)) {
  throw "ISO path not found: $IsoPath"
}

$diskImage = Get-DiskImage -ImagePath $IsoPath -ErrorAction SilentlyContinue
if (-not $diskImage -or -not $diskImage.Attached) {
  Mount-DiskImage -ImagePath $IsoPath | Out-Null
}

$volume = Get-DiskImage -ImagePath $IsoPath | Get-Volume | Select-Object -First 1
if (-not $volume -or -not $volume.DriveLetter) {
  throw "Mounted ISO volume letter was not resolved."
}
$sourceMediaRoot = $volume.DriveLetter + ":\"
Write-Output ("ISO_ROOT=" + $sourceMediaRoot)

& $builderPath `
  -WorkspaceRoot $WorkspaceRoot `
  -StageBundleRoot $StageBundleRoot `
  -UsbDriveLetter $UsbDriveLetter `
  -UsbLabel $UsbLabel `
  -SourceMediaRoot $sourceMediaRoot `
  -ComputerName $ComputerName `
  -ManagedUserName $ManagedUserName `
  -ManagedUserPassword $ManagedUserPassword `
  -PanelSiteUrl $PanelSiteUrl `
  -PanelSiteFallbackIp $PanelSiteFallbackIp `
  -PanelSiteFallbackHost $PanelSiteFallbackHost `
  -AllowTemporaryManagedPassword:$AllowTemporaryManagedPassword `
  -NoTemporaryManagedPassword:$NoTemporaryManagedPassword
