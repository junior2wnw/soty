param(
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string] $LanguageCode = "ru-RU",
  [string] $Edition = "Professional",
  [ValidateSet("x64")]
  [string] $Arch = "x64",
  [string] $MediaCreationToolUrl = "https://go.microsoft.com/fwlink/?linkid=2156295",
  [string] $IsoPath = "",
  [switch] $ForceRedownload
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 10) -Encoding UTF8
}

function Get-Int64Hex([object] $Value) {
  if ($null -eq $Value) {
    return 0
  }
  $text = [string]$Value
  if ([string]::IsNullOrWhiteSpace($text)) {
    return 0
  }
  return [Convert]::ToInt64($text, 16)
}

$RunId = Get-Date -Format "yyyyMMdd-HHmmss"
$RunRoot = Join-Path $WorkspaceRoot ("mct-auto-iso\" + $RunId)
$MediaRoot = Join-Path $WorkspaceRoot "media"
$LogRoot = Join-Path $RunRoot "logs"
$MctRoot = Join-Path $WorkspaceRoot "mct"
$StateRoot = 'C:\$WINDOWS.~WS\Sources\Panther'
$StatePath = Join-Path $StateRoot "windlp.state.xml"
$MctExe = Join-Path $MctRoot "MediaCreationTool.exe"
$CurrentSessionId = [System.Diagnostics.Process]::GetCurrentProcess().SessionId

foreach ($path in @($RunRoot, $MediaRoot, $LogRoot, $MctRoot)) {
  New-Dir $path
}

if ([string]::IsNullOrWhiteSpace($IsoPath)) {
  $IsoPath = Join-Path $MediaRoot ("Windows10-current-" + $LanguageCode + "-" + $Arch + ".iso")
}

$LogPath = Join-Path $LogRoot "mct-auto-iso.log"
function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Get-XmlValue([xml] $Xml, [string] $TaskName, [string] $ActionName, [string] $PropertyName) {
  if ($null -eq $Xml -or $null -eq $Xml.WINDLP) {
    return $null
  }
  foreach ($task in @($Xml.WINDLP.TASK)) {
    if ($task.Name -ne $TaskName) {
      continue
    }
    foreach ($action in @($task.ACTION)) {
      if ($action.ActionName -ne $ActionName) {
        continue
      }
      if ($action.PSObject.Properties.Name -contains $PropertyName) {
        return $action.$PropertyName
      }
    }
  }
  return $null
}

function Wait-ForSetupHost {
  param(
    [System.Diagnostics.Process] $Process,
    [int] $TimeoutSeconds = 180
  )

  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  while ((Get-Date) -lt $deadline) {
    try { $Process.Refresh() } catch {}
    if ($Process.HasExited) {
      break
    }
    $setupHost = Get-Process -Name SetupHost -ErrorAction SilentlyContinue |
      Where-Object { $_.SessionId -eq $CurrentSessionId } |
      Select-Object -First 1
    if ($null -ne $setupHost) {
      $windowHandle = Get-MainWindowHandleValue -Process $setupHost
      while ($windowHandle -le 0 -and -not $Process.HasExited) {
        try { $Process.Refresh() } catch {}
        Start-Sleep -Milliseconds 200
        $setupHost.Refresh()
        $windowHandle = Get-MainWindowHandleValue -Process $setupHost
      }
      if ($windowHandle -gt 0) {
        return $setupHost
      }
    }
    if ($Process.HasExited) {
      break
    }
    Start-Sleep -Milliseconds 500
  }
  return $null
}

function Get-MainWindowHandleValue([System.Diagnostics.Process] $Process) {
  if ($null -eq $Process) {
    return [int64]0
  }
  try { $Process.Refresh() } catch {}
  $rawValue = $Process.MainWindowHandle
  if ($null -eq $rawValue) {
    return [int64]0
  }
  $text = [string]$rawValue
  if ([string]::IsNullOrWhiteSpace($text)) {
    return [int64]0
  }
  try {
    return [int64]$rawValue
  } catch {
    return [int64]0
  }
}

function Load-UiAutomation {
  $assemblies = @(
    "UIAutomationClientsideProviders",
    "UIAutomationClient",
    "UIAutomationTypes",
    "System.Windows.Forms",
    "Microsoft.VisualBasic"
  )
  $loaded = @()
  foreach ($assembly in $assemblies) {
    $loaded += [Reflection.Assembly]::LoadWithPartialName($assembly)
  }
  try {
    [System.Windows.Automation.ClientSettings]::RegisterClientSideProviderAssembly($loaded[0].GetName())
  } catch {
    [System.Windows.Automation.ClientSettings]::RegisterClientSideProviderAssembly($loaded[0].GetName())
  }
}

function Send-EnterToSetupHost([int] $SetupHostId) {
  [Microsoft.VisualBasic.Interaction]::AppActivate($SetupHostId) | Out-Null
  [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
}

function Complete-IsoSelection {
  param(
    [System.Diagnostics.Process] $Process,
    [System.Diagnostics.Process] $SetupHost,
    [string] $TargetIsoPath
  )

  Load-UiAutomation

  $classNameProperty = [System.Windows.Automation.AutomationElement]::ClassNameProperty
  $buttonCondition = New-Object System.Windows.Automation.PropertyCondition($classNameProperty, "Button")
  $editCondition = New-Object System.Windows.Automation.PropertyCondition($classNameProperty, "Edit")
  $treeScope = [System.Windows.Automation.TreeScope]::Subtree

  $mainWindowHandle = Get-MainWindowHandleValue -Process $SetupHost
  if ($mainWindowHandle -le 0) {
    throw ("SetupHost window handle is not ready in session " + $CurrentSessionId + ".")
  }

  $window = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$mainWindowHandle)
  $baselineButtonCount = $window.FindAll($treeScope, $buttonCondition).Count

  while ($window.FindAll($treeScope, $buttonCondition).Count -le $baselineButtonCount) {
    if ($Process.HasExited) {
      throw "MediaCreationTool exited before media type selection UI became ready."
    }
    Start-Sleep -Milliseconds 250
    $mainWindowHandle = Get-MainWindowHandleValue -Process $SetupHost
    if ($mainWindowHandle -le 0) {
      continue
    }
    $window = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$mainWindowHandle)
  }

  $buttons = $window.FindAll($treeScope, $buttonCondition)
  if ($buttons.Count -lt 2) {
    throw ("Unable to identify the ISO/USB selection buttons in session " + $CurrentSessionId + ".")
  }

  Log "Selecting ISO output mode in Media Creation Tool."
  $buttons[1].GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select()
  $buttons[$buttons.Count - 1].SetFocus()
  Send-EnterToSetupHost -SetupHostId $SetupHost.Id

  while ($window.FindAll($treeScope, $editCondition).Count -le 0) {
    if ($Process.HasExited) {
      throw "MediaCreationTool exited before the ISO save dialog became ready."
    }
    Start-Sleep -Milliseconds 200
    $mainWindowHandle = Get-MainWindowHandleValue -Process $SetupHost
    if ($mainWindowHandle -le 0) {
      continue
    }
    $window = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$mainWindowHandle)
  }

  $edits = $window.FindAll($treeScope, $editCondition)
  $targetEdit = $edits[0]

  New-Dir (Split-Path -Parent $TargetIsoPath)
  Log ("Setting ISO output path to " + $TargetIsoPath)
  [System.Windows.Forms.SendKeys]::SendWait(" ")
  $targetEdit.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue($TargetIsoPath)
  [System.Windows.Forms.SendKeys]::Flush()

  $confirmButtons = $window.FindAll($treeScope, $buttonCondition)
  $confirmButton = $null
  foreach ($button in @($confirmButtons)) {
    if ($button.Current.AutomationId -eq "1") {
      $confirmButton = $button
      break
    }
  }
  if ($null -eq $confirmButton -and $confirmButtons.Count -gt 0) {
    $confirmButton = $confirmButtons[$confirmButtons.Count - 1]
  }
  if ($null -eq $confirmButton) {
    throw "Unable to identify the dialog confirmation button."
  }

  $confirmButton.SetFocus()
  Send-EnterToSetupHost -SetupHostId $SetupHost.Id
}

function Get-LayoutProgress {
  if (-not (Test-Path -LiteralPath $StatePath)) {
    return $null
  }
  try {
    [xml]$xml = Get-Content -LiteralPath $StatePath -Raw
  } catch {
    return $null
  }
  $current = Get-XmlValue -Xml $xml -TaskName "MediaCreate" -ActionName "Layout" -PropertyName "ProgressCurrent"
  $total = Get-XmlValue -Xml $xml -TaskName "MediaCreate" -ActionName "Layout" -PropertyName "ProgressTotal"
  if ($null -eq $current -or $null -eq $total) {
    return $null
  }
  $currentValue = Get-Int64Hex $current
  $totalValue = Get-Int64Hex $total
  $percent = 0
  if ($totalValue -gt 0) {
    $percent = [Math]::Min(100, [Math]::Floor(($currentValue * 100.0) / $totalValue))
  }
  return @{
    current = $currentValue
    total = $totalValue
    percent = [int]$percent
  }
}

function Get-LangIniContent([string] $PreferredLanguageCode) {
  $fallbackLanguage = if ($PreferredLanguageCode -ieq "en-US") { "en-US" } else { "en-US" }
  return @(
    "[Available UI Languages]",
    ($PreferredLanguageCode + " = 3"),
    "",
    "[Fallback Languages]",
    ($PreferredLanguageCode + " = " + $fallbackLanguage)
  )
}

function Ensure-SetupLanguageFiles {
  param(
    [string] $PreferredLanguageCode,
    [System.Diagnostics.Process] $Process,
    [int] $TimeoutSeconds = 30
  )

  $sourcesRoot = Split-Path -Parent $StateRoot
  $langIniPath = Join-Path $sourcesRoot "lang.ini"
  $langpacksRoot = Join-Path (Split-Path -Parent $sourcesRoot) "Langpacks"
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)

  while ((Get-Date) -lt $deadline) {
    if (Test-Path -LiteralPath $sourcesRoot) {
      break
    }
    try { $Process.Refresh() } catch {}
    if ($Process.HasExited) {
      return
    }
    Start-Sleep -Milliseconds 250
  }

  if (-not (Test-Path -LiteralPath $sourcesRoot)) {
    return
  }

  New-Dir $langpacksRoot
  if (-not (Test-Path -LiteralPath $langIniPath)) {
    Log ("Creating fallback lang.ini for Setup at " + $langIniPath + " with UI language " + $PreferredLanguageCode)
    Set-Content -LiteralPath $langIniPath -Value (Get-LangIniContent -PreferredLanguageCode $PreferredLanguageCode) -Encoding ASCII
  }
}

if ($ForceRedownload -and (Test-Path -LiteralPath $MctExe)) {
  Remove-Item -LiteralPath $MctExe -Force
}

if (-not (Test-Path -LiteralPath $MctExe)) {
  Log ("Downloading current Media Creation Tool from " + $MediaCreationToolUrl)
  Invoke-WebRequest -Uri $MediaCreationToolUrl -OutFile $MctExe -UseBasicParsing
}

if (Test-Path -LiteralPath $IsoPath) {
  Log ("Removing previous ISO at " + $IsoPath)
  Remove-Item -LiteralPath $IsoPath -Force
}

$argumentList = @(
  "/Selfhost",
  "/Action", "CreateMedia",
  "/MediaLangCode", $LanguageCode,
  "/MediaEdition", $Edition,
  "/MediaArch", $Arch,
  "/Compat", "IgnoreWarning",
  "/ResizeRecoveryPartition", "Disable",
  "/Telemetry", "Disable",
  "/CompactOS", "Disable",
  "/DynamicUpdate", "Enable",
  "/ShowOOBE", "None",
  "/SkipSummary",
  "/Eula", "Accept"
)

Log ("Starting Media Creation Tool with args: " + ($argumentList -join " "))
$process = Start-Process -FilePath $MctExe -ArgumentList $argumentList -PassThru
Ensure-SetupLanguageFiles -PreferredLanguageCode $LanguageCode -Process $process
$setupHost = $null
$result = $null
$errorPath = Join-Path $RunRoot "error.json"
$errorTextPath = Join-Path $RunRoot "error.txt"

try {
  $setupHost = Wait-ForSetupHost -Process $process
  if ($null -eq $setupHost) {
    $process.Refresh()
    $exitCode = $null
    if ($process.HasExited) {
      $exitCode = $process.ExitCode
    }
    throw ("SetupHost did not become ready in session " + $CurrentSessionId + ". MediaCreationTool exited=" + $process.HasExited + "; exitCode=" + $exitCode)
  }

  Complete-IsoSelection -Process $process -SetupHost $setupHost -TargetIsoPath $IsoPath

  $progressDeadline = (Get-Date).AddHours(2)
  $lastPercent = -1
  while ((Get-Date) -lt $progressDeadline) {
    if (Test-Path -LiteralPath $IsoPath -and $process.HasExited) {
      break
    }
    $progress = Get-LayoutProgress
    if ($null -ne $progress -and $progress.percent -ne $lastPercent) {
      $lastPercent = $progress.percent
      Log ("ISO layout progress: " + $progress.percent + "%")
    }
    Start-Sleep -Seconds 5
    if (-not $process.HasExited) {
      $process.Refresh()
    }
  }

  if (-not (Test-Path -LiteralPath $IsoPath)) {
    throw "ISO was not created before the timeout expired."
  }

  $isoItem = Get-Item -LiteralPath $IsoPath
  $result = @{
    status = "ok"
    runId = $RunId
    isoPath = $IsoPath
    isoSizeBytes = [int64]$isoItem.Length
    mediaCreationToolPath = $MctExe
    statePath = $StatePath
    logPath = $LogPath
    languageCode = $LanguageCode
    edition = $Edition
    arch = $Arch
  }
  Save-Json -Path (Join-Path $RunRoot "result.json") -Value $result
  Write-Output ("MCT_AUTO_ISO_RESULT=" + (Join-Path $RunRoot "result.json"))
  Write-Output ("ISO_PATH=" + $IsoPath)
} catch {
  $failure = @{
    status = "error"
    runId = $RunId
    isoPath = $IsoPath
    mediaCreationToolPath = $MctExe
    statePath = $StatePath
    logPath = $LogPath
    currentSessionId = $CurrentSessionId
    message = $_.Exception.Message
    stack = $_.ScriptStackTrace
    processId = if ($null -ne $process) { $process.Id } else { $null }
    processExited = if ($null -ne $process) { $process.HasExited } else { $null }
    processExitCode = if ($null -ne $process -and $process.HasExited) { $process.ExitCode } else { $null }
  }
  Save-Json -Path $errorPath -Value $failure
  Set-Content -LiteralPath $errorTextPath -Value ($failure | ConvertTo-Json -Depth 10) -Encoding UTF8
  Log ("FAILED: " + $_.Exception.Message)
  throw
} finally {
  if ($null -ne $process -and -not $process.HasExited) {
    try { Stop-Process -Id $process.Id -Force -ErrorAction Stop } catch {}
  }
}
