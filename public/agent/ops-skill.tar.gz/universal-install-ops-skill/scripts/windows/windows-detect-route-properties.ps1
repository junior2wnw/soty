param(
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string] $UsbDriveLetter = "D",
  [string] $OutputPath = ""
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Add-RouteProperty {
  param(
    [System.Collections.ArrayList] $Properties,
    [string] $Name,
    [string] $ObservedValue,
    [string] $Proof,
    [string] $EvidenceQuality = "live-observed"
  )

  [void]$Properties.Add([ordered]@{
    name = $Name
    observedValue = $ObservedValue
    proof = $Proof
    evidenceQuality = $EvidenceQuality
  })
}

function Test-FileSystemLikelySupportsLargeFiles {
  param(
    [string] $FileSystem
  )

  $normalized = ([string]$FileSystem).Trim().ToUpperInvariant()
  if ($normalized -match '^FAT(12|16|32)?$') {
    return $false
  }
  return $true
}

$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$runRoot = Join-Path $WorkspaceRoot ("route-properties\" + $runId)
New-Dir $runRoot
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
  $OutputPath = Join-Path $runRoot "route-properties.json"
}

$properties = [System.Collections.ArrayList]::new()
$normalizedUsbLetter = $UsbDriveLetter.TrimEnd(":").ToUpperInvariant()

try {
  $volume = Get-Volume -DriveLetter $normalizedUsbLetter -ErrorAction Stop
  $fs = [string]$volume.FileSystem
  Add-RouteProperty -Properties $properties -Name "usb.present" -ObservedValue "true" -Proof ("Get-Volume " + $normalizedUsbLetter + ": succeeded")
  Add-RouteProperty -Properties $properties -Name "usb.filesystem" -ObservedValue $fs -Proof ("Get-Volume FileSystem=" + $fs)
  Add-RouteProperty -Properties $properties -Name "usb.supports_large_files" -ObservedValue ([string](Test-FileSystemLikelySupportsLargeFiles -FileSystem $fs)).ToLowerInvariant() -Proof ("filesystem=" + $fs)
  try {
    $driveInfo = [System.IO.DriveInfo]::new($normalizedUsbLetter + ":\")
    Add-RouteProperty -Properties $properties -Name "usb.drive_type" -ObservedValue ([string]$driveInfo.DriveType) -Proof ("DriveInfo.DriveType=" + $driveInfo.DriveType)
  } catch {
    Add-RouteProperty -Properties $properties -Name "usb.drive_type" -ObservedValue "unknown" -Proof $_.Exception.Message -EvidenceQuality "case-observed"
  }
} catch {
  Add-RouteProperty -Properties $properties -Name "usb.present" -ObservedValue "false" -Proof $_.Exception.Message
}

try {
  $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
  Add-RouteProperty -Properties $properties -Name "windows.architecture" -ObservedValue ([string]$os.OSArchitecture) -Proof "Win32_OperatingSystem.OSArchitecture"
  Add-RouteProperty -Properties $properties -Name "windows.caption" -ObservedValue ([string]$os.Caption) -Proof "Win32_OperatingSystem.Caption"
} catch {
  Add-RouteProperty -Properties $properties -Name "windows.architecture" -ObservedValue "unknown" -Proof $_.Exception.Message -EvidenceQuality "case-observed"
}

try {
  $secureBoot = Confirm-SecureBootUEFI -ErrorAction Stop
  Add-RouteProperty -Properties $properties -Name "firmware.secure_boot" -ObservedValue ([string]$secureBoot).ToLowerInvariant() -Proof "Confirm-SecureBootUEFI"
} catch {
  Add-RouteProperty -Properties $properties -Name "firmware.secure_boot" -ObservedValue "unknown" -Proof $_.Exception.Message -EvidenceQuality "case-observed"
}

try {
  $bitlocker = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
  Add-RouteProperty -Properties $properties -Name "windows.bitlocker_protection" -ObservedValue ([string]$bitlocker.ProtectionStatus) -Proof ("Get-BitLockerVolume " + $env:SystemDrive)
} catch {
  Add-RouteProperty -Properties $properties -Name "windows.bitlocker_protection" -ObservedValue "unknown" -Proof $_.Exception.Message -EvidenceQuality "case-observed"
}

try {
  $reagent = & reagentc.exe /info 2>&1
  $text = (($reagent | ForEach-Object { $_.ToString() }) -join " ")
  $textLower = $text.ToLowerInvariant()
  $enabledRuPrefix = -join @([char]0x0432, [char]0x043A, [char]0x043B, [char]0x044E, [char]0x0447)
  $disabledRuPrefix = -join @([char]0x043E, [char]0x0442, [char]0x043A, [char]0x043B, [char]0x044E, [char]0x0447)
  $enabled = if ($textLower -match 'enabled' -or $textLower.Contains($enabledRuPrefix)) { "true" } elseif ($textLower -match 'disabled' -or $textLower.Contains($disabledRuPrefix)) { "false" } else { "unknown" }
  Add-RouteProperty -Properties $properties -Name "windows.winre_enabled" -ObservedValue $enabled -Proof "reagentc /info"
} catch {
  Add-RouteProperty -Properties $properties -Name "windows.winre_enabled" -ObservedValue "unknown" -Proof $_.Exception.Message -EvidenceQuality "case-observed"
}

$result = [ordered]@{
  status = "ok"
  collectedAt = (Get-Date).ToString("o")
  usbDriveLetter = $normalizedUsbLetter
  outputPath = $OutputPath
  properties = $properties
}

Save-Json -Path $OutputPath -Value $result
$result | ConvertTo-Json -Depth 12
