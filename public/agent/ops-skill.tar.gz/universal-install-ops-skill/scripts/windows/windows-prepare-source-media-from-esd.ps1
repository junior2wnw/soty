param(
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string] $EsdUrl = "",
  [string] $ExpectedEsdSha256 = "",
  [string] $EsdFileName = "",
  [string] $SourceMediaRoot = "",
  [string] $InstallImagePattern = "Windows 11 Home$|Windows 11 \u0414\u043e\u043c\u0430\u0448\u043d\u044f\u044f$|Home|\u0414\u043e\u043c\u0430\u0448\u043d\u044f\u044f|Core",
  [string] $SetupImagePattern = "Microsoft Windows (PE|Setup).*amd64|Windows (PE|Setup)",
  [switch] $ForceRedownload
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Invoke-CliStrict {
  param(
    [string] $FilePath,
    [string[]] $ArgumentList,
    [string] $LogPath = ""
  )

  if ([string]::IsNullOrWhiteSpace($LogPath)) {
    & $FilePath @ArgumentList | Out-Null
  } else {
    & $FilePath @ArgumentList 2>&1 | Set-Content -LiteralPath $LogPath -Encoding UTF8
  }
  if ($LASTEXITCODE -ne 0) {
    throw ($FilePath + " failed with exit code " + $LASTEXITCODE)
  }
}

function Get-FileNameFromUrl([string] $Url) {
  try {
    $uri = [Uri]$Url
    $leaf = Split-Path -Leaf $uri.AbsolutePath
    if (-not [string]::IsNullOrWhiteSpace($leaf)) {
      return $leaf
    }
  } catch {}
  return "windows-source.esd"
}

function Set-KeepAwake([bool] $Enable) {
  try {
    Add-Type -Namespace Native -Name Power -MemberDefinition '[System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError=true)] public static extern uint SetThreadExecutionState(uint esFlags);' -ErrorAction SilentlyContinue
    if ($Enable) {
      [void][Native.Power]::SetThreadExecutionState(0x80000000 -bor 0x00000001 -bor 0x00000002)
    } else {
      [void][Native.Power]::SetThreadExecutionState(0x80000000)
    }
  } catch {}
}

if ([string]::IsNullOrWhiteSpace($EsdUrl)) {
  throw "EsdUrl is required."
}
if ([string]::IsNullOrWhiteSpace($ExpectedEsdSha256)) {
  throw "ExpectedEsdSha256 is required."
}

$mediaRoot = Join-Path $WorkspaceRoot "media"
$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$runRoot = Join-Path $WorkspaceRoot ("source-media-runs\" + $runId)
$logRoot = Join-Path $runRoot "logs"
foreach ($path in @($WorkspaceRoot, $mediaRoot, $runRoot, $logRoot)) {
  New-Dir $path
}
$script:LogPath = Join-Path $logRoot "prepare-source-media.log"

if ([string]::IsNullOrWhiteSpace($EsdFileName)) {
  $EsdFileName = Get-FileNameFromUrl -Url $EsdUrl
}
if ([string]::IsNullOrWhiteSpace($SourceMediaRoot)) {
  $SourceMediaRoot = Join-Path $WorkspaceRoot ("source-media\" + ($EsdFileName -replace "\.esd$", ""))
}

$sourcesRoot = Join-Path $SourceMediaRoot "sources"
New-Dir $sourcesRoot
$esdPath = Join-Path $mediaRoot $EsdFileName
$expectedHash = $ExpectedEsdSha256.Trim().ToLowerInvariant()

Set-KeepAwake -Enable $true
try {
  if ($ForceRedownload -and (Test-Path -LiteralPath $esdPath)) {
    Log ("Removing existing ESD because ForceRedownload was requested: " + $esdPath)
    Remove-Item -LiteralPath $esdPath -Force
  }

  $needDownload = $true
  if (Test-Path -LiteralPath $esdPath) {
    $existingHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $esdPath).Hash.ToLowerInvariant()
    if ($existingHash -eq $expectedHash) {
      Log "Existing ESD hash is valid; skipping download."
      $needDownload = $false
    } else {
      Log ("Existing ESD hash mismatch; redownloading. actual=" + $existingHash)
      Remove-Item -LiteralPath $esdPath -Force
    }
  }

  if ($needDownload) {
    $curlLog = Join-Path $logRoot "curl-download.log"
    Log ("Downloading ESD to " + $esdPath)
    Invoke-CliStrict -FilePath "curl.exe" -ArgumentList @(
      "-L",
      "--fail",
      "--retry", "8",
      "--retry-delay", "10",
      "--continue-at", "-",
      "--output", $esdPath,
      $EsdUrl
    ) -LogPath $curlLog

    $actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $esdPath).Hash.ToLowerInvariant()
    if ($actualHash -ne $expectedHash) {
      throw ("ESD SHA256 mismatch. expected=" + $expectedHash + " actual=" + $actualHash)
    }
    Log "ESD SHA256 verified."
  }

  Log "Inspecting ESD images."
  $images = @(Get-WindowsImage -ImagePath $esdPath -ErrorAction Stop)
  $setupImage = $images | Where-Object { ([string]$_.ImageName) -match $SetupImagePattern } | Select-Object -First 1
  if (-not $setupImage) {
    throw ("No setup boot image matched pattern: " + $SetupImagePattern)
  }
  $installCandidates = $images | Where-Object { ([string]$_.ImageName) -notmatch "Windows (PE|Setup)|Setup Media" }
  $installImage = $installCandidates | Where-Object { ([string]$_.ImageName) -match $InstallImagePattern } | Select-Object -First 1
  if (-not $installImage) {
    $imageSummary = ($installCandidates | ForEach-Object { $_.ImageIndex.ToString() + ":" + $_.ImageName }) -join "; "
    throw ("No install image matched pattern '" + $InstallImagePattern + "'. Images: " + $imageSummary)
  }

  $bootWimPath = Join-Path $sourcesRoot "boot.wim"
  $installWimPath = Join-Path $sourcesRoot "install.wim"
  foreach ($path in @($bootWimPath, $installWimPath)) {
    if (Test-Path -LiteralPath $path) {
      Remove-Item -LiteralPath $path -Force
    }
  }

  Log ("Exporting setup image index " + $setupImage.ImageIndex + " => " + $setupImage.ImageName)
  Invoke-CliStrict -FilePath "dism.exe" -ArgumentList @(
    "/Export-Image",
    "/SourceImageFile:$esdPath",
    "/SourceIndex:$($setupImage.ImageIndex)",
    "/DestinationImageFile:$bootWimPath",
    "/Compress:max",
    "/CheckIntegrity"
  ) -LogPath (Join-Path $logRoot "dism-export-boot.log")

  Log ("Exporting install image index " + $installImage.ImageIndex + " => " + $installImage.ImageName)
  Invoke-CliStrict -FilePath "dism.exe" -ArgumentList @(
    "/Export-Image",
    "/SourceImageFile:$esdPath",
    "/SourceIndex:$($installImage.ImageIndex)",
    "/DestinationImageFile:$installWimPath",
    "/Compress:max",
    "/CheckIntegrity"
  ) -LogPath (Join-Path $logRoot "dism-export-install.log")

  $result = [ordered]@{
    status = "prepared_source_media"
    runId = $runId
    runRoot = $runRoot
    sourceMediaRoot = $SourceMediaRoot
    esdPath = $esdPath
    esdSha256 = $expectedHash
    bootWimPath = $bootWimPath
    installWimPath = $installWimPath
    setupImage = ($setupImage.ImageIndex.ToString() + ": " + $setupImage.ImageName)
    installImage = ($installImage.ImageIndex.ToString() + ": " + $installImage.ImageName)
    logPath = $script:LogPath
  }
  $resultPath = Join-Path $runRoot "result.json"
  Save-Json -Path $resultPath -Value $result
  Write-Output ("SOURCE_MEDIA_RESULT=" + $resultPath)
  Write-Output ("SOURCE_MEDIA_ROOT=" + $SourceMediaRoot)
} finally {
  Set-KeepAwake -Enable $false
}
