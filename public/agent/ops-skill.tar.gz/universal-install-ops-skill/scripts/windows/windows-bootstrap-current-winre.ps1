param(
  [string] $UsbDriveLetter = "D",
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string] $TargetMarkerPath = "C:\Soty-Reinstall-Target.marker"
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw "This script must run as Administrator."
}

$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$runRoot = Join-Path $WorkspaceRoot ("manual-winre-bootstrap\" + $runId)
$backupRoot = Join-Path $runRoot "backup"
$mountDir = Join-Path $runRoot "mount"
New-Dir $runRoot
New-Dir $backupRoot
$script:LogPath = Join-Path $runRoot "bootstrap.log"

$usbLetter = $UsbDriveLetter.TrimEnd(":").ToUpperInvariant()
$usbRoot = $usbLetter + ":\Soty-Reinstall"
$reinstallRoot = Join-Path $usbRoot "reinstall"
$armedFlagPath = Join-Path $reinstallRoot "armed.flag"
$armedStartedPath = Join-Path $reinstallRoot "armed.started"
$workerScriptPath = Join-Path $reinstallRoot "winre-reinstall.cmd"
$configPath = Join-Path $reinstallRoot "config.cmd"
$usbBackupRoot = Join-Path $usbRoot "backup\winre\manual-latest"
$winrePath = "C:\Windows\System32\Recovery\Winre.wim"
$winreBackupPath = Join-Path $backupRoot "Winre-before-custom.wim"
$usbWinreBackupPath = Join-Path $usbBackupRoot "Winre-before-custom.wim"

foreach ($requiredPath in @($workerScriptPath, $configPath)) {
  if (-not (Test-Path -LiteralPath $requiredPath)) {
    throw ("Required WinRE worker file is missing: " + $requiredPath)
  }
}

$startnetContent = @'
@echo off
setlocal enableextensions enabledelayedexpansion
set INTERNALROOT=
set TARGETROOT=
for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%d:\Soty-Boot\boot.wim" set "INTERNALROOT=%%d:\Soty-Boot"
  if exist "%%d:\Soty-Reinstall-Target.marker" set "TARGETROOT=%%d:"
)
if not exist X:\Soty mkdir X:\Soty >nul 2>nul
set LOG_PATH=X:\Soty\soty-startnet.log
if defined INTERNALROOT (
  if not exist "%INTERNALROOT%\logs" mkdir "%INTERNALROOT%\logs" >nul 2>nul
  set LOG_PATH=%INTERNALROOT%\logs\startnet.log
)
if not defined INTERNALROOT if defined TARGETROOT (
  if not exist "%TARGETROOT%\ProgramData\Soty\WindowsReinstall\logs" mkdir "%TARGETROOT%\ProgramData\Soty\WindowsReinstall\logs" >nul 2>nul
  set LOG_PATH=%TARGETROOT%\ProgramData\Soty\WindowsReinstall\logs\winre-startnet.log
)
>>"%LOG_PATH%" echo [%DATE% %TIME%] startnet entered
wpeinit >>"%LOG_PATH%" 2>&1
>>"%LOG_PATH%" echo [%DATE% %TIME%] wpeinit finished
if defined INTERNALROOT >>"%LOG_PATH%" echo [%DATE% %TIME%] internal root found at %INTERNALROOT%
if defined TARGETROOT >>"%LOG_PATH%" echo [%DATE% %TIME%] target root found at %TARGETROOT%
set USBROOT=
for /L %%i in (1,1,120) do (
  set "USBROOT="
  for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%d:\Soty-Reinstall\reinstall\winre-reinstall.cmd" if exist "%%d:\Soty-Reinstall\reinstall\config.cmd" set "USBROOT=%%d:\Soty-Reinstall"
  )
  if defined USBROOT goto usb_found
  >>"%LOG_PATH%" echo [%DATE% %TIME%] probe %%i: usb root not found yet
  timeout /t 2 /nobreak >nul
)
>>"%LOG_PATH%" echo [%DATE% %TIME%] usb root was not found after retries
wpeutil reboot
exit /b 1

:usb_found
>>"%LOG_PATH%" echo [%DATE% %TIME%] usb root found at %USBROOT%
if defined USBROOT (
  if not exist "%USBROOT%\reinstall\logs" mkdir "%USBROOT%\reinstall\logs" >nul 2>nul
  type "%LOG_PATH%" >> "%USBROOT%\reinstall\logs\startnet.log" 2>nul
  set LOG_PATH=%USBROOT%\reinstall\logs\startnet.log
  >>"%LOG_PATH%" echo [%DATE% %TIME%] invoking worker, usbroot=%USBROOT%
  if exist "%USBROOT%\reinstall\armed.flag" (
    call "%USBROOT%\reinstall\winre-reinstall.cmd"
    set WORKER_EXIT=!ERRORLEVEL!
    >>"%LOG_PATH%" echo [%DATE% %TIME%] worker exit code=!WORKER_EXIT!
    exit /b !WORKER_EXIT!
  ) else (
    >>"%LOG_PATH%" echo [%DATE% %TIME%] armed.flag missing, not invoking worker
    wpeutil reboot
    exit /b 1
  )
)
'@

$sotyLaunchContent = @'
@echo off
call %SYSTEMROOT%\System32\startnet.cmd
exit /b %ERRORLEVEL%
'@

$winpeshlContent = @'
[LaunchApps]
%SYSTEMROOT%\System32\cmd.exe, /c %SYSTEMROOT%\System32\soty-launch.cmd
'@

$winReDisabled = $false
try {
  Log "Cleaning stale DISM mount state."
  try {
    & dism.exe /Cleanup-Wim | Out-Null
  } catch {
    Log ("DISM cleanup warning: " + $_.Exception.Message)
  }

  if (Test-Path -LiteralPath $mountDir) {
    try { & dism.exe /Unmount-Image "/MountDir:$mountDir" /Discard | Out-Null } catch {}
    Remove-Item -LiteralPath $mountDir -Recurse -Force -ErrorAction SilentlyContinue
  }
  New-Dir $mountDir

  Log "Disabling WinRE for offline servicing."
  & reagentc.exe /disable | Out-Null
  $winReDisabled = $true

  Log ("Checking current WinRE payload at " + $winrePath)
  $winReReady = $false
  for ($probe = 1; $probe -le 20; $probe++) {
    & cmd.exe /c "dir /a `"$winrePath`" >nul 2>nul"
    if ($LASTEXITCODE -eq 0) {
      $winReReady = $true
      break
    }
    Start-Sleep -Milliseconds 500
  }
  if (-not $winReReady) {
    throw ("Current WinRE image is missing after reagentc /disable: " + $winrePath)
  }

  Log ("Backing up current WinRE to " + $winreBackupPath)
  Copy-Item -LiteralPath $winrePath -Destination $winreBackupPath -Force
  New-Dir $usbBackupRoot
  Copy-Item -LiteralPath $winrePath -Destination $usbWinreBackupPath -Force

  Log ("Mounting current WinRE image from " + $winrePath)
  & dism.exe /Mount-Image "/ImageFile:$winrePath" /Index:1 "/MountDir:$mountDir" | Out-Null
  if ($LASTEXITCODE -ne 0) {
    throw ("DISM mount failed with exit code " + $LASTEXITCODE)
  }

  $system32Dir = Join-Path $mountDir "Windows\System32"
  Set-Content -LiteralPath (Join-Path $system32Dir "startnet.cmd") -Value $startnetContent -Encoding ASCII
  Set-Content -LiteralPath (Join-Path $system32Dir "soty-launch.cmd") -Value $sotyLaunchContent -Encoding ASCII
  Set-Content -LiteralPath (Join-Path $system32Dir "winpeshl.ini") -Value $winpeshlContent -Encoding ASCII

  Log "Committing customized WinRE image."
  & dism.exe /Unmount-Image "/MountDir:$mountDir" /Commit | Out-Null
  if ($LASTEXITCODE -ne 0) {
    throw ("DISM unmount/commit failed with exit code " + $LASTEXITCODE)
  }
  $winReDisabled = $false

  & reagentc.exe /setreimage /path "C:\Windows\System32\Recovery" /target C:\Windows | Out-Null
  & reagentc.exe /enable | Out-Null
  & reagentc.exe /boottore | Out-Null

  if (Test-Path -LiteralPath $armedStartedPath) {
    Log ("Removing stale worker marker " + $armedStartedPath)
    Remove-Item -LiteralPath $armedStartedPath -Force
  }
  Set-Content -LiteralPath $armedFlagPath -Value ("armed-at=" + (Get-Date).ToString("o")) -Encoding ASCII
  Set-Content -LiteralPath $TargetMarkerPath -Value ("prepared-at=" + (Get-Date).ToString("o")) -Encoding ASCII

  $result = [ordered]@{
    status = "boottore_armed"
    runRoot = $runRoot
    winrePath = $winrePath
    winreBackupPath = $winreBackupPath
    usbWinreBackupPath = $usbWinreBackupPath
    armedFlagPath = $armedFlagPath
    targetMarkerPath = $TargetMarkerPath
    rebootCommand = "shutdown /r /t 0 /f"
    logPath = $script:LogPath
  }
  $resultPath = Join-Path $runRoot "result.json"
  Set-Content -LiteralPath $resultPath -Value ($result | ConvertTo-Json -Depth 12) -Encoding UTF8
  Log "Current WinRE bootstrap completed and boot-to-recovery is armed."
  Write-Output ("CURRENT_WINRE_BOOTSTRAP_RESULT=" + $resultPath)
} finally {
  if (Test-Path -LiteralPath $mountDir) {
    try { & dism.exe /Unmount-Image "/MountDir:$mountDir" /Discard | Out-Null } catch {}
    Remove-Item -LiteralPath $mountDir -Recurse -Force -ErrorAction SilentlyContinue
  }
  if ($winReDisabled) {
    try { & reagentc.exe /setreimage /path "C:\Windows\System32\Recovery" /target C:\Windows | Out-Null } catch {}
    try { & reagentc.exe /enable | Out-Null } catch {}
  }
}
