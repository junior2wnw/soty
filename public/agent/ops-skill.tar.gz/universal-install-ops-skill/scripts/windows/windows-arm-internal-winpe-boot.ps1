param(
  [string] $UsbDriveLetter = "D",
  [string] $UsbLabel = "SOTYWIN",
  [string] $BootRoot = "C:\Soty-Boot",
  [string] $BootEntryDescription = "Soty Automated Reinstall",
  [switch] $RebootNow
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Invoke-CliCapture([string] $FilePath, [string[]] $ArgumentList) {
  $output = & $FilePath @ArgumentList 2>&1
  $exitCode = $LASTEXITCODE
  return [pscustomobject]@{
    exitCode = $exitCode
    output = @($output | ForEach-Object { $_.ToString() })
  }
}

function Invoke-CliStrict([string] $FilePath, [string[]] $ArgumentList) {
  $result = Invoke-CliCapture -FilePath $FilePath -ArgumentList $ArgumentList
  if ($result.exitCode -ne 0) {
    throw ($FilePath + " failed with exit code " + $result.exitCode + "." + [Environment]::NewLine + ($result.output -join [Environment]::NewLine))
  }
  return $result
}

function Parse-Guid([string[]] $Lines) {
  foreach ($line in $Lines) {
    $match = [regex]::Match($line, "\{[0-9a-fA-F\-]+\}")
    if ($match.Success) {
      return $match.Value
    }
  }
  return $null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Get-AssertCustomBootWimScriptPath {
  $candidate = Join-Path $PSScriptRoot "windows-assert-custom-winpe-worker.ps1"
  if (Test-Path -LiteralPath $candidate) {
    return $candidate
  }
  return $null
}

function Remove-StaleSotyEntries {
  $enumOutput = & bcdedit.exe /enum all 2>&1
  if ($LASTEXITCODE -ne 0) {
    Log ("Stale BCD cleanup warning: unable to enumerate all entries.")
    return
  }

  $currentId = $null
  $currentDescription = $null
  $currentDevice = $null
  foreach ($line in @($enumOutput | ForEach-Object { $_.ToString() })) {
    if ($line -match '^\s*identifier\s+(\{[0-9a-fA-F\-]+\})\s*$') {
      if ($currentId -and $currentDescription -match '^Soty ' -and $currentDevice -match 'ramdisk=\[C:\]\\Soty-Boot\\boot\.wim') {
        if ($currentId -ne [string]$script:PreserveEntryGuid) {
          $deleteResult = Invoke-CliCapture -FilePath "bcdedit.exe" -ArgumentList @("/delete", $currentId, "/f")
          if ($deleteResult.exitCode -eq 0) {
            Log ("Deleted stale Soty BCD entry " + $currentId)
          }
        }
      }
      $currentId = $matches[1]
      $currentDescription = $null
      $currentDevice = $null
      continue
    }
    if ($line -match '^\s*description\s+(.+?)\s*$') {
      $currentDescription = $matches[1]
      continue
    }
    if ($line -match '^\s*device\s+(.+?)\s*$') {
      $currentDevice = $matches[1]
      continue
    }
  }
  if ($currentId -and $currentDescription -match '^Soty ' -and $currentDevice -match 'ramdisk=\[C:\]\\Soty-Boot\\boot\.wim') {
    if ($currentId -ne [string]$script:PreserveEntryGuid) {
      $deleteResult = Invoke-CliCapture -FilePath "bcdedit.exe" -ArgumentList @("/delete", $currentId, "/f")
      if ($deleteResult.exitCode -eq 0) {
        Log ("Deleted stale Soty BCD entry " + $currentId)
      }
    }
  }
}

$stateRoot = "C:\ProgramData\Soty\WindowsReinstall\internal-boot"
New-Dir $stateRoot
$script:LogPath = Join-Path $stateRoot "internal-boot.log"

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw "This script must run as Administrator."
}

$usbLetter = $UsbDriveLetter.TrimEnd(":").ToUpperInvariant()
$usbDrive = Get-PSDrive -Name $usbLetter -PSProvider FileSystem -ErrorAction Stop
$actualUsbLabel = [string]$usbDrive.Description
if (-not [string]::IsNullOrWhiteSpace($actualUsbLabel) -and $actualUsbLabel -ne $UsbLabel) {
  throw ("USB label mismatch. Expected " + $UsbLabel + " but found " + $actualUsbLabel)
}

$workerRoot = Join-Path ($usbLetter + ":\Soty-Reinstall") "reinstall"
$workerScriptPath = Join-Path $workerRoot "winre-reinstall.cmd"
$armedFlagPath = Join-Path $workerRoot "armed.flag"
$targetMarkerPath = "C:\Soty-Reinstall-Target.marker"

$requiredPaths = @(
  @{ path = $workerScriptPath; label = "worker script" },
  @{ path = $armedFlagPath; label = "armed flag" },
  @{ path = $targetMarkerPath; label = "target marker" }
)
foreach ($required in $requiredPaths) {
  if (-not (Test-Path -LiteralPath $required.path)) {
    throw ("Required " + $required.label + " is missing: " + $required.path)
  }
}

$bootWimSource = Join-Path ($usbLetter + ":\") "sources\boot.wim"
if (-not (Test-Path -LiteralPath $bootWimSource)) {
  throw "USB boot.wim is missing: $bootWimSource"
}
$assertBootWimScript = Get-AssertCustomBootWimScriptPath
if (-not [string]::IsNullOrWhiteSpace($assertBootWimScript)) {
  Log "Verifying that USB sources\\boot.wim is worker-ready before internal arm."
  & $assertBootWimScript -BootWimPath $bootWimSource | Out-Null
} else {
  Log "Warning: worker boot.wim verification script is missing next to the arm script."
}

$bootSdiSource = "C:\Windows\Boot\DVD\EFI\boot.sdi"
if (-not (Test-Path -LiteralPath $bootSdiSource)) {
  throw "boot.sdi is missing: $bootSdiSource"
}

New-Dir $BootRoot
$bootWimTarget = Join-Path $BootRoot "boot.wim"
$bootSdiTarget = Join-Path $BootRoot "boot.sdi"
Log ("Copying boot assets to " + $BootRoot)
Copy-Item -LiteralPath $bootWimSource -Destination $bootWimTarget -Force
Copy-Item -LiteralPath $bootSdiSource -Destination $bootSdiTarget -Force

$previousResultPath = Join-Path $stateRoot "arm-result.json"
if (Test-Path -LiteralPath $previousResultPath) {
  try {
    $previous = Get-Content -LiteralPath $previousResultPath -Raw | ConvertFrom-Json
    $previousGuid = [string]$previous.entryGuid
    if (-not [string]::IsNullOrWhiteSpace($previousGuid)) {
      $deletePrevious = Invoke-CliCapture -FilePath "bcdedit.exe" -ArgumentList @("/delete", $previousGuid, "/f")
      if ($deletePrevious.exitCode -eq 0) {
        Log ("Deleted stale internal boot entry " + $previousGuid)
      } else {
        Log ("Stale entry cleanup warning for " + $previousGuid + ": " + (($deletePrevious.output -join " ") -replace "\s+", " ").Trim())
      }
    }
  } catch {
    Log ("Previous internal boot cleanup warning: " + $_.Exception.Message)
  }
}

Log "Creating one-time internal WinPE boot entry."
$createResult = Invoke-CliCapture -FilePath "bcdedit.exe" -ArgumentList @("/create", "/d", $BootEntryDescription, "/application", "osloader")
if ($createResult.exitCode -ne 0) {
  throw ("Failed to create BCD osloader entry." + [Environment]::NewLine + ($createResult.output -join [Environment]::NewLine))
}
$entryGuid = Parse-Guid -Lines $createResult.output
if ([string]::IsNullOrWhiteSpace($entryGuid)) {
  throw ("Could not parse BCD GUID from output." + [Environment]::NewLine + ($createResult.output -join [Environment]::NewLine))
}
$script:PreserveEntryGuid = $entryGuid
Remove-StaleSotyEntries

$ramdiskEnum = Invoke-CliCapture -FilePath "bcdedit.exe" -ArgumentList @("/enum", "{ramdiskoptions}")
if ($ramdiskEnum.exitCode -ne 0) {
  $ramdiskCreate = Invoke-CliCapture -FilePath "bcdedit.exe" -ArgumentList @("/create", "{ramdiskoptions}", "/d", "Soty Ramdisk Options")
  if ($ramdiskCreate.exitCode -ne 0 -and (($ramdiskCreate.output -join " ") -notmatch "already")) {
    throw ("Failed to create {ramdiskoptions}." + [Environment]::NewLine + ($ramdiskCreate.output -join [Environment]::NewLine))
  }
}

Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/set", "{ramdiskoptions}", "ramdisksdidevice", "partition=C:")
Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/set", "{ramdiskoptions}", "ramdisksdipath", "\Soty-Boot\boot.sdi")
Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/set", $entryGuid, "device", "ramdisk=[C:]\Soty-Boot\boot.wim,{ramdiskoptions}")
Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/set", $entryGuid, "osdevice", "ramdisk=[C:]\Soty-Boot\boot.wim,{ramdiskoptions}")
Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/set", $entryGuid, "path", "\windows\system32\boot\winload.efi")
Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/set", $entryGuid, "systemroot", "\windows")
Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/set", $entryGuid, "winpe", "yes")
Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/set", $entryGuid, "detecthal", "yes")
Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/set", $entryGuid, "nx", "OptIn")
Invoke-CliStrict -FilePath "bcdedit.exe" -ArgumentList @("/bootsequence", $entryGuid)
Log ("Armed BCD bootsequence for entry " + $entryGuid)

$result = [ordered]@{
  status = "armed"
  entryGuid = $entryGuid
  bootWimSource = $bootWimSource
  bootWimTarget = $bootWimTarget
  bootSdiTarget = $bootSdiTarget
  armedAt = (Get-Date).ToString("o")
  usbLetter = $usbLetter
  usbLabel = $UsbLabel
  workerScriptPath = $workerScriptPath
  armedFlagPath = $armedFlagPath
  markerPath = $targetMarkerPath
  logPath = $script:LogPath
  rebootCommand = "shutdown /r /t 0 /f"
}
$resultPath = Join-Path $stateRoot "arm-result.json"
Save-Json -Path $resultPath -Value $result
Write-Output ("INTERNAL_BOOT_ARM_RESULT=" + $resultPath)

if ($RebootNow) {
  shutdown.exe /r /t 0 /f
}
