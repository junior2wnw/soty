@echo off
setlocal
cd /d "%~dp0"
net session >nul 2>&1
if errorlevel 1 (
  powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
title Soty USB Recovery
echo.
echo Starting USB recovery diagnostics and SSH repair...
echo.
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Soty-Reinstall\recovery\windows-usb-diagnose-and-open-ssh.ps1"
echo.
echo Finished. If the window showed a logs path, leave the USB in place for a minute and then tell Codex it is done.
echo.
pause
