from __future__ import annotations

import argparse
import json
import os
import sys
from argparse import Namespace
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
sys.path.insert(0, str(SCRIPT_DIR / "routing"))
sys.path.insert(0, str(SCRIPT_DIR / "learning"))
sys.path.insert(0, str(SCRIPT_DIR / "lib"))

import find_script
import memory_loop
import route_branch
import route_hot
import route_shelf
from skill_paths import skill_root as find_skill_root

LONG_WORK_TERMS = {
    "long",
    "large",
    "big",
    "download",
    "build",
    "compile",
    "backup",
    "restore",
    "migrate",
    "migration",
    "flash",
    "reinstall",
    "image",
    "checksum",
    "долг",
    "больш",
    "скач",
    "сбор",
    "собер",
    "билд",
    "компил",
    "бэкап",
    "резерв",
    "восстанов",
    "миграц",
    "прош",
    "переустанов",
    "образ",
}
SLEEP_RISK_TERMS = {
    "sleep",
    "awake",
    "idle",
    "timeout",
    "lid",
    "battery",
    "laptop",
    "notebook",
    "remote",
    "ssh",
    "vm",
    "сон",
    "спящ",
    "уснет",
    "уснёт",
    "заснет",
    "заснёт",
    "просн",
    "крыш",
    "батар",
    "ноут",
    "удаленном компе",
    "удалённом компе",
    "удаленной машине",
    "удалённой машине",
    "ssh",
    "виртуал",
    "текущем компьютере",
    "текущей машине",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="One small front door for ops routing and memory.")
    parser.add_argument("task", help="User task in one short sentence.")
    parser.add_argument("--remember", default="", help="Shortcut: capture this useful fact during work; writes automatically when proof and env are present.")
    parser.add_argument("--during", action="store_true", help="Capture a useful fact while the task is still in progress.")
    parser.add_argument("--after", action="store_true", help="Capture memory after the task instead of routing before it.")
    parser.add_argument("--close", action="store_true", help="Close an ops run with a learning_delta decision.")
    parser.add_argument("--branch", action="store_true", help="Record a controlled branch from a default rule or route.")
    parser.add_argument("--checkpoint", action="store_true", help="Refresh route, branch, and memory continuity during long work.")
    parser.add_argument("--kind", choices=["ops", "control"], default="ops", help="Memory marker kind for --during or --after.")
    parser.add_argument("--result", choices=["works", "failed", "partial", "blocked", "unclear"], default="works")
    parser.add_argument("--expected", default="", help="Expected/default route.")
    parser.add_argument("--actual", default="", help="Actual/winning route.")
    parser.add_argument("--parent-rule", default="", help="Default rule or route being branched from.")
    parser.add_argument("--conditions", default="", help="Conditions that make a branch valid.")
    parser.add_argument("--rollback", default="", help="Rollback or return path for a branch.")
    parser.add_argument("--branch-status", choices=["candidate", "proven", "rejected", "promoted"], default="candidate")
    parser.add_argument("--branch-store", default="", help="Override route-branches JSONL path.")
    parser.add_argument("--success", default="", help="Small observable proof.")
    parser.add_argument("--proof", default="", help="Alias for --success.")
    parser.add_argument("--env", default="", help="Sanitized tiny environment fingerprint.")
    parser.add_argument("--risk", choices=["low", "medium", "high"], default="low")
    parser.add_argument("--route-changed", action="store_true")
    parser.add_argument("--fallback-worked", action="store_true")
    parser.add_argument("--default-failed", action="store_true")
    parser.add_argument("--token-saving", action="store_true")
    parser.add_argument("--safety", action="store_true")
    parser.add_argument("--repeated", action="store_true")
    parser.add_argument("--queue", default="", help="Candidate facts JSONL queue path.")
    parser.add_argument("--profile-store", default="", help="Optional route-profiles JSONL store for matching reusable fast lanes.")
    parser.add_argument("--top", type=int, default=2, help="Number of memory matches to show.")
    parser.add_argument("--write", action="store_true", help="Compatibility flag; capture writes automatically when proof/env are present.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    parser.add_argument("--detail", action="store_true", help="Print full text checklist; default text is token-light.")
    args = parser.parse_args()
    if args.proof and not args.success:
        args.success = args.proof
    if args.remember:
        if not args.after:
            args.during = True
            if args.result == "works":
                args.result = "partial"
        if not args.actual:
            args.actual = args.remember
    if sum(bool(value) for value in [args.during, args.after, args.close, args.branch, args.checkpoint]) > 1:
        parser.error("use only one of --during, --after, --close, --branch, or --checkpoint")
    if args.close:
        missing = [
            name
            for name, value in [
                ("--actual", args.actual),
                ("--success/--proof", args.success),
                ("--env", args.env),
            ]
            if not value.strip()
        ]
        if missing:
            parser.error("--close requires " + ", ".join(missing))
    if args.branch:
        if not args.actual:
            args.actual = args.task
        missing = [
            name
            for name, value in [
                ("--parent-rule", args.parent_rule),
                ("--conditions", args.conditions),
                ("--actual", args.actual),
                ("--success/--proof", args.success),
                ("--env", args.env),
            ]
            if not value.strip()
        ]
        if missing:
            parser.error("--branch requires " + ", ".join(missing))
    return args


def compact(value: str) -> str:
    return " ".join(value.strip().split())


def first_or_none(values: list[dict[str, Any]]) -> dict[str, Any] | None:
    return values[0] if values else None


def route_terms(*values: str) -> set[str]:
    terms: set[str] = set()
    for value in values:
        for part in value.replace("_", "-").split("-"):
            part = part.strip().lower()
            if len(part) >= 4:
                terms.add(part)
    return terms


def route_relevant_memory(matches: list[dict[str, Any]], terms: set[str]) -> list[dict[str, Any]]:
    if not matches:
        return []
    filtered: list[dict[str, Any]] = []
    for match in matches:
        text = str(match.get("text", "")).lower()
        score = int(match.get("score", 0))
        if score >= 12 or any(term in text for term in terms):
            filtered.append(match)
    return filtered


def contains_any(text: str, terms: set[str]) -> bool:
    lowered = text.casefold()
    return any(term in lowered for term in terms)


def source_state(root: Path) -> str:
    if not os.access(root, os.W_OK):
        return "read-only"
    parts = {part.casefold() for part in root.parts}
    normalized = str(root).replace("\\", "/").casefold()
    if (root / ".git").exists():
        return "canonical-repo"
    if "bundled-core" in parts or "tools/mcp/skills" in normalized:
        return "bundled-copy"
    if ".codex" in parts and "skills" in parts:
        return "installed-only"
    return "installed-only"


def awake_guard(task: str) -> str:
    lowered = task.casefold()
    explicit_sleep = contains_any(lowered, SLEEP_RISK_TERMS)
    long_work = contains_any(lowered, LONG_WORK_TERMS)
    if not explicit_sleep and not long_work:
        return ""
    if explicit_sleep or long_work:
        return (
            "awake-preflight: prove sleep/lid/battery/idle/VM/session cannot interrupt long "
            "local or remote work; if risk exists, apply a light reversible keep-awake guard."
        )
    return ""


def inner_voice(guards: list[str]) -> list[str]:
    voice = [
        "foundation: optimize the assigned work for result, safety, speed, token cost, and reuse.",
        "route: use one shelf/helper/hot route before scanning or inventing scripts.",
        "probability: choose the safe route with the highest success chance; if a lower-probability outcome happens, record it.",
        "profile: reuse a matching route profile before inventing steps; create/update one when a task family repeats.",
        "contour: if the client questions target, machine, route, speed, or bottleneck, pause, explain, re-route, and remember it now.",
        "quality: target, control plane, smallest safe action, rollback, visible proof.",
        "reflex: a new reusable failure, fallback, timing, command, or wording must become patch/marker/branch/no-op before the next state change.",
        "receipt: final or handoff answer must carry the ops.py --close final_line, or name the blocker.",
        "memory: record sanitized blockers, fallbacks, commands, timings, successes, and associations with --remember + proof/env.",
        "sink: improve module/hot/helper/eval when behavior changes; otherwise queue a sanitized marker or explicitly skip routine results.",
    ]
    if guards:
        voice.insert(1, "guard: handle the printed guard before long or risky state changes.")
    voice.append("promote: patch shelf/hot/eval/helper when a lesson should make the next run faster or better.")
    return voice


def top_state_scorecard(hot: dict[str, Any] | None, helper: dict[str, Any] | None) -> list[str]:
    route = str((hot or {}).get("id") or (helper or {}).get("id") or "choose one shelf/helper before exploring")
    return [
        "result: name the client-visible outcome before details",
        "target: confirm exact machine, console, account, and control plane",
        f"route: use {route} if it fits; otherwise pick the next fastest safe route",
        "profile: reuse a matching route profile, or name the profile gap for repeated work",
        "bottleneck: check speed/wait/retry cause before repeating work",
        "proof: define the observable success signal before claiming done",
        "client: explain corrections or blockers in the user's language",
        "memory: record useful correction/command/timing/win with --remember",
    ]


def ready_gate() -> list[str]:
    return [
        "go: target, control plane, route, proof, and risk gate are clear enough for the next safe action",
        "stop: target machine, account, console, or control plane is unclear",
        "stop: client challenged speed/source/machine and the bottleneck is unverified",
        "stop: risky step lacks rollback, provenance, permission, or return path",
        "stop: next move is broad scanning, fresh scripting, or guesswork",
        "stop: a reusable fact appeared but no patch, marker, branch, or explicit no-op exists yet",
        "stop: a lower-probability outcome or fallback happened and has not been recorded",
        "stop: final or handoff would omit the ops.py --close final_line",
        "branch: a written/default route may lose only to exact proof plus conditions, risk, rollback, and a branch record",
        "write: record the correction or win now if it will shorten future work",
    ]


def helper_matches_route(helper: dict[str, Any] | None, hot: dict[str, Any] | None) -> bool:
    if not helper:
        return False
    if not hot:
        return True
    helper_id = str(helper.get("id", ""))
    hot_id = str(hot.get("id", ""))
    if helper_id == hot_id:
        return True
    exact_route_helpers = {
        "ops-continuity-checkpoint": "ops-checkpoint",
        "skill-finish-gate": "finish-skill-edit",
        "skill-memory-merge-gate": "merge-skill-memory",
        "soty-teacher-review-gate": "ingest-teacher-report",
        "windows-reinstall-fast-lane": "windows-reinstall-profile",
    }
    if exact_route_helpers.get(hot_id) == helper_id:
        return True
    helper_terms = route_terms(helper_id, str(helper.get("purpose", "")))
    hot_terms = route_terms(hot_id)
    return len(helper_terms & hot_terms) >= 2


def exact_route_helper_id(hot: dict[str, Any] | None) -> str:
    route_id = str((hot or {}).get("id", ""))
    return {
        "ops-continuity-checkpoint": "ops-checkpoint",
        "skill-finish-gate": "finish-skill-edit",
        "skill-memory-merge-gate": "merge-skill-memory",
        "soty-teacher-review-gate": "ingest-teacher-report",
        "windows-reinstall-fast-lane": "windows-reinstall-profile",
    }.get(route_id, "")


def catalog_script_by_id(catalog: dict[str, Any], script_id: str, task: str) -> dict[str, Any] | None:
    if not script_id:
        return None
    root = find_skill_root(__file__).resolve()
    for script in catalog.get("scripts", []):
        if isinstance(script, dict) and str(script.get("id", "")) == script_id:
            return find_script.enrich_script(root, script, task)
    return None


def profile_store_path(root: Path, raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else root / ".skill-memory" / "route-profiles.jsonl"


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict):
            rows.append(row)
    return rows


def newer_profile(candidate: dict[str, Any], existing: dict[str, Any] | None) -> bool:
    if existing is None:
        return True
    candidate_time = str(candidate.get("updated_at", ""))
    existing_time = str(existing.get("updated_at", ""))
    if candidate_time != existing_time:
        return candidate_time > existing_time
    return len(json.dumps(candidate, sort_keys=True)) >= len(json.dumps(existing, sort_keys=True))


def latest_route_profiles(path: Path) -> list[dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for row in read_jsonl(path):
        profile_id = str(row.get("profile_id", ""))
        if profile_id and newer_profile(row, latest.get(profile_id)):
            latest[profile_id] = row
    return list(latest.values())


def profile_haystack(profile: dict[str, Any]) -> str:
    return " ".join(
        str(profile.get(key, ""))
        for key in [
            "profile_id",
            "shelf",
            "task_family",
            "platform_family",
            "control_plane",
            "route",
            "proof",
            "transfer_boundary",
        ]
    )


PROFILE_GENERIC_TOKENS = {
    "agent",
    "best",
    "better",
    "check",
    "contract",
    "fast",
    "gate",
    "health",
    "lane",
    "local",
    "proof",
    "quality",
    "route",
    "safe",
    "same",
    "skill",
    "task",
    "work",
}


def profile_token_score(query_tokens: set[str], profile: dict[str, Any]) -> tuple[int, set[str]]:
    weighted_fields = [
        ("profile_id", 5),
        ("task_family", 6),
        ("platform_family", 3),
        ("control_plane", 3),
        ("route", 2),
        ("proof", 1),
        ("transfer_boundary", 1),
    ]
    score = 0
    distinctive: set[str] = set()
    for key, weight in weighted_fields:
        field_tokens = route_shelf.tokens(str(profile.get(key, "")))
        overlap = query_tokens & field_tokens
        score += weight * len(overlap)
        distinctive.update(token for token in overlap if token not in PROFILE_GENERIC_TOKENS)
    return score, distinctive


def score_profile(task: str, query_tokens: set[str], shelf_id: str, profile: dict[str, Any]) -> int:
    evidence_score, distinctive = profile_token_score(query_tokens, profile)
    score = evidence_score
    profile_shelf = str(profile.get("shelf", ""))
    if shelf_id and profile_shelf == shelf_id:
        score += 4
    elif shelf_id and profile_shelf:
        score -= 4
    task_lower = task.casefold()
    for key in ["task_family", "platform_family", "control_plane"]:
        phrase = str(profile.get(key, "")).casefold()
        if phrase and phrase in task_lower:
            score += 12
            distinctive.update(token for token in route_shelf.tokens(phrase) if token not in PROFILE_GENERIC_TOKENS)
    if evidence_score < 6 or not distinctive:
        return 0
    return score


def best_route_profile(root: Path, task: str, shelf_id: str, raw_store: str) -> dict[str, Any] | None:
    store = profile_store_path(root, raw_store)
    query_tokens = route_shelf.tokens(task)
    scored: list[dict[str, Any]] = []
    for profile in latest_route_profiles(store):
        item = dict(profile)
        item["score"] = score_profile(task, query_tokens, shelf_id, profile)
        item["store"] = str(store)
        scored.append(item)
    scored.sort(key=lambda item: (-int(item.get("score", 0)), str(item.get("profile_id", ""))))
    if not scored or int(scored[0].get("score", 0)) < 8:
        return None
    return scored[0]


def optimization_contract(profile: dict[str, Any] | None) -> dict[str, str]:
    if profile:
        return {
            "reuse": f"reuse route profile {profile.get('profile_id')}",
            "improve": "if current proof beats the profile, update profile metrics/route or record a branch/revision",
            "close": "final answer carries the --close final_line: faster|simpler|safer|higher-quality|more-universal, or blocked/no-op reason",
        }
    return {
        "reuse": "no matching route profile; use hot route/helper and avoid broad rediscovery",
        "improve": "if this task family repeats, create a route profile with proof, transfer boundary, and metrics when known",
        "close": "final answer carries the --close final_line: profile|patch|branch|marker|no-op with proof",
    }


def reflex_card() -> dict[str, str]:
    return {
        "first": "run ops.py, then obey do_now",
        "gate": "stop on Ready Gate; prove before done",
        "learn": "patch, marker, branch, or no-op before the next state change",
        "done": "final proof plus --close final_line learning_delta",
    }


def action_packet(
    hot: dict[str, Any] | None,
    helper: dict[str, Any] | None,
    profile: dict[str, Any] | None,
    read: list[str],
    guards: list[str],
    verify: str,
    can_run_helper: bool,
) -> dict[str, str]:
    if guards:
        do_now = "handle the printed guard before any long or risky state change"
    elif can_run_helper and helper and helper.get("run"):
        do_now = f"run helper {helper.get('id')} only if it exactly matches the task"
    elif hot:
        do_now = f"follow hot route {hot.get('id')}; read one shelf file only if needed"
    elif read:
        do_now = f"read {read[0]} first, then choose the smallest safe action"
    else:
        do_now = "make one read-only probe before any state change"
    return {
        "do_now": do_now,
        "profile": (
            f"reuse {profile.get('profile_id')}: {compact(str(profile.get('route', '')))}"
            if profile
            else "no matching route profile yet; create/update one if this task family repeats"
        ),
        "stop_if": "any Ready Gate stop condition is true",
        "prove": verify,
        "checkpoint": 'after long wait/resume/route change, run ops.py "<task>" --checkpoint; add --actual/--proof/--env when a reusable fact appeared',
        "branch": 'if exact current proof beats the route, record: ops.py "<better route>" --branch --parent-rule "<default>" --conditions "<when>" --proof "<proof>" --env "<boundary>" --rollback "<return-path>"',
        "remember": 'before the next state change, patch or run --remember "<fact>" --proof "<proof>" --env "<boundary>" for fallbacks or lower-probability outcomes; otherwise record learning_delta=no-op',
        "close": 'before final, run ops.py "<task>" --close --actual "<patch|note|marker|branch|handoff-marker|no-op>" --success "<proof>" --env "<boundary>"; final/handoff must include its final_line',
    }


def branch_gate(root: Path) -> dict[str, str]:
    script = root / "scripts" / "ops.py"
    return {
        "when": "fresh exact-target proof beats the printed/default route or written rule",
        "record": f'python "{script}" "<better route>" --branch --parent-rule "<default>" --conditions "<when>" --proof "<proof>" --env "<boundary>" --rollback "<return-path>"',
        "promote": "promote only after repeated proof or a safety-changing case; otherwise keep the branch scoped",
    }


def checkpoint_gate(root: Path, task: str) -> dict[str, str]:
    script = root / "scripts" / "ops.py"
    return {
        "when": "after a long wait, context resume, target switch, route change, blocker, fallback, or new proof",
        "run": f'python "{script}" "{compact(task) or "<task>"}" --checkpoint',
        "capture": f'python "{script}" "{compact(task) or "<task>"}" --checkpoint --actual "<new fact>" --proof "<proof>" --env "<boundary>"',
    }


def route_metrics(report: dict[str, Any]) -> dict[str, Any]:
    return {
        "read_count": len(report.get("read", [])),
        "memory_match_count": len(report.get("memory", [])),
        "guard_count": len(report.get("guards", [])),
        "has_hot_route": bool(report.get("hot_route")),
        "hot_score": int((report.get("hot_route") or {}).get("score", 0)),
        "has_profile": bool(report.get("route_profile")),
        "profile_score": int((report.get("route_profile") or {}).get("score", 0)),
        "shelf_score": int((report.get("shelf") or {}).get("score", 0)),
        "helper_fit": str(report.get("helper_fit", "none")),
    }


def small_route(root: Path, task: str, top: int, profile_store: str = "") -> dict[str, Any]:
    shelf_index = route_shelf.load_index(root / "references" / "shelf-index.json")
    hot_index = route_hot.load_routes(root / "references" / "hot-routes.json")
    catalog = find_script.load_catalog()
    queue = memory_loop.queue_path("")

    shelf = first_or_none(route_shelf.rank_shelves(task, shelf_index, top=1))
    hot = first_or_none(route_hot.rank_routes(task, hot_index, top=1))
    shelf_id = str((hot or {}).get("shelf") or (shelf or {}).get("id") or "")
    helper_candidates = find_script.rank_scripts(task, catalog, shelf=shelf_id, top=5) if shelf_id else []
    helper = first_or_none(helper_candidates)
    route_helper_id = exact_route_helper_id(hot)
    if route_helper_id:
        helper = (
            next((item for item in helper_candidates if str(item.get("id", "")) == route_helper_id), None)
            or catalog_script_by_id(catalog, route_helper_id, task)
            or helper
        )
    if helper is None and not shelf_id:
        helper = first_or_none(find_script.rank_scripts(task, catalog, top=1))
    terms = route_terms(
        shelf_id,
        str((shelf or {}).get("id", "")),
        str((hot or {}).get("id", "")),
        str((helper or {}).get("id", "")),
    )
    memory_matches = route_relevant_memory(memory_loop.existing_matches(root, task, queue, top=max(top * 3, top)), terms)[:top]
    profile = best_route_profile(root, task, shelf_id, profile_store)

    read = list((shelf or {}).get("read", []))
    verify = str((hot or {}).get("verify") or "Verify the smallest user-visible success proof.")
    fallback = str((hot or {}).get("fallback") or "If no safe proof exists, stop and name the blocker.")
    guards = [guard for guard in [awake_guard(task)] if guard]
    if str((hot or {}).get("id", "")) == "ops-self-improvement-sink":
        guards = []
    can_run_helper = helper_matches_route(helper, hot)

    next_steps: list[str] = []
    if guards:
        next_steps.append("Handle the printed guard before long-running state changes.")
    if profile and can_run_helper and helper:
        next_steps.append(f"Reuse route profile {profile.get('profile_id')}, then run the printed helper if exact.")
    elif profile:
        next_steps.append(f"Reuse route profile {profile.get('profile_id')} before inventing new steps.")
    elif can_run_helper and helper:
        next_steps.append("Run the printed helper only if it exactly matches the task.")
    elif hot:
        next_steps.append("Follow the hot route first; treat any helper as supporting context only.")
    elif read:
        next_steps.append("Read the first shelf file only, then choose the smallest safe action.")
    else:
        next_steps.append("Use a read-only probe before any state change.")
    next_steps.append("Verify before telling the user it is done; before final or handoff, run --close and include its final_line.")
    next_steps.append("After any reusable failure/success or route change, patch or use --remember/--checkpoint with proof/env before the next state change.")

    report = {
        "ok": True,
        "mode": "before",
        "skill_root": str(root),
        "source_state": source_state(root),
        "task": compact(task),
        "memory": memory_matches,
        "shelf": shelf,
        "hot_route": hot,
        "helper": helper,
        "route_profile": profile,
        "read": read[:3],
        "guards": guards,
        "helper_fit": "run" if can_run_helper else ("candidate" if helper else "none"),
        "voice": inner_voice(guards),
        "scorecard": top_state_scorecard(hot, helper),
        "ready_gate": ready_gate(),
        "reflex_card": reflex_card(),
        "action_packet": action_packet(hot, helper, profile, read, guards, verify, can_run_helper),
        "branch_gate": branch_gate(root),
        "checkpoint_gate": checkpoint_gate(root, task),
        "optimization_contract": optimization_contract(profile),
        "verify": verify,
        "fallback": fallback,
        "next": next_steps,
    }
    report["route_metrics"] = route_metrics(report)
    return report


def after_report(args: argparse.Namespace) -> dict[str, Any]:
    memory_args = Namespace(
        task=args.task,
        mode="during" if args.during else "after",
        kind=args.kind,
        result=args.result,
        expected=args.expected,
        actual=args.actual,
        success=args.success,
        env=args.env,
        risk=args.risk,
        route_changed=args.route_changed,
        fallback_worked=args.fallback_worked,
        default_failed=args.default_failed,
        token_saving=args.token_saving,
        safety=args.safety,
        repeated=args.repeated,
        queue=args.queue,
        top=args.top,
        write=args.write,
        json=args.json,
    )
    return memory_loop.build_report(memory_args)


EXPLICIT_CLOSE_DELTAS = {"profile", "patch", "note", "marker", "branch", "handoff-marker", "no-op"}


def explicit_close_delta(actual: str) -> str:
    head = compact(actual).split(":", 1)[0].split(" ", 1)[0].casefold()
    return head if head in EXPLICIT_CLOSE_DELTAS else ""


def explicit_close_report(root: Path, args: argparse.Namespace, delta: str) -> dict[str, Any]:
    queue = memory_loop.queue_path(args.queue)
    matches = memory_loop.existing_matches(root, " ".join([args.task, args.actual, args.env]), queue, args.top)
    return {
        "skill_root": str(root),
        "source_state": memory_loop.skill_source_state(root),
        "mode": "close",
        "task": compact(args.task),
        "existing_matches": matches,
        "should_record": False,
        "reasons": [],
        "promotion_tier": "explicit-close-delta",
        "questions": [],
        "marker": "",
        "learning_delta": delta,
        "learning_sink": f"{memory_loop.skill_source_state(root)}: explicit close delta accepted; proof/env attached",
        "written": False,
        "cache_decision": "closed with explicit learning_delta",
        "queue": str(queue),
        "record": None,
        "ok": True,
        "final_line": f"learning_delta={delta}; proof={compact(args.success)}",
    }


def close_report(args: argparse.Namespace) -> dict[str, Any]:
    root = find_skill_root(__file__).resolve()
    delta = explicit_close_delta(args.actual)
    if delta:
        return explicit_close_report(root, args, delta)
    report = after_report(args)
    report["mode"] = "close"
    report["final_line"] = (
        f"learning_delta={report.get('learning_delta', 'unknown')}; "
        f"proof={compact(args.success) or report.get('cache_decision', 'not recorded')}"
    )
    return report


def branch_report(args: argparse.Namespace) -> dict[str, Any]:
    branch_args = Namespace(
        parent_rule=args.parent_rule,
        branch=args.actual,
        conditions=args.conditions,
        reason=args.expected or "current exact proof beats the default route",
        proof=args.success,
        env=args.env,
        rollback=args.rollback,
        risk=args.risk,
        status=args.branch_status,
        scope="case-local" if args.branch_status == "candidate" else "platform-or-family",
        store=args.branch_store,
        json=args.json,
    )
    report = route_branch.run(branch_args)
    report["mode"] = "branch"
    report["learning_delta"] = f"branch-{args.branch_status}"
    report["final_line"] = f"learning_delta=branch-{args.branch_status}; proof={compact(args.success)}"
    return report


def checkpoint_report(root: Path, args: argparse.Namespace) -> dict[str, Any]:
    route_report = small_route(root, args.task, top=args.top, profile_store=args.profile_store)
    memory_report = None
    if any(
        [
            args.expected,
            args.actual,
            args.success,
            args.env,
            args.route_changed,
            args.fallback_worked,
            args.default_failed,
            args.token_saving,
            args.safety,
            args.repeated,
            args.write,
        ]
    ):
        memory_args = Namespace(
            task=args.task,
            mode="during",
            kind=args.kind,
            result="partial" if args.result == "works" else args.result,
            expected=args.expected,
            actual=args.actual,
            success=args.success,
            env=args.env,
            risk=args.risk,
            route_changed=args.route_changed,
            fallback_worked=args.fallback_worked,
            default_failed=args.default_failed,
            token_saving=args.token_saving,
            safety=args.safety,
            repeated=args.repeated,
            queue=args.queue,
            top=args.top,
            write=args.write,
            json=args.json,
        )
        memory_report = memory_loop.build_report(memory_args)
    route_report["mode"] = "checkpoint"
    route_report["checkpoint"] = {
        "status": "skill-continuity-active",
        "route": str((route_report.get("hot_route") or {}).get("id") or (route_report.get("shelf") or {}).get("id") or "none"),
        "resume_rule": "continue only if current proof still fits target, route, risk, and rollback",
        "branch_check": "if proof beats the printed/default route, record --branch instead of silently drifting",
        "memory_check": "memory: if a blocker, fallback, lower-probability outcome, timing, command, association, or branch condition appeared, record it now; missing proof/env is not improvement",
        "next_checkpoint": "run --checkpoint again after long wait, context resume, target switch, or route-changing proof",
    }
    if memory_report is not None:
        route_report["checkpoint_memory"] = memory_report
    return route_report


def print_before_brief(report: dict[str, Any]) -> None:
    hot = report.get("hot_route") or {}
    helper = report.get("helper") or {}
    packet = report.get("action_packet", {})
    read = report.get("read", [])
    print("Ops Route")
    print(f"- task: {report['task']}")
    print(
        "- route: "
        f"shelf={(report.get('shelf') or {}).get('id', 'none')} "
        f"hot={hot.get('id', 'none')} "
        f"helper={helper.get('id', 'none')} "
        f"fit={report.get('helper_fit', 'none')}"
    )
    metrics = report.get("route_metrics", {})
    print(
        "- source_state: "
        f"{report.get('source_state', 'unknown')} "
        f"metrics=read:{metrics.get('read_count', 0)} "
        f"memory:{metrics.get('memory_match_count', 0)} "
        f"hot_score:{metrics.get('hot_score', 0)} "
        f"profile:{metrics.get('profile_score', 0)}"
    )
    if read:
        print(f"- read_first: {read[0]}")
    for guard in report.get("guards", []):
        print(f"- guard: {guard}")
    if helper.get("run") and report.get("helper_fit") == "run":
        print(f"- run: {helper['run']}")
    if report.get("reflex_card"):
        print("- reflex: do_now first; proof before done; learn before next state change; close=--close final_line+proof")
    if packet:
        keys = ["do_now", "stop_if", "prove", "checkpoint", "branch", "remember", "close"]
        if report.get("route_profile"):
            keys.insert(1, "profile")
        for key in keys:
            print(f"- {key}: {packet[key]}")
    print("- more: use --detail or --json only when the route is unclear or a snippet changes the next action")


def print_before_detail(report: dict[str, Any]) -> None:
    print("Ops Route")
    print(f"- task: {report['task']}")
    print(f"- source_state: {report.get('source_state', 'unknown')}")
    print(f"- route_metrics: {json.dumps(report.get('route_metrics', {}), ensure_ascii=False, sort_keys=True)}")
    print(f"- shelf: {(report.get('shelf') or {}).get('id', 'none')}")
    if report.get("read"):
        read = report["read"]
        suffix = f" (+{len(read) - 1} optional)" if len(read) > 1 else ""
        print(f"- read_first: {read[0]}{suffix}")
    hot = report.get("hot_route") or {}
    print(f"- hot_route: {hot.get('id', 'none')}")
    helper = report.get("helper") or {}
    print(f"- helper: {helper.get('id', 'none')}")
    print(f"- helper_fit: {report.get('helper_fit', 'none')}")
    if helper.get("run") and report.get("helper_fit") == "run":
        print(f"- run: {helper['run']}")
    profile = report.get("route_profile") or {}
    if profile:
        print(f"- route_profile: {profile.get('profile_id')} score={profile.get('score', 0)}")
        print(f"  - route: {compact(str(profile.get('route', '')))}")
        print(f"  - transfer: {compact(str(profile.get('transfer_boundary', '')))}")
    else:
        print("- route_profile: none")
    for guard in report.get("guards", []):
        print(f"- guard: {guard}")
    print("- voice:")
    for item in report.get("voice", []):
        print(f"  - {item}")
    print("- scorecard:")
    for item in report.get("scorecard", []):
        print(f"  - {item}")
    print("- ready_gate:")
    for item in report.get("ready_gate", []):
        print(f"  - {item}")
    card = report.get("reflex_card", {})
    if card:
        print("- reflex_card:")
        for key in ["first", "gate", "learn", "done"]:
            print(f"  - {key}: {card[key]}")
    packet = report.get("action_packet", {})
    if packet:
        print("- action_packet:")
        for key in ["do_now", "profile", "stop_if", "prove", "checkpoint", "branch", "remember", "close"]:
            print(f"  - {key}: {packet[key]}")
    branch = report.get("branch_gate", {})
    if branch:
        print("- branch_gate:")
        print(f"  - when: {branch['when']}")
        print(f"  - record: {branch['record']}")
        print(f"  - promote: {branch['promote']}")
    checkpoint = report.get("checkpoint_gate", {})
    if checkpoint:
        print("- checkpoint_gate:")
        print(f"  - when: {checkpoint['when']}")
        print(f"  - run: {checkpoint['run']}")
        print(f"  - capture: {checkpoint['capture']}")
    print(f"- verify: {report['verify']}")
    print(f"- fallback: {report['fallback']}")
    contract = report.get("optimization_contract", {})
    if contract:
        print("- optimization_contract:")
        for key in ["reuse", "improve", "close"]:
            print(f"  - {key}: {contract[key]}")
    memory = report.get("memory", [])
    print(f"- memory_matches: {len(memory)}")
    for match in memory:
        print(f"  - {match['source']} score={match['score']}: {memory_loop.match_snippet(match['text'])}")
    print("- next:")
    for index, step in enumerate(report["next"], start=1):
            print(f"  {index}. {step}")


def print_after(report: dict[str, Any]) -> None:
    if report.get("mode") == "checkpoint":
        print("Ops Checkpoint")
        print(f"- task: {report['task']}")
        print(f"- status: {report['checkpoint']['status']}")
        print(f"- route: {report['checkpoint']['route']}")
        print(f"- do_now: {report.get('action_packet', {}).get('do_now', '')}")
        print(f"- branch_check: {report['checkpoint']['branch_check']}")
        print(f"- memory_check: {report['checkpoint']['memory_check']}")
        if report.get("checkpoint_memory"):
            memory = report["checkpoint_memory"]
            print(f"- checkpoint_memory: learning_delta={memory.get('learning_delta')} should_record={memory.get('should_record')} written={memory.get('written')}")
        print(f"- next_checkpoint: {report['checkpoint']['next_checkpoint']}")
        return
    if report.get("mode") == "branch":
        print("Ops Branch")
        route_branch.print_text(report)
        print(f"- final_line: {report.get('final_line', '')}")
        return
    if report.get("mode") == "close":
        print("Ops Close")
        memory_loop.print_text(report)
        print(f"- final_line: {report.get('final_line', '')}")
        return
    memory_loop.print_text(report)


def main() -> int:
    args = parse_args()
    root = find_skill_root(__file__).resolve()
    try:
        report = (
            branch_report(args)
            if args.branch
            else (
                checkpoint_report(root, args)
                if args.checkpoint
                else (close_report(args) if args.close else (after_report(args) if (args.during or args.after) else small_route(root, args.task, top=args.top, profile_store=args.profile_store)))
            )
        )
    except Exception as error:
        report = {"ok": False, "error": str(error)}

    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    elif report.get("ok"):
        if args.during or args.after or args.close or args.branch or args.checkpoint:
            print_after(report)
        else:
            print_before_detail(report) if args.detail else print_before_brief(report)
    else:
        print(f"error: {report.get('error', 'unknown error')}", file=sys.stderr)
    return 0 if report.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
