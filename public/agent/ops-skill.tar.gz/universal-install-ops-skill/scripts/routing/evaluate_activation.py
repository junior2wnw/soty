from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))

from skill_paths import skill_root
import route_hot
import route_shelf


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run lightweight activation routing checks.")
    parser.add_argument("--cases", default="", help="Optional activation-eval.json path.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser.parse_args()


def default_cases_path() -> Path:
    return skill_root(__file__) / "references" / "activation-eval.json"


def evaluate_case(case: dict[str, Any], shelf_index: dict[str, Any], hot_index: dict[str, Any]) -> dict[str, Any]:
    prompt = str(case.get("prompt", ""))
    expected_shelf = str(case.get("expected_shelf", ""))
    expected_hot_route = str(case.get("expected_hot_route", ""))

    shelf_result = route_shelf.rank_shelves(prompt, shelf_index, top=1)[0]
    hot_candidates = route_hot.rank_routes(prompt, hot_index, top=1)
    hot_result = hot_candidates[0] if hot_candidates else {"id": "", "score": 0}
    actual_shelf = str(shelf_result.get("id", ""))
    actual_hot_route = str(hot_result.get("id", "")) if int(hot_result.get("score", 0)) > 0 else ""

    shelf_ok = actual_shelf == expected_shelf
    hot_ok = not expected_hot_route or actual_hot_route == expected_hot_route
    return {
        "id": case.get("id", ""),
        "prompt": prompt,
        "expected_shelf": expected_shelf,
        "actual_shelf": actual_shelf,
        "shelf_score": shelf_result.get("score", 0),
        "expected_hot_route": expected_hot_route,
        "actual_hot_route": actual_hot_route,
        "hot_score": hot_result.get("score", 0),
        "ok": shelf_ok and hot_ok,
    }


def main() -> int:
    args = parse_args()
    cases_path = Path(args.cases).expanduser().resolve() if args.cases.strip() else default_cases_path()
    cases_index = json.loads(cases_path.read_text(encoding="utf-8"))
    shelf_index = route_shelf.load_index()
    hot_index = route_hot.load_routes()

    results = [evaluate_case(case, shelf_index, hot_index) for case in cases_index.get("cases", [])]
    failures = [item for item in results if not item["ok"]]
    report = {
        "case_count": len(results),
        "failure_count": len(failures),
        "results": results,
        "ok": not failures,
    }

    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print("Activation Eval")
        print(f"- case_count: {len(results)}")
        print(f"- failure_count: {len(failures)}")
        for item in results:
            status = "ok" if item["ok"] else "FAIL"
            print(
                f"- {status} {item['id']}: shelf={item['actual_shelf']} "
                f"hot={item['actual_hot_route'] or 'none'}"
            )
            if not item["ok"]:
                print(
                    f"  expected: shelf={item['expected_shelf']} "
                    f"hot={item['expected_hot_route'] or 'any'}"
                )
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
