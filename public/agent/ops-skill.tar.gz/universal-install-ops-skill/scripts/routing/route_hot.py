from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from skill_paths import skill_root

WORD_CHARS = r"0-9A-Za-zА-Яа-яЁё._+-"
STOPWORDS = {
    "a",
    "an",
    "and",
    "as",
    "be",
    "for",
    "in",
    "is",
    "it",
    "of",
    "on",
    "ops",
    "or",
    "reusable",
    "skill",
    "skills",
    "the",
    "this",
    "to",
    "use",
    "work",
    "works",
    "make",
    "в",
    "во",
    "на",
    "надо",
    "есть",
    "это",
    "этом",
    "тот",
    "том",
    "там",
    "что",
    "чтобы",
    "почему",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Pick a tiny hot route for a frequent task.")
    parser.add_argument("query", help="Task summary or user request.")
    parser.add_argument("--routes", default="", help="Optional hot-routes.json path.")
    parser.add_argument("--top", type=int, default=3, help="Number of routes to print.")
    parser.add_argument("--min-score", type=int, default=8, help="Minimum score for default results.")
    parser.add_argument("--show-zero", action="store_true", help="Show zero-score hot routes.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser.parse_args()


def default_routes_path() -> Path:
    return skill_root(__file__) / "references" / "hot-routes.json"


def load_routes(path: Path | None = None) -> dict[str, Any]:
    routes_path = path if path is not None else default_routes_path()
    return json.loads(routes_path.read_text(encoding="utf-8"))


def tokens(value: str) -> set[str]:
    return {
        part
        for part in re.split(rf"[^{WORD_CHARS}]+", value.lower())
        if len(part) >= 2 and part not in STOPWORDS
    }


def phrase_in_query(phrase: str, query: str) -> bool:
    if not phrase:
        return False
    pattern = rf"(?<![{WORD_CHARS}]){re.escape(phrase)}(?![{WORD_CHARS}])"
    return re.search(pattern, query, flags=re.IGNORECASE) is not None


def score_route(query: str, query_tokens: set[str], route: dict[str, Any]) -> int:
    score = 0
    trigger_texts = [str(item).lower() for item in route.get("triggers", [])]
    haystack = " ".join(
        [
            str(route.get("id", "")),
            str(route.get("shelf", "")),
            " ".join(trigger_texts),
            " ".join(str(item) for item in route.get("steps", [])),
            str(route.get("verify", "")),
            str(route.get("fallback", "")),
        ]
    ).lower()
    query_lower = query.lower()
    matched_trigger_tokens: set[str] = set()
    for trigger in trigger_texts:
        trigger_tokens = tokens(trigger)
        if phrase_in_query(trigger, query_lower):
            score += 10 + len(trigger_tokens)
            continue
        overlap = query_tokens & trigger_tokens
        if overlap:
            matched_trigger_tokens.update(overlap)
    score += 3 * len(matched_trigger_tokens)
    for token in query_tokens:
        if token in haystack:
            score += 1
    return score


def rank_routes(
    query: str,
    routes_index: dict[str, Any],
    top: int = 3,
    min_score: int = 8,
    show_zero: bool = False,
) -> list[dict[str, Any]]:
    query_tokens = tokens(query)
    scored: list[dict[str, Any]] = []
    for route in routes_index.get("routes", []):
        if not isinstance(route, dict):
            continue
        scored.append(
            {
                "id": route.get("id", ""),
                "shelf": route.get("shelf", ""),
                "score": score_route(query, query_tokens, route),
                "steps": route.get("steps", []),
                "verify": route.get("verify", ""),
                "fallback": route.get("fallback", ""),
            }
        )
    scored.sort(key=lambda item: (-item["score"], item["id"]))
    if not show_zero:
        scored = [item for item in scored if int(item.get("score", 0)) >= min_score]
    return scored[: max(1, top)]


def main() -> int:
    args = parse_args()
    routes_path = Path(args.routes).expanduser().resolve() if args.routes.strip() else default_routes_path()
    routes_index = load_routes(routes_path)
    result = rank_routes(args.query, routes_index, top=args.top, min_score=args.min_score, show_zero=args.show_zero)

    if args.json:
        print(json.dumps({"query": args.query, "routes": result}, indent=2, ensure_ascii=False))
        return 0

    print(f"query: {args.query}")
    if not result:
        print("- no hot route matched")
        return 0
    for item in result:
        print(f"- {item['id']} shelf={item['shelf']} score={item['score']}")
        for step in item["steps"]:
            print(f"  step: {step}")
        if item["verify"]:
            print(f"  verify: {item['verify']}")
        if item["fallback"]:
            print(f"  fallback: {item['fallback']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
