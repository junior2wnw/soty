from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from skill_paths import skill_root

STOPWORDS = {
    "a",
    "an",
    "and",
    "as",
    "be",
    "for",
    "in",
    "is",
    "it",
    "of",
    "on",
    "ops",
    "or",
    "the",
    "this",
    "to",
    "use",
    "work",
    "works",
}

SHELF_TIE_PRIORITY = {
    "control-surfaces": 0,
    "package-service-stack": 0,
    "windows-reinstall-recovery": 0,
    "device-firmware-media": 0,
    "mobile-linux-porting": 0,
    "network-return-path": 0,
    "risk-security-rollback": 0,
    "general-routing": 5,
    "skill-tool-factory": 8,
    "learning-memory": 9,
    "agent-runtime-skill-ops": 12,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Pick the most relevant knowledge shelf for a task.")
    parser.add_argument("query", help="Task summary or user request.")
    parser.add_argument("--index", default="", help="Optional shelf-index.json path.")
    parser.add_argument("--top", type=int, default=3, help="Number of shelves to print.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser.parse_args()


def default_index_path() -> Path:
    return skill_root(__file__) / "references" / "shelf-index.json"


def load_index(path: Path | None = None) -> dict[str, Any]:
    index_path = path if path is not None else default_index_path()
    return json.loads(index_path.read_text(encoding="utf-8"))


def tokens(value: str) -> set[str]:
    return {
        part
        for part in re.split(r"[^0-9A-Za-zА-Яа-яЁё._+-]+", value.lower())
        if len(part) >= 2 and part not in STOPWORDS
    }


def shelves_with_aliases(index: dict[str, Any]) -> list[dict[str, Any]]:
    shelves = [dict(shelf) for shelf in index.get("shelves", []) if isinstance(shelf, dict)]
    by_id = {str(shelf.get("id", "")): shelf for shelf in shelves}
    aliases = index.get("aliases", {})
    if isinstance(aliases, dict):
        for alias, target in aliases.items():
            target_shelf = by_id.get(str(target))
            if not target_shelf:
                continue
            keywords = list(target_shelf.get("keywords", []))
            keywords.append(str(alias))
            target_shelf["keywords"] = keywords
    return shelves


def score_shelf(query: str, query_tokens: set[str], shelf: dict[str, Any]) -> int:
    score = 0
    haystack = " ".join(
        [
            str(shelf.get("id", "")),
            str(shelf.get("when", "")),
            " ".join(str(item) for item in shelf.get("keywords", [])),
        ]
    ).lower()
    for keyword in shelf.get("keywords", []):
        keyword_text = str(keyword).lower()
        keyword_tokens = tokens(keyword_text)
        if keyword_text and keyword_text in query.lower():
            score += 8 + len(keyword_tokens)
            continue
        overlap = query_tokens & keyword_tokens
        if overlap:
            score += 2 * len(overlap)
    for token in query_tokens:
        if token in haystack:
            score += 1
    return score


def rank_shelves(query: str, index: dict[str, Any], top: int = 3) -> list[dict[str, Any]]:
    query_tokens = tokens(query)
    scored = []
    for shelf in shelves_with_aliases(index):
        scored.append(
            {
                "id": shelf.get("id", ""),
                "score": score_shelf(query, query_tokens, shelf),
                "when": shelf.get("when", ""),
                "read": shelf.get("read", []),
                "scripts": shelf.get("scripts", []),
            }
        )
    default_id = index.get("default_shelf", "general-routing")
    scored.sort(key=lambda item: (-item["score"], SHELF_TIE_PRIORITY.get(str(item["id"]), 6), item["id"]))
    if scored and scored[0]["score"] <= 0:
        for item in scored:
            if item["id"] == default_id:
                item["score"] = 1
        scored.sort(key=lambda item: (-item["score"], SHELF_TIE_PRIORITY.get(str(item["id"]), 6), item["id"]))
    return scored[: max(1, top)]


def main() -> int:
    args = parse_args()
    index_path = Path(args.index).expanduser().resolve() if args.index.strip() else default_index_path()
    index = load_index(index_path)
    result = rank_shelves(args.query, index, top=args.top)

    if args.json:
        print(json.dumps({"query": args.query, "shelves": result}, indent=2, ensure_ascii=False))
        return 0

    print(f"query: {args.query}")
    for item in result:
        print(f"- {item['id']} score={item['score']}")
        if item["read"]:
            print(f"  read: {', '.join(item['read'])}")
        if item["scripts"]:
            print(f"  scripts: {', '.join(item['scripts'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
