from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

RISKY_STATUSES = {"ready", "armed", "executing", "observing"}
RISKY_INTENTS = {
    "install",
    "reinstall",
    "repair",
    "recover",
    "reset",
    "flash",
    "image",
    "wipe",
    "migrate",
    "prepare_media",
    "update",
    "upgrade",
    "downgrade",
    "configure",
}
HIGH_BLAST_RADIUS_INTENTS = {
    "install",
    "reinstall",
    "recover",
    "reset",
    "flash",
    "image",
    "wipe",
    "migrate",
    "prepare_media",
    "upgrade",
    "downgrade",
}
HIGH_BLAST_RADIUS_TARGET_KINDS = {
    "os",
    "firmware",
    "media",
    "recovery_environment",
    "driver",
    "network",
    "cloud",
    "database",
    "storage",
    "vm",
    "hypervisor",
    "virtualization",
    "cluster",
    "orchestrator",
    "container_stack",
    "service_stack",
    "bootloader",
    "package_source",
    "certificate",
    "identity",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate an install-ops case journal before risky transitions or close-out.",
    )
    parser.add_argument("case", help="Path to a case directory or case.json.")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Fail on warnings that block destructive, rebooting, production, network, or trust-affecting work.",
    )
    return parser.parse_args()


def load_case(path_text: str) -> tuple[Path, dict[str, Any]]:
    path = Path(path_text).expanduser().resolve()
    case_json = path / "case.json" if path.is_dir() else path
    if not case_json.exists():
        raise FileNotFoundError(f"case.json was not found: {case_json}")
    data = json.loads(case_json.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("case.json must contain a JSON object.")
    return case_json, data


def has_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set, dict)):
        return bool(value)
    return True


def nested(data: dict[str, Any], *keys: str) -> Any:
    current: Any = data
    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def is_risky_case(data: dict[str, Any]) -> bool:
    status = str(data.get("status", "")).strip().lower()
    intent = str(data.get("intent", "")).strip().lower()
    target_kind = str(data.get("target_kind", "")).strip().lower()
    destructive_scope = data.get("destructive_scope")
    artifact_provenance = data.get("artifact_provenance")
    network_or_media = nested(data, "environment", "network_or_media_constraints")
    return any(
        [
            status in RISKY_STATUSES,
            intent in RISKY_INTENTS,
            target_kind in HIGH_BLAST_RADIUS_TARGET_KINDS,
            has_value(destructive_scope),
            has_value(artifact_provenance),
            has_value(network_or_media),
        ]
    )


def needs_hard_gate(data: dict[str, Any]) -> bool:
    status = str(data.get("status", "")).strip().lower()
    intent = str(data.get("intent", "")).strip().lower()
    target_kind = str(data.get("target_kind", "")).strip().lower()
    destructive_scope = data.get("destructive_scope")
    artifact_provenance = data.get("artifact_provenance")
    network_or_media = nested(data, "environment", "network_or_media_constraints")
    return any(
        [
            status in {"armed", "executing"},
            intent in HIGH_BLAST_RADIUS_INTENTS,
            target_kind in HIGH_BLAST_RADIUS_TARGET_KINDS,
            has_value(destructive_scope),
            has_value(artifact_provenance),
            has_value(network_or_media),
        ]
    )


def add_missing(messages: list[str], data: dict[str, Any], field: str, label: str | None = None) -> None:
    if not has_value(data.get(field)):
        messages.append(label or field)


def validate(data: dict[str, Any], strict: bool) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    for field in ["title", "status", "current_phase", "phases", "environment", "paths"]:
        add_missing(errors, data, field)

    environment = data.get("environment")
    if not isinstance(environment, dict):
        errors.append("environment must be an object")
    else:
        for field in ["transport_now", "transport_next"]:
            if not has_value(environment.get(field)):
                warnings.append(f"environment.{field}")

    route_selection = data.get("route_selection")
    if not isinstance(route_selection, dict):
        warnings.append("route_selection must be an object")
    else:
        if not has_value(route_selection.get("primary")):
            warnings.append("route_selection.primary")
        if not has_value(route_selection.get("evidence_quality")):
            warnings.append("route_selection.evidence_quality")

    if not has_value(data.get("last_verified_fact")):
        warnings.append("last_verified_fact")

    decision_facts = data.get("decision_facts")
    if decision_facts is None:
        warnings.append("decision_facts")
        decision_facts_list: list[Any] = []
    elif not isinstance(decision_facts, list):
        warnings.append("decision_facts must be a list")
        decision_facts_list = []
    else:
        decision_facts_list = decision_facts

    weighted_summary = data.get("weighted_fact_summary")
    if weighted_summary is None:
        warnings.append("weighted_fact_summary")
    elif not isinstance(weighted_summary, dict):
        warnings.append("weighted_fact_summary must be an object")

    control_facts = data.get("control_facts")
    if control_facts is not None and not isinstance(control_facts, list):
        warnings.append("control_facts must be a list")
        control_facts_list: list[Any] = []
    elif isinstance(control_facts, list):
        control_facts_list = control_facts
    else:
        control_facts_list = []

    control_summary = data.get("control_fact_summary")
    if control_summary is not None and not isinstance(control_summary, dict):
        warnings.append("control_fact_summary must be an object")

    route_properties = data.get("route_properties")
    if route_properties is not None and not isinstance(route_properties, list):
        warnings.append("route_properties must be a list")
        route_properties_list: list[Any] = []
    elif isinstance(route_properties, list):
        route_properties_list = route_properties
    else:
        route_properties_list = []

    route_property_summary = data.get("route_property_summary")
    if route_property_summary is not None and not isinstance(route_property_summary, dict):
        warnings.append("route_property_summary must be an object")

    risky = is_risky_case(data)
    if risky or strict:
        for field in [
            "active_owner",
            "allowed_next_state_change",
            "handoff_proof",
            "return_path",
            "rollback_route",
            "abort_triggers",
        ]:
            add_missing(warnings, data, field)
        if not has_value(data.get("artifact_provenance")):
            warnings.append("artifact_provenance")
        if not decision_facts_list:
            warnings.append("decision_facts")
        else:
            has_scored_fact = False
            has_useful_fact = False
            has_hard_gate = False
            for fact in decision_facts_list:
                if not isinstance(fact, dict):
                    warnings.append("decision_facts item must be an object")
                    continue
                if not has_value(fact.get("statement")):
                    warnings.append("decision_facts.statement")
                if not has_value(fact.get("scope")):
                    warnings.append("decision_facts.scope")
                if not has_value(fact.get("evidence_quality")):
                    warnings.append("decision_facts.evidence_quality")
                computed_weight = fact.get("computed_weight")
                if isinstance(computed_weight, (int, float)):
                    has_scored_fact = True
                    if computed_weight >= 55:
                        has_useful_fact = True
                        scope = str(fact.get("scope", "")).strip().lower()
                        if scope in {"platform-or-family", "universal-pattern"} and not has_value(
                            fact.get("shared_dimensions")
                        ):
                            warnings.append("decision_facts.shared_dimensions")
                        polarity = str(fact.get("polarity", "")).strip().lower()
                        target_fit = str(fact.get("target_fit", "")).strip().lower()
                        if (
                            polarity == "blocks"
                            and target_fit != "exact"
                            and scope in {"platform-or-family", "universal-pattern", "case-local"}
                            and not has_value(fact.get("divergent_dimensions"))
                        ):
                            warnings.append("decision_facts.divergent_dimensions")
                if str(fact.get("scope", "")).strip().lower() == "hard-gate":
                    has_hard_gate = True
            if not has_scored_fact:
                warnings.append("decision_facts.computed_weight")
            if not has_useful_fact:
                warnings.append("decision_facts.computed_weight>=55")
            if needs_hard_gate(data) and not has_hard_gate:
                warnings.append("decision_facts.hard-gate")
        if isinstance(weighted_summary, dict):
            route_status = str(weighted_summary.get("route_status", "")).strip().lower()
            if not route_status:
                warnings.append("weighted_fact_summary.route_status")
            elif route_status in {"blocked", "contested", "unproven"}:
                warnings.append(f"weighted_fact_summary.route_status={route_status}")

    if control_facts_list:
        has_scored_control = False
        for fact in control_facts_list:
            if not isinstance(fact, dict):
                warnings.append("control_facts item must be an object")
                continue
            for field in ["action", "target", "control_plane", "method", "observable_success", "result"]:
                if not has_value(fact.get(field)):
                    warnings.append(f"control_facts.{field}")
            surface_score = fact.get("surface_score")
            if isinstance(surface_score, (int, float)):
                has_scored_control = True
                scope = str(fact.get("scope", "")).strip().lower()
                result = str(fact.get("result", "")).strip().lower()
                target_fit = str(fact.get("target_fit", "")).strip().lower()
                if (
                    result in {"works", "partial", "conflicts"}
                    and scope in {"platform-or-family", "universal-pattern"}
                    and float(surface_score) >= 25
                    and not has_value(fact.get("shared_dimensions"))
                ):
                    warnings.append("control_facts.shared_dimensions")
                if (
                    result in {"blocked", "partial", "conflicts"}
                    and target_fit != "exact"
                    and scope in {"platform-or-family", "universal-pattern", "case-local"}
                    and float(surface_score) >= 25
                    and not has_value(fact.get("divergent_dimensions"))
                ):
                    warnings.append("control_facts.divergent_dimensions")
        if not has_scored_control:
            warnings.append("control_facts.surface_score")

    if route_properties_list:
        has_scored_property = False
        for prop in route_properties_list:
            if not isinstance(prop, dict):
                warnings.append("route_properties item must be an object")
                continue
            for field in ["name", "expected_value", "chance", "scope", "evidence_quality"]:
                if not has_value(prop.get(field)):
                    warnings.append(f"route_properties.{field}")
            adjusted_chance = prop.get("adjusted_chance")
            if isinstance(adjusted_chance, (int, float)):
                has_scored_property = True
            result = str(prop.get("result", "")).strip().lower()
            if result == "unchecked" and not has_value(prop.get("probe")):
                warnings.append("route_properties.probe")
            scope = str(prop.get("scope", "")).strip().lower()
            if (
                scope in {"platform-or-family", "universal-pattern"}
                and has_value(prop.get("route_when_expected"))
                and not has_value(prop.get("shared_dimensions"))
            ):
                warnings.append("route_properties.shared_dimensions")
            if (
                result == "disconfirmed"
                and scope in {"platform-or-family", "universal-pattern", "case-local"}
                and str(prop.get("target_fit", "")).strip().lower() != "exact"
                and not has_value(prop.get("divergent_dimensions"))
            ):
                warnings.append("route_properties.divergent_dimensions")
        if not has_scored_property:
            warnings.append("route_properties.adjusted_chance")

    if strict:
        errors.extend(f"strict missing: {warning}" for warning in warnings)
        warnings = []

    return errors, warnings


def main() -> int:
    args = parse_args()
    case_json, data = load_case(args.case)
    errors, warnings = validate(data, args.strict)

    print(f"case: {case_json}")
    if errors:
        print("errors:")
        for item in errors:
            print(f"- {item}")
    if warnings:
        print("warnings:")
        for item in warnings:
            print(f"- {item}")
    if not errors and not warnings:
        print("ok")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
