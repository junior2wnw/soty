from __future__ import annotations

import argparse
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

EVIDENCE_QUALITY_WEIGHTS = {
    "live-observed": 1.00,
    "primary-source": 0.95,
    "case-observed": 0.85,
    "maintainer-or-community": 0.70,
    "user-reported": 0.60,
    "inferred": 0.40,
    "stale": 0.25,
}

SCOPE_WEIGHTS = {
    "hard-gate": 1.00,
    "exact-target": 0.95,
    "platform-or-family": 0.75,
    "universal-pattern": 0.65,
    "case-local": 0.60,
    "hypothesis": 0.30,
}

FRESHNESS_WEIGHTS = {
    "current": 1.00,
    "recent": 0.85,
    "stale": 0.50,
    "unknown": 0.65,
}

TARGET_FIT_WEIGHTS = {
    "exact": 1.00,
    "same-family": 0.85,
    "analogous": 0.60,
    "weak": 0.35,
    "unknown": 0.50,
}

GOAL_FIT_WEIGHTS = {
    "controlling": 1.00,
    "direct": 0.90,
    "supporting": 0.70,
    "weak": 0.40,
    "unknown": 0.50,
}

POLARITY_VALUES = {"supports", "blocks", "caution", "unknown"}

CONTROL_RESULT_MULTIPLIERS = {
    "works": 1.00,
    "blocked": 0.95,
    "partial": 0.80,
    "conflicts": 0.78,
    "unknown": 0.60,
}

CONTROL_FRICTION_WEIGHTS = {
    "low": 1.00,
    "medium": 0.88,
    "high": 0.72,
    "unknown": 0.80,
}

ROUTE_PROPERTY_RESULTS = {"unchecked", "confirmed", "disconfirmed", "unknown"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Score weighted decision facts in an install-ops case journal.",
    )
    parser.add_argument("case", help="Path to a case directory or case.json.")
    parser.add_argument("--write", action="store_true", help="Write computed weights and summary back to case.json.")
    return parser.parse_args()


def load_case(path_text: str) -> tuple[Path, dict[str, Any]]:
    path = Path(path_text).expanduser().resolve()
    case_json = path / "case.json" if path.is_dir() else path
    data = json.loads(case_json.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("case.json must contain a JSON object.")
    return case_json, data


def value_weight(mapping: dict[str, float], value: Any, default: float) -> float:
    if not isinstance(value, str):
        return default
    return mapping.get(value.strip().lower(), default)


def classify(weight: float) -> str:
    if weight >= 85:
        return "very-strong"
    if weight >= 65:
        return "strong"
    if weight >= 45:
        return "medium"
    if weight >= 25:
        return "weak"
    return "very-weak"


def normalized_text(value: Any, default: str = "") -> str:
    if not isinstance(value, str):
        return default
    collapsed = " ".join(value.split())
    return collapsed.strip().lower() or default


def normalized_dimensions(value: Any) -> list[str]:
    parts: list[str] = []
    if isinstance(value, list):
        for item in value:
            if isinstance(item, str):
                parts.extend(re.split(r"[;,]", item))
    elif isinstance(value, str):
        parts.extend(re.split(r"[;,]", value))

    cleaned: list[str] = []
    for part in parts:
        collapsed = " ".join(part.split()).strip().lower()
        if collapsed and collapsed not in cleaned:
            cleaned.append(collapsed)
    return cleaned


def positive_int(value: Any, default: int = 1) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default


def control_result(value: Any) -> str:
    normalized = normalized_text(value, "unknown")
    if normalized in CONTROL_RESULT_MULTIPLIERS:
        return normalized
    return "unknown"


def control_polarity(result: str) -> str:
    if result == "works":
        return "supports"
    if result == "blocked":
        return "blocks"
    if result in {"partial", "conflicts"}:
        return "caution"
    return "unknown"


def step_multiplier(step_count: int) -> float:
    if step_count <= 1:
        return 1.00
    if step_count == 2:
        return 0.95
    if step_count == 3:
        return 0.90
    if step_count == 4:
        return 0.82
    return 0.72


def build_control_marker(fact: dict[str, Any]) -> str:
    parts = [
        f"action={fact.get('action', '')}",
        f"target={fact.get('target', '')}",
        f"plane={fact.get('control_plane', '')}",
        f"result={fact.get('result', '')}",
        f"method={fact.get('method', '')}",
        f"success={fact.get('observable_success', '')}",
    ]
    shared_dimensions = fact.get("shared_dimensions")
    if isinstance(shared_dimensions, list) and shared_dimensions:
        parts.append(f"shared={', '.join(shared_dimensions)}")
    divergent_dimensions = fact.get("divergent_dimensions")
    if isinstance(divergent_dimensions, list) and divergent_dimensions:
        parts.append(f"diff={', '.join(divergent_dimensions)}")
    return "control-memory: " + " | ".join(parts)


def weight_components(fact: dict[str, Any]) -> dict[str, Any]:
    evidence_quality = normalized_text(fact.get("evidence_quality"), "unknown")
    scope = normalized_text(fact.get("scope"), "unknown")
    freshness = normalized_text(fact.get("freshness"), "unknown")
    target_fit = normalized_text(fact.get("target_fit"), "unknown")
    goal_fit = normalized_text(fact.get("goal_fit"), "unknown")
    polarity = normalized_text(fact.get("polarity"), "unknown")
    if polarity not in POLARITY_VALUES:
        polarity = "unknown"

    evidence_weight = value_weight(EVIDENCE_QUALITY_WEIGHTS, evidence_quality, 0.50)
    scope_weight = value_weight(SCOPE_WEIGHTS, scope, 0.50)
    freshness_weight = value_weight(FRESHNESS_WEIGHTS, freshness, 0.65)
    target_fit_weight = value_weight(TARGET_FIT_WEIGHTS, target_fit, 0.50)
    goal_fit_weight = value_weight(GOAL_FIT_WEIGHTS, goal_fit, 0.50)

    return {
        "evidence_quality": evidence_quality,
        "scope": scope,
        "freshness": freshness,
        "target_fit": target_fit,
        "goal_fit": goal_fit,
        "polarity": polarity,
        "evidence_quality_weight": evidence_weight,
        "scope_weight": scope_weight,
        "freshness_weight": freshness_weight,
        "target_fit_weight": target_fit_weight,
        "goal_fit_weight": goal_fit_weight,
    }


def score_fact(fact: dict[str, Any]) -> dict[str, Any]:
    components = weight_components(fact)
    evidence_weight = components["evidence_quality_weight"]
    scope_weight = components["scope_weight"]
    freshness_weight = components["freshness_weight"]
    target_fit_weight = components["target_fit_weight"]
    goal_fit_weight = components["goal_fit_weight"]

    computed_weight = round(
        evidence_weight * scope_weight * freshness_weight * target_fit_weight * goal_fit_weight * 100,
        2,
    )
    fact["scope"] = components["scope"]
    fact["evidence_quality"] = components["evidence_quality"]
    fact["freshness"] = components["freshness"]
    fact["target_fit"] = components["target_fit"]
    fact["goal_fit"] = components["goal_fit"]
    fact["polarity"] = components["polarity"]
    fact["shared_dimensions"] = normalized_dimensions(fact.get("shared_dimensions"))
    fact["divergent_dimensions"] = normalized_dimensions(fact.get("divergent_dimensions"))
    fact["weight_components"] = {
        "evidence_quality": evidence_weight,
        "scope": scope_weight,
        "freshness": freshness_weight,
        "target_fit": target_fit_weight,
        "goal_fit": goal_fit_weight,
    }
    fact["computed_weight"] = computed_weight
    fact["computed_label"] = classify(computed_weight)
    return fact


def score_control_fact(fact: dict[str, Any]) -> dict[str, Any]:
    result = control_result(fact.get("result"))
    friction = normalized_text(fact.get("friction"), "unknown")
    if friction not in CONTROL_FRICTION_WEIGHTS:
        friction = "unknown"
    step_count = positive_int(fact.get("step_count"), 1)
    base_fact = score_fact(
        {
            "statement": normalized_text(fact.get("method"), ""),
            "scope": fact.get("scope"),
            "evidence_quality": fact.get("evidence_quality"),
            "freshness": fact.get("freshness"),
            "target_fit": fact.get("target_fit"),
            "goal_fit": fact.get("goal_fit"),
            "polarity": control_polarity(result),
            "shared_dimensions": fact.get("shared_dimensions"),
            "divergent_dimensions": fact.get("divergent_dimensions"),
        }
    )
    base_weight = float(base_fact.get("computed_weight", 0.0))
    result_multiplier = CONTROL_RESULT_MULTIPLIERS.get(result, CONTROL_RESULT_MULTIPLIERS["unknown"])
    friction_weight = CONTROL_FRICTION_WEIGHTS.get(friction, CONTROL_FRICTION_WEIGHTS["unknown"])
    steps_weight = step_multiplier(step_count)
    surface_score = round(base_weight * result_multiplier * friction_weight * steps_weight, 2)

    fact["action"] = normalized_text(fact.get("action"), "")
    fact["target"] = normalized_text(fact.get("target"), "")
    fact["control_plane"] = normalized_text(fact.get("control_plane"), "")
    fact["method"] = normalized_text(fact.get("method"), "")
    fact["observable_success"] = normalized_text(fact.get("observable_success"), "")
    fact["result"] = result
    fact["friction"] = friction
    fact["step_count"] = step_count
    fact["scope"] = base_fact["scope"]
    fact["evidence_quality"] = base_fact["evidence_quality"]
    fact["freshness"] = base_fact["freshness"]
    fact["target_fit"] = base_fact["target_fit"]
    fact["goal_fit"] = base_fact["goal_fit"]
    fact["polarity"] = base_fact["polarity"]
    fact["shared_dimensions"] = normalized_dimensions(fact.get("shared_dimensions"))
    fact["divergent_dimensions"] = normalized_dimensions(fact.get("divergent_dimensions"))
    fact["computed_weight"] = round(base_weight, 2)
    fact["computed_label"] = classify(base_weight)
    fact["surface_score"] = surface_score
    fact["surface_label"] = classify(surface_score)
    fact["weight_components"] = base_fact["weight_components"]
    fact["surface_components"] = {
        "result": result_multiplier,
        "friction": friction_weight,
        "step_count": steps_weight,
    }
    fact["chat_marker"] = build_control_marker(fact)
    return fact


def clamp_float(value: float, low: float, high: float) -> float:
    return min(max(value, low), high)


def route_property_chance(value: Any, default: float = 0.50) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return default
    if parsed > 1:
        parsed = parsed / 100.0
    return round(clamp_float(parsed, 0.0, 1.0), 4)


def compact_casefold(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return " ".join(value.split()).strip().casefold()


def route_property_result(prop: dict[str, Any]) -> str:
    explicit = normalized_text(prop.get("result"), "")
    if explicit in ROUTE_PROPERTY_RESULTS and explicit != "unchecked":
        return explicit

    observed = prop.get("observed_value")
    if observed is None or (isinstance(observed, str) and not observed.strip()):
        return "unchecked"

    expected = prop.get("expected_value")
    if compact_casefold(observed) == compact_casefold(expected):
        return "confirmed"
    return "disconfirmed"


def route_property_decision(result: str, adjusted_chance: float, prop: dict[str, Any]) -> str:
    expected_route = " ".join(str(prop.get("route_when_expected", "")).split()).strip()
    unexpected_route = " ".join(str(prop.get("route_when_unexpected", "")).split()).strip()
    probe = " ".join(str(prop.get("probe", "")).split()).strip()
    if result == "confirmed":
        return expected_route or "use-expected-route"
    if result == "disconfirmed":
        return unexpected_route or "use-unexpected-route"
    if adjusted_chance >= 0.65:
        return expected_route or "start-with-expected-route"
    if adjusted_chance <= 0.35:
        return unexpected_route or "start-with-unexpected-route"
    if probe:
        return "probe: " + probe
    return "collect-current-observation"


def score_route_property(prop: dict[str, Any]) -> dict[str, Any]:
    name = normalized_text(prop.get("name"), "")
    expected_value = " ".join(str(prop.get("expected_value", "")).split()).strip()
    observed_value = prop.get("observed_value")
    if isinstance(observed_value, str):
        observed_value = " ".join(observed_value.split()).strip()
    elif observed_value is None:
        observed_value = ""
    else:
        observed_value = str(observed_value)

    base_fact = score_fact(
        {
            "statement": name or expected_value,
            "scope": prop.get("scope"),
            "evidence_quality": prop.get("evidence_quality"),
            "freshness": prop.get("freshness"),
            "target_fit": prop.get("target_fit"),
            "goal_fit": prop.get("goal_fit"),
            "polarity": "supports",
            "shared_dimensions": prop.get("shared_dimensions"),
            "divergent_dimensions": prop.get("divergent_dimensions"),
        }
    )
    evidence_strength = round(float(base_fact.get("computed_weight", 0.0)) / 100.0, 4)
    prior = route_property_chance(prop.get("chance"), 0.50)
    result = route_property_result(prop)
    if result == "confirmed":
        adjusted = prior + ((1.0 - prior) * evidence_strength)
    elif result == "disconfirmed":
        adjusted = prior * (1.0 - evidence_strength)
    elif result == "unknown":
        adjusted = prior * 0.75
    else:
        adjusted = prior * evidence_strength
    adjusted = round(clamp_float(adjusted, 0.0, 1.0), 4)

    prop["name"] = name
    prop["expected_value"] = expected_value
    prop["observed_value"] = observed_value
    prop["result"] = result
    prop["chance"] = prior
    prop["evidence_weight"] = round(float(base_fact.get("computed_weight", 0.0)), 2)
    prop["adjusted_chance"] = adjusted
    prop["chance_percent"] = round(adjusted * 100, 2)
    prop["computed_label"] = classify(adjusted * 100)
    prop["scope"] = base_fact["scope"]
    prop["evidence_quality"] = base_fact["evidence_quality"]
    prop["freshness"] = base_fact["freshness"]
    prop["target_fit"] = base_fact["target_fit"]
    prop["goal_fit"] = base_fact["goal_fit"]
    prop["shared_dimensions"] = normalized_dimensions(prop.get("shared_dimensions"))
    prop["divergent_dimensions"] = normalized_dimensions(prop.get("divergent_dimensions"))
    prop["weight_components"] = base_fact["weight_components"]
    prop["route_decision"] = route_property_decision(result, adjusted, prop)
    return prop


def fact_sort_key(fact: dict[str, Any]) -> tuple[float, float, float, float, float, float]:
    components = fact.get("weight_components")
    if not isinstance(components, dict):
        score_fact(fact)
        components = fact.get("weight_components", {})
    scope_is_hard_gate = 1.0 if str(fact.get("scope", "")).strip().lower() == "hard-gate" else 0.0
    return (
        scope_is_hard_gate,
        float(components.get("freshness", 0.0)),
        float(components.get("target_fit", 0.0)),
        float(components.get("evidence_quality", 0.0)),
        float(components.get("goal_fit", 0.0)),
        float(fact.get("computed_weight", 0.0)),
    )


def sort_facts(facts: list[dict[str, Any]]) -> None:
    facts.sort(key=fact_sort_key, reverse=True)


def control_fact_sort_key(fact: dict[str, Any]) -> tuple[float, float, float, float, float, int, float]:
    components = fact.get("weight_components")
    if not isinstance(components, dict):
        score_control_fact(fact)
        components = fact.get("weight_components", {})
    surface_components = fact.get("surface_components")
    if not isinstance(surface_components, dict):
        score_control_fact(fact)
        surface_components = fact.get("surface_components", {})
    return (
        float(fact.get("surface_score", 0.0)),
        float(components.get("freshness", 0.0)),
        float(components.get("target_fit", 0.0)),
        float(components.get("goal_fit", 0.0)),
        float(components.get("evidence_quality", 0.0)),
        -positive_int(fact.get("step_count"), 1),
        float(surface_components.get("friction", 0.0)),
    )


def sort_control_facts(facts: list[dict[str, Any]]) -> None:
    facts.sort(key=control_fact_sort_key, reverse=True)


def route_property_sort_key(prop: dict[str, Any]) -> tuple[float, float, float, float]:
    if "adjusted_chance" not in prop:
        score_route_property(prop)
    result_rank = {
        "confirmed": 3.0,
        "disconfirmed": 3.0,
        "unknown": 1.0,
        "unchecked": 0.0,
    }.get(str(prop.get("result", "")).strip().lower(), 0.0)
    adjusted = float(prop.get("adjusted_chance", 0.0))
    distance_from_undecided = abs(adjusted - 0.5)
    return (
        result_rank,
        distance_from_undecided,
        float(prop.get("evidence_weight", 0.0)),
        adjusted,
    )


def sort_route_properties(properties: list[dict[str, Any]]) -> None:
    properties.sort(key=route_property_sort_key, reverse=True)


def review_flags(
    supporting: list[dict[str, Any]],
    cautions: list[dict[str, Any]],
    blocking: list[dict[str, Any]],
) -> list[str]:
    flags: list[str] = []
    top_support = supporting[0] if supporting else None
    top_caution = cautions[0] if cautions else None
    top_block = blocking[0] if blocking else None

    if not top_support:
        flags.append("no-supporting-facts")
    else:
        support_weight = float(top_support.get("computed_weight", 0))
        if support_weight < 45:
            flags.append("best-support-is-weak")
        if str(top_support.get("freshness", "")).strip().lower() in {"stale", "unknown"}:
            flags.append("best-support-is-not-fresh")
        if str(top_support.get("target_fit", "")).strip().lower() in {"analogous", "weak", "unknown"}:
            flags.append("best-support-is-not-close-target-fit")

    if top_block:
        block_weight = float(top_block.get("computed_weight", 0))
        support_weight = float(top_support.get("computed_weight", 0)) if top_support else 0.0
        if block_weight >= max(support_weight, 45):
            flags.append("blocking-fact-competes-with-route")

    if top_caution and float(top_caution.get("computed_weight", 0)) >= 45:
        flags.append("meaningful-caution-present")

    transfer_support = [
        fact
        for fact in [*supporting, *cautions]
        if str(fact.get("scope", "")).strip().lower() in {"platform-or-family", "universal-pattern"}
        and float(fact.get("computed_weight", 0)) >= 25
    ]
    if any(not fact.get("shared_dimensions") for fact in transfer_support):
        flags.append("transfer-scope-missing-shared-dimensions")

    transfer_blocks = [
        fact
        for fact in blocking
        if str(fact.get("scope", "")).strip().lower() in {"platform-or-family", "universal-pattern", "case-local"}
        and str(fact.get("target_fit", "")).strip().lower() != "exact"
        and float(fact.get("computed_weight", 0)) >= 25
    ]
    if any(not fact.get("divergent_dimensions") for fact in transfer_blocks):
        flags.append("blocking-transfer-missing-divergent-dimensions")

    return flags


def recommended_actions(flags: list[str]) -> list[str]:
    action_map = {
        "unmet-hard-gate": "satisfy-hard-gate",
        "no-supporting-facts": "capture-controlling-support",
        "best-support-is-weak": "collect-stronger-evidence",
        "best-support-is-not-fresh": "collect-fresher-evidence",
        "best-support-is-not-close-target-fit": "confirm-target-fit",
        "blocking-fact-competes-with-route": "clear-blocker-or-change-route",
        "meaningful-caution-present": "resolve-caution-before-risky-step",
        "transfer-scope-missing-shared-dimensions": "record-shared-dimensions",
        "blocking-transfer-missing-divergent-dimensions": "record-divergent-dimensions",
    }
    actions: list[str] = []
    for flag in flags:
        action = action_map.get(flag)
        if action and action not in actions:
            actions.append(action)
    return actions


def route_status(
    supporting: list[dict[str, Any]],
    cautions: list[dict[str, Any]],
    blocking: list[dict[str, Any]],
    has_unmet_hard_gate: bool,
) -> str:
    if has_unmet_hard_gate:
        return "blocked"

    top_support = supporting[0] if supporting else None
    top_caution = cautions[0] if cautions else None
    top_block = blocking[0] if blocking else None
    support_weight = float(top_support.get("computed_weight", 0)) if top_support else 0.0
    caution_weight = float(top_caution.get("computed_weight", 0)) if top_caution else 0.0
    block_weight = float(top_block.get("computed_weight", 0)) if top_block else 0.0

    if block_weight >= max(support_weight, 65):
        return "contested"
    if support_weight >= 65 and block_weight < 45 and caution_weight < 45:
        return "supported"
    if support_weight >= 45 and block_weight < support_weight:
        return "tentative"
    return "unproven"


def build_summary(facts: list[dict[str, Any]]) -> dict[str, Any]:
    supporting = [
        fact
        for fact in facts
        if str(fact.get("polarity", "")).strip().lower() == "supports"
    ]
    cautions = [
        fact
        for fact in facts
        if str(fact.get("polarity", "")).strip().lower() == "caution"
    ]
    blocking = [
        fact
        for fact in facts
        if str(fact.get("polarity", "")).strip().lower() == "blocks"
    ]
    unknown = [
        fact
        for fact in facts
        if str(fact.get("polarity", "")).strip().lower() == "unknown"
    ]
    sort_facts(supporting)
    sort_facts(cautions)
    sort_facts(blocking)
    sort_facts(unknown)
    has_unmet_hard_gate = any(
        str(fact.get("scope", "")).strip().lower() == "hard-gate"
        and str(fact.get("polarity", "")).strip().lower() == "blocks"
        and float(fact.get("computed_weight", 0)) >= 25
        for fact in facts
    )
    flags = review_flags(supporting, cautions, blocking)
    if has_unmet_hard_gate and "unmet-hard-gate" not in flags:
        flags.insert(0, "unmet-hard-gate")
    return {
        "top_supporting": supporting[:3],
        "top_caution": cautions[:3],
        "top_blocking": blocking[:3],
        "top_unknown": unknown[:3],
        "has_unmet_hard_gate": has_unmet_hard_gate,
        "route_status": route_status(supporting, cautions, blocking, has_unmet_hard_gate),
        "review_flags": flags,
        "recommended_actions": recommended_actions(flags),
        "last_scored_at": datetime.now().astimezone().replace(microsecond=0).isoformat(),
    }


def control_review_flags(control_facts: list[dict[str, Any]]) -> list[str]:
    flags: list[str] = []
    working = [fact for fact in control_facts if str(fact.get("result", "")).strip().lower() == "works"]
    blocked = [fact for fact in control_facts if str(fact.get("result", "")).strip().lower() == "blocked"]
    caution = [
        fact for fact in control_facts if str(fact.get("result", "")).strip().lower() in {"partial", "conflicts"}
    ]

    if not working:
        flags.append("no-proven-control-route")

    transfer_support = [
        fact
        for fact in [*working, *caution]
        if str(fact.get("scope", "")).strip().lower() in {"platform-or-family", "universal-pattern"}
        and float(fact.get("surface_score", 0)) >= 25
    ]
    if any(not fact.get("shared_dimensions") for fact in transfer_support):
        flags.append("control-transfer-missing-shared-dimensions")

    transfer_blocks = [
        fact
        for fact in [*blocked, *caution]
        if str(fact.get("scope", "")).strip().lower() in {"platform-or-family", "universal-pattern", "case-local"}
        and str(fact.get("target_fit", "")).strip().lower() != "exact"
        and float(fact.get("surface_score", 0)) >= 25
    ]
    if any(not fact.get("divergent_dimensions") for fact in transfer_blocks):
        flags.append("control-transfer-missing-divergent-dimensions")

    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for fact in working:
        key = (str(fact.get("action", "")), str(fact.get("target", "")))
        grouped.setdefault(key, []).append(fact)
    for items in grouped.values():
        sort_control_facts(items)
        if len(items) < 2:
            continue
        best = items[0]
        alternate = items[1]
        score_gap = float(best.get("surface_score", 0.0)) - float(alternate.get("surface_score", 0.0))
        step_gap = positive_int(best.get("step_count"), 1) - positive_int(alternate.get("step_count"), 1)
        if score_gap <= 10 and step_gap >= 2:
            flags.append("comparable-control-route-has-fewer-steps")
            break

    return flags


def control_recommended_actions(flags: list[str]) -> list[str]:
    action_map = {
        "no-proven-control-route": "capture-working-control-route",
        "control-transfer-missing-shared-dimensions": "record-control-shared-dimensions",
        "control-transfer-missing-divergent-dimensions": "record-control-divergent-dimensions",
        "comparable-control-route-has-fewer-steps": "surface-lower-step-control-route",
    }
    actions: list[str] = []
    for flag in flags:
        action = action_map.get(flag)
        if action and action not in actions:
            actions.append(action)
    return actions


def build_control_summary(control_facts: list[dict[str, Any]]) -> dict[str, Any]:
    scored = [score_control_fact(fact) for fact in control_facts if isinstance(fact, dict)]
    if not scored:
        return {
            "top_surface_routes": [],
            "top_caution_routes": [],
            "top_blocked_routes": [],
            "best_by_action": [],
            "review_flags": [],
            "recommended_actions": [],
            "last_scored_at": datetime.now().astimezone().replace(microsecond=0).isoformat(),
        }
    working = [fact for fact in scored if fact["result"] == "works"]
    caution = [fact for fact in scored if fact["result"] in {"partial", "conflicts"}]
    blocked = [fact for fact in scored if fact["result"] == "blocked"]
    sort_control_facts(working)
    sort_control_facts(caution)
    sort_control_facts(blocked)

    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for fact in scored:
        key = (str(fact.get("action", "")), str(fact.get("target", "")))
        grouped.setdefault(key, []).append(fact)

    best_by_action: list[dict[str, Any]] = []
    for (action, target), items in grouped.items():
        sort_control_facts(items)
        best = items[0]
        alternates = [
            {
                "control_plane": item.get("control_plane", ""),
                "method": item.get("method", ""),
                "result": item.get("result", ""),
                "surface_score": item.get("surface_score", 0.0),
                "step_count": item.get("step_count", 1),
                "friction": item.get("friction", ""),
            }
            for item in items[1:3]
        ]
        best_by_action.append(
            {
                "action": action,
                "target": target,
                "best_control_plane": best.get("control_plane", ""),
                "best_method": best.get("method", ""),
                "best_result": best.get("result", ""),
                "best_surface_score": best.get("surface_score", 0.0),
                "best_observable_success": best.get("observable_success", ""),
                "step_count": best.get("step_count", 1),
                "friction": best.get("friction", ""),
                "shared_dimensions": best.get("shared_dimensions", []),
                "divergent_dimensions": best.get("divergent_dimensions", []),
                "chat_marker": best.get("chat_marker", ""),
                "alternates": alternates,
            }
        )
    best_by_action.sort(key=lambda item: float(item.get("best_surface_score", 0.0)), reverse=True)

    flags = control_review_flags(scored)
    return {
        "top_surface_routes": working[:5],
        "top_caution_routes": caution[:3],
        "top_blocked_routes": blocked[:3],
        "best_by_action": best_by_action[:8],
        "review_flags": flags,
        "recommended_actions": control_recommended_actions(flags),
        "last_scored_at": datetime.now().astimezone().replace(microsecond=0).isoformat(),
    }


def route_property_review_flags(properties: list[dict[str, Any]]) -> list[str]:
    flags: list[str] = []
    unchecked = [prop for prop in properties if prop.get("result") == "unchecked"]
    disconfirmed = [prop for prop in properties if prop.get("result") == "disconfirmed"]
    uncertain = [
        prop
        for prop in properties
        if prop.get("result") in {"unchecked", "unknown"}
        and 0.35 < float(prop.get("adjusted_chance", 0.0)) < 0.65
    ]
    missing_probe = [
        prop
        for prop in unchecked
        if not str(prop.get("probe", "")).strip()
    ]
    transfer_properties = [
        prop
        for prop in properties
        if str(prop.get("scope", "")).strip().lower() in {"platform-or-family", "universal-pattern"}
        and float(prop.get("adjusted_chance", 0.0)) >= 0.25
    ]
    transfer_disconfirmed = [
        prop
        for prop in disconfirmed
        if str(prop.get("scope", "")).strip().lower() in {"platform-or-family", "universal-pattern", "case-local"}
        and str(prop.get("target_fit", "")).strip().lower() != "exact"
    ]

    if unchecked:
        flags.append("route-property-needs-current-observation")
    if disconfirmed:
        flags.append("route-property-disconfirmed")
    if uncertain:
        flags.append("route-property-belief-uncertain")
    if missing_probe:
        flags.append("route-property-missing-probe")
    if any(not prop.get("shared_dimensions") for prop in transfer_properties):
        flags.append("route-property-transfer-missing-shared-dimensions")
    if any(not prop.get("divergent_dimensions") for prop in transfer_disconfirmed):
        flags.append("route-property-transfer-missing-divergent-dimensions")
    return flags


def route_property_recommended_actions(flags: list[str]) -> list[str]:
    action_map = {
        "route-property-needs-current-observation": "run-property-probe-before-risky-step",
        "route-property-disconfirmed": "switch-route-or-record-divergent-dimensions",
        "route-property-belief-uncertain": "collect-stronger-property-evidence",
        "route-property-missing-probe": "add-property-probe",
        "route-property-transfer-missing-shared-dimensions": "record-property-shared-dimensions",
        "route-property-transfer-missing-divergent-dimensions": "record-property-divergent-dimensions",
    }
    actions: list[str] = []
    for flag in flags:
        action = action_map.get(flag)
        if action and action not in actions:
            actions.append(action)
    return actions


def build_route_property_summary(properties: list[dict[str, Any]]) -> dict[str, Any]:
    scored = [score_route_property(prop) for prop in properties if isinstance(prop, dict)]
    likely_expected = [
        prop
        for prop in scored
        if prop["result"] == "confirmed" or float(prop.get("adjusted_chance", 0.0)) >= 0.65
    ]
    likely_unexpected = [
        prop
        for prop in scored
        if prop["result"] == "disconfirmed" or float(prop.get("adjusted_chance", 0.0)) <= 0.35
    ]
    needs_probe = [
        prop
        for prop in scored
        if prop["result"] in {"unchecked", "unknown"}
        and 0.35 < float(prop.get("adjusted_chance", 0.0)) < 0.65
    ]
    for group in [likely_expected, likely_unexpected, needs_probe]:
        sort_route_properties(group)
    route_hints = [
        {
            "name": prop.get("name", ""),
            "result": prop.get("result", ""),
            "adjusted_chance": prop.get("adjusted_chance", 0.0),
            "chance_percent": prop.get("chance_percent", 0.0),
            "route_decision": prop.get("route_decision", ""),
            "proof": prop.get("proof", ""),
        }
        for prop in sorted(scored, key=route_property_sort_key, reverse=True)[:8]
    ]
    flags = route_property_review_flags(scored)
    return {
        "top_likely_expected": likely_expected[:5],
        "top_likely_unexpected": likely_unexpected[:5],
        "needs_probe": needs_probe[:5],
        "route_hints": route_hints,
        "review_flags": flags,
        "recommended_actions": route_property_recommended_actions(flags),
        "last_scored_at": datetime.now().astimezone().replace(microsecond=0).isoformat(),
    }


def print_summary(case_json: Path, facts: list[dict[str, Any]], summary: dict[str, Any]) -> None:
    print(f"case: {case_json}")
    print("top_supporting:")
    if summary["top_supporting"]:
        for fact in summary["top_supporting"]:
            print(f"- {fact.get('computed_weight')}: {fact.get('statement', '')}")
    else:
        print("- none")
    print("top_caution:")
    if summary["top_caution"]:
        for fact in summary["top_caution"]:
            print(f"- {fact.get('computed_weight')}: {fact.get('statement', '')}")
    else:
        print("- none")
    print("top_blocking:")
    if summary["top_blocking"]:
        for fact in summary["top_blocking"]:
            print(f"- {fact.get('computed_weight')}: {fact.get('statement', '')}")
    else:
        print("- none")
    print(f"has_unmet_hard_gate: {summary['has_unmet_hard_gate']}")
    print(f"route_status: {summary['route_status']}")
    print("review_flags:")
    if summary["review_flags"]:
        for flag in summary["review_flags"]:
            print(f"- {flag}")
    else:
        print("- none")
    print("recommended_actions:")
    if summary["recommended_actions"]:
        for action in summary["recommended_actions"]:
            print(f"- {action}")
    else:
        print("- none")
    print(f"fact_count: {len(facts)}")


def print_control_summary(control_facts: list[dict[str, Any]], summary: dict[str, Any]) -> None:
    print("top_control_routes:")
    if summary["top_surface_routes"]:
        for fact in summary["top_surface_routes"]:
            print(
                f"- {fact.get('surface_score')}: {fact.get('action', '')} -> {fact.get('target', '')} via "
                f"{fact.get('control_plane', '')} | {fact.get('method', '')}"
            )
    else:
        print("- none")
    print("control_review_flags:")
    if summary["review_flags"]:
        for flag in summary["review_flags"]:
            print(f"- {flag}")
    else:
        print("- none")
    print("control_recommended_actions:")
    if summary["recommended_actions"]:
        for action in summary["recommended_actions"]:
            print(f"- {action}")
    else:
        print("- none")
    print(f"control_fact_count: {len(control_facts)}")


def print_route_property_summary(properties: list[dict[str, Any]], summary: dict[str, Any]) -> None:
    print("top_route_properties:")
    if summary["route_hints"]:
        for item in summary["route_hints"]:
            print(
                f"- {item.get('chance_percent')}: {item.get('name', '')} "
                f"result={item.get('result', '')} -> {item.get('route_decision', '')}"
            )
    else:
        print("- none")
    print("route_property_review_flags:")
    if summary["review_flags"]:
        for flag in summary["review_flags"]:
            print(f"- {flag}")
    else:
        print("- none")
    print("route_property_recommended_actions:")
    if summary["recommended_actions"]:
        for action in summary["recommended_actions"]:
            print(f"- {action}")
    else:
        print("- none")
    print(f"route_property_count: {len(properties)}")


def main() -> int:
    args = parse_args()
    case_json, data = load_case(args.case)
    facts = data.get("decision_facts")
    if not isinstance(facts, list):
        raise ValueError("decision_facts must be a list in case.json")
    control_facts = data.get("control_facts")
    if control_facts is None:
        control_facts = []
    if not isinstance(control_facts, list):
        raise ValueError("control_facts must be a list in case.json")
    route_properties = data.get("route_properties")
    if route_properties is None:
        route_properties = []
    if not isinstance(route_properties, list):
        raise ValueError("route_properties must be a list in case.json")

    scored: list[dict[str, Any]] = []
    for item in facts:
        if not isinstance(item, dict):
            continue
        scored.append(score_fact(item))

    summary = build_summary(scored)
    scored_control: list[dict[str, Any]] = []
    for item in control_facts:
        if not isinstance(item, dict):
            continue
        scored_control.append(score_control_fact(item))
    control_summary = build_control_summary(scored_control)
    scored_route_properties: list[dict[str, Any]] = []
    for item in route_properties:
        if not isinstance(item, dict):
            continue
        scored_route_properties.append(score_route_property(item))
    route_property_summary = build_route_property_summary(scored_route_properties)
    data["decision_facts"] = scored
    data["weighted_fact_summary"] = summary
    data["control_facts"] = scored_control
    data["control_fact_summary"] = control_summary
    data["route_properties"] = scored_route_properties
    data["route_property_summary"] = route_property_summary

    if args.write:
        case_json.write_text(f"{json.dumps(data, indent=2)}\n", encoding="utf-8")

    print_summary(case_json, scored, summary)
    print_control_summary(scored_control, control_summary)
    print_route_property_summary(scored_route_properties, route_property_summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
