from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

from score_case_facts import (
    EVIDENCE_QUALITY_WEIGHTS,
    FRESHNESS_WEIGHTS,
    GOAL_FIT_WEIGHTS,
    SCOPE_WEIGHTS,
    TARGET_FIT_WEIGHTS,
    build_route_property_summary,
    score_route_property,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Record a route-driving property prediction and optionally its live observation.",
    )
    parser.add_argument("case", help="Path to a case directory or case.json.")
    parser.add_argument("--name", required=True, help="Stable property name, for example usb.supports_large_files.")
    parser.add_argument("--expected-value", required=True, help="The value the current route expects.")
    parser.add_argument(
        "--chance",
        type=float,
        default=0.50,
        help="Prior chance that the expected value is true. Accepts 0-1 or 0-100.",
    )
    parser.add_argument("--scope", required=True, choices=sorted(SCOPE_WEIGHTS))
    parser.add_argument("--evidence-quality", required=True, choices=sorted(EVIDENCE_QUALITY_WEIGHTS))
    parser.add_argument("--freshness", default="unknown", choices=sorted(FRESHNESS_WEIGHTS))
    parser.add_argument("--target-fit", default="unknown", choices=sorted(TARGET_FIT_WEIGHTS))
    parser.add_argument("--goal-fit", default="unknown", choices=sorted(GOAL_FIT_WEIGHTS))
    parser.add_argument("--source-ref", default="", help="Short pointer to the source of the prediction.")
    parser.add_argument("--probe", default="", help="Read-only probe or observation method that can verify the property.")
    parser.add_argument("--observed-value", default="", help="Current value observed on the exact target.")
    parser.add_argument("--proof", default="", help="Short pointer to the observation proof.")
    parser.add_argument(
        "--result",
        default="auto",
        choices=["auto", "unchecked", "confirmed", "disconfirmed", "unknown"],
        help="Override auto comparison of expected and observed values.",
    )
    parser.add_argument("--route-when-expected", default="", help="Route hint when the expected value holds.")
    parser.add_argument("--route-when-unexpected", default="", help="Route hint when the expected value fails.")
    parser.add_argument(
        "--shared-dimensions",
        default="",
        help="Comma- or semicolon-separated dimensions that make the prediction transferable.",
    )
    parser.add_argument(
        "--divergent-dimensions",
        default="",
        help="Comma- or semicolon-separated dimensions that explain a mismatch from similar targets.",
    )
    parser.add_argument(
        "--append-duplicate",
        action="store_true",
        help="Append another property row even when the same property name already exists.",
    )
    return parser.parse_args()


def current_timestamp() -> str:
    return datetime.now().astimezone().replace(microsecond=0).isoformat()


def load_case(path_text: str) -> tuple[Path, dict[str, Any]]:
    path = Path(path_text).expanduser().resolve()
    case_json = path / "case.json" if path.is_dir() else path
    if not case_json.exists():
        raise FileNotFoundError(f"case.json was not found: {case_json}")
    data = json.loads(case_json.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("case.json must contain a JSON object.")
    return case_json, data


def normalize_text(value: str) -> str:
    return " ".join(value.split()).strip()


def normalize_dimensions(value: str) -> list[str]:
    parts = re.split(r"[;,]", value)
    cleaned: list[str] = []
    for part in parts:
        normalized = normalize_text(part)
        if normalized and normalized not in cleaned:
            cleaned.append(normalized)
    return cleaned


def normalized_name(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return normalize_text(value).lower()


def main() -> int:
    args = parse_args()
    case_json, data = load_case(args.case)
    route_properties = data.get("route_properties")
    if route_properties is None:
        route_properties = []
    if not isinstance(route_properties, list):
        raise ValueError("route_properties must be a list in case.json")

    prop = {
        "name": normalize_text(args.name),
        "expected_value": normalize_text(args.expected_value),
        "chance": args.chance,
        "scope": args.scope,
        "evidence_quality": args.evidence_quality,
        "freshness": args.freshness,
        "target_fit": args.target_fit,
        "goal_fit": args.goal_fit,
        "source_ref": normalize_text(args.source_ref),
        "probe": normalize_text(args.probe),
        "observed_value": normalize_text(args.observed_value),
        "proof": normalize_text(args.proof),
        "route_when_expected": normalize_text(args.route_when_expected),
        "route_when_unexpected": normalize_text(args.route_when_unexpected),
        "shared_dimensions": normalize_dimensions(args.shared_dimensions),
        "divergent_dimensions": normalize_dimensions(args.divergent_dimensions),
    }
    if args.result != "auto":
        prop["result"] = args.result
    score_route_property(prop)

    if not args.append_duplicate:
        name_key = normalized_name(prop["name"])
        replaced = False
        for index, existing in enumerate(route_properties):
            if not isinstance(existing, dict):
                continue
            if normalized_name(existing.get("name")) == name_key:
                route_properties[index] = prop
                replaced = True
                break
        if not replaced:
            route_properties.append(prop)
    else:
        route_properties.append(prop)

    scored: list[dict[str, Any]] = []
    for item in route_properties:
        if not isinstance(item, dict):
            continue
        scored.append(score_route_property(item))

    data["route_properties"] = scored
    data["route_property_summary"] = build_route_property_summary(scored)
    data["updated_at"] = current_timestamp()
    case_json.write_text(f"{json.dumps(data, indent=2)}\n", encoding="utf-8")

    print(f"case: {case_json}")
    print(f"saved_property: {prop['name']}")
    print(f"result: {prop['result']}")
    print(f"chance_percent: {prop['chance_percent']}")
    print(f"route_decision: {prop['route_decision']}")
    print(f"route_property_count: {len(scored)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
