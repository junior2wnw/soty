from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

from score_case_facts import (
    CONTROL_FRICTION_WEIGHTS,
    CONTROL_RESULT_MULTIPLIERS,
    EVIDENCE_QUALITY_WEIGHTS,
    FRESHNESS_WEIGHTS,
    GOAL_FIT_WEIGHTS,
    SCOPE_WEIGHTS,
    TARGET_FIT_WEIGHTS,
    build_control_summary,
    positive_int,
    score_control_fact,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Append or update a lightweight recurring control fact inside an install-ops case journal.",
    )
    parser.add_argument("case", help="Path to a case directory or case.json.")
    parser.add_argument("--action", required=True, help="Plain-language action such as mute audio or toggle wifi.")
    parser.add_argument("--target", required=True, help="Target being controlled, such as system audio or wifi radio.")
    parser.add_argument("--control-plane", required=True, help="Control plane such as local-shell, ssh, adb, or gui.")
    parser.add_argument("--method", required=True, help="Concrete command, API, or user action that worked.")
    parser.add_argument("--observable-success", required=True, help="Plain-language success sign.")
    parser.add_argument("--result", default="works", choices=sorted(CONTROL_RESULT_MULTIPLIERS))
    parser.add_argument("--step-count", default="1", help="Number of real steps required.")
    parser.add_argument("--friction", default="low", choices=sorted(CONTROL_FRICTION_WEIGHTS))
    parser.add_argument("--scope", required=True, choices=sorted(SCOPE_WEIGHTS))
    parser.add_argument("--evidence-quality", required=True, choices=sorted(EVIDENCE_QUALITY_WEIGHTS))
    parser.add_argument("--freshness", default="unknown", choices=sorted(FRESHNESS_WEIGHTS))
    parser.add_argument("--target-fit", default="unknown", choices=sorted(TARGET_FIT_WEIGHTS))
    parser.add_argument("--goal-fit", default="unknown", choices=sorted(GOAL_FIT_WEIGHTS))
    parser.add_argument("--source-ref", default="", help="Short pointer to the source command, log, or doc.")
    parser.add_argument(
        "--shared-dimensions",
        default="",
        help="Optional comma- or semicolon-separated dimensions that explain why this control fact transfers.",
    )
    parser.add_argument(
        "--divergent-dimensions",
        default="",
        help="Optional comma- or semicolon-separated dimensions that explain why a similar target diverges.",
    )
    parser.add_argument(
        "--append-duplicate",
        action="store_true",
        help="Append another control fact even when the same route key already exists.",
    )
    return parser.parse_args()


def current_timestamp() -> str:
    return datetime.now().astimezone().replace(microsecond=0).isoformat()


def load_case(path_text: str) -> tuple[Path, dict[str, Any]]:
    path = Path(path_text).expanduser().resolve()
    case_json = path / "case.json" if path.is_dir() else path
    if not case_json.exists():
        raise FileNotFoundError(f"case.json was not found: {case_json}")
    data = json.loads(case_json.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("case.json must contain a JSON object.")
    return case_json, data


def normalize_text(value: str) -> str:
    return " ".join(value.split()).strip()


def normalize_dimensions(value: str) -> list[str]:
    parts = re.split(r"[;,]", value)
    cleaned: list[str] = []
    for part in parts:
        normalized = normalize_text(part)
        if normalized and normalized not in cleaned:
            cleaned.append(normalized)
    return cleaned


def route_key(fact: dict[str, Any]) -> tuple[str, str, str, str]:
    return (
        str(fact.get("action", "")).strip().lower(),
        str(fact.get("target", "")).strip().lower(),
        str(fact.get("control_plane", "")).strip().lower(),
        str(fact.get("method", "")).strip().lower(),
    )


def main() -> int:
    args = parse_args()
    case_json, data = load_case(args.case)
    control_facts = data.get("control_facts")
    if control_facts is None:
        control_facts = []
    if not isinstance(control_facts, list):
        raise ValueError("control_facts must be a list in case.json")

    fact = {
        "action": normalize_text(args.action),
        "target": normalize_text(args.target),
        "control_plane": normalize_text(args.control_plane),
        "method": normalize_text(args.method),
        "observable_success": normalize_text(args.observable_success),
        "result": args.result,
        "step_count": positive_int(args.step_count, 1),
        "friction": args.friction,
        "scope": args.scope,
        "evidence_quality": args.evidence_quality,
        "freshness": args.freshness,
        "target_fit": args.target_fit,
        "goal_fit": args.goal_fit,
        "source_ref": normalize_text(args.source_ref),
        "shared_dimensions": normalize_dimensions(args.shared_dimensions),
        "divergent_dimensions": normalize_dimensions(args.divergent_dimensions),
    }
    score_control_fact(fact)

    if not args.append_duplicate:
        key = route_key(fact)
        replaced = False
        for index, existing in enumerate(control_facts):
            if not isinstance(existing, dict):
                continue
            if route_key(existing) == key:
                control_facts[index] = fact
                replaced = True
                break
        if not replaced:
            control_facts.append(fact)
    else:
        control_facts.append(fact)

    rescored: list[dict[str, Any]] = []
    for item in control_facts:
        if not isinstance(item, dict):
            continue
        rescored.append(score_control_fact(item))

    data["control_facts"] = rescored
    data["control_fact_summary"] = build_control_summary(rescored)
    data["updated_at"] = current_timestamp()
    case_json.write_text(f"{json.dumps(data, indent=2)}\n", encoding="utf-8")

    print(f"case: {case_json}")
    print(f"saved_control_fact: {fact['action']} -> {fact['target']}")
    print(f"surface_score: {fact['surface_score']}")
    print(f"chat_marker: {fact['chat_marker']}")
    print(f"control_fact_count: {len(rescored)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
