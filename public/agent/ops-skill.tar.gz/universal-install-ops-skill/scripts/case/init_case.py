from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from skill_paths import skill_root as find_skill_root

GENERIC_PHASES = [
    "preflight",
    "stage",
    "prepare",
    "confirm",
    "execute",
    "observe",
    "collect_logs",
    "improve",
]

WINDOWS_REINSTALL_PHASES = [
    "preflight",
    "clear_blockers",
    "stage",
    "acquire_media",
    "prepare",
    "confirm",
    "arm",
    "observe",
    "collect_logs",
    "improve",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create a durable install-ops case directory with case.json and runbook.md.",
    )
    parser.add_argument("--workspace", required=True, help="Safe fixed workspace root for case files.")
    parser.add_argument("--title", required=True, help="Human-readable case title.")
    parser.add_argument("--platform", default="", help="Target platform, for example windows or linux.")
    parser.add_argument("--intent", default="", help="Lifecycle intent, for example reinstall or repair.")
    parser.add_argument("--target-kind", default="", help="Target kind, for example os or app.")
    parser.add_argument("--transport", default="", help="Control path, for example ssh or local_agent.")
    parser.add_argument("--host", default="", help="Host alias, IP, or target label.")
    parser.add_argument("--environment", default="", help="Sanitized summary of the environment that shapes the route.")
    parser.add_argument("--skill-root", default="", help="Optional override for the skill root path.")
    return parser.parse_args()


def current_timestamp() -> str:
    return datetime.now().astimezone().replace(microsecond=0).isoformat()


def today_slug_prefix() -> str:
    return datetime.now().astimezone().strftime("%Y-%m-%d")


def slugify(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return normalized[:48] or "case"


def choose_phases(platform: str, intent: str, target_kind: str) -> list[str]:
    platform_value = platform.strip().lower()
    intent_value = intent.strip().lower()
    target_kind_value = target_kind.strip().lower()
    if platform_value == "windows" and intent_value in {"install", "reinstall", "repair", "recover", "prepare_media"}:
        if target_kind_value in {"", "os", "media", "recovery_environment", "driver"}:
            return WINDOWS_REINSTALL_PHASES
    return GENERIC_PHASES


def allocate_case_dir(root: Path, slug: str) -> Path:
    base = root / "install-op-cases" / f"{today_slug_prefix()}-{slug}"
    candidate = base
    counter = 2
    while candidate.exists():
        candidate = Path(f"{base}-{counter}")
        counter += 1
    return candidate


def render_runbook(case: dict[str, object]) -> str:
    phase_rows = "\n".join(
        f"| `{phase}` | pending | | |" for phase in case["phases"]
    )
    host_line = case["host"] or "(not yet set)"
    transport_line = case["transport"] or "(not yet set)"
    platform_line = case["platform"] or "(not yet set)"
    intent_line = case["intent"] or "(not yet set)"
    target_kind_line = case["target_kind"] or "(not yet set)"
    environment_summary_line = case["environment_summary"] or "(not yet set)"
    return "\n".join(
        [
            f"# {case['title']}",
            "",
            f"- Created: `{case['created_at']}`",
            f"- Status: `{case['status']}`",
            f"- Current phase: `{case['current_phase']}`",
            f"- Platform: `{platform_line}`",
            f"- Intent: `{intent_line}`",
            f"- Target kind: `{target_kind_line}`",
            f"- Transport: `{transport_line}`",
            f"- Host: `{host_line}`",
            "",
            "## Ownership",
            "",
            "- Active owner:",
            "- Allowed next state change:",
            "- Handoff proof:",
            "",
            "## Outcome",
            "",
            "- Requested outcome:",
            "- Verified outcome:",
            "",
            "## Control Plane",
            "",
            "- Current control path:",
            "- Post-change return path:",
            "- Operator handoff needed:",
            "",
            "## Route Selection",
            "",
            "- Primary route:",
            "- Strongest alternate:",
            "- Rejected routes and why they lost:",
            "",
            "## Weighted Decision Facts",
            "",
            "- Keep route-driving facts here with: statement, scope, evidence quality, freshness, target fit, goal fit, polarity, source_ref, and transfer dimensions when the fact is reused across similar targets.",
            "- Prefer `python scripts/case/record_case_fact.py <case-dir> ...` for quick fact capture during live work.",
            "- Recompute with `python scripts/case/score_case_facts.py <case-dir> --write` after new evidence arrives.",
            "- Shared dimensions for transferred facts:",
            "- Divergent dimensions for near-miss facts:",
            "- Strongest supporting fact:",
            "- Strongest caution fact:",
            "- Strongest blocking fact:",
            "- Recommended next evidence:",
            "",
            "## Route Properties",
            "",
            "- Record route-driving properties here with: name, expected value, prior chance, probe, observed value, proof, and route hints for expected/unexpected outcomes.",
            "- Prefer `python scripts/case/record_route_property.py <case-dir> ...` for properties that should steer the first route and then be corrected by live evidence.",
            "- Recompute with `python scripts/case/score_case_facts.py <case-dir> --write` after property observations arrive.",
            "- Highest-confidence expected properties:",
            "- Disconfirmed or unlikely properties:",
            "- Properties that still need a current probe:",
            "- Route hints after property comparison:",
            "",
            "## Everyday Control Memory",
            "",
            "- Record recurring low-risk controls here with: action, target, control plane, method, success sign, result, step count, friction, and transfer dimensions when the fact is reused across similar targets.",
            "- Prefer `python scripts/case/record_control_fact.py <case-dir> ...` for quick capture of sound, Wi-Fi, Bluetooth, media, VPN, and similar control-state facts.",
            "- Recompute with `python scripts/case/score_case_facts.py <case-dir> --write` to keep the surfaced best route current.",
            "- Surfaced best route for repeated controls:",
            "- Best action/target pair on the surface:",
            "- Alternate lower-friction route if needed:",
            "",
            "## Environment Snapshot",
            "",
            f"- Summary: `{environment_summary_line}`",
            "- Host OS, distro, or recovery mode:",
            "- Architecture, virtualization, or device family:",
            "- Package manager, installer path, runtime, or service manager:",
            "- Privilege, trust, unlock, or policy boundary:",
            "- Current transport and expected next transport:",
            "- Network, proxy, media, or storage constraints:",
            "",
            "## Blockers",
            "",
            "- [ ] Record the current blockers here.",
            "",
            "## Evidence",
            "",
            "- Last verified fact:",
            "- Evidence quality for risky decisions:",
            "- Artifact provenance:",
            "- Rollback or recovery route:",
            "- Abort triggers:",
            "- Key evidence path:",
            "",
            "## Phase Table",
            "",
            "| Phase | State | Proof | Notes |",
            "| --- | --- | --- | --- |",
            phase_rows,
            "",
            "## Learnings To Promote",
            "",
            "- Proven:",
            "- Failed:",
            "- Unclear:",
            "",
        ]
    ) + "\n"


def main() -> int:
    args = parse_args()
    workspace = Path(args.workspace).expanduser().resolve()
    skill_root = (
        Path(args.skill_root).expanduser().resolve()
        if args.skill_root.strip()
        else find_skill_root(__file__)
    )
    case_dir = allocate_case_dir(workspace, slugify(args.title))
    evidence_dir = case_dir / "evidence"
    logs_dir = case_dir / "logs"
    exports_dir = case_dir / "exports"

    for directory in [case_dir, evidence_dir, logs_dir, exports_dir]:
        directory.mkdir(parents=True, exist_ok=True)

    phases = choose_phases(args.platform, args.intent, args.target_kind)
    now = current_timestamp()
    case = {
        "schema_version": 6,
        "title": args.title.strip(),
        "slug": case_dir.name,
        "created_at": now,
        "updated_at": now,
        "platform": args.platform.strip(),
        "intent": args.intent.strip(),
        "target_kind": args.target_kind.strip(),
        "transport": args.transport.strip(),
        "host": args.host.strip(),
        "environment_summary": args.environment.strip(),
        "environment": {
            "host_os_or_mode": args.platform.strip(),
            "host_version": "",
            "architecture_or_device_family": "",
            "virtualization_or_container_boundary": "",
            "package_manager_or_installer": "",
            "runtime_or_service_manager": "",
            "privilege_or_policy_boundary": "",
            "transport_now": args.transport.strip(),
            "transport_next": "",
            "network_or_media_constraints": "",
            "storage_or_filesystem_constraints": "",
            "device_identity_or_firmware_family": "",
        },
        "status": "planned",
        "current_phase": phases[0],
        "phases": phases,
        "blockers": [],
        "route_selection": {
            "primary": "",
            "alternate": "",
            "rejected": [],
            "evidence_quality": "",
        },
        "decision_facts": [],
        "weighted_fact_summary": {
            "top_supporting": [],
            "top_caution": [],
            "top_blocking": [],
            "top_unknown": [],
            "has_unmet_hard_gate": False,
            "route_status": "unproven",
            "review_flags": [],
            "recommended_actions": [],
            "last_scored_at": "",
        },
        "route_properties": [],
        "route_property_summary": {
            "top_likely_expected": [],
            "top_likely_unexpected": [],
            "needs_probe": [],
            "route_hints": [],
            "review_flags": [],
            "recommended_actions": [],
            "last_scored_at": "",
        },
        "control_facts": [],
        "control_fact_summary": {
            "top_surface_routes": [],
            "top_caution_routes": [],
            "top_blocked_routes": [],
            "best_by_action": [],
            "review_flags": [],
            "recommended_actions": [],
            "last_scored_at": "",
        },
        "return_path": "",
        "destructive_scope": "",
        "active_owner": "",
        "allowed_next_state_change": "",
        "handoff_proof": "",
        "artifact_provenance": [],
        "rollback_route": "",
        "abort_triggers": [],
        "last_verified_fact": "",
        "skill_root": str(skill_root),
        "paths": {
            "case_dir": str(case_dir),
            "evidence_dir": str(evidence_dir),
            "logs_dir": str(logs_dir),
            "exports_dir": str(exports_dir),
        },
    }

    case_json_path = case_dir / "case.json"
    runbook_path = case_dir / "runbook.md"
    case_json_path.write_text(f"{json.dumps(case, indent=2)}\n", encoding="utf-8")
    runbook_path.write_text(render_runbook(case), encoding="utf-8")

    print(str(case_dir))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
