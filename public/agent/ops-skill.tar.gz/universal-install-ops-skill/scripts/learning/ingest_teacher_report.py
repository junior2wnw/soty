from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "learning"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))

import ingest_memory_marker
from skill_paths import skill_root as find_skill_root


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Review or import sanitized Soty Teacher candidates into the ops candidate queue.")
    parser.add_argument("report", nargs="?", default="-", help="Teacher JSON file, or '-' for stdin. Accepts raw teacher JSON or sotyctl learn doctor --json output.")
    parser.add_argument("--memory-dir", default="", help="Directory containing candidate-facts.jsonl.")
    parser.add_argument("--queue", default="", help="Override candidate JSONL queue path.")
    parser.add_argument("--source", default="soty.teacher", help="Source label for queued candidates.")
    parser.add_argument("--scope", action="append", choices=["candidate", "promote", "profile"], default=[], help="Candidate scope to include. Repeatable; default is all.")
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--write", action="store_true", help="Append accepted candidates. Default is dry-run review.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__).resolve()


def queue_path(args: argparse.Namespace) -> Path:
    if args.queue.strip():
        return Path(args.queue).expanduser().resolve()
    mem_dir = Path(args.memory_dir).expanduser().resolve() if args.memory_dir.strip() else skill_root() / ".skill-memory"
    return mem_dir / "candidate-facts.jsonl"


def read_report(path: str) -> dict[str, Any]:
    text = sys.stdin.read() if path == "-" else Path(path).expanduser().read_text(encoding="utf-8")
    text = text.lstrip("\ufeff")
    payload = json.loads(text)
    if not isinstance(payload, dict):
        raise ValueError("teacher report must be a JSON object")
    teacher = payload.get("teacher") if isinstance(payload.get("teacher"), dict) else payload
    if not isinstance(teacher, dict):
        raise ValueError("teacher report wrapper does not contain a teacher object")
    return teacher


def read_existing_markers(path: Path) -> set[str]:
    if not path.exists():
        return set()
    markers: set[str] = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict):
            marker = str(row.get("marker", "")).strip()
            if marker:
                markers.add(marker)
    return markers


def wanted_scope(scope: str, allowed: set[str]) -> bool:
    return not allowed or scope in allowed


def clean_teacher_family(value: Any) -> str:
    family = " ".join(str(value).strip().split())
    if not family:
        return ""
    try:
        return ingest_memory_marker.sanitize_or_fail(family[:1000])[:80]
    except ValueError:
        return ""


def candidate_rows(report: dict[str, Any], args: argparse.Namespace, path: Path) -> list[dict[str, Any]]:
    allowed = {item.strip().lower() for item in args.scope if item.strip()}
    existing = read_existing_markers(path)
    rows: list[dict[str, Any]] = []
    candidates = report.get("candidates", [])
    if not isinstance(candidates, list):
        candidates = []
    for index, item in enumerate(candidates[: max(0, args.limit)], start=1):
        if not isinstance(item, dict):
            rows.append({"index": index, "accepted": False, "reason": "candidate is not an object"})
            continue
        scope = str(item.get("scope", "candidate")).strip().lower() or "candidate"
        marker = str(item.get("marker", "")).strip()
        if not wanted_scope(scope, allowed):
            rows.append({"index": index, "accepted": False, "scope": scope, "reason": "scope filtered"})
            continue
        try:
            clean_marker = ingest_memory_marker.sanitize_or_fail(marker)
        except ValueError as error:
            rows.append({"index": index, "accepted": False, "scope": scope, "reason": str(error)})
            continue
        if clean_marker in existing:
            rows.append({"index": index, "accepted": False, "scope": scope, "marker": clean_marker, "reason": "already queued"})
            continue
        record = {
            "created_at": ingest_memory_marker.now_utc(),
            "type": ingest_memory_marker.marker_kind(clean_marker),
            "shelf": ingest_memory_marker.choose_shelf(clean_marker, ""),
            "source": args.source.strip() or "soty.teacher",
            "teacher_scope": scope,
            "teacher_family": clean_teacher_family(item.get("family", "")),
            "marker": clean_marker,
        }
        rows.append({"index": index, "accepted": True, "scope": scope, "record": record})
        existing.add(clean_marker)
    return rows


def run(args: argparse.Namespace) -> dict[str, Any]:
    report = read_report(args.report)
    path = queue_path(args)
    rows = candidate_rows(report, args, path)
    accepted = [row["record"] for row in rows if row.get("accepted") and isinstance(row.get("record"), dict)]
    if args.write:
        for record in accepted:
            ingest_memory_marker.append_jsonl(path, record)
    return {
        "ok": True,
        "mode": "write" if args.write else "dry-run",
        "queue": str(path),
        "teacher_schema": report.get("schema", ""),
        "teacher_source": report.get("source", ""),
        "teacher_scope": report.get("scope", {}),
        "publish_model": report.get("publishModel", "reviewed-ops-patch-then-build-release-deploy"),
        "teacher_receipts": report.get("receipts", 0),
        "accepted_count": len(accepted),
        "skipped_count": len(rows) - len(accepted),
        "rows": rows,
        "next": [
            "python scripts/learning/compile_memory_queue.py",
            "patch the relevant shelf, hot route, helper, profile, or activation eval for promote rows",
            "python scripts/skill/finish_skill_edit.py",
        ],
    }


def print_text(report: dict[str, Any]) -> None:
    print("Soty Teacher Candidate Review")
    print(f"- mode: {report['mode']}")
    print(f"- queue: {report['queue']}")
    print(f"- teacher_receipts: {report['teacher_receipts']}")
    scope = report.get("teacher_scope") if isinstance(report.get("teacher_scope"), dict) else {}
    if scope:
        print(f"- teacher_scope: {scope.get('kind', 'server-global-sanitized-receipts')} devices={scope.get('deviceCount', 0)}")
    if report.get("publish_model"):
        print(f"- publish_model: {report['publish_model']}")
    print(f"- accepted_count: {report['accepted_count']}")
    print(f"- skipped_count: {report['skipped_count']}")
    for row in report["rows"]:
        if row.get("accepted"):
            record = row["record"]
            print(f"  - accept[{row['index']}]: {row['scope']} {record['shelf']} | {record['marker']}")
        else:
            print(f"  - skip[{row['index']}]: {row.get('scope', '')} | {row.get('reason', 'skipped')}")
    print("- next:")
    for item in report["next"]:
        print(f"  - {item}")
    if report["mode"] == "dry-run" and report["accepted_count"]:
        print("- write: rerun with --write")


def main() -> int:
    args = parse_args()
    try:
        report = run(args)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(str(error), file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
