from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "learning"))

from skill_paths import skill_root as find_skill_root
from ingest_memory_marker import sanitize_or_fail


PROFILE_ID_RE = re.compile(r"[A-Za-z0-9_.+-]{2,96}")
SHELF_ID_RE = re.compile(r"[a-z0-9][a-z0-9-]{1,80}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Store or read a sanitized reusable ops route profile.")
    parser.add_argument("--action", choices=["upsert", "get", "summary"], default="summary")
    parser.add_argument("--profile-id", default="", help="Stable sanitized id, not a private hostname.")
    parser.add_argument("--shelf", default="general-routing", help="Shelf this route profile belongs to.")
    parser.add_argument("--task-family", default="", help="Reusable task family, e.g. service repair or Windows reinstall.")
    parser.add_argument("--platform-family", default="", help="Transfer boundary such as OS/runtime/device family.")
    parser.add_argument("--control-plane", default="", help="How work is executed: local shell, SSH, Soty worker, etc.")
    parser.add_argument("--route", default="", help="Shortest proven reusable route.")
    parser.add_argument("--proof", default="", help="Observable success proof.")
    parser.add_argument("--transfer-boundary", default="", help="When this profile is expected to transfer or not transfer.")
    parser.add_argument("--baseline-minutes", type=float, default=None)
    parser.add_argument("--actual-minutes", type=float, default=None)
    parser.add_argument("--baseline-steps", type=float, default=None)
    parser.add_argument("--actual-steps", type=float, default=None)
    parser.add_argument("--baseline-tokens", type=float, default=None)
    parser.add_argument("--actual-tokens", type=float, default=None)
    parser.add_argument("--baseline-quality", type=float, default=None, help="Optional 0-10 quality score before the profile.")
    parser.add_argument("--actual-quality", type=float, default=None, help="Optional 0-10 quality score after the profile.")
    parser.add_argument("--baseline-safety", type=float, default=None, help="Optional 0-10 safety score before the profile.")
    parser.add_argument("--actual-safety", type=float, default=None, help="Optional 0-10 safety score after the profile.")
    parser.add_argument("--baseline-simplicity", type=float, default=None, help="Optional 0-10 simplicity score before the profile.")
    parser.add_argument("--actual-simplicity", type=float, default=None, help="Optional 0-10 simplicity score after the profile.")
    parser.add_argument("--baseline-universality", type=float, default=None, help="Optional 0-10 universality score before the profile.")
    parser.add_argument("--actual-universality", type=float, default=None, help="Optional 0-10 universality score after the profile.")
    parser.add_argument("--store", default="", help="Override JSONL profile store path.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def skill_root() -> Path:
    return find_skill_root(__file__).resolve()


def default_store() -> Path:
    return skill_root() / ".skill-memory" / "route-profiles.jsonl"


def store_path(raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else default_store()


def compact(value: str) -> str:
    return " ".join(value.strip().split())


def sanitize_field(value: str) -> str:
    text = compact(value)
    if not text:
        return ""
    return sanitize_or_fail(text)


def validate_profile_id(value: str) -> str:
    profile_id = sanitize_field(value)
    if not profile_id:
        raise ValueError("--profile-id is required for upsert/get")
    if not PROFILE_ID_RE.fullmatch(profile_id):
        raise ValueError("profile id must be 2-96 chars: letters, digits, dot, underscore, plus, or hyphen")
    return profile_id


def validate_shelf(value: str) -> str:
    shelf = compact(value) or "general-routing"
    if not SHELF_ID_RE.fullmatch(shelf):
        raise ValueError("--shelf must be a valid shelf id")
    return shelf


def non_negative(value: float | None, name: str) -> float | None:
    if value is None:
        return None
    if value < 0:
        raise ValueError(f"--{name} must be non-negative")
    return value


def score_value(value: float | None, name: str) -> float | None:
    if value is None:
        return None
    if value < 0 or value > 10:
        raise ValueError(f"--{name} must be between 0 and 10")
    return value


def savings(before: float | None, after: float | None) -> dict[str, Any]:
    if before is None or after is None:
        return {"known": False}
    saved = max(0.0, before - after)
    percent = round((saved / before) * 100, 2) if before > 0 else 0.0
    return {"known": True, "before": before, "after": after, "saved": saved, "percent": percent}


def score_delta(before: float | None, after: float | None) -> dict[str, Any]:
    if before is None or after is None:
        return {"known": False}
    gained = round(after - before, 2)
    return {"known": True, "before": before, "after": after, "gained": gained}


def read_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict):
            rows.append(row)
    return rows


def write_profiles(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = "".join(
        json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n"
        for row in sorted(rows, key=lambda item: str(item.get("profile_id", "")))
    )
    path.write_text(text, encoding="utf-8", newline="\n")


def newer_profile(candidate: dict[str, Any], existing: dict[str, Any] | None) -> bool:
    if existing is None:
        return True
    candidate_time = str(candidate.get("updated_at", ""))
    existing_time = str(existing.get("updated_at", ""))
    if candidate_time != existing_time:
        return candidate_time > existing_time
    return len(json.dumps(candidate, sort_keys=True)) >= len(json.dumps(existing, sort_keys=True))


def latest_by_profile(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for row in rows:
        profile_id = str(row.get("profile_id", ""))
        if profile_id and newer_profile(row, latest.get(profile_id)):
            latest[profile_id] = row
    return latest


def build_profile(args: argparse.Namespace) -> dict[str, Any]:
    required = {
        "task_family": args.task_family,
        "platform_family": args.platform_family,
        "control_plane": args.control_plane,
        "route": args.route,
        "proof": args.proof,
        "transfer_boundary": args.transfer_boundary,
    }
    fields = {key: sanitize_field(value) for key, value in required.items()}
    missing = [key.replace("_", "-") for key, value in fields.items() if not value]
    if missing:
        raise ValueError("missing required profile fields: " + ", ".join(missing))
    metrics = {
        "minutes": savings(
            non_negative(args.baseline_minutes, "baseline-minutes"),
            non_negative(args.actual_minutes, "actual-minutes"),
        ),
        "steps": savings(
            non_negative(args.baseline_steps, "baseline-steps"),
            non_negative(args.actual_steps, "actual-steps"),
        ),
        "tokens": savings(
            non_negative(args.baseline_tokens, "baseline-tokens"),
            non_negative(args.actual_tokens, "actual-tokens"),
        ),
        "quality": score_delta(
            score_value(args.baseline_quality, "baseline-quality"),
            score_value(args.actual_quality, "actual-quality"),
        ),
        "safety": score_delta(
            score_value(args.baseline_safety, "baseline-safety"),
            score_value(args.actual_safety, "actual-safety"),
        ),
        "simplicity": score_delta(
            score_value(args.baseline_simplicity, "baseline-simplicity"),
            score_value(args.actual_simplicity, "actual-simplicity"),
        ),
        "universality": score_delta(
            score_value(args.baseline_universality, "baseline-universality"),
            score_value(args.actual_universality, "actual-universality"),
        ),
    }
    return {
        "updated_at": now_utc(),
        "profile_id": validate_profile_id(args.profile_id),
        "shelf": validate_shelf(args.shelf),
        **fields,
        "metrics": metrics,
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    path = store_path(args.store)
    rows = read_rows(path)
    latest = latest_by_profile(rows)
    if args.action == "upsert":
        row = build_profile(args)
        latest[row["profile_id"]] = row
        write_profiles(path, list(latest.values()))
        return {"action": "upsert", "store": str(path), "profile": row, "profile_count": len(latest), "ok": True}
    if args.action == "get":
        profile_id = validate_profile_id(args.profile_id)
        profile = latest.get(profile_id)
        return {"action": "get", "store": str(path), "profile": profile, "found": profile is not None, "ok": profile is not None}
    by_shelf: dict[str, int] = {}
    for profile in latest.values():
        shelf = str(profile.get("shelf", "unknown"))
        by_shelf[shelf] = by_shelf.get(shelf, 0) + 1
    return {
        "action": "summary",
        "store": str(path),
        "profile_count": len(latest),
        "profiles_by_shelf": by_shelf,
        "profiles": sorted(latest.values(), key=lambda item: str(item.get("profile_id", ""))),
        "ok": True,
    }


def print_text(report: dict[str, Any]) -> None:
    print("Ops Route Profiles")
    print(f"- action: {report['action']}")
    print(f"- store: {report['store']}")
    if report["action"] == "summary":
        print(f"- profile_count: {report['profile_count']}")
        for shelf, count in sorted(report["profiles_by_shelf"].items()):
            print(f"  - shelf {shelf}: {count}")
        for profile in report["profiles"]:
            metrics = profile.get("metrics", {})
            minutes = metrics.get("minutes", {})
            quality = metrics.get("quality", {})
            suffixes = []
            if minutes.get("known"):
                suffixes.append(f"minutes_saved={minutes.get('saved')}")
            if quality.get("known"):
                suffixes.append(f"quality_gained={quality.get('gained')}")
            suffix = " " + " ".join(suffixes) if suffixes else ""
            print(f"  - {profile['profile_id']}: shelf={profile['shelf']} route={profile['route']}{suffix}")
    elif report["action"] == "get":
        print(f"- found: {report['found']}")
        if report["profile"]:
            print(f"- profile: {json.dumps(report['profile'], ensure_ascii=False, sort_keys=True)}")
    else:
        print(f"- profile_id: {report['profile']['profile_id']}")
        print(f"- profile_count: {report['profile_count']}")


def main() -> int:
    args = parse_args()
    try:
        report = run(args)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
