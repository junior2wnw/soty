from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "learning"))

from skill_paths import skill_root as find_skill_root
from ingest_memory_marker import append_jsonl, choose_shelf, default_queue_path, marker_kind, now_utc, sanitize_or_fail

WORD_CHARS = r"0-9A-Za-zА-Яа-яЁё._+-"
RISKY_WORDS = {
    "prod",
    "production",
    "secret",
    "token",
    "credential",
    "wipe",
    "flash",
    "firmware",
    "reinstall",
    "rollback",
    "destructive",
    "прод",
    "секрет",
    "токен",
    "пароль",
    "стереть",
    "прошивка",
    "переустанов",
    "риск",
}
SYNONYMS = {
    "звук": {"audio", "sound", "mute"},
    "звука": {"audio", "sound", "mute"},
    "звуком": {"audio", "sound", "mute"},
    "громкость": {"audio", "sound", "volume"},
    "выключи": {"mute", "disable", "off"},
    "выключить": {"mute", "disable", "off"},
    "включи": {"unmute", "enable", "on"},
    "включить": {"unmute", "enable", "on"},
    "проверь": {"check", "get", "state"},
    "проверить": {"check", "get", "state"},
    "память": {"memory", "ops-memory", "control-memory"},
    "запомнить": {"memory", "record", "marker"},
    "факт": {"fact", "marker", "memory"},
}

COMMAND_CACHE_HINTS = {
    " run:",
    " helper",
    " script",
    "scripts/",
    ".ps1",
    ".py",
    ".sh",
    ".cmd",
    ".bat",
    "powershell",
    "pwsh",
    "python ",
    "npm ",
    "npx ",
    "pip ",
    "uv ",
    "docker ",
    "docker-compose",
    "systemctl ",
    "journalctl ",
    "git ",
    "gh ",
    "kubectl ",
    "helm ",
    "ssh ",
    "scp ",
    "winget ",
    "choco ",
    "scoop ",
    "brew ",
    "apt ",
    "apt-get ",
    "dnf ",
    "yum ",
    "pacman ",
    "dism",
    "reagentc",
    "pnputil",
}
SEQUENCE_LINKS = ("->", " then ", " before ", " after ", " followed by ")
SEQUENCE_ACTIONS = {
    "probe",
    "preflight",
    "stage",
    "build",
    "install",
    "repair",
    "configure",
    "sync",
    "validate",
    "verify",
    "test",
    "check",
    "restart",
    "deploy",
    "rollback",
    "fallback",
    "reboot",
    "flash",
    "mute",
    "unmute",
}
MATCH_SNIPPET_LIMIT = 220

SOLVED_DIALOG_HINTS = {
    "learned a lot",
    "why not record",
    "why not write",
    "next time",
    "next agent",
    "other device",
    "other devices",
    "other os",
    "other operating system",
    "cross-os",
    "cross platform",
    "cross-platform",
    "portable",
    "portability",
    "transfer",
    "transfers",
    "same os family",
    "same device family",
    "shared dimension",
    "divergent dimension",
    "successful fallback",
    "failed then worked",
    "why does the skill not improve",
    "why did the skill not improve",
    "skill should improve",
    "skill must improve",
    "self improve",
    "self-improve",
    "installed-only skill",
    "another repo",
    "other repo",
    "raw dialogs",
    "save all dialogs",
    "dialog links",
    "много нового",
    "почему не запис",
    "почему не сохраня",
    "следующий раз",
    "следующему агент",
    "других устройствах",
    "других устройств",
    "другие устройства",
    "других ос",
    "другие ос",
    "других операцион",
    "другие операцион",
    "на других os",
    "на других oс",
    "перенос",
    "переносим",
    "сработало после",
    "сначала не сработало",
    "обходной путь",
}

PREDICTION_ERROR_HINTS = {
    "prediction error",
    "lower probability",
    "lower-probability",
    "less likely",
    "lower chance",
    "smaller chance",
    "unexpected fallback",
    "unlikely fallback",
    "меньший шанс",
    "меньшим шансом",
    "меньшей вероят",
    "низкой вероят",
    "неожиданный fallback",
    "неожиданный фолбэк",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Advise, query, and optionally queue operational memory.")
    parser.add_argument("task", help="User task or compact route summary.")
    parser.add_argument(
        "--mode",
        choices=["before", "during", "after"],
        default="after",
        help="Before-action lookup, during-work fact capture, or after-action capture.",
    )
    parser.add_argument("--kind", choices=["ops", "control"], default="ops", help="Marker kind to generate when capture is useful.")
    parser.add_argument("--result", choices=["works", "failed", "partial", "blocked", "unclear"], default="works")
    parser.add_argument("--expected", default="", help="Default, first route, or expectation.")
    parser.add_argument("--actual", default="", help="Winning route, fallback, or actual result.")
    parser.add_argument("--success", default="", help="Small observable proof.")
    parser.add_argument("--env", default="", help="Small sanitized environment fingerprint.")
    parser.add_argument("--risk", choices=["low", "medium", "high"], default="low")
    parser.add_argument("--route-changed", action="store_true", help="The route changed from expected to actual.")
    parser.add_argument("--fallback-worked", action="store_true", help="A fallback route worked after the first route failed.")
    parser.add_argument("--default-failed", action="store_true", help="The expected/default route failed.")
    parser.add_argument("--token-saving", action="store_true", help="The fact saves meaningful future exploration or tokens.")
    parser.add_argument("--safety", action="store_true", help="The fact prevents unsafe or brittle future work.")
    parser.add_argument("--repeated", action="store_true", help="The fact is repeated or broadly useful enough to promote above a marker.")
    parser.add_argument("--queue", default="", help="Candidate facts JSONL queue path.")
    parser.add_argument("--top", type=int, default=3, help="Number of existing memory matches to show.")
    parser.add_argument("--write", action="store_true", help="Compatibility flag; capture writes automatically when proof/env make a marker safe.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__).resolve()


def queue_path(raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else default_queue_path()


def skill_source_state(root: Path) -> str:
    if (root / ".git").exists():
        return "canonical-repo"
    if (root / "SKILL.md").exists() and (root / "scripts").exists():
        return "installed-or-bundled-skill"
    return "unknown-skill-root"


def tokens(value: str) -> set[str]:
    return {
        part
        for part in re.split(rf"[^{WORD_CHARS}]+", value.lower())
        if len(part) >= 2
    }


def expand_tokens(values: set[str]) -> set[str]:
    expanded = set(values)
    for value in values:
        expanded.update(SYNONYMS.get(value, set()))
    return expanded


def compact(value: str) -> str:
    return " ".join(value.strip().split())


def ellipsize(value: str, limit: int = MATCH_SNIPPET_LIMIT) -> str:
    text = compact(value)
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 3)].rstrip() + "..."


def match_snippet(value: str, limit: int = MATCH_SNIPPET_LIMIT) -> str:
    text = compact(value)
    parts = [part.strip() for part in text.split(" | ")]
    if text.startswith("- ") and len(parts) >= 7:
        summary = f"{parts[1]}/{parts[2]} {parts[4]} {parts[5]}: {parts[6]}"
        return ellipsize(summary, limit)
    return ellipsize(text, limit)


def changed(expected: str, actual: str) -> bool:
    return bool(expected.strip() and actual.strip() and compact(expected).casefold() != compact(actual).casefold())


def command_cache_reason(actual: str) -> str:
    route = compact(actual)
    if not route:
        return ""
    normalized = route.casefold().replace("\\", "/")
    lowered = f" {normalized} "
    if any(hint in lowered for hint in COMMAND_CACHE_HINTS):
        return "reusable command/helper route"
    if re.search(
        r"\b(?:python|powershell|pwsh|cmd|bash|sh|npm|npx|pip|uv|docker|kubectl|gh|git|ssh|scp|winget|brew|apt|systemctl)\b\s+",
        lowered,
    ):
        return "reusable command/helper route"
    if any(link in lowered for link in SEQUENCE_LINKS) and any(action in lowered for action in SEQUENCE_ACTIONS):
        return "reusable action order"
    return ""


def solved_dialog_reason(*values: str) -> str:
    text = " ".join(compact(value) for value in values if value.strip()).casefold()
    if text and any(hint in text for hint in SOLVED_DIALOG_HINTS):
        return "solved-dialog transfer"
    return ""


def prediction_error_reason(*values: str) -> str:
    text = " ".join(compact(value) for value in values if value.strip()).casefold()
    if text and any(hint in text for hint in PREDICTION_ERROR_HINTS):
        return "prediction-error outcome"
    return ""


def is_risky(text: str, risk: str) -> bool:
    if risk == "high":
        return True
    lowered = text.lower()
    return any(word in lowered for word in RISKY_WORDS)


def should_capture(args: argparse.Namespace) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    if args.result != "works":
        reasons.append(f"result={args.result}")
    if args.mode == "during" and args.actual.strip():
        reasons.append("during-work fact")
    if args.result == "works" and args.actual.strip() and args.success.strip() and args.env.strip():
        reasons.append("proved success")
    auto_reason = command_cache_reason(args.actual)
    if args.result == "works" and auto_reason:
        reasons.append(auto_reason)
    dialog_reason = solved_dialog_reason(args.task, args.actual, args.env)
    if args.result == "works" and dialog_reason:
        reasons.append(dialog_reason)
    prediction_reason = prediction_error_reason(args.task, args.expected, args.actual, args.success, args.env)
    if prediction_reason:
        reasons.append(prediction_reason)
    if changed(args.expected, args.actual):
        reasons.append("route changed")
    if args.route_changed:
        reasons.append("route-changed flag")
    if args.default_failed:
        reasons.append("default failed")
    if args.fallback_worked:
        reasons.append("fallback worked")
    if args.token_saving:
        reasons.append("token-saving")
    if args.safety:
        reasons.append("safety")
    if args.repeated:
        reasons.append("repeated")
    return bool(reasons), reasons


def promotion_tier(args: argparse.Namespace, capture: bool) -> str:
    if not capture:
        return "none"
    text = " ".join([args.task, args.expected, args.actual, args.env])
    if is_risky(text, args.risk):
        return "case-or-module-rule"
    if args.safety or args.repeated:
        return "field-note-or-module-rule"
    return "dialog-marker"


def missing_questions(args: argparse.Namespace, capture: bool) -> list[str]:
    if not capture:
        return []
    questions: list[str] = []
    if not args.env.strip():
        questions.append("What tiny environment fingerprint explains when this fact transfers?")
    if not args.success.strip():
        questions.append("What observable proof, error, or blocker showed this result?")
    if (args.route_changed or args.default_failed or args.fallback_worked or changed(args.expected, args.actual)) and not args.expected.strip():
        questions.append("What default or expected route failed or lost?")
    if (args.route_changed or args.default_failed or args.fallback_worked or changed(args.expected, args.actual)) and not args.actual.strip():
        questions.append("What actual route worked or became the best next step?")
    return questions


def build_marker(args: argparse.Namespace, capture: bool, questions: list[str]) -> str:
    if not capture or questions:
        return ""
    goal = compact(args.task)
    expected = compact(args.expected) or "not recorded"
    actual = compact(args.actual) or ("blocked" if args.result in {"blocked", "failed"} else "not recorded")
    success = compact(args.success) or args.result
    env = compact(args.env)
    if args.kind == "control":
        marker = (
            f"control-memory: action={goal} | target=operational control | plane=best-known control plane | "
            f"result={args.result} | method={actual} | success={success} | env={env}"
        )
    else:
        marker = f"ops-memory: goal={goal} | expected={expected} | actual={actual} | success={success} | env={env}"
    return sanitize_or_fail(marker)


def cache_decision(capture: bool, questions: list[str], marker: str, written: bool, already_queued: bool) -> str:
    if written:
        return "recorded sanitized candidate"
    if already_queued:
        return "sanitized candidate already recorded"
    if questions:
        return "answer missing questions before writing"
    if marker:
        return "not improved yet; patch before continuing"
    if capture:
        return "capture requested but marker is not ready"
    return "skip routine result; no reusable command, route change, failure, safety, or repetition signal"


def learning_sink_advice(
    root: Path,
    queue: Path,
    capture: bool,
    questions: list[str],
    tier: str,
    marker: str,
    already_queued: bool = False,
) -> str:
    state = skill_source_state(root)
    prefix = f"{state}: "
    if not capture:
        return prefix + "explicit no-reusable-lesson decision is enough"
    if already_queued:
        return prefix + "sanitized candidate marker is already queued; do not duplicate it"
    if questions:
        return prefix + "answer missing proof/env/default-route questions before writing"
    if tier == "case-or-module-rule":
        return prefix + "patch the relevant module/script/hot route or case fact before relying on a marker"
    if tier == "field-note-or-module-rule":
        return prefix + "use record_learning.py or patch the module when the rule changes behavior"
    if marker:
        return prefix + f"auto-queue sanitized candidate marker at {queue} before the next state change"
    return prefix + "emit one sanitized ops-memory/control-memory marker in the final if the skill tree is not writable"


def learning_delta(capture: bool, questions: list[str], tier: str, marker: str, written: bool, already_queued: bool) -> str:
    if written:
        return "marker-written"
    if already_queued:
        return "marker-present"
    if questions:
        return "blocked-missing-proof"
    if not capture:
        return "no-op"
    if tier == "case-or-module-rule":
        return "patch-required"
    if tier == "field-note-or-module-rule":
        return "note-or-patch-required"
    if marker:
        return "marker-ready"
    return "handoff-marker-required"


def field_note_lines(root: Path) -> list[str]:
    path = root / "references" / "field-notes.md"
    if not path.exists():
        return []
    return [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip().startswith("- ")]


def queue_records(path: Path) -> list[str]:
    if not path.exists():
        return []
    rows: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        marker = str(row.get("marker", "")).strip()
        if marker:
            rows.append(marker)
    return rows


def score_text(query_tokens: set[str], value: str) -> int:
    value_tokens = tokens(value)
    overlap = query_tokens & value_tokens
    if not overlap:
        return 0
    return (3 * len(overlap)) + sum(1 for token in query_tokens if token in value.lower())


def existing_matches(root: Path, query: str, queue: Path, top: int) -> list[dict[str, Any]]:
    query_tokens = expand_tokens(tokens(query))
    rows: list[dict[str, Any]] = []
    for source, values in [
        ("field-notes", field_note_lines(root)),
        ("candidate-queue", queue_records(queue)),
    ]:
        for value in values:
            score = score_text(query_tokens, value)
            if score <= 0:
                continue
            rows.append({"source": source, "score": score, "text": value[:500]})
    rows.sort(key=lambda item: (-int(item["score"]), str(item["source"]), str(item["text"])))
    return rows[: max(0, top)]


def build_report(args: argparse.Namespace) -> dict[str, Any]:
    root = skill_root()
    queue = queue_path(args.queue)
    query_text = " ".join([args.task, args.expected, args.actual, args.env])
    matches = existing_matches(root, query_text, queue, args.top)
    capture, reasons = should_capture(args)
    capture_mode = args.mode in {"during", "after"}
    tier = promotion_tier(args, capture)
    questions = missing_questions(args, capture)
    marker = build_marker(args, capture, questions)
    already_queued = bool(marker and marker in queue_records(queue))
    record: dict[str, Any] | None = None
    auto_write = (
        capture_mode
        and tier == "dialog-marker"
        and bool(marker)
        and not questions
        and bool(args.success.strip())
        and bool(args.env.strip())
    )
    if (args.write or auto_write) and marker and not already_queued:
        record = {
            "created_at": now_utc(),
            "type": marker_kind(marker),
            "shelf": choose_shelf(marker, ""),
            "source": "memory-loop",
            "marker": marker,
        }
        append_jsonl(queue, record)
    elif args.write and capture and questions:
        raise ValueError("cannot write marker until missing questions are answered")
    return {
        "skill_root": str(root),
        "source_state": skill_source_state(root),
        "mode": args.mode,
        "task": compact(args.task),
        "existing_matches": matches,
        "should_record": capture if capture_mode else False,
        "reasons": reasons if capture_mode else [],
        "promotion_tier": tier if capture_mode else "lookup-only",
        "questions": questions if capture_mode else [],
        "marker": marker if capture_mode else "",
        "learning_delta": learning_delta(capture, questions, tier, marker, record is not None, already_queued) if capture_mode else "lookup-only",
        "learning_sink": learning_sink_advice(root, queue, capture, questions, tier, marker, already_queued) if capture_mode else "lookup-only",
        "written": record is not None,
        "cache_decision": cache_decision(capture, questions, marker, record is not None, already_queued) if capture_mode else "lookup-only",
        "queue": str(queue),
        "record": record,
        "ok": True,
    }


def print_text(report: dict[str, Any]) -> None:
    print("Ops Memory Loop")
    print(f"- mode: {report['mode']}")
    print(f"- task: {report['task']}")
    print(f"- existing_matches: {len(report['existing_matches'])}")
    for match in report["existing_matches"]:
        print(f"  - {match['source']} score={match['score']}: {match_snippet(match['text'])}")
    if report["mode"] == "before":
        return
    print(f"- should_record: {report['should_record']}")
    print(f"- promotion_tier: {report['promotion_tier']}")
    print(f"- cache_decision: {report['cache_decision']}")
    print(f"- source_state: {report['source_state']}")
    print(f"- learning_delta: {report['learning_delta']}")
    print(f"- learning_sink: {report['learning_sink']}")
    if report["reasons"]:
        print(f"- reasons: {', '.join(report['reasons'])}")
    if report["questions"]:
        print("- questions:")
        for question in report["questions"]:
            print(f"  - {question}")
    if report["marker"]:
        print(f"- marker: {report['marker']}")
    print(f"- written: {report['written']}")
    if report["written"]:
        print(f"- queue: {report['queue']}")


def main() -> int:
    args = parse_args()
    try:
        report = build_report(args)
    except Exception as error:
        report = {"ok": False, "error": str(error)}
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        if report.get("ok"):
            print_text(report)
        else:
            print(f"error: {report.get('error', 'unknown error')}", file=sys.stderr)
    return 0 if report.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
