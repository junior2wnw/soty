from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "learning"))

from skill_paths import skill_root as find_skill_root
import memory_loop


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Classify candidate memory queue rows for promotion or pruning.")
    parser.add_argument("--memory-dir", default="", help="Directory containing candidate-facts.jsonl.")
    parser.add_argument("--notes-file", default="", help="Optional field-notes.md override.")
    parser.add_argument("--write-reviewed", action="store_true", help="Move covered rows to reviewed-candidate-facts.jsonl and keep the rest queued.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__).resolve()


def memory_dir(raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else skill_root() / ".skill-memory"


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as error:
            rows.append({"_error": f"{path.name}:{line_number}: {error.msg}"})
            continue
        rows.append(row if isinstance(row, dict) else {"_error": f"{path.name}:{line_number}: not an object"})
    return rows


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True))
            handle.write("\n")


def marker_parts(marker: str) -> dict[str, str]:
    body = marker.split(":", 1)[1] if ":" in marker else marker
    parts: dict[str, str] = {}
    for piece in body.split(" | "):
        if "=" not in piece:
            continue
        key, value = piece.split("=", 1)
        parts[key.strip()] = value.strip()
    return parts


def signature(row: dict[str, Any]) -> str:
    marker = str(row.get("marker", ""))
    parts = marker_parts(marker)
    shelf = str(row.get("shelf", ""))
    goal = parts.get("goal", "")
    actual = parts.get("actual", "")
    return re.sub(r"\s+", " ", f"{shelf}|{goal}|{actual}".casefold()).strip()


def note_lines(notes_file: Path) -> list[str]:
    if not notes_file.exists():
        return []
    return [line.strip() for line in notes_file.read_text(encoding="utf-8").splitlines() if line.strip().startswith("- ")]


def covered_by_notes(marker: str, notes: list[str]) -> bool:
    parts = marker_parts(marker)
    actual = parts.get("actual", "")
    goal = parts.get("goal", "")
    needles = [value for value in [actual, goal] if len(value) >= 36]
    if any(any(needle in note for note in notes) for needle in needles):
        return True
    query_tokens = memory_loop.tokens(marker)
    for note in notes:
        score = memory_loop.score_text(query_tokens, note)
        if score >= 30:
            return True
    return False


def classify(rows: list[dict[str, Any]], notes: list[str]) -> list[dict[str, Any]]:
    signatures = Counter(signature(row) for row in rows if "_error" not in row)
    decisions: list[dict[str, Any]] = []
    for index, row in enumerate(rows, start=1):
        if "_error" in row:
            decisions.append({"index": index, "decision": "review", "reason": row["_error"], "row": row})
            continue
        marker = str(row.get("marker", ""))
        sig = signature(row)
        if covered_by_notes(marker, notes):
            decision = "covered"
            reason = "field note already covers marker"
        elif signatures[sig] > 1:
            decision = "promote"
            reason = "repeated candidate signature"
        elif "success=" in marker and "env=" in marker:
            decision = "keep"
            reason = "single candidate with proof/env"
        else:
            decision = "review"
            reason = "missing proof/env or malformed marker"
        decisions.append({"index": index, "decision": decision, "reason": reason, "shelf": row.get("shelf", ""), "marker": marker})
    return decisions


def compile_queue(args: argparse.Namespace) -> dict[str, Any]:
    root = skill_root()
    mem_dir = memory_dir(args.memory_dir)
    queue = mem_dir / "candidate-facts.jsonl"
    notes_file = Path(args.notes_file).expanduser().resolve() if args.notes_file.strip() else root / "references" / "field-notes.md"
    rows = read_jsonl(queue)
    decisions = classify(rows, note_lines(notes_file))
    counts = dict(Counter(str(item["decision"]) for item in decisions))
    if args.write_reviewed:
        kept: list[dict[str, Any]] = []
        reviewed: list[dict[str, Any]] = []
        by_marker = {str(row.get("marker", "")): row for row in rows if "_error" not in row}
        for decision in decisions:
            row = by_marker.get(str(decision.get("marker", "")))
            if not row:
                continue
            if decision["decision"] == "covered":
                reviewed.append({**row, "review_decision": decision["decision"], "review_reason": decision["reason"]})
            else:
                kept.append(row)
        write_jsonl(queue, kept)
        if reviewed:
            reviewed_path = mem_dir / "reviewed-candidate-facts.jsonl"
            existing = read_jsonl(reviewed_path)
            write_jsonl(reviewed_path, [row for row in existing if "_error" not in row] + reviewed)
    return {
        "memory_dir": str(mem_dir),
        "queue": str(queue),
        "notes_file": str(notes_file),
        "candidate_count": len([row for row in rows if "_error" not in row]),
        "decision_counts": counts,
        "decisions": decisions,
        "wrote_reviewed": bool(args.write_reviewed),
        "ok": not any(item["decision"] == "review" for item in decisions),
    }


def print_text(report: dict[str, Any]) -> None:
    print("Memory Queue Compile")
    print(f"- memory_dir: {report['memory_dir']}")
    print(f"- candidate_count: {report['candidate_count']}")
    print("- decision_counts:")
    for key, value in sorted(report["decision_counts"].items()):
        print(f"  - {key}: {value}")
    print("- decisions:")
    for item in report["decisions"]:
        print(f"  - {item['index']}: {item['decision']} | {item['reason']}")
    print(f"- wrote_reviewed: {report['wrote_reviewed']}")


def main() -> int:
    args = parse_args()
    report = compile_queue(args)
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
