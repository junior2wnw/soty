from __future__ import annotations

import argparse
import re
import sys
from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from skill_paths import skill_root as find_skill_root

NOTE_RE = re.compile(r"^- (?P<date>\d{4}-\d{2}-\d{2}) \| (?P<bucket>[^|]+) \| (?P<domain>[^|]+) \| (?P<body>.*)$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Review field-notes.md for stale, duplicate, and underspecified learnings.",
    )
    parser.add_argument("--notes-file", default="", help="Optional path to field-notes.md.")
    parser.add_argument("--stale-days", type=int, default=120)
    parser.add_argument("--report", default="", help="Optional path to write a markdown report.")
    parser.add_argument(
        "--fail-on-findings",
        action="store_true",
        help="Return a non-zero exit code when maintenance findings are present.",
    )
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__)


def parse_date(value: str) -> date | None:
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        return None


def normalized_body(body: str) -> str:
    cleaned = re.sub(r"\|\s*env:.*$", "", body).strip().lower()
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned


def build_report(notes_file: Path, stale_days: int) -> tuple[str, int]:
    raw = notes_file.read_text(encoding="utf-8")
    today = datetime.now().astimezone().date()
    stale_before = today - timedelta(days=stale_days)
    parsed: list[tuple[int, str, str, str, str]] = []
    malformed: list[tuple[int, str]] = []
    orphan_lines: list[tuple[int, str]] = []
    active_bucket: str | None = None

    for line_number, line in enumerate(raw.splitlines(), start=1):
        stripped = line.strip()
        if stripped.startswith("## "):
            active_bucket = stripped[3:].strip().lower()
            continue
        if active_bucket in {"proven", "failed", "unclear"} and stripped and not line.startswith("- "):
            orphan_lines.append((line_number, line))
            continue
        if not line.startswith("- "):
            continue
        match = NOTE_RE.match(line)
        if not match:
            malformed.append((line_number, line))
            continue
        parsed.append(
            (
                line_number,
                match.group("date"),
                match.group("bucket").strip(),
                match.group("domain").strip(),
                match.group("body").strip(),
            )
        )

    missing_env: list[tuple[int, str]] = []
    missing_scope_or_evidence: list[tuple[int, str]] = []
    stale_unclear: list[tuple[int, str]] = []
    by_signature: dict[tuple[str, str, str], list[int]] = defaultdict(list)

    for line_number, date_text, bucket, domain, body in parsed:
        signature = (bucket, domain, normalized_body(body))
        by_signature[signature].append(line_number)
        if "env:" not in body:
            missing_env.append((line_number, body))
        if "scope:" not in body and "evidence:" not in body:
            missing_scope_or_evidence.append((line_number, body))
        note_date = parse_date(date_text)
        if bucket == "unclear" and note_date is not None and note_date < stale_before:
            stale_unclear.append((line_number, body))

    duplicates = {signature: lines for signature, lines in by_signature.items() if len(lines) > 1}

    sections = [
        "# Field Notes Maintenance Report",
        "",
        f"- Notes file: `{notes_file}`",
        f"- Parsed notes: `{len(parsed)}`",
        f"- Malformed note lines: `{len(malformed)}`",
        f"- Orphan note fragments: `{len(orphan_lines)}`",
        f"- Duplicate signatures: `{len(duplicates)}`",
        f"- Missing `env:`: `{len(missing_env)}`",
        f"- Missing `scope:` or `evidence:`: `{len(missing_scope_or_evidence)}`",
        f"- Stale `unclear` older than {stale_days} days: `{len(stale_unclear)}`",
        "",
    ]

    def add_items(title: str, items: list[tuple[int, str]], limit: int = 20) -> None:
        sections.extend([f"## {title}", ""])
        if not items:
            sections.extend(["- none", ""])
            return
        for line_number, body in items[:limit]:
            sections.append(f"- line {line_number}: {body[:180]}")
        if len(items) > limit:
            sections.append(f"- ... {len(items) - limit} more")
        sections.append("")

    add_items("Malformed", malformed)
    add_items("Orphan Fragments", orphan_lines)
    add_items("Missing Environment", missing_env)
    add_items("Missing Scope Or Evidence", missing_scope_or_evidence)
    add_items("Stale Unclear", stale_unclear)

    sections.extend(["## Duplicates", ""])
    if not duplicates:
        sections.extend(["- none", ""])
    else:
        for (_bucket, _domain, body), lines in list(duplicates.items())[:20]:
            sections.append(f"- lines {', '.join(map(str, lines))}: {body[:180]}")
        sections.append("")

    action_count = (
        len(malformed)
        + len(orphan_lines)
        + len(duplicates)
        + len(missing_env)
        + len(missing_scope_or_evidence)
        + len(stale_unclear)
    )
    return "\n".join(sections).rstrip() + "\n", action_count


def main() -> int:
    args = parse_args()
    notes_file = (
        Path(args.notes_file).expanduser().resolve()
        if args.notes_file.strip()
        else skill_root() / "references" / "field-notes.md"
    )
    report, action_count = build_report(notes_file, args.stale_days)
    if args.report.strip():
        report_path = Path(args.report).expanduser().resolve()
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(report, encoding="utf-8")
        print(str(report_path))
    else:
        print(report, end="")
    return 2 if args.fail_on_findings and action_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
