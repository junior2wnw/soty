from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "routing"))

from skill_paths import skill_root as find_skill_root
import route_shelf

STOPWORDS = {
    "and",
    "the",
    "this",
    "that",
    "with",
    "from",
    "into",
    "как",
    "что",
    "это",
    "надо",
    "если",
    "чтобы",
    "почему",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize local operational memory queues.")
    parser.add_argument("--memory-dir", default="", help="Directory containing candidate and missed JSONL queues.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__)


def default_memory_dir() -> Path:
    return skill_root() / ".skill-memory"


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                parsed = json.loads(line)
            except json.JSONDecodeError as error:
                rows.append({"_error": f"{path.name}:{line_number}: {error.msg}"})
                continue
            rows.append(parsed if isinstance(parsed, dict) else {"_error": f"{path.name}:{line_number}: not an object"})
    return rows


def top_prompt_tokens(rows: list[dict[str, Any]], limit: int = 12) -> list[tuple[str, int]]:
    counter: Counter[str] = Counter()
    for row in rows:
        prompt = str(row.get("prompt", ""))
        for token in route_shelf.tokens(prompt):
            if token not in STOPWORDS:
                counter[token] += 1
    return counter.most_common(limit)


def summarize(memory_dir: Path) -> dict[str, Any]:
    candidates = read_jsonl(memory_dir / "candidate-facts.jsonl")
    missed = read_jsonl(memory_dir / "missed-invocations.jsonl")
    errors = [row["_error"] for row in candidates + missed if "_error" in row]
    candidate_rows = [row for row in candidates if "_error" not in row]
    missed_rows = [row for row in missed if "_error" not in row]
    return {
        "memory_dir": str(memory_dir),
        "candidate_count": len(candidate_rows),
        "missed_invocation_count": len(missed_rows),
        "candidate_shelves": dict(Counter(str(row.get("shelf", "")) for row in candidate_rows)),
        "candidate_types": dict(Counter(str(row.get("type", "")) for row in candidate_rows)),
        "missed_expected_shelves": dict(Counter(str(row.get("expected_shelf", "")) for row in missed_rows)),
        "missed_reasons": dict(Counter(str(row.get("reason", "")) for row in missed_rows if row.get("reason"))),
        "top_missed_prompt_tokens": top_prompt_tokens(missed_rows),
        "errors": errors,
        "ok": not errors,
    }


def print_text(report: dict[str, Any]) -> None:
    print("Memory Queue Summary")
    print(f"- memory_dir: {report['memory_dir']}")
    print(f"- candidate_count: {report['candidate_count']}")
    print(f"- missed_invocation_count: {report['missed_invocation_count']}")
    print("- candidate_shelves:")
    for key, value in sorted(report["candidate_shelves"].items()):
        print(f"  - {key or 'unknown'}: {value}")
    print("- missed_expected_shelves:")
    for key, value in sorted(report["missed_expected_shelves"].items()):
        print(f"  - {key or 'unknown'}: {value}")
    print("- top_missed_prompt_tokens:")
    for key, value in report["top_missed_prompt_tokens"]:
        print(f"  - {key}: {value}")
    print("- errors:")
    if report["errors"]:
        for item in report["errors"]:
            print(f"  - {item}")
    else:
        print("  - none")


def main() -> int:
    args = parse_args()
    memory_dir = Path(args.memory_dir).expanduser().resolve() if args.memory_dir.strip() else default_memory_dir()
    report = summarize(memory_dir)
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
