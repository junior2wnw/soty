from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "learning"))

from skill_paths import skill_root as find_skill_root
from ingest_memory_marker import sanitize_or_fail


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Record a controlled branch from a default rule or route.")
    parser.add_argument("--parent-rule", required=True, help="Default rule, route, or instruction being branched from.")
    parser.add_argument("--branch", required=True, help="Situational route that works better here.")
    parser.add_argument("--conditions", required=True, help="Conditions that make the branch valid.")
    parser.add_argument("--reason", required=True, help="Why the branch beats the parent rule in this situation.")
    parser.add_argument("--proof", required=True, help="Observable evidence for the branch decision.")
    parser.add_argument("--env", required=True, help="Tiny sanitized environment and transfer boundary.")
    parser.add_argument("--rollback", default="", help="Rollback or safe return path. Required for medium/high risk.")
    parser.add_argument("--risk", choices=["low", "medium", "high"], default="medium")
    parser.add_argument("--status", choices=["candidate", "proven", "rejected", "promoted"], default="candidate")
    parser.add_argument("--scope", default="case-local", help="case-local, platform-or-family, universal-pattern, hard-gate, or hypothesis.")
    parser.add_argument("--store", default="", help="Override route-branches JSONL path.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def skill_root() -> Path:
    return find_skill_root(__file__).resolve()


def default_store() -> Path:
    return skill_root() / ".skill-memory" / "route-branches.jsonl"


def store_path(raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else default_store()


def compact(value: str) -> str:
    return " ".join(value.strip().split())


def clean(value: str, field: str) -> str:
    text = compact(value)
    if not text:
        raise ValueError(f"--{field} is required")
    return sanitize_or_fail(text)


def optional_clean(value: str) -> str:
    text = compact(value)
    return sanitize_or_fail(text) if text else ""


def read_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict):
            rows.append(row)
    return rows


def append_row(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True))
        handle.write("\n")


def build_row(args: argparse.Namespace) -> dict[str, Any]:
    rollback = optional_clean(args.rollback)
    if args.risk in {"medium", "high"} and not rollback:
        raise ValueError("--rollback is required when --risk is medium or high")
    return {
        "created_at": now_utc(),
        "type": "route-branch",
        "status": args.status,
        "risk": args.risk,
        "parent_rule": clean(args.parent_rule, "parent-rule"),
        "branch": clean(args.branch, "branch"),
        "conditions": clean(args.conditions, "conditions"),
        "reason": clean(args.reason, "reason"),
        "proof": clean(args.proof, "proof"),
        "env": clean(args.env, "env"),
        "rollback": rollback,
        "scope": clean(args.scope, "scope"),
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    path = store_path(args.store)
    row = build_row(args)
    append_row(path, row)
    rows = read_rows(path)
    return {"action": "record", "store": str(path), "branch": row, "branch_count": len(rows), "ok": True}


def print_text(report: dict[str, Any]) -> None:
    branch = report["branch"]
    print("Route Branch")
    print(f"- status: {branch['status']}")
    print(f"- risk: {branch['risk']}")
    print(f"- parent_rule: {branch['parent_rule']}")
    print(f"- branch: {branch['branch']}")
    print(f"- conditions: {branch['conditions']}")
    print(f"- proof: {branch['proof']}")
    if branch["rollback"]:
        print(f"- rollback: {branch['rollback']}")
    print(f"- store: {report['store']}")
    print(f"- branch_count: {report['branch_count']}")


def main() -> int:
    args = parse_args()
    try:
        report = run(args)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
