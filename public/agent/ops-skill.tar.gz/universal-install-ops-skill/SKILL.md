---
name: ops
description: >-
  Use $ops as the default memory-backed accelerator for computer and system
  work: terminal, PowerShell, SSH, packages, apps, services, runtimes,
  containers, OS, firmware, devices, MCP, Codex skills, skill sync, audio,
  Wi-Fi/VPN controls, and reusable tool work. Reuse the best known route,
  command, proof, rollback, and source-scoped memory; act once ready; record
  sanitized successes and failures so future agents finish faster with fewer
  tokens and round trips.
metadata:
  aliases:
    - universal-install-ops
    - system-ops
    - computer-ops
---

# Ops

Ops is shared operational memory for computer/software work. Its job is not to
bind the agent with rules; its job is to make the agent faster and more capable
by surfacing the best known route, command, proof, rollback, and reusable
lesson before the agent wastes a round trip.

## One Reflex

Route -> Act -> Prove -> Learn -> Close. That is the whole skill: ask memory
for the strongest prior, act when the target/proof/risk are clear, update memory
when reality teaches something, and close with proof plus `learning_delta`. A
final answer without a `--close` receipt or named blocker is unfinished.

Before each state change and final answer, check:

- result: the visible outcome the client needs.
- target: the right machine, user, console, and control plane.
- route: one shelf/helper/hot route, or one deterministic probe.
- proof: the exact signal that shows success or the blocker.
- learn: patch, note, marker, branch, handoff marker, or explicit no-op.
- client: plain language when the contour changed.

Route forks are learnable events. If ask-vs-probe, stop-vs-continue,
helper-vs-new-script, foreground-vs-background, or patch-vs-note-vs-branch
changes the next comparable run, give it a sink before the next state change.
Use [core-operating-rules.md](references/core-operating-rules.md) as the legacy
filename for core operating memory when subtle. Default to the safest
highest-probability route; if current proof beats memory, take the better path
and record `expected`, `actual`, `proof`, and `env` so memory improves.

## Ready Gate

Proceed when target, route, proof, risk, and learning sink are clear enough.
The gate is not a restraint; it is a short readiness check that lets the agent
act confidently. Pause for one fact only when target/control plane, bottleneck,
proof, rollback, or route-fork sink is unclear, or when the next move is broad
scanning, fresh scripting, guesswork, or a reusable lesson with no
patch/marker/branch/no-op.

Done means `user-visible proof + learning_delta + --close final_line`.
`learning_delta=no-op` is valid only when no blocker, fallback, timing, command,
lower-probability outcome, route fork, route, or wording lesson would make the
next comparable run faster or safer.

## One Command First

Run this from the skill root, or by absolute path from an installed copy:

```powershell
python scripts/ops.py "<task in one sentence>"
```

Follow its output:

- `action_packet`: do this first; it compresses the route into do/stop/prove/remember/close.
- `helper` / `run`: use the printed command only when it exactly matches.
- `helper_fit`: run a helper only when this says `run`; `candidate` is context.
- `read`: open only the listed shelf file if no helper fits or risk is higher.
- default text output is brief; use `--detail` or `--json` only when the route is unclear, risk is higher, or memory snippets change the next action.

Fallback when `scripts/ops.py` is unavailable: run `memory_loop.py --mode
before`, `route_shelf.py --top 1`, `route_hot.py --top 1`, then
`find_script.py --top 1`; in Soty LINK-only sessions with no local shell but
`soty_run` / `soty_script`, keep execution source-scoped with one direct LINK
command plus readback and treat the controller as the routing surface.

## Memory Priors

These are cached accelerators, not commandments. Ask memory for the best known
route/helper/profile before inventing work; override it when current proof is
stronger and record the branch.

- Use `scripts/ops.py`, hot routes, route profiles, and `find_script.py` to get
  current commands and proof targets without scanning.
- Keep default output small; pull `--detail`/`--json` only for uncertainty,
  higher risk, or route-changing memory.
- Prefer one deterministic probe, or parallel independent safe probes, over a
  broad inventory.
- For source-scoped Soty work, one exact action+readback is usually enough; use
  machine-worker proof only for privileged work.
- For long/risky work, reuse the lightest awake/rollback/return-path pattern
  that preserves proof.
- Keep secrets, private paths, raw logs, serials, MACs, IMEIs, and transcripts
  out of shared memory.
- Treat skill growth as done-work: patch, branch, note, marker, or no-op the
  reusable lesson, update metadata/sync when needed, then run health gates.

## Self-Improvement Sink

Use compact reusable memory as the default path instead of raw dialog storage.
Prefer the strongest writable sink: patch module/hot/helper/eval,
`ops.py --branch`, field note, `ops.py` with proof/env, or one sanitized marker
when no skill tree is writable.

Learning is a reflex: every reusable failure, fallback, timing, command, lower-probability outcome, route fork, or wording win must become patch, auto-written marker, branch, or explicit no-op before the next state change.
For Soty Agent successes/failures, `--remember` expected/actual/proof/env before broad retry or final, and keep receipts out of user chat unless asked. Before final, close with `ops.py --close` and carry its `final_line` forward.

## Learn During/After

Capture useful memory while the run is still alive. Run `--checkpoint` after
waits/resumes/route changes. Use `--remember "<fact>" --proof "<proof>"
--env "<env>"` for route-changing facts, fallbacks, blockers, associations,
tool failures, clearer wording, and winning routes; promote repeated or
safety-changing facts into shelf/hot/eval/helper.

## Universal Improvement Contract
Improve the next comparable run or name why it cannot. Reuse a surfaced route
profile before new exploration; if none matches repeated work, create/update one
with proof, transfer boundary, and metrics when known. Claim ideal improvement
only from profile/patch/branch/marker/no-op proof, not from an unreviewed note.
For skill edits, finish with `python scripts/skill/finish_skill_edit.py`.

## Done

Finish when the outcome is verified or one blocker is named, required copies
match for skill-sync work, and the smallest safe reusable `learning_delta`
receipt is complete: patch, note, marker, handoff marker, or no-op.
