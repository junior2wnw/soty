# Everyday Control Memory

Use this module for recurring low-risk controls where the user wants the agent to act on real system or device state without opening a heavy case every time.

Typical examples:

- mute, unmute, or change output device
- stop or resume music
- switch Wi-Fi, Bluetooth, hotspot, or VPN state
- reconnect a device, sink, radio, or media session
- choose among several working control planes for the same action

## Core Rule

Small controls still produce reusable operational knowledge.

Capture that knowledge in a lightweight layer instead of losing it in prose or
forcing a full destructive-case ritual onto it.

Keep a lightweight control-memory layer that captures:

- what action was needed
- what target it touched
- which control plane worked
- how success was observed
- which route was shortest and least annoying
- which facts transfer to similar systems and which do not

## When To Use This Instead Of A Full Case

Use the light contour first when all of these are true:

- the action is low-risk and reversible
- no destructive write, firmware change, or credential rotation is happening
- no multi-reboot or long handoff is required
- the main value is remembering the quickest reliable control path

Escalate to a full case when the control action:

- changes trust, persistence, or boot state
- affects production services or wide network reachability
- has a meaningful rollback story
- requires several sessions, logs, or operator handoff

## Control Fact Shape

Record recurring control learnings as `control_facts`.

Recommended fields:

- `action`
  - plain-language action such as `mute audio`, `stop music`, `toggle wifi`, `disconnect bluetooth headset`
- `target`
  - what is being controlled, such as `system audio`, `spotify`, `wifi radio`, `pipewire sink`, `android media session`
- `control_plane`
  - local shell, ssh, adb, fastboot, gui, media session API, browser tab, MCP, and so on
- `method`
  - the concrete command, API, or user action that worked
- `observable_success`
  - what proves success right now
- `result`
  - `works`, `blocked`, `partial`, or `conflicts`
- `step_count`
  - how many real steps the operator or agent had to take
- `friction`
  - `low`, `medium`, or `high`
- `scope`
- `evidence_quality`
- `freshness`
- `target_fit`
- `goal_fit`
- `source_ref`
- `shared_dimensions`
- `divergent_dimensions`

## Surface Rule

A good control fact should be easy to find later.

Keep the best-known route on the surface by scoring not only confidence, but also route cost.

Use the same evidence dimensions as weighted facts, then apply small control-specific multipliers:

- result quality
- step count
- friction

This produces a `surface_score`.

Use that score to keep visible:

- the best current method for a given action and target
- the strongest alternate
- blocked or conflicting methods that should not be retried blindly
- transferable family-level control facts that still need exact-target confirmation

## Lookup-First Rule

Before taking any tiny-control action, normalize the request and check this module for a matching surfaced route.

Fast lookup order:

- `Quick Route Index`
- `Proven Tiny-Control Example`
- bundled helper scripts under `scripts/`
- compact matching notes in [field-notes.md](field-notes.md)

If a surfaced route matches the OS, control plane, target, and desired state, run it before probing for external tools or building a new command. If that route fails, record the failure and then continue route selection.

For exact-state controls, prefer `Mute`, `Unmute`, `Get`, or explicit setters over blind toggles.

## Quick Route Index

| User intent | Target | Environment | Primary route | Success sign |
| --- | --- | --- | --- | --- |
| mute audio / выключи звук | system audio | Windows 10/11 local desktop session with PowerShell and a default render endpoint | `python scripts/find_script.py "выключи звук" --shelf control-surfaces --top 1`, then run the printed `run:` line | JSON contains `"Muted":true` |
| unmute audio / включи звук | system audio | Windows 10/11 local desktop session with PowerShell and a default render endpoint | `python scripts/find_script.py "включи звук" --shelf control-surfaces --top 1`, then run the printed `run:` line | JSON contains `"Muted":false` |
| get audio mute state / проверь звук | system audio | Windows 10/11 local desktop session with PowerShell and a default render endpoint | `python scripts/find_script.py "проверь звук" --shelf control-surfaces --top 1`, then run the printed `run:` line | JSON reports the current `Muted` value |

## Path Discipline For Weak Agents

Resolve where this skill is installed before running helper paths.

- Use the `run:` line printed by `find_script.py`; it contains an absolute helper path.
- Use `command_from_skill_root` only after setting the current directory to the printed `run_from`.
- Prefer the printed absolute helper path over stale flat paths such as
  `scripts/windows-set-audio-mute.ps1`.
- Use custom paths such as `D:\klava_2.0\...` only after that exact file was
  just proven to exist.
- If the helper is missing in one copy, treat it as canonical/project/installed copy drift and run the skill sync gate.

## Optimization Tie-Break

When two control methods are close in evidence quality and safety:

- prefer fewer steps
- prefer lower friction
- prefer fewer operator round trips
- prefer lower token cost
- prefer the cleaner success signal

Keep proof in the score. A one-step trick that is unreliable should rank below
a two-step method with a stable success sign.

## Proven Tiny-Control Example

Windows audio mute should use the catalog first:

```powershell
python scripts/find_script.py "выключи звук" --shelf control-surfaces --top 1
```

Then run the printed `run:` command. It should look like:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "<absolute-skill-path>\scripts\control\windows-set-audio-mute.ps1" -Action Mute
```

Success signs and guardrails:

- the script returns machine-readable JSON
- `"Muted":true` proves the endpoint is muted now
- `"Muted":false` proves unmute
- the same helper also supports `Get` for read-only state
- use `-Action Mute|Unmute|Toggle|Get`; `-Muted $true` is not the supported
  parameter
- use exact-state routes before the keyboard mute key, because the key toggles
  and can invert the desired state
- prove mute with the endpoint `Muted` state, not volume `0`
- use the bundled helper before hand-written CoreAudio COM snippets

## Fast Path In A Case

If a case already exists, record small control facts with:

```bash
python scripts/case/record_control_fact.py <case-dir> --action "mute audio" --target "system audio" --control-plane local-shell --method "find_script.py returned windows-audio-mute run: powershell -NoProfile -ExecutionPolicy Bypass -File <absolute-skill-path>\\scripts\\control\\windows-set-audio-mute.ps1 -Action Mute" --observable-success "JSON output contains \"Muted\":true" --result works --step-count 1 --friction low --scope exact-target --evidence-quality live-observed --freshness current --target-fit exact --goal-fit direct --source-ref "command output"
```

Then surface the best routes with:

```bash
python scripts/case/score_case_facts.py <case-dir> --write
```

## Fast Path Without New Backend Features

If a full case is not worth opening and the practical durable corpus is dialog history, emit one compact sanitized marker line:

```text
control-memory: action=mute audio | target=system audio | plane=local-shell | result=works | method=find_script windows-audio-mute run line with -Action Mute | success=JSON output contains "Muted":true | shared=windows 10/11, local desktop session with active PowerShell
```

This keeps the current project simple:

- no new server feature is required
- later review can grep dialog history for `control-memory:`
- the skill can still promote the durable pattern into shared notes afterward

Keep the marker short, sanitized, and only for facts that are likely to help again.

## Promotion Rule

Promote a control fact when it is likely to recur across:

- the same machine
- the same software stack
- the same hardware family
- the same control plane model
- the same operator environment

Promote the pattern, not the noisy story.

Good shared learnings:

- the system media session is the real control layer here
- Bluetooth volume is independent from sink volume on this stack
- this Wi-Fi toggle path needs two steps because policy snaps it back
- the lower-step route is reliable only after one exact preflight

Bad shared learnings:

- an exact host-only alias with private data
- a lucky one-off button path with no success sign
- a route that worked once but has no scope boundary
