# Agent Runtime And Skill Ops

Use this module when the operational target is the agent system itself: Codex CLI, ProxyAPI, MCP servers, tool discovery, local or bundled skills, prompt/default-skill routing, any console used by the agent, or the memory path that teaches future software-ops runs.

Use `console` as the universal word for terminal, shell, command prompt, PowerShell, SSH shell, recovery shell, serial console, container exec, cloud shell, and comparable command surfaces.

## Core Memory

Treat agent and skill plumbing as software-state work.
The target is not only the user's app or OS; it can be the runner that decides which tools, skills, prompts, and memories are available.

Resolve the active control plane first; a skill directory, config file, or
synced copy is only active after the current response can see or follow it:

- current session: the prompt and tool registry already loaded for this conversation
- canonical skill tree: the source directory where reusable workflow and memory should be edited
- bundled copy: the version shipped with an agent build, if present
- installed machine-skill copy: the runtime directory a local CLI or ProxyAPI reads
- sync path: script, junction, copy, package build, or restart that moves canonical edits into the runtime

## Ops Mission Changes

When the user says the ops skill should be faster, more universal, better at
remembering, or cheaper in tokens, treat that as a mission-contract update, not
only a memory note.

- Patch the visible runtime surfaces first: `SKILL.md`, `scripts/ops.py` voice,
  `references/core-operating-rules.md`, hot routes, activation eval, and
  self-check.
- Keep details out of `SKILL.md` unless every agent needs them before routing.
- Measure success by shorter future runs: fewer scanned files, fewer commands,
  fewer operator round trips, clearer proof, and better reusable memory.
- Preserve only the gates that unlock confident action: identity, backup,
  rollback, provenance, return path, and privacy. The rest of the skill should
  be memory that accelerates work, not restrictions that shrink the agent.
- When a skill missed behavior, fix the capture mechanism for the route forks
  that led there, not only the final visible symptom.

## Discovery Procedure

1. Identify which agent runtime is answering:
   - API-hosted session
   - local Codex CLI
   - ProxyAPI wrapper
   - bundled app agent
   - another MCP-backed runner
2. Check whether that runtime exposes a skill registry or tool-discovery surface in the active session.
3. If a console is involved, record which console the runner is using, what host or container it targets, its working directory, and whether the next command is read-only, reversible, or state-changing.
4. If the registry is unavailable, read the canonical `SKILL.md` and reference files directly from disk before acting.
5. Verify the canonical source path and any installed or bundled copies.
6. If a configured skill did not activate, separate these states:
   - `source-present`: the skill exists in the repo
   - `runtime-installed`: the runner can see the skill directory it reads at startup
   - `session-active`: the current prompt/tool registry includes the skill now
   - `memory-updated`: the canonical tree contains the new reusable learning
7. If wording missed the right route, record it with `scripts/learning/record_missed_invocation.py` and add or update a case in `references/activation-eval.json`.
8. Update the canonical tree first, then sync or record the blocked sync path.
9. Tell the user plainly which layer failed: missing source, unsynced runtime, active session already built, or no discovery surface exposed.

## Codex And ProxyAPI Notes

- A running Codex or API conversation may not reload a newly installed skill until a new session or runner restart builds a fresh prompt/tool registry.
- `agents/openai.yaml` can describe how a skill should be invoked, but it does not prove the current session received that instruction.
- A local skill copy under a runtime home directory can diverge from the canonical repo. Prefer a junction or managed sync when the runtime supports it.
- For Codex CLI, the durable binding is the skill directory under the Codex home skills path. Prefer a link to the canonical tree when local development should update the skill immediately; otherwise use the managed sync script and verify the copied metadata hash.
- A `skills.config` entry proves intended routing, not active routing. Pair it with the filesystem binding, `scripts/skill/skill_health.py`, and a fresh Codex CLI session or runner restart before calling the skill active.
- If Codex CLI reports `chatgpt.com/backend-api/codex/responses`, it is still using ChatGPT transport. For an OpenAI-compatible provider, verify the active `CODEX_HOME`, then require `model_provider`, `forced_login_method = "api"`, a provider `base_url`, an `env_key` with a process or user secret, `requires_openai_auth = false`, and `supports_websockets = false` when the provider does not support Codex WebSockets. Treat `OPENAI_BASE_URL` as a hint, not proof of provider routing.
- For an always-on Soty server Codex executor, if ChatGPT web-auth files are present but direct server traffic gets ChatGPT/Cloudflare 403, a private server-side proxy secret can be the smaller fix than switching the whole route to API-key mode. Store only a chmod-600 secret env file such as `proxy.env` outside the repo/bundle, pass a single `SOTY_CODEX_PROXY_URL` into the executor, expand it only into the child Codex process proxy env, and expose only redacted health like `codexProxy=true` plus the scheme. Record proxy health as redacted capability evidence, keeping proxy URL, password, IP, and username out of learning receipts, bundles, manifests, repo config, and user-visible proof.
- For Soty server Codex executor model checks, inspect the actual executor container or process rather than the login user's Codex config. In the managed Docker executor, check `/agent/soty-agent.mjs` for `codex exec` arguments, `/agent/codex-stock-home/config.toml` for explicit `model` overrides, and `CODEX_HOME=/agent/codex-stock-home codex debug models --bundled` for the bundled default when no model is pinned. Treat a host user's `~/.codex/config.toml` as separate unless the executor copies or points to it.
- If an MCP server returns HTML, Cloudflare, or a webpage instead of JSON-RPC during initialize, treat it as a bad endpoint or blocked remote service and disable that MCP entry unless the current task needs it. Use `enabled = false` for configured servers and `features.apps = false` for built-in Codex Apps startup noise.
- If a repository provides a sync script, use that path before hand-copying files.
- After editing a skill, run `scripts/skill/skill_health.py` from the skill tree. Treat bundle or installed-copy drift warnings as routing facts, not as proof the workflow change is wrong.
- After changing triggers, shelf keywords, hot routes, or prompt wording, run `scripts/routing/evaluate_activation.py` so invocation quality is tested instead of guessed.

## Soty PWA Operator Bridge

Use this when the controller has the Soty PWA open and the local `soty-agent` companion is running on `127.0.0.1:49424`.

- Control plane: the browser PWA owns rooms, shared text, local settings, files metadata, and the operator bridge. The local agent only relays localhost HTTP requests into the open PWA.
- Quick probe: `powershell -ExecutionPolicy Bypass -File scripts/soty/soty-operator.ps1 -Action list`.
- Operator dialog: `powershell -ExecutionPolicy Bypass -File scripts/soty/soty-operator.ps1 -Action say -Target <label-or-id> -Text <message>` writes into shared text gradually, preserving live-mode behavior. For urgent operational status messages, pass `-Speed fast` and keep the text short.
- Agent dialog test/send: use `powershell -ExecutionPolicy Bypass -File scripts/soty/soty-operator.ps1 -Action agent-message -Text <message>` on the device whose PWA owns the Agent dialog, or use the visible Soty composer. Keep user-facing dialog tests on transcript-aware paths; direct `/api/agent/relay/request` replies to the technical caller/stdout and bypasses the chat transcript.
- If one visible Agent-chat message starts two near-simultaneous Codex turns,
  suspect both the browser direct path and the operator bridge path. Fix below
  the transport boundary by coalescing duplicate Codex turns with
  `session + exact user text` before spawning `codex exec`, then verify with a
  marker that exactly one `task_started`, one user message, and one
  `task_complete` were recorded.
- The chat surface and the OS-command executor are separate layers. A target may still receive `say` messages through the PWA while `run` or `machine-status` fails because the target-side localhost companion is down.
- Backup: `powershell -ExecutionPolicy Bypass -File scripts/soty/soty-operator.ps1 -Action export -OutFile <path>` exports PWA-visible rooms, local Soty settings, shared text, selected device metadata, and file metadata. Treat the JSON as sensitive.
- Remote command: `powershell -ExecutionPolicy Bypass -File scripts/soty/soty-operator.ps1 -Action run -Target <label-or-id> -Command <command>` sends a short command through the target PWA and its local loopback agent.
- Universal action job: on Soty Agent `0.3.112+`, prefer `soty_action`, `sotyctl action run|script ...`, or `POST /operator/action` for nontrivial OS/software work that should be reproducible and learnable. It wraps the old `run`/`script` paths without replacing them, writes `action-jobs/<job-id>/job.json`, `result.json`, and `stdout.txt`, and emits a sanitized `action-job` learning receipt. Keep old `run`/`script` for tiny probes; promote repeated work to action jobs.
- Durable action status and cancel: for long work, pass `--detached` or `detached:true`, keep the returned `jobId`, and poll `soty_action status`, `sotyctl action status <job-id>`, or `GET /operator/action/<job-id>`. Use action list/stop when available. Treat `result.json` plus the proof string as completion evidence; if a foreground call times out or the client disconnects, check the action job/artifacts or cancel acknowledgement before retrying the same operation.
- Duplicate-safe action starts: for any long, costly, or destructive action, pass `--idempotency-key <stable-case-key>` or `idempotencyKey` in HTTP. Reusing the same key with the same command returns the existing job; reusing it with different command content is a conflict. This prevents a timed-out foreground request from launching a second format/copy/reset job.
- Timeout propagation: Soty operator timeouts must stay bounded from the HTTP companion through the browser bridge, encrypted remote command, and target local agent websocket. If a short probe hangs, suspect an old target-side agent/PWA or missing cancel path before raising timeouts; use action status/cancel evidence or refresh/restart the target side before starting another job.
- Action kernel regression gate: after changing Soty action job behavior, run `pnpm agent:selftest`. It starts an isolated agent plus mock relay and covers validation, source execution, failures, timeouts, blocked Windows reset handoff, classification, risk, detached status, idempotency, restart interruption, CLI, artifacts, learning, cancellation, and Docker skill-bundle fallback.
- Agent-chat source command: when the Soty Agent prompt provides a source device id and a target like `agent-source:<device-id>`, use that exact target with `-SourceDevice <device-id>`, for example `powershell -ExecutionPolicy Bypass -File scripts/soty/soty-operator.ps1 -Action run -SourceDevice <device-id> -Target agent-source:<device-id> -Command <command>`. Prefer source ids over visible room labels such as `lo`; labels can repeat and may point to the wrong device. If `-Action list` does not show a `source` row for that device, LINK is not active for that exact Agent dialog yet.
- Inside the Soty Agent Codex MCP bridge, source-scoped tools must synthesize and
  prefer `agent-source:<source-device-id>` before any ordinary `access=true`
  room target that merely shares the same device id. Ordinary rooms can be
  stale or unrelated to the current Agent dialog; using them can turn audio/run
  tools into `! agent-source`/404 even while the real LINK source works.
- Soty Agent Codex sessions expose the source device as seamless approved MCP
  tools, not as separate user-confirm prompts: `soty_file` for
  Desktop-Commander-style file/project work, `soty_browser` for browser
  open/CDP automation with URL fallback when a machine/SYSTEM browser cannot
  expose DevTools, `soty_desktop` for Windows screenshot/window/focus/click/type
  fallback, plus `soty_run`, `soty_script`, `soty_audio`, and
  `soty_skill_read`. Prefer specialized Soty tools before generic shell when
  they express the task more directly; keep every action source-scoped to the
  active LINK device and visible in the LINK console.
- Server-global Teacher receipts show the active Agent-dialog MCP route
  (`codex.exec.resume` plus `soty-mcp`) as the proven path for repeated
  source-scoped dialog work. When those MCP tools are present, continue through
  that surface and reserve operator-bridge wrappers for sessions where the MCP
  surface is absent, blocked, or explicitly outside the Agent dialog.
- Server-global Teacher profile rows also show `agent-source.script` as the
  proven route for nontrivial source-scoped commands such as Windows reinstall
  preparation, audio volume, power checks, and generic Windows probes. Reserve
  `agent-source.run`/`soty_run` for trivial one-line commands; use
  `agent-source.script`/`soty_script` when PowerShell quoting, variables,
  pipelines, multiple statements, or durable proof artifacts matter.
- If `agent-source:<device-id>` returns `! agent-source` but the operator bridge
  lists exactly one `access=true` concrete target whose `hostDeviceId` or
  `deviceIds` contains the same source device id, use that concrete target id
  with `-SourceDevice <device-id>`. This is still source-scoped and keeps the
  command in the visible Soty remote-command window; keep fallback anchored to a
  concrete id rather than a reusable label.
- For low-risk reversible Agent-chat work on an `agent-source:<device-id>`
  target, the source id and target id are enough route proof. Prefer one command
  that changes the setting and reads it back, for example set volume and print
  the resulting volume in the same run. Add `whoami`, `hostname`, or OS probes
  only when the route is fresh after reconnect, ambiguous, failed, privileged,
  or destructive.
- After a successful nontrivial source-scoped command, record a sanitized
  reusable command-family fact (target shape, route, proof, environment). The
  Soty agent ctl layer may auto-record audio/driver/power/package/service
  outcomes; add `ops.py --remember` yourself when the useful detail is visible
  only in the Codex run.
- If a source-scoped Soty command fails, capture a reusable route fact before
  broad retry or final answer: expected command, actual failure, exact proof
  such as `! target`/timeout/nonzero output, and environment boundary
  (relay/source id, target id shape, local companion version when known). Use
  `ops.py --remember ... --proof ... --env ...`; keep the learning receipt out
  of ordinary Soty chat unless the user asked to see internals.
- When Soty Teacher or a live run reports source-command failures, classify the
  proof before changing the route. `! agent-source`, 404/target-missing, and
  timeout are transport or source-binding evidence; plain process exits such as
  `exitcode=1`, `127`, or `3221225781` are command/runtime evidence unless the
  exact stderr proves otherwise. Keep the source-scoped route, prefer the
  specialized `soty_*` tool or `soty_script` when it fits, and capture the exact
  command plus stderr before promoting a helper, hot route, or stop gate.
- Quoting-safe remote PowerShell: use `-Action run-encoded -Target <label-or-id>
  -Command <script>` for commands with quotes, variables, `-like`, `-join`,
  pipelines, here-strings, non-ASCII text, or multiple statements. Raw
  `-Action run` is only for trivial one-liners.
- Long remote command: use `-Action run-background -Target <label-or-id> -Command <command>` for copies, DISM, media prep, backups, and other work that may exceed the PWA HTTP timeout. It returns `jobId`, `resultPath`, `stdoutPath`, and `stderrPath`; poll with `-Action job-status -Target <label-or-id> -JobId <jobId>` and inspect the result artifact instead of re-running the job.
- If a large PWA `EncodedCommand` or preflight block fails as one payload, treat it as a transport/length fallback: split diagnostics into short read-only probes, switch to `run-background` or a staged target script for longer work, and immediately close the learning reflex with `--remember` or explicit no-op if the rule is already present.
- Windows machine worker: `-Action install-machine -Target <label-or-id>` starts a detached UAC launcher on the target desktop for the one explicit admin grant needed to install Soty as a machine worker. The command should return `soty-agent-machine:uac-launcher-started`; then poll `-Action machine-status -Target <label-or-id>` and require `scope=Machine`, `system=true`, and `maintenance=true` before backups, boot-media preparation, BCD/WinRE edits, or reinstall staging.
- For Soty Agent Windows reinstall/reset requests, prefer the source-scoped
  preflight route before manual recovery settings. If `agent-source:<device-id>`
  is missing, the blocker is LINK/source access for that exact Agent dialog. If
  it is present, run read-only preflight and machine-worker checks first; manual
  recovery settings are a user-requested last-resort handoff.
- For Soty Agent clean Windows reinstall after the user has chosen the clean
  install route and said data is saved / physical access is present, continue
  through the LINK source device: prove the machine worker, inspect removable
  media, stage/download installer media in a background job when safe, or stop
  with the exact blocker such as no blank USB or explicit permission needed to
  erase the USB. Disk wipe or reboot still requires an exact destructive
  confirmation.
- If the helper says the bridge is not attached, open or refresh the PWA on the controller. Updating the local agent alone is not proof that the currently open PWA page loaded the matching bridge code.
- Managed local companion agents preserve newer local builds over older
  production manifests. When testing an unreleased Soty agent, either disable
  the update URL or require updater version comparison before accepting a
  manifest hash.
- If the user says Soty/PWA is the primary channel, use Soty for target
  identity, chat/status, export, read-only preflight, and non-elevated commands;
  keep SSH as an optional fallback when the user or workflow asks for it.
- For Windows reinstall with Soty as primary, preserve both sides of the channel: the companion agent and a clean PWA identity path. Local agent health alone does not restore a wiped PWA device because Edge/Chromium IndexedDB can hold browser-bound device identity and room state.
- Back up raw Soty browser origin folders only as forensic evidence unless Soty has an explicit app-level import/export restore path. Raw cross-profile restore can leave stale identity or inverted remote-access state; the default recovery is clean re-pair. If a device cannot share access or the command field opens when access is off, open `https://xn--n1afe0b.online/?pwa=1&reset-local=1` on that device, name it again, and re-pair.
- Soty also exposes that same local repair as a hidden service gesture: click or tap the QR code canvas ten times within a few seconds. Use it when URL entry is awkward but the PWA UI is still reachable.
- Soty Windows companion installer supports managed recovery mode: `install-windows.ps1 -Scope Machine -LaunchAppAtLogon`. Use it from the explicit machine-worker UAC grant, a SetupComplete/postinstall script that this workflow wrote to the installer media, or a proven elevated task when the PWA should remain the primary channel after Windows boots; pair it with clean PWA re-pair or an app-level PWA restore flow.
- Existing open PWA pages may have old JS after a deploy. For Soty v0.3.5+, verify `/sw.js` is `no-store` and service-worker update reload is present; otherwise ask for a refresh before expecting new operator handlers such as `say` or `export`.
- After restarting or updating the local companion, `ctl list` can say `pwa bridge is not attached` until the controller's PWA page is open or refreshed. Prove both layers: `/health` for the local companion version and `-Action list` for the attached browser bridge.
- Soty agent auto-update is best-effort and can be delayed by its polling interval. To prove an update, compare the public `/agent/manifest.json` version/hash, restart or wait for the managed runner, then verify local `/health` reports the new version.
- Soty-bundled skills use a cache-and-manifest loop. The canonical repo remains
  the writable source; `npm run build` in Soty packages it into
  `/agent/ops-skill.zip` and `/agent/ops-skill.tar.gz`, records archive hashes
  under `opsSkill` in `/agent/manifest.json`, and user companions treat their
  `skill-sources/universal-install-ops-skill` directory as replaceable cache.
  User devices produce sanitized candidate learnings; reviewed changes promote
  in the canonical repo, then health, commit, build, deploy, and manifest/hash
  plus `/health.opsSkill` verification distribute them.
- Use machine-worker health/result artifacts as proof of UAC approval,
  secure-desktop control, post-reinstall OS health, or elevated Windows
  execution. The PWA can request the UAC handoff, while legacy
  machine-specific artifacts such as `Pochinit Agent.exe` or an old postinstall
  task are case evidence rather than the universal route.
- When this module says `SYSTEM postinstall`, read it as `the SetupComplete/postinstall hook that we stage onto this run's Windows media or restore bundle`. On a fresh computer it does not already exist; the PWA/machine-worker flow must create it, copy it to the USB or applied image, and verify the file before reboot.

## Update Procedure

1. Patch the canonical skill tree first.
2. Run a route-fork audit before metadata or validation: list the decisions that
   changed the run, the rejected branch, why the chosen branch won, and the
   sink for each reusable fork. Patch or branch missing sinks immediately.
3. Keep the `SKILL.md` frontmatter `description` at or below 1024 characters; put detailed trigger logic in the body or agent prompt instead.
4. If an installed or bundled copy may contain local `.skill-memory` queues, run `scripts/skill/merge_skill_memory.py --copy-root <copy> --write` before learning review or package sync.
5. Use `scripts/skill/sync_doctor.py --copy-root <copy>` as read-only proof
   between skill copies; if a copy contains useful package edits, port the
   reviewed changes into canonical source with an explicit patch instead of
   copying either tree wholesale.
6. Update the canonical metadata hash after the final canonical edit.
7. Sync or link the installed Codex CLI skill path with `scripts/skill/sync_skill_copy.py --codex`; if replacing a divergent artifact after manual review proof, pass `--force-canonical` and keep the generated `.skill-memory/package-backups/` snapshot.
8. Copy canonical changes into any project or bundled skill tree with `scripts/skill/sync_skill_copy.py --project-root <project-root>` when the app ships or references a bundled copy.
9. Regenerate the bundled manifest from bundle files, excluding `manifest.json` itself because the updater writes the fetched manifest separately and a self-hash cannot be stable.
10. Run `scripts/skill/skill_health.py --copy-root <required-copy> --strict` for every copy that must match this release; remove generated caches such as `__pycache__` before the final health check.
11. Run `evaluate_activation.py` when the change touches invocation or shelf routing.
12. Run the skill tests when the change touches scripts, generated metadata, or routing rules.

Keep git index operations serialized. Run `git add`, `git commit`, and other
index-mutating commands separately from status/diff commands in the same
repository so stale `index.lock` noise cannot hide the real result.

For mass rollout, load [release-and-sync.md](release-and-sync.md). Use candidate/canary/stable channels and keep a previous stable hash available for rollback.

## Memory Update Rules

- Write reusable route facts into the canonical skill tree, not only into chat.
- Use `field-notes.md` for compact durable facts and patch a module when behavior changes the workflow.
- Treat route forks as first-class memory. A final patch does not cover the
  forks that led to it unless each transferable fork has its own sink or an
  explicit no-op pointing at an existing rule.
- For the current conversation, include a sanitized `ops-memory:` marker only when it will help later dialog-history mining.
- Keep private paths, hostnames, tokens, and raw transcripts out of shared notes.
- Record the smallest environment fingerprint that explains the runtime behavior: agent family, session type, skill source path, installed-copy shape, and discovery surface.

When the user asks why the skill did not improve itself, answer with the layer:

- current session may have used the skill but no writable sink was selected
- canonical repo may be absent from the working tree
- installed copy may be writable but not synced to the shared source
- hosted/read-only skill may only allow emitting a sanitized marker
- raw chat may contain evidence, but it is not the reusable artifact

Then fix the contour: patch the canonical tree when available; otherwise patch
the installed copy and label it `installed-only`, or emit one `ops-memory:`
handoff marker when no writable copy exists.

A capture with proof and env is a learning delta by default. `ops.py --during`,
`--after`, `--checkpoint`, `--close`, or `--remember` writes or reuses a
sanitized candidate marker when it can build one safely; missing proof/env
prints the blocker instead. Reuse existing marker coverage instead of appending
duplicates. When a fact changes route, risk, proof, timing, or operator wording, write it immediately or patch
the module before continuing. "I will do it later" is not a completed
improvement.

Make the learning reflex stateful, not aspirational. Before the next state
change after a reusable failure, fallback, timing, command, or wording win, one
of these must exist: a module/hot/helper/eval patch, a field note, a candidate
marker, a route branch, or an explicit no-op with proof. `--remember` with
proof/env is the fast path; capture output with missing proof/env is only a
warning that the reflex has not completed.

Treat prediction errors as reusable by default. First choose the safest
highest-expected-success route. If a less likely failure mode, fallback, or user
correction actually happens, record `expected`, `actual`, `proof`, `env`, and
whether this keeps the default, adds a conditional branch, downgrades the
default, or requires a module/helper/eval patch before the next state change.

When the active writable root is an installed Codex skill copy and the user
allows installed-copy edits, treat that copy as the edit target. Run health and
activation gates in that copy, label the result `installed-only`, and leave
canonical sync/merge as a separate proof instead of blocking the live task on a
missing canonical repo.

Answer future improvement questions with concrete close-out state. Carry forward
the `final_line` from `ops.py --close`, which names `learning_delta=patch`,
`note`, `marker`, `handoff-marker`, or `no-op`, plus the proof or blocker.
Use `python scripts/ops.py "<task>" --close --actual "<delta>" --success
"<proof>" --env "<boundary>"` when a compact close-out line is useful.
For "make it ideal/universal" work, require a reusable mechanism: route
profile, learning conveyor, stricter gate, route/eval expansion, or sync/release
proof. Treat better wording as universalization when wording was the verified
activation failure; otherwise pair it with a reusable mechanism.

Route profiles are executable priors, not shelf decorations. Reuse a profile
only when the current prompt shares distinctive task-family, profile-id,
platform, control-plane, route, or transfer-boundary evidence. Same shelf alone
is not enough; otherwise a broad skill-quality prompt can inherit an unrelated
fast lane.

## Failure Signals

- Treat "the skill exists on disk" as weaker evidence than "the active session lists or follows the skill."
- Treat "the skill is in a config file" as weaker evidence than "the runtime loaded that config before this session."
- Treat "canonical and installed copies match" as weaker evidence than "all required project, bundled, and installed copies match the same hash."
- Attribute skill misses to the active layer: content, installed copy, config,
  active session, or discovery surface.
- Turn skill-discovery failures into module or field-note memory so the next
  agent checks the same boundary sooner.
- Queue one-off wording misses as missed invocations, then promote repeated
  patterns into description text, shelf keywords, or hot routes.
- For Codex chat/session lookup, return more than `line 1` and a session id.
  First run the session locator or inspect `session_index.jsonl`; return title,
  updated_at, index path:line, transcript path:line, and useful
  title/user-message lines. Say web URLs are absent after checking local data,
  and keep raw transcripts out of the answer unless requested.

## Verification Checklist

- canonical `SKILL.md` and relevant references were read or updated
- installed or bundled copy was checked, synced, or recorded as divergent
- active-session limitation was named when the current response cannot reload skills
- Codex CLI binding was verified through the expected skills path or a managed sync result when Codex CLI is the target runtime
- console type, host/context, working directory, and privilege boundary were recorded when a command surface was involved
- health check was run or the reason it was skipped is recorded
- activation eval was run when routing behavior changed
- reusable facts were promoted into shared notes or a module
- route forks encountered during the update were patched, branched, noted,
  marked, or explicitly no-op'd with proof
- user-facing explanation names the exact layer that failed and the next activation path
