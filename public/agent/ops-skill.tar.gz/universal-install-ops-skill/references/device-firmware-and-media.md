# Device Firmware And Media

Use this module for phones, tablets, Chromebook conversions, firmware flashes, driver binding, and bootable media.

## Universal Device Memory

1. Identify the exact model and codename from evidence, not memory.
   - Treat connector type, screen text, model label, and host-visible USB identity as evidence.
   - When the observed connector or screen contradicts the assumed model, treat
     that as re-identification evidence before flashing.
2. Confirm the real desired outcome:
   - stock restore
   - custom ROM
   - Linux on device
   - recovery flash
   - bootable media
3. Check bootloader or firmware state before touching images.
4. Unlock destructive actions with backup, battery, cable, USB, and hash checks.
5. Verify that the host can see the device in the required mode before flashing.
6. Record the host and device environment facts that explain why the route should work here: host OS, toolchain source, driver state, cable or port reality, current mode, and expected next transport.
7. Infer cable connector or data capability from host proof first. Ask for the
   human-visible connector shape when the host cannot prove it, then verify data
   capability with `adb`, `fastboot`, MTP, or live USB enumeration.

## Scoped Transfer For Hardware

Treat hardware, firmware, driver, network-device, and boot-media facts as scoped evidence, not universal rules.

Reusable similarities can suggest the next route or preflight check:

- same hardware generation, SoC, chipset, firmware family, board family, boot mode, partition style, or peripheral family
- same host OS, driver stack, cable or port behavior, flashing tool, boot media format, recovery environment, or network control path
- same transport transition, such as GUI -> USB boot, OS -> recovery, `adb -> fastboot`, SSH -> serial, web UI -> recovery shell, or controller -> out-of-band console

Exact-target differences still decide risky work:

- model suffix, board revision, carrier or region variant, codename, architecture, firmware build, bootloader unlockability, storage layout, panel or peripheral variant, driver identity, network policy, and rollback image

When a hardware fact transfers, record the shared dimension that made it transfer. When it fails to transfer, record the divergent dimension before trying another destructive step.

## Transport Ladder

- Name the current transport before every phase: `adb`, `fastboot`, recovery shell, serial, USB network, SSH, GUI-only driver tool, or a human-at-device step.
- Predict the next transport before changing state. A good flash plan looks like `adb -> fastboot -> flashed system over USB network` instead of one giant "install OS" step.
- Verify the next transport directly and treat disappearance of the previous
  transport as a transition signal until the new transport is checked.
- When a step crosses into `UAC`, certificate trust, or GUI-only driver flow,
  collect explicit operator evidence before continuing the headless path.

## Android And Phones

- Prefer official Android Platform-Tools for `adb` and `fastboot`.
- Treat USB debugging, RSA trust, bootloader unlock, and mode visibility as first-class gates.
- On Windows, treat driver binding as part of the workflow, not as cleanup.
- On Windows, use `scripts/android/android-usb-preflight.ps1` when Android USB visibility is confusing; it summarizes `adb`, `fastboot`, and live PnP evidence in one place.
- If the workflow needs a GUI-only driver tool or vendor confirmation dialog,
  use the user-visible confirmation as the proof source for that step.
- After any Windows driver install attempt, verify the exact live hardware ID or compatible ID and then verify tool visibility such as `fastboot devices`. A success dialog alone is not evidence.
- Treat `CurrentUser` certificate trust as one signal for Windows driver
  packages. New driver packages can still require elevation and machine-level
  trust before `pnputil` accepts them.
- For Samsung devices, prefer an open tool such as Heimdall only when the exact device and workflow are known to work there. Otherwise fall back to the vendor-required path.

### Android Operator Prompts

Use these simple prompts instead of asking the user to interpret Android jargon:

- To check file-transfer mode: "Unlock the phone. Swipe down from the very top. Tap the Android system notification about USB. Choose `File transfer` or `Передача файлов`. Reply `files` if a phone folder appears on the computer, or `no files` if nothing appears."
- If there is no USB notification: "Open Settings. Tap the search box. Type `USB`. Open the result that mentions USB preferences or USB settings. Choose `File transfer` or `Передача файлов`."
- To enter bootloader mode: "Turn the phone fully off. Hold Power and Volume Down together until the screen says `FASTBOOT` or shows the fastboot picture. Reply `fastboot screen`."
- To avoid accidental destructive steps: "This next check only looks. It does not erase anything. I will say clearly before any step that can erase the phone."
- For Russian-speaking users, prefer plain Russian prompts with the exact visible label, e.g. `Передача файлов`, and avoid raw acronyms unless the phone screen actually shows them.

For nontechnical users, ask for the visible result, such as whether a phone
folder appears on the computer, instead of asking them to interpret "MTP".

## Mobile Linux

- Always start with [route-selection.md](route-selection.md) when the user asked to "install Linux" or "pick the best option" on a phone or tablet.
- If the user chooses to begin a true port for an unsupported phone, switch from install mode to [mobile-linux-porting.md](mobile-linux-porting.md) and keep the route `porting-only` until boot and feature evidence justify a stronger claim.
- Explain mobile Linux in simple terms: "ready image" means a file someone already made and tested; "porting" means we must build and test the first working path ourselves.
- Prefer maintained device matrices over generic distro promises.
- Treat modem, calls, SMS, camera, Wi-Fi, Bluetooth, GPS, suspend, charging, and USB OTG as separate support dimensions.
- Distinguish these route roles before naming a distro:
  - end-user install
  - advanced install
  - experiment-only install
  - porting-only workflow
- Prefer the route whose support story best matches the user's real goal:
  - daily-driver phone: favor feature completeness and update reality on the exact device
  - spare phone or learning project: a testing-grade or mainline-first route can be the better fit
  - Debian userland goal: a Halium-based route such as Droidian can be the better fit when the exact device is truly listed
  - Linux-first hardware: Mobian or the distro aligned with that hardware may beat Android-adaptation stacks
- Rank `postmarketOS`, `Droidian`, `Ubuntu Touch`, `Mobian`, and other projects
  by exact-device support, user goal, and feature proof instead of a single
  default.
- If the exact device page exists and is maintained, use it as the primary install authority.
- If the exact device page defers to a generic SoC or family page, treat that family page as the install authority instead of improvising from memory.
- Use cross-device similarities as candidate evidence, not proof. SoC family, bootloader family, firmware lineage, partition style, host OS, cable or driver behavior, and distro tooling can suggest the next checks or route family.
- Verify exact-device differences before any destructive action. Model suffix, region or carrier variant, bootloader unlockability, partition names, panel or touchscreen variant, modem, camera, feature matrix, and maintained image availability can differ even when the phones look related.
- When a fact transfers from one phone to another, record the shared dimension that made it transfer. When it does not transfer, record the divergent dimension instead of discarding the broader pattern.
- If the device is not on the normal supported-device list, downgrade the route honestly:
  - from end-user install to experiment-only
  - or from experiment-only to porting-only
- Treat community mobile Linux ports as second-device workflows unless the support matrix shows otherwise.
- Prefer stable prebuilt images first. Use edge builds only for a named blocker.
- Compare route families honestly:
  - mainline-first distros can win on openness and long-term kernel direction
  - Android-kernel adaptation stacks can win on hardware completeness for Android-born devices
  - Linux-first-device distros can win when the hardware was designed around upstream Linux support
- On Windows, if `fastboot` crashes on a large raw image with host-side allocation errors, convert the raw image to Android sparse format with `img2simg` or `wsl img2simg` and flash the sparse image instead of repeating the same failing command. Use `scripts/android/android-convert-image-to-sparse.ps1` when you want that step packaged into one reusable helper.
- Post-flash success can be proven by a new transport such as USB NCM gadget networking, `ping`, or a reachable service, even when `adb` never comes back because the target is no longer Android.
- If the new Linux system boots to a visible UI, side buttons work, and a new transport is reachable but touch does not work, treat this as a targeted input or boot-config variant issue first. Prefer a boot, device-tree, or `lk2nd` correction before repeating a full rootfs flash.

### Mobile Linux Quick Ranking

Use this quick ranking when several distros are plausible:

1. exact-device route with the best fit for the user's goal
2. maintained family or generic route with explicit feature boundaries
3. named community build with current evidence and reversible recovery path
4. porting workflow

If the best route still misses a must-have feature, say the goal is not honestly met yet.

## Apple Devices

- For macOS reinstall, use macOS Recovery.
- For Apple silicon or T2 firmware recovery, use the official revive or restore path from another Mac.
- For iPhone or iPad revive or restore work, use Apple Configurator or the official recovery path.
- Use Apple's required tooling where Apple devices depend on it, and name the
  exact Mac/Configurator/Recovery route.

## Chromebook Conversions

- Verify exact model or HWID, CPU family, and firmware support before planning Windows or Linux installation.
- Separate physical prerequisites from software steps:
  - Developer Mode
  - write-protect state
  - firmware path
  - bootable media
  - driver reality after install
- Keep firmware work gated behind support and recovery checks.

## Bootable Media

- Prefer official Windows media or official ISOs over random repacks.
- Prefer Ventoy when multi-image USB behavior is useful and supported by the scenario.
- Use WIM splitting when a FAT32 path cannot hold a large `install.wim`.
- Keep backup data on a different device than the installer USB.

## Media Execution Contract

- verify source URL and hash when available
- verify removable target identity
- verify whether erase approval is explicit
- write media
- re-read the media contents or boot entry facts
- verify the next boot path

## Expansion Priors

- Flash after exact model/codename and rollback path are known.
- Re-identify the device when connector, model label, or screen contradicts the
  assumed route.
- Treat USB cable, port, charging, and data visibility as separate facts.
- Give nontechnical users the exact phone-screen path and the visible success
  sign.
- Switch from firmware changes to media repair when bad media is the blocker.
- Treat first boot as bring-up proof; daily-driver claims need feature proof.
- Pair driver installer success with live device identity and platform-tool
  visibility.
- After installing a non-Android OS, let the new transport replace `adb` when
  the target proves it.
- Follow boot-side variant evidence before repeating a full system flash.
- Promote flash routes with host, driver, transport, and device-mode facts.
