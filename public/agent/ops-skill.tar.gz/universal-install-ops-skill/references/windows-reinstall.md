# Windows Reinstall Module

Use this module for Windows install, reinstall, repair install, or recovery handoff on the local machine, through Soty/PWA, or over a fallback remote shell.
Use [case-system.md](case-system.md) when the work is destructive, rebooting, or likely to span more than one chat.
Use [control-plane-hub.md](control-plane-hub.md) whenever VPN, tunnel, source-interface choice, or post-reboot return path is shaping the route.

Default version rule:

- If the user does not specify a Windows version, prefer official Windows 11 media.
- If the user explicitly asks for Windows 10 or another version, follow that request.

## Default Plain-Language Answer

When the user asks a broad question like `how would you reinstall Windows?` and there is no remote-control or enterprise context yet:

- Default to the `local_operator` consumer path.
- Keep the answer short, calm, and plain-language.
- Split the answer into two branches before giving steps:
  - `keep my files` -> repair install or reset path when Windows still boots
  - `clean reinstall` -> official Windows 11 USB path when the user wants a fresh system or Windows is too broken
- For the clean path, the default recommendation is:
  1. back up personal files first
  2. confirm BitLocker or other recovery-key safety
  3. build an official Microsoft Windows 11 installer USB
  4. boot from that USB
  5. choose the custom install path only when the user is ready to erase the internal Windows disk
  6. finish setup, Windows Update, drivers, and file restore
- Explicitly separate `I am erasing the USB flash drive` from `I am erasing the laptop or PC disk`.
- If the user did not say whether files must be kept, make that the first branching point instead of jumping straight to the destructive path.

## Canonical Flow

1. `preflight`
2. `clear_blockers`
3. `stage`
4. `acquire_media`
5. `prepare`
6. `confirm`
7. `arm`
8. `observe`
9. `collect_logs`
10. `improve`

## Fast-Lane Target

The benchmark is a human specialist who can start a routine reinstall on a prepared device in 5-10 minutes.
Treat that as the target for supported, ready machines, not as a promise for unknown, remote, or unsafe machines.

Classify every Windows reinstall into one of these lanes before writing scripts:

- `fast_lane`
  - all gates are true: data boundary or backup known, trusted official media ready, BitLocker state safe, control plane or return path proven, exact device profile present, and operator handoff clear
- `readiness_building`
  - one or more gates are missing; run the shortest read-only probe or ask one blocker, update the case/device profile, and stop before destructive work
- `recovery_or_risky`
  - post-reboot control, media, backup, or storage facts are uncertain; use the safe branch and keep destructive work blocked

Fast-lane behavior:

- Reuse prepared official media, a mounted ISO, a proven USB worker, a WinRE/internal boot payload, a Soty machine worker, or the device profile before creating anything new.
- Give one start command or one physical operator action when gates pass.
- Avoid new one-off reinstall scripts during a live reinstall. If the same missing step costs time twice, promote it as a reusable helper, hot route, or module patch after the run.
- For new devices, create or refresh the device profile before implementation details sprawl.

Device profile minimum:

- model and exact target identity
- firmware or UEFI boot key, boot mode, secure boot, and USB boot behavior
- storage layout, destructive/data boundary, and backup target
- BitLocker state and recovery-key safety
- network, Wi-Fi, driver, and return-path facts
- control plane, operator handoff method, and operator skill level
- prepared media path, source, hash/date when available, and known worker/handoff path
- route-driving properties with priors, probes, observations, adjusted chances, and route hints
- last timings, proven failures, proven successes, and reusable blockers

Use `scripts/windows/windows-reinstall-profile.py` for sanitized reusable
profiles. Store only profile ids, device family, control plane, return path,
media state, working route, and proof; keep private hostnames, IPs, MACs,
serials, and personal paths in the case, not the shared profile.

Run `scripts/windows/windows-reinstall-profile.py --action doctor --json`
before any destructive reinstall start. Treat `lane=fast_lane` as the only
permission to give one proven start command or operator action. Any other lane
means readiness-building or recovery: name the first missing gate, prove it with
the shortest read-only probe or operator answer, update the profile/case, and
keep reset/reinstall/reboot-to-recovery blocked.

Repeated slow path:

- If an agent spends more than about 10 minutes writing or adjusting scripts before the gates are known, treat that as a skill failure.
- Stop, name the missing gate, store the profile/memory facts, and patch the reusable route instead of continuing to grow a case-local script pile.
- When all gates are already true, prefer the already-proven media/profile/handoff path over fresh discovery, even if a newer-looking path exists.

## Preferred Model

- Treat Windows reinstall as a staged destructive workflow with explicit proof at
  each phase.
- If a `windows_reinstall` MCP exists, use it as the control plane and reuse its operation state, artifacts, operator questions, and recommended next action.
- Prefer a dedicated installer USB plus a separate backup destination.
- Keep stage bundles on a fixed disk, not on the removable installer USB.

## Control-Plane Ladder

Classify the real control path before choosing media or reboot logic:

1. `out_of_band_console`
   - hardware KVM, iDRAC, iLO, IPMI console, or hypervisor console
   - best path for remote OS reinstall because post-reboot control stays available
2. `local_operator`
   - a person at the machine can insert media, confirm BIOS or boot prompts, and report what is on screen
3. `existing_remote_agent`
   - a purpose-built reinstall MCP, thin agent, or pre-staged WinRE path already exists and survives the handoff
   - a browser/PWA bridge such as Soty is useful for operator chat, status, export, and preflight, but it does not by itself survive a clean OS apply unless restore reconnects it
   - if Soty is the declared primary channel, an installed machine-scope Soty Worker with `scope=Machine`, `system=true`, and `maintenance=true` is the privileged Windows control path; the browser page alone is not
4. `ssh_only`
   - current SSH access exists now, but you must prove who controls the machine after reboot
5. `unreachable`
   - no current transport or console exists

Treat `unreachable` as a blocker report, not as the start of reinstall execution.

## SSH-Only Gate

Promise a Windows reinstall from SSH after all of these are true:

- the host is reachable now
- the post-reboot return path is explicit and testable
- a non-interactive handoff path exists for the current machine
- the user accepts any steps that still require local or console interaction

If any one of those is missing, downgrade the outcome to one of these:

- connectivity recovery
- readiness-building
- manual handoff preparation

That still counts as progress. Guessing through a reboot does not.

## VPN And Multi-Interface Rule

When the controller has both LAN and VPN or tunnel interfaces, treat a generic
timeout as route evidence until source-bound or local-neighbor proof explains
whether the Windows target is down.

- If the target is still on the same local subnet, prove local neighbor presence first.
- Compare route choice and source addresses before changing the reinstall plan.
- Prefer a source-bound SSH probe such as `ssh -b <lan-ip> user@host` when the LAN interface already proved it can see the target subnet.
- If the source-bound path works, record that exact controller source IP in the case journal and treat it as the real current transport.
- Ask the user to disable VPN only after narrower routing fixes have failed.

## Mandatory Gates

Continue after these are explicit:

- personal-file backup destination
- trusted Windows image source
- removable USB that may be erased when the chosen path needs one
- BitLocker state and recovery-key safety
- return path after reinstall
- exact destructive confirmation phrase

## Clarifying Question Gate

For an imperative reinstall request such as `reinstall Windows on X`, ask the
current human blockers before live preflight when the user has not already made
the destructive intent clear. A remote-control check can feel like execution to
the user even when it is read-only.

Ask first when any of these are unclear:

- whether this is a clean wipe, repair install, or keep-files reset
- which exact target should be affected when the label, hostname, or room name
  could differ
- whether personal files should be preserved and where
- which USB flash drive may be erased
- whether the user wants remote preparation now or only a readiness report

Exception: run one minimal read-only identity probe without waiting only when it
is needed to avoid asking about the wrong machine or to prove the target exists.
Say plainly that the probe is read-only, keep this exception to the identity
probe, and ask the blockers immediately after the identity proof.

## Reinstall Route Forks

Record Windows reinstall forks in the case journal before they fade into the
command stream. Promote the reusable ones into this module, a hot route, a
profile, or `ops.py --branch` before the next phase.

Common forks that must have a sink:

- ask first vs run a minimal identity probe
- minimal identity probe vs full preflight
- readiness report vs remote preparation now
- clean wipe vs repair install vs keep-files reset
- reuse existing media/profile vs rebuild media
- foreground PWA/SSH command vs background job or scheduled task
- PWA-first return vs SSH-first fallback
- stop at missing gate vs proceed to `prepare`, `confirm`, or `arm`

Case-only facts can stay in the case. If a fork changes what the next comparable
reinstall should do, the case is not enough; promote the route.

## Operator Questions

Ask only the current blockers.
Keep them short and concrete.
Make them understandable for a nontechnical operator on the first read.

Required categories:

1. Where should personal files be backed up?
2. Which removable USB may be erased?
3. Which trusted Windows image or official Microsoft flow should be used?

## Operator UX Rules

When a step depends on a person near the machine, make the experience plain-language and calm:

- In Soty Agent chat, keep ops and transport mechanics internal. Do not say
  `preflight`, `gates`, `source-scoped`, `bridge`, `managed staging`, or
  similar route words to a nontechnical user. Say the practical meaning instead:
  `I can see the PC`, `I cannot see the PC through Soty right now`, `I am only
  preparing the flash drive`, or `I am not erasing Windows yet`.
- If the Soty command channel times out during a reinstall request, do not
  repeat several broad probes and then dump a technical report. Try one narrow
  channel proof or repair route, then answer with one plain blocker and one next
  action, usually: `I do not see the computer through Soty right now. Open or
  restart Soty on that PC, then write "ready".`
- Do not show raw tool errors such as `agent-source 404`, `exitCode`,
  `timeoutMs`, stack traces, helper names, or JSON in chat. Translate them to
  practical meaning, for example `I do not see this PC through Soty right now`.
- Do not ask for the final destructive confirmation while the target channel is
  broken or the exact target is unproven. First restore visibility, then ask the
  next single missing fact.
- Use simple final approvals only at the moment they apply, for example
  `Да, стереть флешку` for USB-only formatting or
  `Да, стереть Windows-диск` for the actual OS disk wipe.
- Ask for one physical action at a time.
- Say what you already verified before asking for the next thing.
- Replace jargon with everyday words the first time you mention it.
  - Example: say `USB flash drive` before `removable media`
  - Example: say `what shows up on the screen after restart` before `post-reboot console state`
- Start physical-step prompts with a tiny three-part structure:
  - `What to do now`
  - `What success looks like`
  - `What to reply back with`
- If the user says they already did a physical step, verify it and answer in plain language with what was detected.
- When asking for a USB, describe the easy checks:
  - where it is plugged in
  - the drive letter or label you detected
  - whether you will erase only the USB or also touch the laptop disk
- For low-confidence operators, prefer wording like:
  - `Right now we are only preparing the flash drive. I am not erasing the laptop yet.`
  - `After restart, tell me the first thing you see on the screen. A photo is also fine.`
- When a destructive step is near, separate the scopes in simple words.
  - Example: `I am about to erase the flash drive only. I am not starting the Windows reinstall yet.`
- If a human needs to watch the screen after reboot, say exactly what to look for and what to report back.
- When a recovery step could be done either through Windows screens or through
  Command Prompt/PowerShell, put the no-command Windows-screens path first for
  nontechnical operators when it is safe enough, even if it takes longer. Put the
  command path second as the faster/more targeted technical fallback. Include one
  short pros/cons line for each.
- If no-command recovery would reset, reinstall, or risk user data while the
  command path is targeted and reversible, recommend the command path and say
  why.
- For Windows 11 OOBE Microsoft-account prompts, first look for no-command
  buttons such as `Offline account`, `Limited setup`, `Domain join instead`, or
  an unconnected-network path. If those are absent on Home/current builds, the
  short technical fallback on stable 24H2/25H2 is usually `Shift+F10`, then
  `start ms-cxh:localonly`; older `OOBE\BYPASSNRO` is no longer reliable on new
  builds and should be offered only as a fallback with that caveat.
- Avoid stacked conditions and long paragraphs when the operator is doing a physical step.
- Prefer confirmation wording that a grandparent could follow without knowing Windows internals.

## No-Go Conditions

Stop destructive planning and return a blocker report when any of these are true:

- the current host is unreachable
- there is no out-of-band console and no proven post-reboot return path
- backup destination is unknown
- trusted media source is unknown
- BitLocker state is unknown on a device that may require recovery
- the operator cannot identify which USB may be erased
- the exact destructive confirmation phrase has not been accepted

## Step Contract

### Preflight

- Collect transport, USB, disk, BitLocker, installer-source, backup-scope, and return-path facts.
- Stay read-only.
- Produce a checklist, operator questions, and confirmation phrase.
- Re-run after blocker-clearing answers.

### Stage

- Back up activation, drivers, Wi-Fi, SSH, app state, keyboard tooling, and system manifests.
- Call a restore bundle a personal-file backup only after verifying a real
  personal-files backup scope and destination; otherwise say plainly that only
  system return artifacts are being preserved and personal files will not be
  restored from this bundle.
- Store artifacts on a fixed workspace.
- Create or update the case journal before mutating anything.
- Verify that the stage bundle is present before moving on.

### Acquire Media

- Prefer official Microsoft media or a pre-verified local ISO or ESD.
- Prefer official Windows 11 media by default unless the user explicitly asked for another Windows version.
- Tie the media path to the current machine, not a guessed global cache.
- Treat removable media filesystems as a policy/capability decision, not a closed enum. Preserve the current filesystem when it is already suitable; accept an explicit filesystem string for newer or site-specific formats; keep special values such as `Auto` and `Preserve` as policy words rather than filesystem names.
- Decide whether to split `install.wim` by large-file capability or an explicit install-image layout override, not by a growing list of filesystem names. Known FAT-family targets require `.swm`; large-file-capable targets can keep a validated one-index `install.wim`; a worker can still force split or direct layout when its own constraints are stricter than the filesystem.
- exFAT is one valid large-file removable filesystem option for a worker/data
  USB, while boot defaults should stay firmware-aware: UEFI boot support varies,
  and NTFS is often the better Windows/WinPE worker choice when ACLs, large WIM
  files, and restore payloads matter.
- Re-verify Windows download fwlinks at execution time; when the official page drifts, use `scripts/windows/windows-resolve-official-win10-media.ps1` to record which current Microsoft target is actually live before you cache or reuse it.
- If Microsoft returns browser error `715-123130`, API `SentinelReject`, or equivalent media-service denial, stop retrying blind automation on the same path. Switch to another network, use an already trusted local ISO, or ask whether the user wants to proceed with another already-prepared official media set that is actually present.
- When exporting from a multi-index Microsoft ESD, select the real OS image by
  excluding `Windows Setup Media`, `Windows PE`, and setup images first, then
  prefer the installed consumer edition with localized names such as Russian
  `Домашняя`; validate any cached `install.wim` is a real OS image before
  splitting it.

Route-property rule:

- For every branch that might grow new variants, record the property instead of expanding an enum. Example: `usb.supports_large_files=true` should choose direct `install.wim`; false should choose split `.swm`. The initial route may use the highest adjusted chance, but the live target probe must be able to overturn it.
- Store the property in the case with `record_route_property.py`: prior chance, evidence quality, transfer dimensions, read-only probe, observed value, proof, and route hints for both outcomes.
- On Windows targets, `scripts/windows/windows-detect-route-properties.ps1` is the read-only probe for common USB, WinRE, BitLocker, architecture, and firmware properties. Treat its JSON as observation input, not as permission to proceed destructively.
- When a property is disconfirmed on the exact target, change the route and record divergent dimensions instead of patching one more special-case name.

### Prepare

- Build the safest verified handoff for the current machine.
- Prefer a dedicated USB path unless a verified local WinRE path already exists for this machine.
- Require a machine-specific ready signal before arm.
- When transport is `ssh_only`, write the post-reboot control path explicitly into the case journal.
- If the same machine already has a proven legacy `Pochinit-Reinstall` USB
  worker and matching logs from a successful run, treat it as evidence about
  that machine only. Build new reusable media under Soty/generic names.
- If you already have an official Windows ISO mounted as a drive, treat that mounted media root as the preferred source for rebuilding the worker USB. This avoids brittle GUI-only Media Creation Tool automation from a non-interactive SSH session.
- Before any `arm` step that depends on `sources\boot.wim`, verify that the staged or USB `boot.wim` contains the expected custom launcher for the current workflow. If verification fails, stop and rebuild media instead of letting the machine fall through to stock Windows Setup screens.
- If the operator formats the USB flash drive between attempts, invalidate every prior USB-ready fact, backup-on-USB proof, label assumption, boot-image patch, BCD edit, and restore-hook verification. Rebuild the installer media from trusted source, recreate or re-copy backups from a fixed-disk case copy, and re-run the USB proof gates before arming.
- For long remote USB rebuilds or DISM work over OpenSSH, use a durable worker
  such as a one-shot scheduled task as `SYSTEM` that writes stdout, stderr, and
  exit code to disk, then poll those artifacts.
- When a scheduled-task wrapper launches an inner bootstrap, have the inner script write script-owned result JSON and state markers. If wrapper `$LASTEXITCODE` is stale but result JSON/stdout says `status=boottore_armed`, trust the explicit inner success marker and record the wrapper residue as a cleanup bug.
- For long Soty/PWA-controlled work, use `scripts/soty/soty-operator.ps1 -Action run-background` and poll `-Action job-status`, or stage an equivalent machine-worker scheduled task that writes `result.json`, stdout, and stderr under ProgramData. Treat a foreground PWA timeout as transport evidence, not proof the target job stopped.
- When preserving browser/PWA return state, copy volatile Edge/Chromium folders such as `IndexedDB`, `Local Storage`, `Service Worker`, and `Sessions` with a short timeout and continue if they stall. These caches are helpful for re-pair diagnostics while trusted media, WinPE patching, and readiness remain the priority.
- On Windows PowerShell 5, a script re-launched with `powershell.exe -File` can receive `[bool]` parameter values as strings and fail transformation. For detached relaunches that need booleans, prefer an encoded `-Command` runner that invokes the script with real `$true`/`$false`, or use `[switch]` parameters.
- In PowerShell helper functions that forward CLI arguments, use a parameter such as `$ArgumentList`; `$Args` can collide with automatic `$args` and leave native tools such as `bcdedit` running without the intended argument list. Assert the command output before trusting parsed IDs.

## Machine-Specific Local Handoff Ladder

When a Windows target is only reachable over SSH, prefer the shortest already-proven local reboot path for that exact machine:

1. Current WinRE bootstrap
   - service `C:\Windows\System32\Recovery\Winre.wim`
   - inject a retrying `startnet.cmd` that finds the prepared USB worker
   - re-enable WinRE and arm `reagentc /boottore`
   - this is usually the best one-shot handoff when WinRE is healthy and the worker on USB already proved itself on the same machine
2. Internal WinPE boot entry
   - rebuild a workflow-owned boot payload such as `C:\Soty-Boot\boot.wim` and `boot.sdi`
   - arm a one-time BCD `bootsequence` entry that boots that ramdisk
   - use this when stale reinstall BCD entries already exist or when current WinRE is not the most trustworthy handoff
3. Dedicated USB boot with a local operator
   - use when neither local handoff is already proven
4. Online `setup.exe`
   - treat as a lower-confidence fallback for this workflow, not as the default remote clean-install path

Reuse the path that the same hardware already proved before jumping to a
brand-new handoff path that only sounds simpler.

## Proven-Artifacts Rules

- Prefer `observe` facts from the machine and the removable workspace over chat memory.
- If legacy `Pochinit-Reinstall\\reinstall\\logs\\winre-reinstall.log` shows a prior successful format/apply/restore sequence on the same machine, use that as evidence that this machine has run a worker before, not as permission to reuse Pochinit for new media.
- If legacy `C:\\ProgramData\\Pochinit\\WindowsReinstall\\logs\\postinstall.log` shows drivers, Wi-Fi, SSH, or agent restore activity, use that to understand what actually happened after the last reinstall before changing the flow.
- If stale BCD entries already point to a missing old boot payload, rebuild a fresh Soty/generic boot payload instead of abandoning the internal boot path as "unknown".
- For internal WinPE bootsequence arming, create `{ramdiskoptions}` explicitly when it is absent, then assert the new BCD entry is an `osloader` with the expected Soty description and `\Soty-Boot\boot.wim` device before setting `bootsequence`. Trust a parsed GUID only after it resolves to the expected OS loader, not `winresume.efi` or Windows Recovery.
- `bcdedit /enum {ramdiskoptions}` may exit successfully while printing that no matching objects exist; treat that output as absent and create `{ramdiskoptions}` before setting ramdisk fields.
- If the user reports normal Windows Setup pages asking for language or other install parameters during what should be a worker-driven reinstall, treat that as evidence that the machine booted a stock `boot.wim`, not the custom worker image. Stop guessing, verify the boot image, and rebuild before the next arm.
- Keep `armed.flag` and the target marker machine-specific and explicit. If a prior successful run left `armed.started`, clear that stale marker before writing a fresh `armed.flag` during the next arm action.

## OOBE And Spinner Rules

- Windows first-boot screens such as `Please wait`, `Thank you for your patience`, `Getting things ready`, `Идет подготовка`, `Благодарим за терпение`, and `Устройтесь поудобнее...` are not enough by themselves to call the install stuck.
- Treat those screens as potentially normal for a substantial wait window before choosing a hard reset. Prefer fresh observation over panic.
- On laptops, explicitly tell the operator before reboot:
  - keep the charger connected
  - keep the lid open
  - keep the machine awake during OOBE or post-install restore
- If sleep or a premature hard reset interrupted OOBE once, record that fact immediately and bias the next guidance toward waiting longer, not rebooting faster.
- If a hard power-off during a long spinner later reaches sign-in or setup-completion screens, treat it as a partially recovered state, not proof that reinstall failed. Collect logs, run the restore path, and clean duplicate accounts, OOBE residue, autologon residue, and retry tasks before retrying the whole install.
- When the operator is nontechnical, say in plain words that the spinning setup screen can still be healthy and that they should wait for visible change unless you give a different instruction.

## Return-Path Recovery After Reinstall

- A changed SSH host key after reinstall is a positive signal that the new Windows booted and OpenSSH was regenerated or restored. Update `known_hosts`, then test authentication again.
- If port `22` is back but key-based SSH is not, first assume the OS is up and
  the restore path is only partially finished.
- Restore one stable return path first. Keep unrelated archived user profiles or
  stale local names from blocking the SSH return path.
- If the desktop is reachable only through a local operator and the controller machine has a USB flash drive, prefer a prepared USB recovery bundle before inventing fresh one-off commands. Build it with `scripts/windows/windows-write-usb-ssh-recovery-bundle.ps1`, then run `RUN-ON-LAPTOP.cmd` on the target.
- If the only browser/PWA channel existed before reinstall, assume it is gone after a clean apply until restore or an operator proves the companion agent is installed, running, and attached. A remembered PWA room or target list on the controller is not target-side liveness proof.
- If the user explicitly declares Soty/PWA as the primary channel, make the return path PWA-first instead of SSH-first: stage Soty companion install, restore or re-pair PWA room state, and keep any SSH repair as optional fallback only.
- For Soty PWA-first return, back up the controller export and the target browser origin state before wipe, but treat the raw browser copy as forensic evidence unless Soty has an explicit app-level import/export path. On Edge/Chromium this can include `Local Storage\leveldb` and `IndexedDB\https_xn--n1afe0b.online_0.indexeddb.leveldb`; the IndexedDB may contain browser-bound device identity, so copying it into a new Windows/browser profile can break or invert sharing. Default recovery is a clean re-pair, and the emergency local repair URL is `https://xn--n1afe0b.online/?pwa=1&reset-local=1`.
- Soty's managed Windows installer mode is `install-windows.ps1 -Scope Machine -LaunchAppAtLogon`. It is appropriate after an explicit Soty Worker UAC grant, inside `SetupComplete`, a SYSTEM postinstall hook that this reinstall workflow wrote to the USB/applied image, or a proven elevated task so the loopback agent starts at boot and the PWA opens at user logon.
- A Soty/PWA live target running as a normal admin user with a medium integrity token is not elevated. It cannot approve UAC, format boot media, modify WinRE/BCD, install machine startup tasks, or start a destructive reinstall without an elevated handoff. Use `scripts/soty/soty-operator.ps1 -Action install-machine -Target <label-or-id>` for the detached one-time UAC launcher, then `-Action machine-status` and require `scope=Machine`, `system=true`, and `maintenance=true`.
- In Soty Agent chat, repair or prove the exact source-scoped LINK/console
  route before offering “open Windows Settings and reset manually” as a manual
  fallback. Then prove machine-worker, backup/return-path, and
  destructive-confirmation gates. Give Settings steps when the user explicitly
  asks for that manual fallback.
- If `machine-status` reports `scope=Machine` but `system=false`, treat it as a failed handoff or stale user-owned loopback process. After one known UAC grant, try `scripts/soty/soty-operator.ps1 -Action repair-machine -Target <label-or-id>` once, then verify again. If the target PWA remains visible but OS commands return `127.0.0.1:49424`, the PWA room is alive but the target-side companion is down; OS work is blocked until the local worker is relaunched on that machine.
- Treat leftover machine-specific artifacts such as `Pochinit Agent.exe`, old
  restore folders, or an existing SYSTEM postinstall task as one-machine
  evidence. The universal route is PWA plus a verified machine worker or fresh
  setup media/SetupComplete.
- On a new target, assume there is no existing postinstall mechanism. The reusable path is: PWA attaches -> one explicit UAC installs/verifies Soty machine worker -> the worker stages backup, media, SetupComplete/postinstall, and PWA restore -> only then reboot or wipe.
- For long PWA-controlled work such as Soty state backup, driver export, DISM, ISO copy, USB build, or restore sync, prefer a detached job or scheduled task that writes `result.json`, stdout, and stderr under ProgramData. A foreground PWA HTTP call can time out while the target keeps working, so prove completion from artifacts before retrying.
- If a long Soty/PWA `EncodedCommand` returns `EncodedCommand is not properly encoded` or an oversized unsigned exit code such as `4294770688`, treat it as a transport/command-length failure. Split diagnostics into short reads, invoke `soty-operator.ps1` directly from the local PowerShell process when passing complex `-Command` variables, or stage a target-side script/task instead of retrying the same encoded payload.
- Before wiping from a PWA-only control plane, prove the removable workspace has actual install media or worker files: `setup.exe`, `sources\boot.wim`, `install.wim`/`install.esd`, or a verified workflow-owned reinstall command. A restore folder alone is not boot media.
- The preferred recovery order is:
  1. local `run-manual-restore.cmd` or `postinstall.ps1`
  2. if PWA is primary, Soty machine companion plus clean PWA re-pair or app-level restore
  3. USB diagnostics and SSH recovery bundle from `scripts/windows/windows-write-usb-ssh-recovery-bundle.ps1`
  4. local SSH return-path repair that restores `ProgramData\ssh` and the current operator key first
  5. case-local password SSH bridge only when a maintained helper exists and the password is not persisted
  6. one local sign-in plus retry-task observation
  7. only then deeper reinstall recovery
- When SSH is down or auth is incomplete, make the local fallback instructions extremely short:
  - one way to open an elevated shell
  - one command to run
  - one success sign to expect
- If the system is already on the Windows desktop and the restore bundle was copied locally, the first operator fallback should usually be a workflow-owned `run-manual-restore.cmd` under ProgramData or the USB restore folder. Prefer Soty/generic paths; use old Pochinit paths only as legacy evidence on machines that already contain them.
- If the target is on the desktop but inbound TCP is dead or ambiguous, the USB recovery bundle should collect local network, firewall, OpenSSH, and route evidence before and after SSH repair so the next agent is not blind.
- If `22/tcp` opens after USB recovery but the old SSH alias still fails, separate network success from authentication failure. Read `CONNECT-INFO.txt` or the latest USB `result.json`, then try the current Windows user from that file before changing firewall or reinstall logic.
- After a successful login under a different post-OOBE user, update local SSH
  aliases or case notes so future checks use the current account instead of
  stale names such as a pre-reinstall service account.

## SSH Secret Rule

- Default to key-based SSH return paths. They are clearer, safer, and easier to automate than persisted passwords.
- Keep SSH passwords out of chat, JSON manifests, restore bundles, and logs.
- If password SSH is temporarily needed as a recovery bridge, make it explicit, temporary, and removable after key-based access is back.
- A restore bundle may archive historical user SSH directories, but the return path should prioritize the current operator identity and machine-level OpenSSH state before any unrelated old profile data.
- When Windows group names are localized, key ACL or membership logic off the
  built-in administrators SID `S-1-5-32-544` and user SIDs instead of the
  literal string `Administrators`.
- Accept both current and legacy staged SSH archive layouts during recovery. Stage bundles should emit both `backup\\ssh\\user_ssh\\NAME\\authorized_keys` and legacy-compatible `backup\\ssh\\users\\NAME\\.ssh\\authorized_keys` until all restore payloads are known to read the newer layout.

### Confirm

- Ask the final start question only after technical blockers are gone.
- Require the exact destructive confirmation phrase.
- Require explicit USB format approval for USB-destructive paths.

### Arm

- Run only after confirmation phrase and approvals match.
- Treat any mismatch as a hard stop.

### Observe

- Use live read-only observation during execution, after reboot, and whenever another agent joins the case.
- Trust fresh artifacts and live checks more than stale chat memory.
- If the machine cannot be observed after reboot, treat the flow as blocked, not complete.

### Collect Logs and Improve

- Collect artifacts and event trails.
- Import reusable findings into the knowledge tree immediately.

## Windows-Specific Rules

- Keep the local Windows password empty unless the user explicitly wants a password.
- For a managed Soty/PWA-first reinstall, explicitly provision a workflow-owned
  local administrator, normally `Soty`, as the stable post-install identity. Put
  a real temporary non-persisted setup password in `unattend.xml` only for
  `LocalAccount`/one-time `AutoLogon` unless the user explicitly asked for a
  password, then clear the password and autologon residue in the first-logon
  restore hook. Keep the account name configurable if the user or site policy
  requires another name.
- Keep a managed return workflow on managed account creation. If the operator
  had to choose language, region, account name, or password during a
  worker-driven reinstall, treat that as a media or answer-file failure to fix
  before the next run.
- After a managed reinstall, the default automation username is the account named in the current answer file. Keep stale human names, Microsoft-account display names, old `Pochinit` names, or prior local accounts out of canonical aliases unless fresh diagnostics prove the managed account was not created.
- Treat `SetupComplete.cmd` as the primary restore path.
- Treat first-logon helpers as secondary safety nets only.
- Promise first-sign-in credentials only when the workflow explicitly provisions
  a real account. Otherwise keep OOBE generic and rely on `SetupComplete`, retry
  logic, and a short local manual-restore fallback.
- On consumer or OA3-key Windows paths, the preferred automated route is the managed workflow account above. Use `ShowOOBE Full` plus a manual restore fallback only when account provisioning is not part of the chosen workflow.
- Restore drivers before attempting Wi-Fi reconnection.
- On laptops or other battery-backed machines, account for sleep before `arm`. Operator guidance must mention power and lid state explicitly.
- Keep retry logic alive until Wi-Fi, SSH, and local restore health are all good, not only panel or agent reachability.
- If Soty/PWA is the declared primary channel, keep retry logic alive until
  Wi-Fi, Soty companion health, and PWA attachment or re-pair are good; treat
  SSH success as fallback proof, not a replacement for the user's chosen
  primary channel.
- For a browser/PWA-first return path after a clean apply, machine companion health is not enough: the browser PWA must open in a user session or the agent must provide a headless server tunnel. Managed media should provision a one-time autologon (`LogonCount=1`) for the workflow account so first-logon restore can launch the PWA, then the first-logon restore script must remove autologon residue.
- In any generated `SetupComplete.cmd`, create the target log directory before redirecting stdout or stderr into it. `cmd.exe` fails redirection to a missing directory before launching PowerShell, so a missing `C:\ProgramData\...\logs` folder can silently skip the whole postinstall restore.
- Treat raw Soty browser origin folders as diagnostics or a future app-level
  import path; otherwise re-pair the target and use the reset URL above if the
  access UI desynchronizes.
- Clear `AutoAdminLogon`, `DefaultPassword`, and `AutoLogonCount` in the
  first-logon restore hook, because `SetupComplete` runs before the first
  desktop logon and can cancel the autologon needed for PWA return.
- If unattended setup creates or leaves `defaultuser0`, treat it as an OOBE failure symptom. The reusable route is to make the managed workflow account creation/autologon reliable, then remove `defaultuser0` during first-logon cleanup after logs are collected.
- If OpenSSH uses `administrators_authorized_keys`, restore admin public keys there as well as in the user profile.
- Capture whether a backed-up SSH user was an administrator and reuse that fact during restore.
- Use `observe` when a new agent joins mid-run or the user asks to continue or check status.
- If the only available transport is SSH and it disappears before a durable handoff exists, fall back to readiness-building or manual handoff instead of continuing blindly.
- If the host is currently Wi-Fi-only and the reinstall path has no out-of-band console, treat a removable restore workspace as mandatory before `arm`; a network-only post-reinstall promise is not durable enough.
- Re-verify live Microsoft fwlinks at execution time; public Windows download pages can lag behind the working backend targets.
- Treat `setup.exe` compatibility probes over SSH as weak readiness evidence.
  If the run exits with opaque codes such as `126` and produces no usable
  Panther or `copylogs` evidence, return to the proven WinRE or internal-boot
  handoff.
- If OOBE eventually completes after a long spinner, record that it was slow but healthy. The next operator message should say to wait longer before force-rebooting through the same screen.
- If a run unexpectedly produces a human-named account or duplicate sign-in choices, record it as a recovery fact, then fix the answer-file path so the next run returns to the workflow-owned account without asking the operator for credentials.

## Reusable Pitfalls Seeded From `b82470a...`

- Place the active stage bundle somewhere other than the removable USB that will
  become installer media.
- Use GUI-only Microsoft media flows over SSH only when the interaction path is
  observable and controllable.
- Derive the Windows account name from managed workflow evidence, not only
  `C:\Users\<folder>`.
- Promise generated first-sign-in credentials only when the workflow really
  creates that account on the new Windows.
- Keep retry tasks while Wi-Fi or SSH are still broken, even if panel
  connectivity is back.
- If USB BCD edits fail with access denied, check and clear protective attributes on the USB BCD file first.
- Strip leading BOM garbage from bundled PowerShell assets before execution if transport writes corrupt the runner file.
- Prefer a known-good machine-specific reinstall USB over a remote `setup.exe`
  experiment that only looks more modern. The shortest safe path is the one the
  current machine already proved.

## Short Resolution Rules

- `install Windows`, `reinstall Windows`, `clean install Windows`, and `repair install Windows` all route here.
- `... on this computer` targets the current machine.
- `... on ssh HOST` means `transport=ssh` and the exact host alias must be preserved.

## Close-Out

- Close or update the case journal with the final status, return path, and evidence.
- Update [field-notes.md](field-notes.md) with durable lessons from the run.
- If the lesson changes workflow, patch this file now.
