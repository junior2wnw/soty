# Package And Service Ops

Use this module for app install, uninstall, reinstall, repair, upgrades, feature packs, service stacks, and language-tooling bootstrap.
Use it for the smallest meaningful software-state changes too, not only big rebuilds.

## Default Strategy

1. Discover current state.
2. Record the environment boundary that explains which route should work here.
3. Record package or artifact provenance when the change adds or changes trust: repo, channel, version, lockfile, checksum, signature, installer source, policy source, or image tag.
4. Choose the native or declarative package manager first.
5. Run the smallest change that can satisfy the request.
6. Verify the exact artifact, binary, service, network behavior, API result, or GUI result.
7. Persist reusable learning with the environment facts that made the route valid or invalid.

## Environment Snapshot

Capture only the environment dimensions that change the path:

- host OS, distro, version, and architecture
- package managers already in play
- installer format or runtime family
- service manager, container engine, or orchestration layer
- privilege boundary, trust store, or policy gate
- network, proxy, offline, or mirror constraints
- transport and the expected post-change control path
- rollback source: snapshot, backup, lockfile, previous package version, image digest, config export, policy export, or restore command

## Scoped Transfer For Software

Treat package, service, runtime, and stack facts as scoped evidence, not universal rules.

Reusable similarities can suggest the next route or preflight check:

- same OS family, distro family, image base, or cloud image
- same package manager, installer format, repo, channel, or lockfile style
- same runtime, language ecosystem, dependency resolver, or build backend
- same service manager, container engine, orchestration layer, or health-check model
- same privilege, policy, certificate, proxy, firewall, or offline boundary
- same storage, config, data, API, port-readiness, or network shape

Exact-target differences still decide risky work:

- package name, source, channel, repo, lockfile, version, architecture, or local patch
- service unit name, config path, data directory, user account, secret source, or port
- container image tag, digest, volume mapping, network policy, health check, or orchestrator object
- package-manager ownership, mixed-manager state, pinning, held packages, or local overrides
- production versus disposable environment, backup availability, and rollback path

When a fix transfers across machines or stacks, record the shared dimension that made it transfer. When it does not transfer, record the divergent dimension instead of turning one failure into a universal rejection.

## Platform Order Of Preference

### Windows

- Prefer `winget` for mainstream package install, uninstall, upgrade, export, import, and configuration-state work.
- Use `msiexec`, `DISM`, or platform-native commands when the package is not represented in `winget`.
- Use `Scoop` when the task is clearly userland CLI tooling and a Scoop bucket is the established path.
- Use `Chocolatey` only when it is already part of the environment or the package is maintained there and not elsewhere.

### macOS and Linux

- Prefer native package managers for system packages:
  - `apt`
  - `dnf`
  - `pacman`
  - `zypper`
- Prefer `brew` for cross-platform userland packages on macOS or Linux.
- Prefer `flatpak` or `snap` only when the app is intentionally managed there.
- Prefer `nix` when reproducibility and rollback matter more than local convention.

### Language Ecosystems

- Use the ecosystem-native manager when the task is language-scoped:
  - Python: `uv`, `pipx`, `pip`
  - JavaScript: `pnpm`, `npm`, `yarn`
  - Rust: `cargo`
  - Go: `go install`
  - .NET: `dotnet tool`
- Keep language-level installs separate from OS-level package assumptions.

### Agent And Skill Runtimes

- Treat Codex CLI, ProxyAPI wrappers, MCP servers, tool registries, bundled skills, local machine-skills, and prompt-default files as package or service state when the user's goal is to change how software operations are routed.
- First identify the runtime directory actually used by the active runner. A canonical repo skill, a bundled app copy, and an installed local skill can be three different artifacts.
- Prefer a maintained sync script, junction, package build, or official runtime install path over manual copying.
- Verify both the future path and the current-session limitation: an already-running conversation may keep the prompt and tool registry it started with even after the filesystem skill copy is fixed.
- Use [agent-runtime-and-skill-ops.md](agent-runtime-and-skill-ops.md) when the issue is skill discovery, MCP/tool exposure, default-prompt routing, or operational memory capture.

### Console Work

- Use `console` as the cross-platform term for terminal, shell, command prompt, PowerShell, SSH shell, recovery shell, serial console, container exec, cloud shell, and comparable command surfaces.
- Any console request activates this skill, even when the first command is read-only. Keep the depth light unless the command changes software state.
- Before state-changing console commands, record the target host or container, working directory, privilege boundary, command intent, and success proof.
- Promote reusable command-route facts when a console method is shorter, safer, or less misleading than the default route.

## Repair Versus Reinstall

- `repair` means keep configuration when possible, replace the broken package state, and verify the exact failure disappeared.
- `reinstall` means remove and re-add package state only after confirming what config or data should be preserved.
- `uninstall` means verify whether user data should be removed or retained before deleting residual state.

## Service Stack Contract

For services, containers, and stacks:

1. Probe:
   - package presence
   - unit or service presence
   - port readiness
   - config syntax
   - storage or permission blockers
2. Change one layer at a time:
   - package
   - config
   - service enablement
   - restart or reload
   - health check
3. Verify:
   - service manager state
   - port or API readiness
   - user-visible function
4. Keep rollback concrete:
   - previous config path or export
   - previous package version or image digest
   - database or volume backup status
   - firewall or policy export
   - health check that decides whether to roll back

## Declarative And Repeatable Paths

- Prefer `winget configure` or export/import for repeatable Windows app state.
- Prefer `brew bundle` with a `Brewfile` for cross-machine macOS or Linux package sets.
- Prefer `nix` for reproducible shells, package sets, and rollback-heavy environments.
- Prefer `Ansible` when the same install, uninstall, or repair must run across more than one machine or must stay idempotent.

## Expansion Priors

- Let discovery reveal the smallest fix before choosing reinstall.
- Mix package managers only with an environment reason and record the ownership
  boundary.
- Poll services, ports, logs, or health endpoints when they can prove readiness.
- Preserve user config by default and treat explicit reset as a stronger route.
- Treat package success as an intermediate signal; finish on binary, app,
  service, API, network, or GUI proof.
- Promote routes with the environment facts that made them work or fail.

## Verification Checklist

- package registered as installed or removed
- binary or app path present or absent as expected
- version or hash matches expectation
- service is running, stopped, enabled, or removed as intended
- ports, logs, or GUI behavior prove the change actually worked
- proven, failed, or unclear learnings were captured with a sanitized environment fingerprint
