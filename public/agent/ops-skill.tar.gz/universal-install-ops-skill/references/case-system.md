# Case System

Use this module when lifecycle work is destructive, spans reboots, may continue in later chats, or needs a clean operator handoff.

## Goal

Create one durable case directory per operation so planning, blockers, evidence, logs, environment boundaries, and reusable learnings survive beyond chat memory.

## Storage Rule

- Keep the case directory on a fixed safe workspace.
- Store it away from the target disk being rebuilt.
- Store it away from removable installer media that may be reformatted.
- Keep mutable case files outside the shared skill tree.

## Case Directory Shape

Create a directory under a safe workspace, usually:

- `install-op-cases/YYYY-MM-DD-short-title/`

Inside it, keep:

- `case.json` for machine-readable state
- `runbook.md` for the human-readable narrative
- `evidence/` for screenshots, inventories, manifests, and exported checks
- `logs/` for command output, event trails, and collected diagnostics
- `exports/` for generated artifacts that the next phase or operator needs

## Required Fields

Keep these fields current in `case.json` and mirrored in `runbook.md` when they change:

- title
- platform
- intent
- target_kind
- transport
- host or target label
- current owner or active operator
- environment summary
- environment facts that bound the route
- evidence quality for facts that steer risky work
- current phase
- status
- blockers
- route candidates when multiple paths were compared
- chosen primary route and strongest alternate
- weighted decision facts, their transfer dimensions when applicable, and the strongest supporting, caution, and blocking facts
- route properties with prior chance, probe, observed value, proof, adjusted chance, and route hints for expected/unexpected outcomes
- lightweight control facts and the surfaced best-known control routes when the task includes recurring everyday controls
- artifact provenance for downloaded, generated, flashed, installed, booted, or policy-changing files
- destructive scope
- rollback or recovery route
- abort triggers for risky phases
- return path
- last verified fact

## Recommended Status Values

Use one of these status values:

- `planned`
- `blocked`
- `staged`
- `ready`
- `armed`
- `executing`
- `observing`
- `done`
- `aborted`

## Fast Start

Run the bundled initializer from the skill directory:

```bash
python scripts/case/init_case.py --workspace <safe-dir> --title "<task title>" --platform windows --intent reinstall --target-kind os --transport ssh --host <host> --environment "windows 11 host; ssh return path; winget plus usb worker"
```

Then keep the fact weights current:

```bash
python scripts/case/score_case_facts.py <case-dir> --write
```

For quick live capture of tiny facts without hand-editing JSON:

```bash
python scripts/case/record_case_fact.py <case-dir> --statement "..." --scope exact-target --evidence-quality live-observed --freshness current --target-fit exact --goal-fit direct --polarity supports --source-ref "short source note"
```

When the fact transfers from a similar target instead of the exact one, also record:

```bash
python scripts/case/record_case_fact.py <case-dir> --statement "..." --scope platform-or-family --evidence-quality case-observed --freshness recent --target-fit same-family --goal-fit supporting --polarity supports --shared-dimensions "same package manager, same service manager"
```

For a branch variable that should start as a probability and then be corrected by
live target proof:

```bash
python scripts/case/record_route_property.py <case-dir> --name usb.supports_large_files --expected-value true --chance 0.8 --scope exact-target --evidence-quality live-observed --freshness current --target-fit exact --goal-fit direct --probe "read filesystem and capability" --route-when-expected "use direct install.wim" --route-when-unexpected "split install.wim"
```

For repeated low-risk control actions, keep a lighter memory layer:

```bash
python scripts/case/record_control_fact.py <case-dir> --action "toggle wifi" --target "system wifi radio" --control-plane local-shell --method "nmcli radio wifi off" --observable-success "nmcli reports wifi disabled" --result works --step-count 1 --friction low --scope platform-or-family --evidence-quality live-observed --freshness current --target-fit exact --goal-fit direct --source-ref "nmcli output" --shared-dimensions "same distro family, same network stack"
```

Use the generated `runbook.md` as the live source for:

- current blockers
- route candidates and why one route won
- phase-by-phase verification
- environment facts that explain route choices
- evidence quality, artifact provenance, rollback route, and abort triggers for risky phases
- weighted supporting, caution, and blocking facts for the current route
- route-property predictions, probes, observations, adjusted chances, and route hints
- surfaced control routes, their action/target pairs, and why the winning control path is currently on top
- shared and divergent dimensions for transferred facts that are steering the route
- recommended next evidence when the current route is still tentative, contested, or blocked
- who or what can act after reboot
- where evidence and logs are stored

## Validation Rule

Run the bundled validator before risky transitions and at close-out:

```bash
python scripts/case/validate_case.py <case-dir>
```

Use `--strict` before destructive, rebooting, production, network-affecting, or trust-affecting state changes. A strict validation failure means the next action is documentation or preflight, not a blind state change.
Run `scripts/case/score_case_facts.py <case-dir> --write` before strict validation when the route depends on mixed or recently changed evidence.

## Ownership Rule

For destructive, rebooting, production, network-affecting, trust-affecting, or multi-session work, record one active owner at a time:

- agent, human operator, shell session, SSH host, VM console, recovery environment, cloud console, network session, or automation job
- what the owner is allowed to change next
- which signal proves handoff to the next owner is complete

If ownership is unclear, pause state-changing actions and update the case instead of letting two control paths modify the same target.

## Handoff Rule

When another agent or human joins the case:

- trust fresh evidence and logs over stale chat memory
- read `case.json` and `runbook.md` first
- continue from the current phase instead of replaying the whole plan
- verify the active owner, rollback route, abort triggers, evidence quality, weighted decision facts, and artifact provenance before the next risky action

## Close-Out Rule

Before marking the task done:

1. verify the requested outcome
2. verify the return path
3. capture the final blockers that were cleared or remain
4. record whether rollback artifacts were used, retained, rotated, or no longer needed
5. run `scripts/case/score_case_facts.py <case-dir> --write` so the final fact ranking matches the final route and outcome
6. run `scripts/case/validate_case.py <case-dir>` and document any remaining warnings
7. collect the reusable lessons
8. promote sanitized notes with [knowledge-loop.md](knowledge-loop.md)
