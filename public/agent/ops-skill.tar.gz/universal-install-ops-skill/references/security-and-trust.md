# Security And Trust

Use this module whenever lifecycle work touches credentials, privileges, certificates, package sources, firmware, remote scripts, network policy, production services, or persistent access.

## Core Rule

Treat trust as part of the control plane. A path is not safe just because it works; it must come from an acceptable source and preserve a recoverable access model.

## Source Provenance

Record provenance for anything installed, flashed, booted, trusted, or used to mutate infrastructure:

- source URL, package manager, repository, registry, bucket, vendor page, or control plane
- version, build, channel, commit, image digest, checksum, signature, or release name
- whether the source is official, maintained upstream, internal, mirrored, community, or unknown
- why that source is acceptable for this target and user goal

Prefer:

- official package managers and repositories
- signed releases or checksummed artifacts
- vendor or upstream recovery media
- declarative infrastructure or package state
- maintained project support matrices

Avoid:

- anonymous binaries
- copied one-line remote install scripts
- stale forum links for firmware or drivers
- changing package sources without a rollback plan

## Credential Handling

- Keep passwords, tokens, private keys, recovery keys, license keys, and
  personal secrets out of the skill tree, field notes, logs, and chat summaries.
- Prefer key-based and short-lived access over persisted passwords.
- Record where a secret must be supplied without recording the secret value.
- After temporary access is used, record whether it was revoked, rotated, or intentionally retained.

## Privilege And Blast Radius

Before privileged work, record:

- user, role, group, or cloud principal
- why elevation is needed
- whether a lower-privilege route exists
- what can be changed by this principal
- rollback or revocation path

For production or shared systems, prefer:

- maintenance window or explicit user approval
- dry run, plan, or diff
- backup or snapshot
- staged rollout
- health check and automatic rollback when supported

## Trust Gates

Stop before state changes when:

- artifact provenance is unknown
- checksum or signature is missing when the upstream provides one
- package source changed unexpectedly
- certificate or driver trust prompt appears without a recorded reason
- a command asks for credentials in a context where they could be logged
- production target identity is ambiguous
- rollback depends on a secret or access path that has not been verified

## Reusable Learning

Promote sanitized patterns such as:

- official source that moved or changed behavior
- signature or checksum check that prevented a bad install
- lower-privilege route that worked
- temporary credential cleanup pattern
- production gate that reduced blast radius
