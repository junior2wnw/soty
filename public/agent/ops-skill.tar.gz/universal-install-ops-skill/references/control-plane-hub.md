# Control-Plane Hub

Use this file when transport, VPN or tunnel routing, multi-interface hosts, proxy shape, reboot handoff, or return-path reliability determines whether the task is safe.

Keep this module simple:

1. prove the current control plane
2. predict the next control plane
3. choose the strongest proven route
4. converge once one route is actually working

## Reliability Ladder

From strongest to weakest:

1. `out_of_band_console`
   - hardware or hypervisor console
2. `local_operator`
   - a person at the machine can see the screen and do one physical step at a time
3. `existing_remote_agent`
   - a machine-proven reinstall or recovery agent survives the handoff
4. `source_bound_remote`
   - remote access works only when traffic is bound to the right source interface
5. `generic_remote`
   - remote access works without special routing help
6. `manual_handoff_only`
   - the machine is reachable only through a person at the device
7. `unproven`
   - no reliable current or next path exists

Take the first proven route above the blocker line and use it. Let stronger
live proof retire weaker theories.

## One-Screen Checklist

Capture these facts before a risky change:

- current transport
- expected next transport
- whether sleep, lid close, battery saver, session timeout, or VM suspend can remove the current or next transport
- current return path
- strongest proven fallback
- network shape that explains success or failure
- one short blocker sentence if the route is still not safe

## VPN, Tunnel, And Multi-Interface Rule

Treat an unbound probe failure during active VPN or tunnel use as route evidence,
not immediate proof that the target is unreachable.

This pattern is common:

- controller has both LAN and VPN or tunnel interfaces
- target sits on the same private subnet as the controller LAN
- generic `ping`, `ssh`, or `Test-NetConnection` follows the VPN path
- the target is still present on local Ethernet or Wi-Fi and can be reached when traffic is bound to the LAN source address

### Fast Signs

- ARP or neighbor tables still show the target MAC on the local subnet
- there are two candidate routes to the same host, one through VPN and one on-link
- `Test-NetConnection` shows the wrong source interface
- unbound `ssh` times out, but the machine should still be on the same room LAN

### Ordered Recovery Ladder

1. prove local-subnet presence
   - check `arp -a`, `Get-NetNeighbor`, or equivalent neighbor evidence
2. inspect route choice
   - check interface list, source addresses, and host routes
3. test a source-bound connection
   - example: `ssh -b <lan-ip> user@host`
4. if source binding works, record that exact source IP in the case and reuse it
5. only if needed, add a narrow host-specific route or switch to another controller on the same LAN
6. only then downgrade to local operator or manual handoff

Prefer source binding or a narrow route before asking the user to change VPN
state.

## WSL Builder Network Rule

When Windows can reach the internet but WSL cannot, treat WSL as its own control plane.

Fast checks:

- Windows `Test-NetConnection` to the source and package hosts
- WSL `curl` to the same hosts
- WSL route table and `/etc/resolv.conf`
- active Windows VPN, tunnel, and Hyper-V adapters

Use `scripts/windows/windows-wsl-network-preflight.ps1` to capture these facts in one log.
If WSL times out to both source hosts and package mirrors, switch from package
retry to the control-plane fix:

- WSL NAT
- VPN split-tunnel policy
- proxy settings
- DNS forwarding
- firewall rules
- or move the build to another Linux host

This is a blocker before bootloader unlock for phone porting work.

## Return-Path Rule

For rebooting or reinstall work, track both:

- `transport_now`
- `transport_next`

The workflow is blocked when `transport_now` works but `transport_next` is a guess.

Good examples:

- `ssh over LAN bound to 192.168.1.181 -> WinRE worker on current machine`
- `Soty PWA bridge -> verified Soty machine worker -> SetupComplete opens/restores PWA after Windows install`
- `Soty PWA bridge -> background job writes ProgramData result.json -> poll job-status instead of retrying the same long command`
- `local operator on screen -> Windows desktop -> local admin PowerShell restore`
- `adb -> fastboot -> USB network gadget`

Bad example:

- `ssh works now, so reboot will probably be fine`
- `the PWA is open now, so it can confirm UAC or survive a clean wipe`
- `the command is running over SSH, so the laptop cannot sleep`
- `the PWA HTTP request timed out, so the target job must have stopped`

## Soty/PWA Rule

When Soty is the primary channel, separate the two halves:

- PWA room: chat, shared text, pairing, operator bridge, and intent transport
- Soty companion: local OS command executor on `127.0.0.1:49424`

For admin or reinstall work, the companion must be machine-scoped and truly
elevated. `scope=Machine` with `system=false` is not a success state; it usually
means a user-owned runner occupied the loopback port. Use
`scripts/soty/soty-operator.ps1 -Action machine-status -Target <name>` to prove
health, and after a known UAC handoff use `-Action repair-machine` only as a
short recovery action before verifying again. If the target then has a visible
PWA room but no local companion, OS commands are blocked until the local worker
is relaunched on that machine.

## Awake Transport Rule

For long remote tasks, sleep is a control-plane risk. Before starting, prove one
of these:

- the target is on power and configured not to sleep for the expected duration
- a temporary keep-awake guard is active and reversible
- the work runs under a service, scheduled task, job runner, or multiplexer that
  survives disconnect and writes proof artifacts
- a local operator can keep the machine awake and report the success sign

If none is proven, pause before long state changes. A foreground SSH command can
die or become unobservable when the target sleeps.

## Port-Open Auth-Failed Rule

If `22/tcp` is open but key auth fails, stop treating it as a network outage.

Check in this order:

1. stale host key after reinstall
2. wrong Windows account name after OOBE or Microsoft/local account creation
3. key placement and ACLs
4. `sshd_config` administrator-key rules

For USB recovery runs, prefer the current Windows user written in `CONNECT-INFO.txt` or `results/<run>/result.json` before retrying stale pre-reinstall aliases.

## Operator Rule

When a person near the device must help:

- ask for one action
- say what success looks like
- ask for one reply

Treat human-visible prompts as part of the control plane, not as background noise.

## Promotion Rule

Transport lessons must graduate out of the case runbook when they are reusable.

Promote:

- reliable routes
- misleading failure signs
- environment fingerprints that explain why a route worked
- short recovery ladders that future agents can follow without rediscovering them

Keep out of promoted memory:

- raw personal network details unless they are sanitized
- one-off machine trivia with no routing value
