# Ecosystem

Use these maintained upstream building blocks instead of inventing a parallel ecosystem.

## Cross-Platform Orchestration

- Ansible:
  - good for idempotent multi-machine install, uninstall, service, and reboot flows
  - useful Windows modules include `ansible.windows.win_package`, `ansible.windows.win_reboot`, and `ansible.windows.win_dsc`
  - docs:
    - https://docs.ansible.com/projects/ansible/latest/collections/ansible/windows/win_package_module.html
    - https://docs.ansible.com/projects/ansible/latest/collections/ansible/windows/win_reboot_module.html
    - https://docs.ansible.com/projects/ansible/latest/collections/ansible/windows/win_dsc_module.html
- Terraform or OpenTofu:
  - useful when cloud or network resources need plan/apply, drift detection, and rollback-friendly review
  - prefer a saved plan and state backup before production changes
- Vendor or platform CLIs:
  - useful when they expose dry-run, diff, validation, or native rollback
  - record CLI version, profile or account boundary, and target subscription/project/tenant without secrets

## Windows App And Environment State

- WinGet:
  - install, upgrade, remove, export, import, and configure apps on Windows
  - `winget configure` is the strongest built-in declarative path for repeatable Windows environment setup
  - docs:
    - https://learn.microsoft.com/en-us/windows/package-manager/winget/
    - https://learn.microsoft.com/en-us/windows/package-manager/winget/configure
    - https://learn.microsoft.com/en-us/windows/package-manager/configuration/create

## macOS And Linux Package Sets

- Homebrew:
  - `brew bundle dump` captures installed state into a `Brewfile`
  - `brew bundle install` restores it
  - docs:
    - https://docs.brew.sh/Manpage
    - https://docs.brew.sh/
- Nix:
  - best when reproducibility, rollback, and multi-tool environments matter more than local convention
  - docs:
    - https://nixos.org/
    - https://nixos.org/guides/how-nix-works/

## Windows Media

- Official Microsoft installation media and ISO flows:
  - https://support.microsoft.com/en-us/windows/create-installation-media-for-windows-99a58364-8c02-206f-aa6f-40c3b507420d
  - https://www.microsoft.com/software-download/windows11
- Ventoy:
  - open-source multi-image bootable USB tool
  - docs:
    - https://www.ventoy.net/en/
    - https://www.ventoy.net/en/doc_start.html
- wimlib:
  - useful for splitting large `install.wim` into `.swm` parts for FAT32 media
  - docs:
    - https://wimlib.net/
    - https://wimlib.net/man1/wimsplit.html

## Android And Mobile

- Android SDK Platform-Tools:
  - official `adb` and `fastboot` family
  - docs:
    - https://developer.android.com/studio/command-line/adb
    - https://developer.android.com/tools/releases/platform-tools
- postmarketOS:
  - strongest general matrix for mainline-first and broad experimental device coverage
  - use the supported-device matrix and exact device page before planning Linux-on-phone
  - docs:
    - https://wiki.postmarketos.org/wiki/Supported_devices
- Droidian:
  - Debian-based mobile Linux using Halium on Android devices
  - strongest fit when the exact device is officially listed and the user wants Debian userland more than mainline purity
  - docs:
    - https://devices.droidian.org/
    - https://docs.droidian.org/faq/
- Ubuntu Touch device matrix:
  - use only when the exact device page exists and the support level is acceptable for the user's goal
  - docs:
    - https://devices.ubuntu-touch.io/
- Mobian:
  - Debian mobile distribution with strongest fit on Linux-first hardware and a smaller supported-device footprint
  - docs:
    - https://wiki.debian.org/Mobian/Devices
    - https://blog.mobian.org/posts/2023/03/07/porting-to-new-devices/
- Heimdall:
  - open-source Samsung flashing tool for workflows that are known to work there
  - docs:
    - https://github.com/Benjamin-Dobell/Heimdall

## Mobile Linux Selection Rule

- Pick the project whose support model best fits the user's goal on the exact device.
- On Android-born hardware, a Halium-based route can beat a mainline-first route when hardware completeness matters more than kernel purity.
- On Linux-first hardware, a distro aligned with upstream Linux support can beat Android-adaptation stacks.
- If the device is not on the normal supported-device list, call it a porting or experiment workflow instead of a normal install.

## Apple Official Paths

- macOS reinstall:
  - https://support.apple.com/en-us/ht204904
- Mac firmware revive or restore:
  - https://support.apple.com/en-us/HT213662
- Apple Configurator revive flow:
  - https://support.apple.com/en-euro/guide/apple-configurator-mac/cad367dc4593/mac

## Selection Rule

- Use the narrowest maintained upstream that already solves the task.
- Favor declarative or idempotent tooling when the same task will recur.
- Favor official vendor media and recovery paths for firmware and OS reinstall.
- Favor tools that can produce a plan, validate config, preserve provenance, and support rollback.
- Avoid generic remote scripts when an official package manager, signed artifact, or declarative provider exists.
