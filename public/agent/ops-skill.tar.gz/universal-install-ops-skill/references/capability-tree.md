# Capability Tree

Use this file to route the task before loading a narrower module.

## 1. System Lifecycle

- Windows:
  - clean install
  - reinstall
  - repair install
  - recovery environment
  - driver and post-install restore
- Linux:
  - distro install or reinstall
  - package-manager repair
  - bootloader recovery
  - service recovery
- macOS:
  - reinstall from Recovery
  - firmware revive or restore on supported hardware
  - migration or backup handoff
- ChromeOS and Chromebook conversions:
  - support check
  - firmware path
  - Windows or Linux conversion
- Android and mobile Linux:
  - adb or fastboot visibility
  - bootloader unlock
  - stock firmware flash
  - recovery flash
  - maintained Linux port
- VMs and images:
  - ISO attach
  - cloud image bootstrap
  - snapshot or rollback
- Networks and control planes:
  - route, DNS, VPN, firewall, proxy, tunnel, switch, router, and cloud network changes
  - source-interface selection
  - timed rollback for remote network changes

## 2. Software Lifecycle

- OS package managers:
  - `winget`
  - `apt`
  - `dnf`
  - `pacman`
  - `zypper`
  - `brew`
  - `nix`
  - `flatpak`
  - `snap`
- Windows installer formats:
  - `msi`
  - `msix`
  - `appx`
  - `exe`
- software update, rollback, downgrade, and reset paths
- runtime, SDK, and dependency bootstrap or repair
- Language ecosystems:
  - `pip` or `pipx` or `uv`
  - `npm` or `pnpm` or `yarn`
  - `cargo`
  - `go install`
  - `gem`
  - `dotnet tool`
- Service stacks:
  - Docker Compose
  - systemd services
  - Windows services
  - databases
  - reverse proxies
  - agents and background workers
- Agent runtime and skill plumbing:
  - Codex CLI and ProxyAPI runtime state
  - MCP servers, tools, and discovery surfaces
  - canonical, bundled, and installed skill copies
  - skill default prompts, sync paths, and operational memory stores
- Console access:
  - local terminals, shells, command prompts, and PowerShell
  - SSH shells, recovery shells, serial consoles, container exec, and cloud shells
  - command intent, working directory, privilege boundary, and proof output
- Security and trust:
  - package-source changes
  - certificates, keys, users, groups, and auth policy
  - artifact provenance and signed release checks

## 3. Firmware and Media

- bootable USB creation
- recovery USB creation
- WIM split workflows
- BIOS or UEFI updates
- phone firmware and recovery images
- USB driver binding and device mode transitions

## 4. Knowledge System

- `proven`: reusable safe paths
- `failed`: confirmed bad paths
- `unclear`: hypotheses and edge cases
- weighted decision facts with supporting, caution, blocking, and stale evidence
- sanitized environment fingerprints that explain where a route applies
- module patches when a note graduates from observation to workflow rule
- field-note aging, deduplication, graduation, and compaction
- measured improvements in safety, speed, token cost, operator burden, and user satisfaction

## 5. Route Selection

- restate the real user outcome
- choose the lightest safe depth: `info`, `tiny-control`, `normal-lifecycle`, or `risky-lifecycle`
- generate route candidates instead of jumping to one remembered tool
- classify routes as `primary`, `alternate`, `situational`, `recovery-only`, `experiment-only`, `porting-only`, or `reject`
- compare support reality, feature completeness, safety, reversibility, operator burden, and maintenance cost
- compare evidence quality, source trust, rollback proof, health checks, and efficiency
- score and rank the current decision facts before trusting a route that depends on mixed evidence
- choose the best available route for this user and this environment
- when safety and evidence are comparable, choose the route with fewer actions, lower token cost, and clearer proof
- keep rejected candidates and why they lost

## 6. Control Plane And Return Path

- current transport and next transport
- VPN, tunnel, proxy, or multi-interface routing
- source-bound remote paths
- reboot handoff and post-change return path
- operator-visible gates and fallback paths
- active owner, handoff proof, and abort triggers
- weighted strongest supporting, caution, and blocking facts

## 7. Environment Boundaries

- host platform, version, build, or recovery mode
- architecture and virtualization or container boundary
- package manager, installer format, runtime, or service manager
- privilege model, trust store, policy gate, or device-unlock state
- current transport and predicted next transport
- network, proxy, offline, or removable-media constraints
- device identity, boot mode, firmware family, or driver state
- artifact provenance, evidence quality, rollback route, and health-check proof
- freshness, target fit, goal fit, and fact weight

## Routing Rules

- If the task materially touches software state at any scale, keep this skill active until [knowledge-loop.md](knowledge-loop.md) is complete.
- If the user asks for the best option, the best distro, the best install path, or any outcome with multiple plausible solutions, load [route-selection.md](route-selection.md) before committing.
- If the task is a Windows OS install or reinstall, load [windows-reinstall.md](windows-reinstall.md) immediately.
- If transport, VPN, tunnel, source-interface choice, or return-path safety is a blocker, load [control-plane-hub.md](control-plane-hub.md) alongside the platform module.
- If the task can lose data, access, bootability, production behavior, or rollback options, load [backup-restore-matrix.md](backup-restore-matrix.md).
- If the task touches credentials, privileges, certificates, package sources, firmware, remote scripts, production, or trust boundaries, load [security-and-trust.md](security-and-trust.md).
- If the task needs post-change proof, load [health-checks.md](health-checks.md) and choose the cheapest reliable check for the user-visible outcome.
- If the route depends on several facts, on conflicting facts, or on transferring knowledge between similar targets, load [fact-weighting.md](fact-weighting.md) and score the current decision facts.
- If the task is mostly package management, stack repair, app install, or uninstall, load [package-and-service-ops.md](package-and-service-ops.md).
- If the task uses any console, keep this skill active at least at `console-touch` depth and classify the command intent before running it.
- If the task asks why a skill, MCP tool, agent runner, or operational memory path did not activate, load [agent-runtime-and-skill-ops.md](agent-runtime-and-skill-ops.md) and verify source, installed copy, active session, and sync path separately.
- If the task touches phones, tablets, firmware, boot media, or Chromebook conversions, load [device-firmware-and-media.md](device-firmware-and-media.md).
- If the task needs better upstream tooling, package sources, or a declarative engine, load [ecosystem.md](ecosystem.md).
- If shared notes are getting noisy or stale, load [field-notes-maintenance.md](field-notes-maintenance.md).
- Always finish with [knowledge-loop.md](knowledge-loop.md).
