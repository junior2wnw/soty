# Backup Restore Matrix

Use this module whenever a lifecycle task can erase data, break boot, change access, mutate production behavior, or make rollback harder.

## Core Rule

A backup is not real until the restore path is named and at least the smallest practical verification has passed.

Record three things before risky work:

- what is protected
- where it can be restored from
- what proves the restore would work

## Destructive Scope

Classify the blast radius before the state change:

- `none`
  - read-only discovery, inventory, version checks, support-matrix checks
- `config`
  - app config, service unit, registry key, network policy, firewall rule, boot entry
- `package`
  - package install, uninstall, upgrade, downgrade, repo or channel change
- `runtime`
  - SDK, language runtime, dependency resolver, container image, driver stack
- `service-data`
  - databases, queues, volumes, user uploads, app state, persistent caches
- `identity-access`
  - keys, users, groups, certificates, tokens, SSO, SSH, local admin access
- `boot-or-firmware`
  - bootloader, firmware, BIOS or UEFI, recovery media, phone partitions
- `disk-or-os`
  - partitioning, clean install, wipe, reset, image restore
- `network-control`
  - routing, firewall, VPN, DNS, DHCP, switch, router, cloud network policy

If more than one applies, use the highest blast radius and list the lower layers in the case.

## Minimum Restore Proof

Use the strongest proof that is practical before the risky step:

- config
  - export the current file or setting, then run syntax or dry-run validation
- package
  - record current version, source, lockfile, package cache, and downgrade or reinstall route
- service-data
  - capture backup command, backup location, size, timestamp, and one restore or integrity check
- identity-access
  - verify a second access path before changing keys, users, certificates, or auth policy
- boot-or-firmware
  - verify exact rollback image, tool, device mode, checksum, battery or power, and next transport
- disk-or-os
  - verify installer, backup destination, recovery media, product/license path when needed, and post-install return path
- network-control
  - export current policy or config, keep an out-of-band path, and use a timed rollback when supported

## Backup Storage Rule

- Keep backups off the target disk, media, partition, or volume being rebuilt.
- Keep logs and case journals off media that may be formatted.
- For removable media, prove the erase target and backup target are different devices.
- If a removable installer USB was formatted between attempts, any backup proof that existed only on that USB is gone. Restore from a fixed-disk case copy or create a new backup before the next destructive arm.
- For cloud and VM work, prefer snapshots or exports in a separate failure domain when practical.

## Restore Verification Ladder

From strongest to weakest:

1. full restore tested on a disposable target
2. partial restore or mount test
3. checksum, listing, and application-level integrity check
4. backup tool reported success plus artifact size and timestamp
5. user says the file exists
6. assumed backup with no proof

Let levels 5 or 6 carry destructive work only when the user explicitly accepts
the risk and a safer route is unavailable.

## Rollback Notes

Record rollback in operational terms:

- command or tool
- artifact path or source
- credentials or access path, without storing secrets
- expected duration
- health check that decides rollback succeeded
- cleanup needed after rollback

## Reusable Learning

Promote these facts when observed:

- backup command that reliably captures the right state
- restore check that caught a bad backup
- storage layout that made a backup unsafe
- timed rollback pattern that saved a network or remote session
- shortest backup proof that was enough for a low-risk operation

## Soty PWA State

When Soty/PWA is the primary control plane for a Windows reinstall, protect both:

- controller-side export: `scripts/soty/soty-operator.ps1 -Action export -OutFile <path>`
- target-side browser origin state as forensic evidence only: Edge/Chromium `Local Storage\leveldb` and `IndexedDB\https_xn--n1afe0b.online_0.indexeddb.leveldb` when present

Treat raw browser/PWA origin folders as diagnostic backups across a Windows
reinstall or different browser profile. Soty uses browser-bound cryptographic
identity and volatile remote-grant state; a byte copy can produce stale device
identity, inverted access toggles, or broken sharing. The default restore path
is app-level import/export or clean re-pair.

The restore proof must name how the target will either regain the same PWA identity through an application-level import/export flow or be re-paired cleanly. A Soty companion agent health check alone is not a PWA-state backup. If sharing or command access looks inverted after restore, open `https://xn--n1afe0b.online/?pwa=1&reset-local=1` on the damaged device, give it a fresh name, and pair it again.
