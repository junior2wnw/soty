# Knowledge Shelves

Use this module when the knowledge base must stay usable after thousands or millions of user runs.

The simple idea:

```text
raw dialogs -> sanitized markers -> candidate queue -> shelf facts -> hot routes
```

Strong models can mine and compile knowledge. Smaller OSS models should mostly
read hot routes and one shelf. Shelves are memory indexes, not rulebooks: they
should shorten the next run by suggesting what worked, what failed, and what
proof/rollback made it transferable.

## Shelf Contract

Every reusable learning needs a home shelf.

A shelf is not a registry of tools. It is a stable drawer for related operational knowledge:

- `skill-tool-factory`: making reusable skills or script-backed workflows
- `agent-runtime-skill-ops`: Codex, MCP, provider, sync, and activation work
- `package-service-stack`: apps, packages, runtimes, services, and stacks
- `windows-reinstall-recovery`: Windows reinstall, WinRE, boot media, and return paths
- `device-firmware-media`: phones, firmware, drivers, flashing, and boot media
- `mobile-linux-porting`: unsupported mobile Linux bring-up
- `control-surfaces`: tiny reversible controls
- `network-return-path`: SSH, VPN, proxy, routing, and post-reboot access
- `risk-security-rollback`: credentials, trust, backup, rollback, and blast radius
- `learning-memory`: field notes, markers, weighting, compaction, and promotion

The machine-readable shelf list lives in `references/shelf-index.json`.

## How An OSS Model Should Use This

Treat `ops.py` as the working loop, not as optional lookup. Even a small model
should route, act, verify, and account for reusable problems or successes.

1. Run `scripts/routing/route_shelf.py "<task in one sentence>"` or read `references/shelf-index.json`.
2. Run `scripts/routing/route_hot.py "<task in one sentence>"` when the task looks common.
3. Pick the top shelf, plus only one extra shelf if there is a safety or transport blocker.
4. Read only the listed files for that shelf.
5. Use scripts listed by the shelf before hand-writing fragile commands.
6. If the right helper is not obvious, run `python scripts/find_script.py "<task>"` instead of browsing folders.
7. If the shelf does not fit, fall back to `general-routing`.

The model should use shelves and hot routes before `field-notes.md`; field
notes are the source archive, not the fastest entry point.

## How Strong Models Should Compile Knowledge

When mining dialogs or case journals:

1. Keep raw private evidence out of the shared tree.
2. Convert useful facts into sanitized `ops-memory:` or `control-memory:` markers.
3. Queue markers with `ingest_memory_marker.py`; reviewed candidates graduate
   into modules.
4. Promote repeated or high-impact markers into the right reference module, hot route, activation eval, or script.
5. Keep only short environment fingerprints in shared notes.
6. Update `shelf-index.json` when a new module or route family becomes important.
7. Prune duplicates and stale unclear notes with `maintain_field_notes.py`.

The target is not "more notes" or stricter instructions. The target is a
shorter next run with better first guesses, fewer probes, clearer proof, and
less rediscovery.

## Fact Shape

Use compact, searchable facts:

```text
date | bucket | shelf | role | scope | evidence | fact | env | why
```

Required dimensions:

- `bucket`: proven, failed, or unclear
- `shelf`: one shelf id from `shelf-index.json`
- `scope`: hard-gate, universal-pattern, platform-or-family, exact-target, case-local, or hypothesis
- `evidence`: live-observed, primary-source, case-observed, maintainer-or-community, user-reported, inferred, or stale
- `env`: smallest environment fingerprint that explains where the fact applies

## Growth Limits

Keep the brain distributed across small, findable shelves.

- Keep `SKILL.md` as a router, not an encyclopedia.
- Keep `shelf-index.json` small enough to read in one glance.
- Keep detailed workflow in one direct reference file per shelf.
- Keep raw logs, huge artifacts, private values, and case-only files outside the skill.
- When `field-notes.md` gets noisy, graduate repeated facts into modules and leave the archive thinner.
- For shared releases, use [release-and-sync.md](release-and-sync.md) so the server publishes compact shelf facts through candidate, canary, stable, and rollback channels instead of pushing raw dialog memory.

## Findability Rules

- Use stable shelf ids. Rename shelves only with a migration reason.
- Put user-language trigger words in `keywords`, including common Russian words when they are likely to be used.
- Put exact scripts in the shelf index only when they are safe reusable entry points.
- Put every executable helper in `scripts/catalog.json` so small models can find it by task words.
- Prefer one obvious shelf over several clever overlapping shelves.
- If a fact could live in two shelves, place it where the agent will look first during the next task.

## Done Criteria

A knowledge update is done only when:

- The fact is sanitized.
- The shelf is clear.
- The module or index that helps the next run has been updated.
- The validation scripts pass.
- A smaller model could find the fact without reading the entire repository.
