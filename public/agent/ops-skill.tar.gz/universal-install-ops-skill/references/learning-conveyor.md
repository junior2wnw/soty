# Learning Conveyor

Use this when many users produce operational evidence and the shared skill must stay clean.

The simple pipeline:

```text
case/raw dialog -> sanitized marker -> candidate queue -> review/compile -> shelf fact -> hot route
```

The runtime path is:

```text
active task -> best writable skill sink -> sanitized candidate or direct patch -> health/eval/sync proof
```

## Roles

- Small runtime model: read `shelf-index.json`, use hot routes, emit sanitized markers for reusable problems and successes.
- Strong compiler model: deduplicate candidate queues, promote durable facts, prune noise.
- Human maintainer: review high-risk route changes, destructive defaults, privacy-sensitive rules, and public repo releases.

## Files

- `references/hot-routes.json`: fastest safe routes for frequent tasks.
- `references/shelf-index.json`: shelf map for small models.
- `scripts/catalog.json`: script map for small models.
- `.skill-memory/candidate-facts.jsonl`: local or server-side candidate queue, not committed.
- `.skill-memory/missed-invocations.jsonl`: prompts that should have activated a shelf but did not.
- `.skill-memory/*.jsonl` is local state, not package payload; merge it across required copies with `scripts/skill/merge_skill_memory.py --codex --write` before learning review or release sync.

## Scripts

- `scripts/routing/route_hot.py "<task>"`: choose the shortest ready route card.
- `scripts/find_script.py "<task>"`: choose the smallest helper without scanning the tree.
- `scripts/routing/evaluate_activation.py`: prove common prompts route to the expected shelf and hot route.
- `scripts/learning/ingest_memory_marker.py "ops-memory: ..."`: queue a sanitized candidate fact.
- `scripts/learning/ingest_teacher_report.py`: review or import sanitized Soty Teacher candidates into the candidate queue.
- `scripts/learning/record_missed_invocation.py "<prompt>" --expected-shelf <id>`: record trigger misses without polluting the skill.
- `scripts/learning/summarize_memory_queue.py`: count candidate facts, missed invocations, shelves, and repeated prompt terms before curation.
- `scripts/learning/compile_memory_queue.py`: classify queued rows as covered, promote, keep, or review before pruning or promotion.
- `scripts/learning/learning_conveyor.py`: one health gate that combines queue summary, compile decisions, missed invocations, route profiles, and recommendations.
- `scripts/skill/merge_skill_memory.py`: bidirectional JSONL union for local `.skill-memory` queues across canonical and runtime copies.
- `scripts/learning/learning_review.py`: summarize recent learnings, route-profile savings, and branch/revision actions before ideal or release claims.
- `scripts/learning/route_profile.py`: store sanitized reusable route profiles for any repeated task family, including optional time/step/token savings and 0-10 quality/safety/simplicity/universality deltas.
- `scripts/learning/review_memory.py`: record when a remembered best route is superseded, downgraded, rejected, or deliberately kept after fresh proof.
- `scripts/learning/route_branch.py`: record a controlled situational branch from a default rule without overwriting the parent rule from one case.
- `scripts/skill/sync_doctor.py`: read-only package drift proof for runtime copies; package-file merge is intentionally unavailable.
- `scripts/ops.py "<task>" --close --actual "<learning>" --success "<proof>" --env "<boundary>"`: print the final `learning_delta` line when closing a skill-backed run.

## Memory Priorities

- Shared facts carry compact sanitized patterns, not raw logs, secrets, personal
  files, private IPs, MACs, serials, or IMEIs.
- Candidate queues are temporary. Shelf modules are the product.
- Promote a fact only when it improves the next route, safety, speed, token use, or operator clarity.
- A used ops skill is not done until the agent has picked a sink: module/hot
  route/helper/eval patch, field note, candidate marker, case-local note, or
  explicit no-reusable-lesson decision.
- Surface that decision by carrying the `ops.py --close` `final_line` into the
  final or handoff; this makes "no useful learning" an explicit checked result
  instead of silent forgetting.
- Treat a proven command, helper run line, or short step order as a cache candidate by default when it has an observable proof and a small environment boundary.
- During long or exploratory work, queue useful verified facts as they appear;
  waiting until the final answer loses associations between blocker, fallback,
  proof, target family, and transfer boundary.
- Treat "you learned a lot, why did you not write it down?" as a direct memory-capture request for solved failures, working fallbacks, and OS/device transfer boundaries.
- If a fact becomes common, turn it into a hot route or module rule instead of adding the same field note again.
- If a prompt misses the right shelf, patch trigger words and add an activation eval case.
- Keep curation server-friendly: append-only raw queues, deterministic dedup keys, stable shelf ids, and small published artifacts.
- Treat `field-notes.md` as a surfaced archive, not the main database. Hot routes and shelf modules are the fast path.
- Use the queue compiler before bulk pruning; `covered` rows may move to reviewed storage, `promote` rows need a shelf/hot/helper/eval patch, `keep` rows stay queued, and `review` rows block automated cleanup.
- Create a route profile when a task family repeats and the winning route has proof plus a transfer boundary. Profiles are the universal fast-lane substrate; shelf facts explain why, profiles remember the reusable route and measurable deltas.
- The runtime router must surface matching route profiles in its first action packet. A profile that only appears in a later review report is not an optimization path yet.
- If no profile matches a repeated task, treat that as optimization debt: finish with a profile, route/module/helper/eval patch, branch/revision, candidate marker, or explicit no-op with proof.
- Create a route branch when exact current proof beats a written/default rule. Require conditions, proof, risk, env, and rollback for medium/high risk; promote only after repeated or safety-changing proof.
- Reconsider stored memory whenever current proof beats a remembered default.
  The old route may become `reject`, `alternate`, `situational`, or
  `superseded`; keep "best" wording fresh enough that future agents can trust
  it as a prior.

## Server Conveyor

At scale, the server should keep raw dialog evidence and local machine details outside the published skill.
The compiler path is:

```text
raw evidence -> sanitized marker -> candidate queue -> dedup/rank -> reviewed shelf fact -> published skill
```

Use stable shelf ids as partition keys.
Use prompt hashes or sanitized signatures for dedup, not private paths or hostnames.
Publish only compact facts, hot routes, activation cases, and scripts that reduce future work.

Partition high-volume queues by shelf id, task family, platform family, risk level, and day.
Keep published artifacts small: shelf modules, hot routes, activation eval cases, script catalog entries, and scripts.
Publish compiled memory only: compact facts, hot routes, activation cases, and
scripts that reduce future work. Keep raw dialogs, raw logs, stack dumps,
personal paths, hostnames, private addresses, tokens, serials, IMEIs, and
one-user workarounds in private audit storage when needed.

The normal runtime index should point agents at compiled artifacts: scoped shelf
facts, hot routes, eval cases, script catalog entries, and sanitized candidate
queues. A server may retain raw evidence privately for audit.

## Soty Replay Journal + Teacher

Keep Codex stock. The Soty agent records only sanitized receipts from real
turns and source commands, syncs them to the server, and asks the Teacher for a
ranked report:

```text
stock Codex -> local learning-outbox.jsonl -> /api/agent/learning/receipts -> /api/agent/learning/teacher -> reviewed skill/profile patch
```

The read-only diagnosis command is `sotyctl learn doctor`. It must sync the
local outbox first, then print top repeated blockers, proven routes, and
sanitized `ops-memory: ...` candidates.

The simple review command is `sotyctl learn review-merge`. It fetches the
Teacher report, imports sanitized candidates into the local ops candidate queue,
runs the queue compiler, and prints `promote` / `keep` / `review` counts.
Promote reviewed candidates into this skill and route normal agents to compiled
memory rather than raw dialogs.

Global learning contract:

```text
collect automatically -> promote deliberately -> distribute automatically
```

- Collect automatically: every Soty agent syncs sanitized receipts to the
  configured Soty server, and `sotyctl learn doctor` / `review-merge` reads
  that server journal, not only the current device.
- Promote deliberately: Teacher rows are candidates. They become rules only
  after a reviewed patch to one durable sink: shelf module, hot route, helper,
  route profile, activation eval, or field note.
- Distribute automatically: after `finish_skill_edit`, build/release/deploy
  updates `/agent/manifest.json`; managed Soty agents fetch the new agent and
  ops skill bundle from that manifest.
- A local ops repository commit without `sotyctl` or `teacher-report.json` is
  local-only work. It does not pull server knowledge and does not publish to
  other devices.
- "Every event" means every reusable, sanitized operational receipt. Raw
  dialogs, secrets, personal paths, private network details, and one-user noise
  stay out of the shared skill.

Requests like "Teacher review", "ticher review", or
"тичер ревью и мерж в ops" route to the Teacher review gate. If `sotyctl` is
unavailable, treat the missing report as the blocker and review any existing
ops patch explicitly instead of inventing Teacher output.

Correction: missing `sotyctl` is not a blocker by itself inside a Soty
runtime. Before declaring `teacher-report.json` absent, try the live ctl
fallback: `node scripts/soty-agent.mjs ctl learn review-merge` in the Soty
repo, or `node /agent/soty-agent.mjs ctl learn review-merge` in the server
executor. Only fall back to a local `teacher-report.json` after live Soty ctl
and `sotyctl learn doctor --json > teacher-report.json` both fail.
If live `review-merge` reaches the Teacher but stops because the server runtime
does not have a writable ops skill source installed, keep the server knowledge:
run `learn doctor --json`, download or pipe that report into
`ingest_teacher_report.py`, and record the missing source binding as a separate
runtime/deploy blocker.

Teacher candidate review path:

```powershell
sotyctl learn review-merge

# Expanded manual path:
sotyctl learn doctor --json > teacher-report.json
python scripts/learning/ingest_teacher_report.py teacher-report.json
python scripts/learning/ingest_teacher_report.py teacher-report.json --write
python scripts/learning/compile_memory_queue.py
```

Then patch exactly one reviewed sink: shelf module, hot route, helper, route
profile, activation eval, or field note. Run `scripts/skill/finish_skill_edit.py`
after the patch, then build and release the Soty agent bundle. Treat
`ingest_teacher_report.py --write` as candidate import; promotion happens in the
reviewed sink patch.

Use release channels from [release-and-sync.md](release-and-sync.md):

- `candidate`: compiled but not trusted for broad routing.
- `canary`: small cohort after health, privacy, and activation checks.
- `stable`: broad release after canary shows no regressions.
- `rollback`: previous stable hash remains available.

## Promotion Quality Gate

- One private case can create a candidate marker, not a global rule.
- Repeated cases, primary-source evidence, or a high-impact safety finding can promote a fact.
- Destructive defaults, trust/security changes, and public release rules need human or trusted-review approval.
- Failed routes should be kept with scope; they save time as route memory and
  become universal guidance only after broad evidence supports that status.
- Stale `unclear` facts should either get refreshed evidence, become scoped hypotheses, or be pruned.
- Aggregate Teacher rows that contain only family, route, exit code, and count
  can justify a classifier or review rule, but they are not enough to change a
  command default. Require exact command, stderr/proof shape, and environment
  boundary before promoting a helper fix, stop gate, or route replacement.

## Done Criteria

- Candidate facts are sanitized and shelf-tagged.
- Queue compiler has no `review` rows before automated pruning.
- Learning conveyor has run cleanly or named exact review/promote work.
- Learning review has reported recent learnings, savings, and branch/revision actions.
- Memory revisions have either been reflected in profiles/routes/modules or are explicitly queued for review.
- Repeated task families have route profiles with proof and transfer boundaries.
- Missed invocations have a prompt, expected shelf, and fix hint.
- Activation eval passes after trigger changes.
- Hot routes remain short enough for a small model to use without extra reading.
- Required runtime/project copies pass the copy drift gate before a shared release.
