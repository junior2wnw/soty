from __future__ import annotations

import sys
from pathlib import Path


def skill_root(start: str | Path) -> Path:
    path = Path(start).resolve()
    for candidate in [path, *path.parents]:
        if (candidate / "SKILL.md").exists():
            return candidate
    raise RuntimeError(f"Could not find skill root from {path}")


def scripts_root(start: str | Path) -> Path:
    return skill_root(start) / "scripts"


def add_script_category(start: str | Path, category: str) -> Path:
    path = scripts_root(start) / category
    path_text = str(path)
    if path_text not in sys.path:
        sys.path.insert(0, path_text)
    return path
