from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

METADATA_FILE = ".klava-canonical-skill.json"
EXCLUDED_NAMES = {".git", ".skill-memory", "__pycache__", ".gitignore", "README.md", METADATA_FILE}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}


def should_include(relative: Path) -> bool:
    if any(part in EXCLUDED_NAMES for part in relative.parts):
        return False
    if relative.suffix in EXCLUDED_SUFFIXES:
        return False
    return True


def digest_file(path: Path) -> str:
    value = hashlib.sha256()
    value.update(path.read_bytes())
    return value.hexdigest()


def collect(root: Path) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    if not root.exists():
        return result
    for item in root.rglob("*"):
        if not item.is_file():
            continue
        relative = item.relative_to(root)
        if not should_include(relative):
            continue
        result[relative.as_posix()] = {"hash": digest_file(item), "length": item.stat().st_size}
    return result


def hash_package(root: Path) -> str:
    digest = hashlib.sha256()
    for relative, item in sorted(collect(root).items()):
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update((root / relative).read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def read_applied_hash(root: Path) -> str:
    path = root / METADATA_FILE
    if not path.exists():
        return ""
    try:
        parsed = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return ""
    value = parsed.get("appliedHash")
    return value.strip() if isinstance(value, str) else ""


def is_clean_applied_copy(root: Path) -> bool:
    applied_hash = read_applied_hash(root)
    return bool(applied_hash) and hash_package(root) == applied_hash


def compare_roots(source: Path, copy: Path) -> dict[str, Any]:
    source_files = collect(source)
    copy_files = collect(copy)
    all_paths = sorted(set(source_files) | set(copy_files))

    only_canonical: list[str] = []
    only_copy: list[str] = []
    different: list[str] = []
    for relative in all_paths:
        source_item = source_files.get(relative)
        copy_item = copy_files.get(relative)
        if source_item is None:
            only_copy.append(relative)
            continue
        if copy_item is None:
            only_canonical.append(relative)
            continue
        if source_item["hash"] != copy_item["hash"]:
            different.append(relative)

    return {
        "only_canonical": only_canonical,
        "only_copy": only_copy,
        "different": different,
        "has_drift": bool(only_canonical or only_copy or different),
        "copy_applied_hash": read_applied_hash(copy),
        "copy_package_hash": hash_package(copy) if copy.exists() else "",
        "copy_clean_applied": is_clean_applied_copy(copy) if copy.exists() else False,
    }
