from __future__ import annotations

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from skill_paths import skill_root as find_skill_root

HEADING_BY_BUCKET = {
    "proven": "## Proven",
    "failed": "## Failed",
    "unclear": "## Unclear",
}

SCOPE_VALUES = {
    "hard-gate",
    "universal-pattern",
    "platform-or-family",
    "exact-target",
    "case-local",
    "hypothesis",
}

EVIDENCE_QUALITY_VALUES = {
    "live-observed",
    "primary-source",
    "case-observed",
    "maintainer-or-community",
    "user-reported",
    "inferred",
    "stale",
}

PRIVATE_IPV4_RE = re.compile(
    r"\b(?:10(?:\.\d{1,3}){3}|127(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})\b"
)
PRIVATE_IPV6_RE = re.compile(r"\b(?:fc|fd)[0-9a-f:]+\b|\bfe80:[0-9a-f:]+\b", re.IGNORECASE)
MAC_RE = re.compile(r"\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b")
PRIVATE_PATH_RE = re.compile(
    r"(?:\b[A-Za-z]:\\+(?:Users|Documents and Settings)\\+[^|\s]+|(?:^|[\s=])(?:~[/\\]|/(?:home|Users)/)[^|\s]+|\\{2,}[^\\\s|]+\\+[^|\s]+)",
    re.IGNORECASE,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Append a sanitized learning note with an environment fingerprint into references/field-notes.md.",
    )
    parser.add_argument("--bucket", required=True, choices=sorted(HEADING_BY_BUCKET))
    parser.add_argument("--domain", required=True)
    parser.add_argument(
        "--route-role",
        default="",
        help="Optional route role such as primary, alternate, situational, recovery-only, experiment-only, porting-only, or reject.",
    )
    parser.add_argument(
        "--scope",
        default="",
        choices=["", *sorted(SCOPE_VALUES)],
        help="Optional evidence scope such as hard-gate, platform-or-family, exact-target, case-local, or hypothesis.",
    )
    parser.add_argument(
        "--evidence-quality",
        default="",
        choices=["", *sorted(EVIDENCE_QUALITY_VALUES)],
        help="Optional evidence quality such as live-observed, primary-source, case-observed, user-reported, inferred, or stale.",
    )
    parser.add_argument(
        "--shared-dimensions",
        default="",
        help="Optional comma- or semicolon-separated dimensions that explain why a fact transfers across targets.",
    )
    parser.add_argument(
        "--divergent-dimensions",
        default="",
        help="Optional comma- or semicolon-separated dimensions that explain why a similar target diverges here.",
    )
    parser.add_argument("--pattern", required=True)
    parser.add_argument("--environment", required=True)
    parser.add_argument("--rationale", required=True)
    parser.add_argument("--timestamp", default="")
    parser.add_argument("--notes-file", default="", help="Optional override for field-notes.md.")
    return parser.parse_args()


def today_local() -> str:
    return datetime.now().astimezone().strftime("%Y-%m-%d")


def normalize_part(value: str) -> str:
    collapsed = " ".join(value.split())
    return collapsed.strip()


def normalize_dimensions(value: str) -> str:
    raw_parts = re.split(r"[;,]", value)
    cleaned: list[str] = []
    for part in raw_parts:
        normalized = normalize_part(part)
        if normalized and normalized not in cleaned:
            cleaned.append(normalized)
    return ", ".join(cleaned)


def reject_sensitive(text: str) -> None:
    ipv4_match = PRIVATE_IPV4_RE.search(text)
    if ipv4_match:
        raise ValueError(f"Refusing to write a note containing a private IPv4 address: {ipv4_match.group(0)}")
    ipv6_match = PRIVATE_IPV6_RE.search(text)
    if ipv6_match:
        raise ValueError(f"Refusing to write a note containing a private IPv6 address: {ipv6_match.group(0)}")
    mac_match = MAC_RE.search(text)
    if mac_match:
        raise ValueError(f"Refusing to write a note containing a MAC address: {mac_match.group(0)}")
    path_match = PRIVATE_PATH_RE.search(text)
    if path_match:
        raise ValueError(f"Refusing to write a note containing a private path: {path_match.group(0)}")


def insert_note(raw: str, heading: str, note_line: str) -> str:
    lines = raw.splitlines()
    if note_line in lines:
        return raw if raw.endswith("\n") else f"{raw}\n"

    try:
        start = lines.index(heading)
    except ValueError as exc:
        raise ValueError(f"Heading {heading!r} was not found in notes file.") from exc

    end = len(lines)
    for index in range(start + 1, len(lines)):
        if lines[index].startswith("## "):
            end = index
            break

    insert_at = end
    while insert_at > start + 1 and lines[insert_at - 1].strip() == "":
        insert_at -= 1

    lines.insert(insert_at, note_line)
    if insert_at == end:
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def main() -> int:
    args = parse_args()
    timestamp = normalize_part(args.timestamp) or today_local()
    domain = normalize_part(args.domain)
    route_role = normalize_part(args.route_role)
    scope = normalize_part(args.scope)
    evidence_quality = normalize_part(args.evidence_quality)
    shared_dimensions = normalize_dimensions(args.shared_dimensions)
    divergent_dimensions = normalize_dimensions(args.divergent_dimensions)
    pattern = normalize_part(args.pattern)
    environment = normalize_part(args.environment)
    rationale = normalize_part(args.rationale)

    for value in [
        domain,
        route_role,
        scope,
        evidence_quality,
        shared_dimensions,
        divergent_dimensions,
        pattern,
        environment,
        rationale,
    ]:
        if not value:
            continue
        reject_sensitive(value)

    skill_root = find_skill_root(__file__)
    notes_file = (
        Path(args.notes_file).expanduser().resolve()
        if args.notes_file.strip()
        else skill_root / "references" / "field-notes.md"
    )
    raw = notes_file.read_text(encoding="utf-8")
    segments = [f"- {timestamp}", args.bucket, domain]
    if route_role:
        segments.append(f"role: {route_role}")
    if scope:
        segments.append(f"scope: {scope}")
    if evidence_quality:
        segments.append(f"evidence: {evidence_quality}")
    if shared_dimensions:
        segments.append(f"shared: {shared_dimensions}")
    if divergent_dimensions:
        segments.append(f"diff: {divergent_dimensions}")
    segments.extend([pattern, f"env: {environment}", rationale])
    note_line = " | ".join(segments)
    updated = insert_note(raw, HEADING_BY_BUCKET[args.bucket], note_line)
    notes_file.write_text(updated, encoding="utf-8")
    print(note_line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
