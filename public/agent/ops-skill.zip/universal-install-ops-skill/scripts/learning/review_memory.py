from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "learning"))

from skill_paths import skill_root as find_skill_root
from ingest_memory_marker import sanitize_or_fail


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Record that remembered knowledge was reconsidered, downgraded, or superseded.")
    parser.add_argument("--belief", required=True, help="Short name of the remembered belief or route.")
    parser.add_argument("--old-best", required=True, help="Previous route, assumption, helper, or memory that looked best.")
    parser.add_argument("--new-best", default="", help="New better route when one is proven.")
    parser.add_argument("--decision", choices=["supersede", "downgrade", "keep", "reject"], default="supersede")
    parser.add_argument("--reason", required=True, help="Why the old memory lost confidence or stayed valid.")
    parser.add_argument("--proof", required=True, help="Observable evidence for the decision.")
    parser.add_argument("--env", required=True, help="Tiny sanitized environment and transfer boundary.")
    parser.add_argument("--scope", default="platform-or-family", help="case-local, platform-or-family, universal-pattern, hard-gate, or hypothesis.")
    parser.add_argument("--store", default="", help="Override memory-revisions JSONL path.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def skill_root() -> Path:
    return find_skill_root(__file__).resolve()


def default_store() -> Path:
    return skill_root() / ".skill-memory" / "memory-revisions.jsonl"


def store_path(raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else default_store()


def compact(value: str) -> str:
    return " ".join(value.strip().split())


def clean(value: str, field: str) -> str:
    text = compact(value)
    if not text:
        raise ValueError(f"--{field} is required")
    return sanitize_or_fail(text)


def read_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict):
            rows.append(row)
    return rows


def append_row(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True))
        handle.write("\n")


def build_row(args: argparse.Namespace) -> dict[str, Any]:
    new_best = compact(args.new_best)
    if args.decision == "supersede" and not new_best:
        raise ValueError("--new-best is required when --decision supersede")
    if new_best:
        new_best = sanitize_or_fail(new_best)
    return {
        "created_at": now_utc(),
        "type": "memory-revision",
        "decision": args.decision,
        "belief": clean(args.belief, "belief"),
        "old_best": clean(args.old_best, "old-best"),
        "new_best": new_best,
        "reason": clean(args.reason, "reason"),
        "proof": clean(args.proof, "proof"),
        "env": clean(args.env, "env"),
        "scope": clean(args.scope, "scope"),
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    path = store_path(args.store)
    row = build_row(args)
    append_row(path, row)
    rows = read_rows(path)
    return {"action": "record", "store": str(path), "revision": row, "revision_count": len(rows), "ok": True}


def print_text(report: dict[str, Any]) -> None:
    revision = report["revision"]
    print("Memory Review")
    print(f"- decision: {revision['decision']}")
    print(f"- belief: {revision['belief']}")
    print(f"- old_best: {revision['old_best']}")
    if revision["new_best"]:
        print(f"- new_best: {revision['new_best']}")
    print(f"- proof: {revision['proof']}")
    print(f"- store: {report['store']}")
    print(f"- revision_count: {report['revision_count']}")


def main() -> int:
    args = parse_args()
    try:
        report = run(args)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
