from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "learning"))

from skill_paths import skill_root as find_skill_root
import learning_conveyor


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Review recent ops learning, savings, and stale branch/revision work.")
    parser.add_argument("--memory-dir", default="", help="Directory containing local memory queues.")
    parser.add_argument("--notes-file", default="", help="Optional field-notes.md override.")
    parser.add_argument("--profile-store", default="", help="Optional route-profiles JSONL override.")
    parser.add_argument("--limit", type=int, default=8, help="Recent learning rows to show.")
    parser.add_argument("--branch-review-days", type=int, default=30)
    parser.add_argument("--strict", action="store_true", help="Return non-zero when review actions remain.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__).resolve()


def memory_dir(raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else skill_root() / ".skill-memory"


def store_path(raw: str, mem_dir: Path, name: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else mem_dir / name


def parse_time(value: str) -> datetime | None:
    text = value.strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def row_time(row: dict[str, Any]) -> datetime | None:
    return parse_time(str(row.get("created_at") or row.get("updated_at") or ""))


def age_days(row: dict[str, Any]) -> int | None:
    timestamp = row_time(row)
    if timestamp is None:
        return None
    return max(0, (datetime.now(timezone.utc) - timestamp.astimezone(timezone.utc)).days)


def read_jsonl(path: Path, label: str) -> tuple[list[dict[str, Any]], list[str]]:
    if not path.exists():
        return [], []
    rows: list[dict[str, Any]] = []
    errors: list[str] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as error:
            errors.append(f"{label}:{line_number}: invalid JSON: {error.msg}")
            continue
        if not isinstance(row, dict):
            errors.append(f"{label}:{line_number}: row is not an object")
            continue
        rows.append(row)
    return rows, errors


def compact(value: str, limit: int = 180) -> str:
    text = " ".join(value.strip().split())
    return text if len(text) <= limit else text[: limit - 3].rstrip() + "..."


def latest_profiles(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for row in rows:
        profile_id = str(row.get("profile_id", ""))
        current = latest.get(profile_id)
        if profile_id and (
            current is None
            or (
                (row_time(row) or datetime.min.replace(tzinfo=timezone.utc))
                > (row_time(current) or datetime.min.replace(tzinfo=timezone.utc))
            )
        ):
            latest[profile_id] = row
    return sorted(latest.values(), key=lambda item: str(item.get("profile_id", "")))


def savings(profiles: list[dict[str, Any]]) -> dict[str, dict[str, float | bool]]:
    totals: dict[str, dict[str, float | bool]] = {
        "minutes": {"known": False, "saved": 0.0},
        "steps": {"known": False, "saved": 0.0},
        "tokens": {"known": False, "saved": 0.0},
        "quality": {"known": False, "gained": 0.0},
        "safety": {"known": False, "gained": 0.0},
        "simplicity": {"known": False, "gained": 0.0},
        "universality": {"known": False, "gained": 0.0},
    }
    lower_is_better = {"minutes", "steps", "tokens"}
    for profile in profiles:
        metrics = profile.get("metrics", {})
        if not isinstance(metrics, dict):
            continue
        for key in totals:
            item = metrics.get(key, {})
            if not (isinstance(item, dict) and item.get("known")):
                continue
            totals[key]["known"] = True
            if key in lower_is_better:
                totals[key]["saved"] = round(float(totals[key]["saved"]) + float(item.get("saved", 0.0)), 2)
            else:
                totals[key]["known"] = True
                totals[key]["gained"] = round(float(totals[key]["gained"]) + float(item.get("gained", 0.0)), 2)
    return totals


def recent_items(
    candidates: list[dict[str, Any]],
    revisions: list[dict[str, Any]],
    branches: list[dict[str, Any]],
    profiles: list[dict[str, Any]],
    limit: int,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for row in candidates:
        items.append(
            {
                "time": str(row.get("created_at", "")),
                "kind": str(row.get("type", "candidate")),
                "summary": compact(str(row.get("marker", ""))),
            }
        )
    for row in revisions:
        items.append(
            {
                "time": str(row.get("created_at", "")),
                "kind": "memory-revision",
                "summary": compact(f"{row.get('decision', '')}: {row.get('belief', '')} -> {row.get('new_best') or row.get('old_best', '')}"),
            }
        )
    for row in branches:
        items.append(
            {
                "time": str(row.get("created_at", "")),
                "kind": "route-branch",
                "summary": compact(f"{row.get('status', '')}: {row.get('parent_rule', '')} -> {row.get('branch', '')}"),
            }
        )
    for row in profiles:
        items.append(
            {
                "time": str(row.get("updated_at", "")),
                "kind": "route-profile",
                "summary": compact(f"{row.get('profile_id', '')}: {row.get('route', '')}"),
            }
        )
    items.sort(key=lambda item: parse_time(str(item.get("time", ""))) or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    return items[: max(1, limit)]


def review_actions(
    conveyor: dict[str, Any],
    revisions: list[dict[str, Any]],
    branches: list[dict[str, Any]],
    branch_review_days: int,
) -> list[str]:
    actions: list[str] = []
    summary = conveyor.get("summary", {})
    compile_report = conveyor.get("compile", {})
    decisions = compile_report.get("decision_counts", {})
    for item in conveyor.get("recommendations", []):
        text = str(item)
        if text and not text.startswith("conveyor clean:") and text not in actions:
            actions.append(text)
    if decisions.get("review", 0):
        actions.append(f"review {decisions['review']} candidate fact rows before pruning")
    if decisions.get("promote", 0):
        actions.append(f"promote {decisions['promote']} repeated candidate fact rows")
    if summary.get("missed_invocation_count", 0):
        actions.append(f"patch activation for {summary['missed_invocation_count']} missed invocation rows")
    revision_counts = Counter(str(row.get("decision", "unknown")) for row in revisions)
    stale_revision_count = revision_counts.get("supersede", 0) + revision_counts.get("downgrade", 0) + revision_counts.get("reject", 0)
    if stale_revision_count:
        actions.append(f"verify {stale_revision_count} memory revision rows are reflected in active routes/profiles/modules")
    candidate_branches = [row for row in branches if row.get("status") == "candidate"]
    if candidate_branches:
        actions.append(f"review {len(candidate_branches)} candidate route branch rows")
    stale_branches = [
        row
        for row in candidate_branches
        if (age_days(row) is not None and int(age_days(row) or 0) >= branch_review_days)
    ]
    if stale_branches:
        actions.append(f"promote/reject {len(stale_branches)} route branches older than {branch_review_days} days")
    promoted_branches = [row for row in branches if row.get("status") == "promoted"]
    if promoted_branches:
        actions.append(f"confirm {len(promoted_branches)} promoted branches have shelf/hot/helper/eval patches")
    return actions


def conveyor_args(args: argparse.Namespace, mem_dir: Path) -> argparse.Namespace:
    return argparse.Namespace(
        memory_dir=str(mem_dir),
        notes_file=args.notes_file,
        profile_store=args.profile_store,
        write_reviewed=False,
        json=True,
    )


def run(args: argparse.Namespace) -> dict[str, Any]:
    mem_dir = memory_dir(args.memory_dir)
    candidate_rows, candidate_errors = read_jsonl(mem_dir / "candidate-facts.jsonl", "candidate-facts")
    revision_rows, revision_errors = read_jsonl(mem_dir / "memory-revisions.jsonl", "memory-revisions")
    branch_rows, branch_errors = read_jsonl(mem_dir / "route-branches.jsonl", "route-branches")
    profile_rows, profile_errors = read_jsonl(store_path(args.profile_store, mem_dir, "route-profiles.jsonl"), "route-profiles")
    profiles = latest_profiles(profile_rows)
    conveyor = learning_conveyor.run(conveyor_args(args, mem_dir))
    errors = (
        candidate_errors
        + revision_errors
        + branch_errors
        + profile_errors
        + list(conveyor.get("branches", {}).get("errors", []))
        + list(conveyor.get("revisions", {}).get("errors", []))
    )
    actions = review_actions(conveyor, revision_rows, branch_rows, args.branch_review_days)
    return {
        "memory_dir": str(mem_dir),
        "conveyor_ok": bool(conveyor.get("ok")),
        "counts": {
            "candidate_facts": len(candidate_rows),
            "memory_revisions": len(revision_rows),
            "route_branches": len(branch_rows),
            "route_profiles": len(profiles),
        },
        "branch_status_counts": dict(Counter(str(row.get("status", "unknown")) for row in branch_rows)),
        "revision_decision_counts": dict(Counter(str(row.get("decision", "unknown")) for row in revision_rows)),
        "savings": savings(profiles),
        "teacher_acceleration": conveyor.get("compile", {}).get("acceleration_gate", {}),
        "recent": recent_items(candidate_rows, revision_rows, branch_rows, profiles, args.limit),
        "review_actions": actions,
        "errors": errors,
        "ok": bool(conveyor.get("ok")) and not errors,
        "action_required": bool(actions),
    }


def print_text(report: dict[str, Any]) -> None:
    print("Ops Learning Review")
    print(f"- memory_dir: {report['memory_dir']}")
    print(f"- conveyor_ok: {report['conveyor_ok']}")
    print("- counts:")
    for key, value in report["counts"].items():
        print(f"  - {key}: {value}")
    print("- savings:")
    for key, value in report["savings"].items():
        known = value.get("known", False)
        if "saved" in value:
            print(f"  - {key}: saved={value.get('saved', 0)} known={known}")
        else:
            print(f"  - {key}: gained={value.get('gained', 0)} known={known}")
    if report.get("teacher_acceleration"):
        gate = report["teacher_acceleration"]
        print("- teacher_acceleration:")
        print(f"  - verdict: {gate.get('verdict')}")
        print(f"  - ok_to_claim_acceleration: {gate.get('ok_to_claim_acceleration')}")
        print(f"  - message: {gate.get('message')}")
    print(f"- action_required: {report['action_required']}")
    if report["review_actions"]:
        print("- review_actions:")
        for item in report["review_actions"]:
            print(f"  - {item}")
    print("- recent:")
    for item in report["recent"]:
        print(f"  - {item['time']} {item['kind']}: {item['summary']}")
    print("- errors:")
    if report["errors"]:
        for item in report["errors"]:
            print(f"  - {item}")
    else:
        print("  - none")


def main() -> int:
    args = parse_args()
    report = run(args)
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    if not report["ok"]:
        return 1
    if args.strict and report["action_required"]:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
