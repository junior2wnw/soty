from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any
from collections import Counter

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "learning"))

from skill_paths import skill_root as find_skill_root
import compile_memory_queue
import route_profile
import summarize_memory_queue


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the ops learning conveyor health gate.")
    parser.add_argument("--memory-dir", default="", help="Directory containing local memory queues.")
    parser.add_argument("--notes-file", default="", help="Optional field-notes.md override.")
    parser.add_argument("--profile-store", default="", help="Optional route-profiles JSONL override.")
    parser.add_argument("--write-reviewed", action="store_true", help="Move covered candidate rows to reviewed storage.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__).resolve()


def memory_dir(raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else skill_root() / ".skill-memory"


def compiler_args(args: argparse.Namespace, mem_dir: Path) -> argparse.Namespace:
    return argparse.Namespace(
        memory_dir=str(mem_dir),
        notes_file=args.notes_file,
        write_reviewed=args.write_reviewed,
        json=True,
    )


def route_profile_args(args: argparse.Namespace) -> argparse.Namespace:
    return argparse.Namespace(
        action="summary",
        profile_id="",
        shelf="general-routing",
        task_family="",
        platform_family="",
        control_plane="",
        route="",
        proof="",
        transfer_boundary="",
        baseline_minutes=None,
        actual_minutes=None,
        baseline_steps=None,
        actual_steps=None,
        baseline_tokens=None,
        actual_tokens=None,
        store=args.profile_store,
        json=True,
    )


def read_revision_rows(mem_dir: Path) -> list[dict[str, Any]]:
    path = mem_dir / "memory-revisions.jsonl"
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            rows.append({"_error": "invalid JSON in memory-revisions.jsonl"})
            continue
        rows.append(row if isinstance(row, dict) else {"_error": "non-object row in memory-revisions.jsonl"})
    return rows


def read_branch_rows(mem_dir: Path) -> list[dict[str, Any]]:
    path = mem_dir / "route-branches.jsonl"
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            rows.append({"_error": "invalid JSON in route-branches.jsonl"})
            continue
        rows.append(row if isinstance(row, dict) else {"_error": "non-object row in route-branches.jsonl"})
    return rows


def decision_counts(rows: list[dict[str, Any]]) -> dict[str, int]:
    return dict(Counter(str(row.get("decision", "unknown")) for row in rows if "_error" not in row))


def branch_status_counts(rows: list[dict[str, Any]]) -> dict[str, int]:
    return dict(Counter(str(row.get("status", "unknown")) for row in rows if "_error" not in row))


def recommendation(
    summary: dict[str, Any],
    compiled: dict[str, Any],
    profiles: dict[str, Any],
    revisions: list[dict[str, Any]],
    branches: list[dict[str, Any]],
) -> list[str]:
    items: list[str] = []
    decisions = compiled.get("decision_counts", {})
    gate = compiled.get("acceleration_gate", {})
    branch_statuses = branch_status_counts(branches)
    if decisions.get("review", 0):
        items.append("review candidate rows before pruning or promotion")
    if decisions.get("promote", 0):
        items.append("promote repeated candidates into shelf, hot route, helper, or activation eval")
    if decisions.get("covered", 0) and not compiled.get("wrote_reviewed"):
        items.append("run with --write-reviewed to move already-covered rows out of the active queue")
    if gate.get("verdict") == "confidence-only":
        items.append("Teacher batch is confidence/classifier only; record confidence or no-op and do not claim faster behavior")
    if gate.get("verdict") == "behavior-change-pending":
        items.append("promote behavior-changing rows into a reviewed sink before claiming Teacher acceleration")
    if summary.get("missed_invocation_count", 0):
        items.append("patch triggers or activation eval for missed invocations")
    if profiles.get("profile_count", 0) == 0:
        items.append("create route profiles for repeated task families before claiming universal fast-lanes")
    if any(str(row.get("decision")) in {"supersede", "reject", "downgrade"} for row in revisions if "_error" not in row):
        items.append("review superseded/downgraded memories and patch active shelves, hot routes, or profiles when behavior changed")
    if branch_statuses.get("candidate", 0):
        items.append("review candidate route branches after proof; promote, reject, or keep them case-local")
    if branch_statuses.get("promoted", 0):
        items.append("patch parent shelves, hot routes, helpers, or evals for promoted route branches")
    if not items:
        items.append("conveyor clean: no queued review/promote/missed work detected")
    return items


def run(args: argparse.Namespace) -> dict[str, Any]:
    mem_dir = memory_dir(args.memory_dir)
    summary = summarize_memory_queue.summarize(mem_dir)
    compiled = compile_memory_queue.compile_queue(compiler_args(args, mem_dir))
    profiles = route_profile.run(route_profile_args(args))
    revisions = read_revision_rows(mem_dir)
    branches = read_branch_rows(mem_dir)
    recs = recommendation(summary, compiled, profiles, revisions, branches)
    ok = bool(summary.get("ok")) and bool(compiled.get("ok"))
    ok = ok and not any("_error" in row for row in revisions)
    ok = ok and not any("_error" in row for row in branches)
    return {
        "memory_dir": str(mem_dir),
        "summary": summary,
        "compile": {
            "candidate_count": compiled.get("candidate_count", 0),
            "decision_counts": compiled.get("decision_counts", {}),
            "effect_counts": compiled.get("effect_counts", {}),
            "acceleration_gate": compiled.get("acceleration_gate", {}),
            "wrote_reviewed": compiled.get("wrote_reviewed", False),
            "ok": compiled.get("ok", False),
        },
        "profiles": {
            "store": profiles.get("store", ""),
            "profile_count": profiles.get("profile_count", 0),
            "profiles_by_shelf": profiles.get("profiles_by_shelf", {}),
        },
        "revisions": {
            "revision_count": len([row for row in revisions if "_error" not in row]),
            "decision_counts": decision_counts(revisions),
            "errors": [row["_error"] for row in revisions if "_error" in row],
        },
        "branches": {
            "branch_count": len([row for row in branches if "_error" not in row]),
            "status_counts": branch_status_counts(branches),
            "errors": [row["_error"] for row in branches if "_error" in row],
        },
        "recommendations": recs,
        "ok": ok,
    }


def print_text(report: dict[str, Any]) -> None:
    print("Learning Conveyor")
    print(f"- memory_dir: {report['memory_dir']}")
    print(f"- candidate_count: {report['summary']['candidate_count']}")
    print(f"- missed_invocation_count: {report['summary']['missed_invocation_count']}")
    print(f"- compile_ok: {report['compile']['ok']}")
    print("- decision_counts:")
    for key, value in sorted(report["compile"]["decision_counts"].items()):
        print(f"  - {key}: {value}")
    print("- effect_counts:")
    for key, value in sorted(report["compile"].get("effect_counts", {}).items()):
        print(f"  - {key}: {value}")
    gate = report["compile"].get("acceleration_gate", {})
    if gate:
        print("- acceleration_gate:")
        print(f"  - verdict: {gate.get('verdict')}")
        print(f"  - ok_to_claim_acceleration: {gate.get('ok_to_claim_acceleration')}")
        print(f"  - message: {gate.get('message')}")
    print(f"- route_profile_count: {report['profiles']['profile_count']}")
    print(f"- memory_revision_count: {report['revisions']['revision_count']}")
    if report["revisions"]["decision_counts"]:
        print("- revision_decisions:")
        for key, value in sorted(report["revisions"]["decision_counts"].items()):
            print(f"  - {key}: {value}")
    print(f"- route_branch_count: {report['branches']['branch_count']}")
    if report["branches"]["status_counts"]:
        print("- branch_statuses:")
        for key, value in sorted(report["branches"]["status_counts"].items()):
            print(f"  - {key}: {value}")
    print("- recommendations:")
    for item in report["recommendations"]:
        print(f"  - {item}")


def main() -> int:
    args = parse_args()
    report = run(args)
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
