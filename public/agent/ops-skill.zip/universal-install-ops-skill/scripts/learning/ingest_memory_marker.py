from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "routing"))

from skill_paths import skill_root as find_skill_root
import route_shelf

PRIVATE_IPV4 = re.compile(
    r"\b(?:10(?:\.\d{1,3}){3}|172\.(?:1[6-9]|2\d|3[01])(?:\.\d{1,3}){2}|192\.168(?:\.\d{1,3}){2}|127(?:\.\d{1,3}){3})\b"
)
MAC_ADDRESS = re.compile(r"\b[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}\b")
TOKEN_LIKE = re.compile(r"\b(?:sk-[A-Za-z0-9_-]{16,}|ghp_[A-Za-z0-9_]{16,}|xox[baprs]-[A-Za-z0-9-]{10,})\b")
IMEI_LIKE = re.compile(r"\bimei[:=\s-]*\d{14,17}\b", re.IGNORECASE)
PRIVATE_PATH = re.compile(
    r"(?:\b[A-Za-z]:\\+(?:Users|Documents and Settings)\\+[^|\s]+|(?:^|[\s=])(?:~[/\\]|/(?:home|Users)/)[^|\s]+|\\{2,}[^\\\s|]+\\+[^|\s]+)",
    re.IGNORECASE,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Queue a sanitized operational memory marker.")
    parser.add_argument("marker", help="A short ops-memory/control-memory marker or candidate fact.")
    parser.add_argument("--shelf", default="", help="Override target shelf id.")
    parser.add_argument("--source", default="manual", help="Source label for this candidate.")
    parser.add_argument("--queue", default="", help="Output JSONL queue path.")
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__)


def default_queue_path() -> Path:
    return skill_root() / ".skill-memory" / "candidate-facts.jsonl"


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def marker_kind(marker: str) -> str:
    lowered = marker.strip().lower()
    if lowered.startswith("ops-memory:"):
        return "ops-memory"
    if lowered.startswith("control-memory:"):
        return "control-memory"
    return "candidate"


def sanitize_or_fail(value: str) -> str:
    marker = " ".join(value.strip().split())
    if not marker:
        raise ValueError("marker is empty")
    if len(marker) > 1000:
        raise ValueError("marker is too long; keep candidate facts under 1000 characters")
    checks = [
        (PRIVATE_IPV4, "private IPv4 address"),
        (MAC_ADDRESS, "MAC address"),
        (TOKEN_LIKE, "token-like secret"),
        (IMEI_LIKE, "IMEI-like identifier"),
        (PRIVATE_PATH, "private path"),
    ]
    for pattern, label in checks:
        if pattern.search(marker):
            raise ValueError(f"marker contains {label}; keep shared memory sanitized")
    return marker


def choose_shelf(marker: str, override: str) -> str:
    if override.strip():
        return override.strip()
    index = route_shelf.load_index()
    return str(route_shelf.rank_shelves(marker, index, top=1)[0].get("id", "general-routing"))


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True))
        handle.write("\n")


def main() -> int:
    args = parse_args()
    try:
        marker = sanitize_or_fail(args.marker)
        record = {
            "created_at": now_utc(),
            "type": marker_kind(marker),
            "shelf": choose_shelf(marker, args.shelf),
            "source": args.source.strip() or "manual",
            "marker": marker,
        }
        queue_path = Path(args.queue).expanduser().resolve() if args.queue.strip() else default_queue_path()
        append_jsonl(queue_path, record)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 1

    print(f"queued: {queue_path}")
    print(f"type: {record['type']}")
    print(f"shelf: {record['shelf']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
