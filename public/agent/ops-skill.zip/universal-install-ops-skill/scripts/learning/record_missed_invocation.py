from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "routing"))

from skill_paths import skill_root as find_skill_root
import route_shelf
from ingest_memory_marker import sanitize_or_fail

STOPWORDS = {
    "and",
    "the",
    "this",
    "that",
    "with",
    "for",
    "from",
    "into",
    "why",
    "как",
    "что",
    "это",
    "надо",
    "если",
    "чтобы",
    "почему",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Record a prompt that should have activated a shelf but missed.")
    parser.add_argument("prompt", help="User wording that should have routed differently.")
    parser.add_argument("--expected-shelf", default="", help="Shelf that should have been selected.")
    parser.add_argument("--actual-shelf", default="", help="Shelf that was selected, if known.")
    parser.add_argument("--reason", default="", help="Short reason or suspected missing trigger.")
    parser.add_argument("--queue", default="", help="Output missed-invocations JSONL path.")
    return parser.parse_args()


def skill_root() -> Path:
    return find_skill_root(__file__)


def default_queue_path() -> Path:
    return skill_root() / ".skill-memory" / "missed-invocations.jsonl"


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def top_prompt_terms(prompt: str, limit: int = 8) -> list[str]:
    terms = []
    for token in sorted(route_shelf.tokens(prompt), key=lambda item: (-len(item), item)):
        if token in STOPWORDS:
            continue
        terms.append(token)
        if len(terms) >= limit:
            break
    return terms


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True))
        handle.write("\n")


def main() -> int:
    args = parse_args()
    try:
        prompt = sanitize_or_fail(args.prompt)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 1

    shelf_index = route_shelf.load_index()
    suggested = route_shelf.rank_shelves(prompt, shelf_index, top=1)[0]
    terms = top_prompt_terms(prompt)
    expected = args.expected_shelf.strip()
    record: dict[str, Any] = {
        "created_at": now_utc(),
        "prompt": prompt,
        "expected_shelf": expected,
        "actual_shelf": args.actual_shelf.strip(),
        "suggested_shelf": suggested.get("id", ""),
        "suggested_score": suggested.get("score", 0),
        "reason": args.reason.strip(),
        "trigger_terms": terms,
        "fix_hint": f"if repeated, add trigger terms to {expected or suggested.get('id', '')}: {', '.join(terms)}",
    }
    queue_path = Path(args.queue).expanduser().resolve() if args.queue.strip() else default_queue_path()
    append_jsonl(queue_path, record)

    print(f"recorded: {queue_path}")
    print(f"suggested_shelf: {record['suggested_shelf']}")
    print(f"fix_hint: {record['fix_hint']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
