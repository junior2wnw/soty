from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

from score_case_facts import (
    EVIDENCE_QUALITY_WEIGHTS,
    FRESHNESS_WEIGHTS,
    GOAL_FIT_WEIGHTS,
    POLARITY_VALUES,
    SCOPE_WEIGHTS,
    TARGET_FIT_WEIGHTS,
    build_summary,
    score_fact,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Append or update a weighted decision fact inside an install-ops case journal.",
    )
    parser.add_argument("case", help="Path to a case directory or case.json.")
    parser.add_argument("--statement", required=True, help="Plain-language decision fact.")
    parser.add_argument("--scope", required=True, choices=sorted(SCOPE_WEIGHTS))
    parser.add_argument("--evidence-quality", required=True, choices=sorted(EVIDENCE_QUALITY_WEIGHTS))
    parser.add_argument("--freshness", default="unknown", choices=sorted(FRESHNESS_WEIGHTS))
    parser.add_argument("--target-fit", default="unknown", choices=sorted(TARGET_FIT_WEIGHTS))
    parser.add_argument("--goal-fit", default="unknown", choices=sorted(GOAL_FIT_WEIGHTS))
    parser.add_argument("--polarity", default="supports", choices=sorted(POLARITY_VALUES))
    parser.add_argument("--source-ref", default="", help="Short pointer to the source command, log, or document.")
    parser.add_argument(
        "--shared-dimensions",
        default="",
        help="Optional comma- or semicolon-separated dimensions that explain why this fact transfers across targets.",
    )
    parser.add_argument(
        "--divergent-dimensions",
        default="",
        help="Optional comma- or semicolon-separated dimensions that explain why a similar target diverges here.",
    )
    parser.add_argument(
        "--append-duplicate",
        action="store_true",
        help="Append another fact even when the same statement already exists.",
    )
    return parser.parse_args()


def current_timestamp() -> str:
    return datetime.now().astimezone().replace(microsecond=0).isoformat()


def load_case(path_text: str) -> tuple[Path, dict[str, Any]]:
    path = Path(path_text).expanduser().resolve()
    case_json = path / "case.json" if path.is_dir() else path
    if not case_json.exists():
        raise FileNotFoundError(f"case.json was not found: {case_json}")
    data = json.loads(case_json.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("case.json must contain a JSON object.")
    return case_json, data


def normalize_text(value: str) -> str:
    return " ".join(value.split()).strip()


def normalize_dimensions(value: str) -> list[str]:
    parts = re.split(r"[;,]", value)
    cleaned: list[str] = []
    for part in parts:
        normalized = normalize_text(part)
        if normalized and normalized not in cleaned:
            cleaned.append(normalized)
    return cleaned


def normalized_statement(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return normalize_text(value).lower()


def main() -> int:
    args = parse_args()
    case_json, data = load_case(args.case)
    decision_facts = data.get("decision_facts")
    if decision_facts is None:
        decision_facts = []
    if not isinstance(decision_facts, list):
        raise ValueError("decision_facts must be a list in case.json")

    fact = {
        "statement": normalize_text(args.statement),
        "scope": args.scope,
        "evidence_quality": args.evidence_quality,
        "freshness": args.freshness,
        "target_fit": args.target_fit,
        "goal_fit": args.goal_fit,
        "polarity": args.polarity,
        "source_ref": normalize_text(args.source_ref),
        "shared_dimensions": normalize_dimensions(args.shared_dimensions),
        "divergent_dimensions": normalize_dimensions(args.divergent_dimensions),
    }
    score_fact(fact)

    if not args.append_duplicate:
        statement_key = normalized_statement(fact["statement"])
        replaced = False
        for index, existing in enumerate(decision_facts):
            if not isinstance(existing, dict):
                continue
            if normalized_statement(existing.get("statement")) == statement_key:
                decision_facts[index] = fact
                replaced = True
                break
        if not replaced:
            decision_facts.append(fact)
    else:
        decision_facts.append(fact)

    rescored: list[dict[str, Any]] = []
    for item in decision_facts:
        if not isinstance(item, dict):
            continue
        rescored.append(score_fact(item))

    data["decision_facts"] = rescored
    data["weighted_fact_summary"] = build_summary(rescored)
    data["updated_at"] = current_timestamp()
    case_json.write_text(f"{json.dumps(data, indent=2)}\n", encoding="utf-8")

    print(f"case: {case_json}")
    print(f"saved_fact: {fact['statement']}")
    print(f"computed_weight: {fact['computed_weight']}")
    print(f"route_status: {data['weighted_fact_summary']['route_status']}")
    print(f"fact_count: {len(rescored)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
