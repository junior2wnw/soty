param(
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string] $ControllerBase = "",
  [string] $EsdUrl = "",
  [string] $ExpectedEsdSha256 = "",
  [string] $SourceMediaRoot = "",
  [string] $UsbDriveLetter = "D",
  [string] $UsbLabel = "SOTYWIN",
  [string] $UsbFileSystem = "Preserve",
  [string] $InstallImageLayout = "Auto",
  [switch] $PrepareOnly,
  [switch] $BuildUsb,
  [switch] $ArmInternalBoot,
  [switch] $RebootNow
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Set-Status([string] $Status, $Extra = $null) {
  $payload = [ordered]@{
    status = $Status
    updatedAt = (Get-Date).ToString("o")
    runRoot = $script:RunRoot
    logPath = $script:LogPath
  }
  if ($null -ne $Extra) {
    foreach ($property in $Extra.GetEnumerator()) {
      $payload[$property.Key] = $property.Value
    }
  }
  Save-Json -Path $script:StatusPath -Value $payload
}

function Set-KeepAwake([bool] $Enable) {
  try {
    Add-Type -Namespace Native -Name Power -MemberDefinition '[System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError=true)] public static extern uint SetThreadExecutionState(uint esFlags);' -ErrorAction SilentlyContinue
    if ($Enable) {
      [void][Native.Power]::SetThreadExecutionState(0x80000000 -bor 0x00000001 -bor 0x00000002)
    } else {
      [void][Native.Power]::SetThreadExecutionState(0x80000000)
    }
  } catch {}
}

function Invoke-Step {
  param(
    [string] $Name,
    [scriptblock] $Block
  )

  Set-Status -Status $Name
  Log ("STEP " + $Name)
  & $Block
}

if ([string]::IsNullOrWhiteSpace($ControllerBase)) {
  throw "ControllerBase is required."
}
if ([string]::IsNullOrWhiteSpace($EsdUrl)) {
  throw "EsdUrl is required."
}
if ([string]::IsNullOrWhiteSpace($ExpectedEsdSha256)) {
  throw "ExpectedEsdSha256 is required."
}

$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$script:RunRoot = Join-Path $WorkspaceRoot ("clean-reinstall-bootstrap\" + $runId)
$currentRoot = Join-Path $WorkspaceRoot "clean-reinstall-bootstrap\current"
$toolsRoot = Join-Path $WorkspaceRoot "tools"
$logsRoot = Join-Path $script:RunRoot "logs"
foreach ($path in @($WorkspaceRoot, $script:RunRoot, $currentRoot, $toolsRoot, $logsRoot)) {
  New-Dir $path
}
$script:LogPath = Join-Path $logsRoot "bootstrap.log"
$script:StatusPath = Join-Path $currentRoot "status.json"
$resultPath = Join-Path $currentRoot "result.json"
$errorPath = Join-Path $currentRoot "error.json"
$routePropertiesPath = Join-Path $script:RunRoot "route-properties.json"

if ([string]::IsNullOrWhiteSpace($SourceMediaRoot)) {
  $SourceMediaRoot = Join-Path $WorkspaceRoot "source-media\win11-current"
}

Set-Status -Status "starting"
Set-KeepAwake -Enable $true
try {
  Invoke-Step -Name "download-helpers" -Block {
    $base = $ControllerBase.TrimEnd("/")
    $scriptNames = @(
      "windows-detect-route-properties.ps1",
      "windows-prepare-source-media-from-esd.ps1",
      "windows-stage-bundle.ps1",
      "windows-build-bootable-usb.ps1",
      "windows-arm-internal-winpe-boot.ps1",
      "windows-assert-custom-winpe-worker.ps1"
    )
    foreach ($name in $scriptNames) {
      $url = $base + "/scripts/windows/" + $name
      $dest = Join-Path $toolsRoot $name
      Log ("Downloading helper " + $name)
      Invoke-WebRequest -Uri $url -UseBasicParsing -OutFile $dest -TimeoutSec 60
    }
  }

  Invoke-Step -Name "detect-route-properties" -Block {
    & (Join-Path $toolsRoot "windows-detect-route-properties.ps1") `
      -WorkspaceRoot $WorkspaceRoot `
      -UsbDriveLetter $UsbDriveLetter `
      -OutputPath $routePropertiesPath | Out-Null
  }

  Invoke-Step -Name "prepare-source-media" -Block {
    & (Join-Path $toolsRoot "windows-prepare-source-media-from-esd.ps1") `
      -WorkspaceRoot $WorkspaceRoot `
      -EsdUrl $EsdUrl `
      -ExpectedEsdSha256 $ExpectedEsdSha256 `
      -SourceMediaRoot $SourceMediaRoot
  }

  Invoke-Step -Name "stage-restore-bundle" -Block {
    & (Join-Path $toolsRoot "windows-stage-bundle.ps1") `
      -WorkspaceRoot $WorkspaceRoot `
      -RunLabel "clean-reinstall" `
      -IncludeUserFiles:$false
  }

  $latestStage = Get-ChildItem -LiteralPath (Join-Path $WorkspaceRoot "stage-bundles") -Directory -ErrorAction Stop |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

  $usbResult = $null
  if ($BuildUsb) {
    Invoke-Step -Name "build-usb" -Block {
      & (Join-Path $toolsRoot "windows-build-bootable-usb.ps1") `
        -WorkspaceRoot $WorkspaceRoot `
        -StageBundleRoot $latestStage.FullName `
        -UsbDriveLetter $UsbDriveLetter `
        -UsbLabel $UsbLabel `
        -SourceMediaRoot $SourceMediaRoot `
        -UsbFileSystem $UsbFileSystem `
        -InstallImageLayout $InstallImageLayout
    }
    $latestUsb = Get-ChildItem -LiteralPath (Join-Path $WorkspaceRoot "usb-bootable") -Directory -ErrorAction Stop |
      Sort-Object LastWriteTime -Descending |
      Select-Object -First 1
    $usbResult = $latestUsb.FullName
  }

  if ($ArmInternalBoot) {
    Invoke-Step -Name "arm-internal-boot" -Block {
      & (Join-Path $toolsRoot "windows-arm-internal-winpe-boot.ps1") `
        -UsbDriveLetter $UsbDriveLetter `
        -UsbLabel $UsbLabel `
        -RebootNow:$RebootNow
    }
  }

  $result = [ordered]@{
    status = "ok"
    finishedAt = (Get-Date).ToString("o")
    runRoot = $script:RunRoot
    sourceMediaRoot = $SourceMediaRoot
    stageBundleRoot = $latestStage.FullName
    usbBuildRoot = $usbResult
    routePropertiesPath = $routePropertiesPath
    buildUsb = [bool]$BuildUsb
    armInternalBoot = [bool]$ArmInternalBoot
    rebootNow = [bool]$RebootNow
    logPath = $script:LogPath
  }
  Save-Json -Path $resultPath -Value $result
  Set-Status -Status "ok" -Extra @{ resultPath = $resultPath }
} catch {
  $failure = [ordered]@{
    status = "error"
    failedAt = (Get-Date).ToString("o")
    runRoot = $script:RunRoot
    message = $_.Exception.Message
    stack = $_.ScriptStackTrace
    logPath = $script:LogPath
  }
  Save-Json -Path $errorPath -Value $failure
  Set-Status -Status "error" -Extra @{ errorPath = $errorPath; message = $_.Exception.Message }
  throw
} finally {
  Set-KeepAwake -Enable $false
}
