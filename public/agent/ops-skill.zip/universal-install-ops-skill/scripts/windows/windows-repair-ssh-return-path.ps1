param(
  [string] $UsbDriveLetter = "D",
  [string] $PreferredUserName = "",
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall"
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Get-LeafUserName([string] $Identity) {
  if ([string]::IsNullOrWhiteSpace($Identity)) {
    return $null
  }
  $leaf = [string]$Identity
  if ($leaf.Contains("\")) {
    $leaf = $leaf.Split("\")[-1]
  }
  if ($leaf.Contains("/")) {
    $leaf = $leaf.Split("/")[-1]
  }
  return $leaf.Trim()
}

function Resolve-UsbRoot([string] $DriveLetter) {
  $letter = $DriveLetter.TrimEnd(":").ToUpperInvariant()
  $candidate = $letter + ":\Soty-Reinstall"
  if (Test-Path -LiteralPath $candidate) {
    return $candidate
  }
  foreach ($volume in @(Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.DriveLetter })) {
    $root = $volume.DriveLetter + ":\Soty-Reinstall"
    if (Test-Path -LiteralPath $root) {
      return $root
    }
  }
  return $null
}

function Ensure-OpenSshServer {
  if (Get-Service sshd -ErrorAction SilentlyContinue) {
    return
  }
  try {
    Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0 -ErrorAction Stop | Out-Null
  } catch {
    Log ("OpenSSH capability warning: " + $_.Exception.Message)
    try {
      & dism.exe /Online /Add-Capability /CapabilityName:OpenSSH.Server~~~~0.0.1.0 /NoRestart | Out-Null
    } catch {
      Log ("OpenSSH DISM warning: " + $_.Exception.Message)
    }
  }
}

function Test-SshdUsesAdministratorsAuthorizedKeys([string] $ConfigPath) {
  if (-not (Test-Path -LiteralPath $ConfigPath)) {
    return $false
  }
  try {
    $configText = Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop
  } catch {
    Log ("OpenSSH config read warning: " + $_.Exception.Message)
    return $false
  }
  return ($configText -match '(?im)^\s*Match\s+Group\s+administrators\b' -and $configText -match '(?im)^\s*AuthorizedKeysFile\s+__PROGRAMDATA__/ssh/administrators_authorized_keys\b')
}

function Merge-AuthorizedKeysFile([string] $SourcePath, [string] $DestinationPath) {
  if (-not (Test-Path -LiteralPath $SourcePath)) {
    return $false
  }
  $lines = New-Object "System.Collections.Generic.List[string]"
  if (Test-Path -LiteralPath $DestinationPath) {
    foreach ($line in @(Get-Content -LiteralPath $DestinationPath -ErrorAction SilentlyContinue)) {
      $trimmed = [string]$line
      if (-not [string]::IsNullOrWhiteSpace($trimmed) -and -not ($lines.Contains($trimmed))) {
        $lines.Add($trimmed) | Out-Null
      }
    }
  }
  foreach ($line in @(Get-Content -LiteralPath $SourcePath -ErrorAction SilentlyContinue)) {
    $trimmed = [string]$line
    if (-not [string]::IsNullOrWhiteSpace($trimmed) -and -not ($lines.Contains($trimmed))) {
      $lines.Add($trimmed) | Out-Null
    }
  }
  if ($lines.Count -le 0) {
    return $false
  }
  New-Dir (Split-Path -Parent $DestinationPath)
  Set-Content -LiteralPath $DestinationPath -Value @($lines.ToArray()) -Encoding ASCII
  return $true
}

function Resolve-ReturnUserName([string] $Preferred, $Manifest) {
  if (-not [string]::IsNullOrWhiteSpace($Preferred)) {
    return $Preferred
  }
  if ($Manifest -and $Manifest.PSObject.Properties.Name -contains "preferredReturnUserName") {
    $manifestUser = [string]$Manifest.preferredReturnUserName
    if (-not [string]::IsNullOrWhiteSpace($manifestUser)) {
      return $manifestUser
    }
  }
  return (Get-LeafUserName ([Security.Principal.WindowsIdentity]::GetCurrent().Name))
}

function Resolve-ReturnUserSid([string] $ReturnUserName, $Manifest) {
  if ($Manifest -and $Manifest.PSObject.Properties.Name -contains "preferredReturnUserSid") {
    $manifestSid = [string]$Manifest.preferredReturnUserSid
    if (-not [string]::IsNullOrWhiteSpace($manifestSid)) {
      return "*" + $manifestSid
    }
  }
  $resolvedSid = Resolve-PrincipalSid -UserName $ReturnUserName
  if (-not [string]::IsNullOrWhiteSpace($resolvedSid)) {
    return "*" + $resolvedSid
  }
  try {
    return "*" + [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  } catch {
    return $null
  }
}

function Resolve-PrincipalSid([string] $UserName, [string] $UserSid = "") {
  if (-not [string]::IsNullOrWhiteSpace($UserSid)) {
    return $UserSid.TrimStart("*")
  }
  if ([string]::IsNullOrWhiteSpace($UserName)) {
    return $null
  }
  try {
    return ([System.Security.Principal.NTAccount]$UserName).Translate([System.Security.Principal.SecurityIdentifier]).Value
  } catch {}
  try {
    $account = Get-CimInstance Win32_UserAccount -ErrorAction SilentlyContinue |
      Where-Object { $_.LocalAccount -and [string]$_.Name -eq $UserName } |
      Select-Object -First 1
    if ($account -and $account.SID) {
      return [string]$account.SID
    }
  } catch {}
  return $null
}

function Resolve-ReturnUserProfile([string] $ReturnUserName, [string] $ReturnUserSid = "") {
  $plainSid = $ReturnUserSid.TrimStart("*")
  try {
    $match = Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue |
      Where-Object {
        ($plainSid -and [string]$_.SID -eq $plainSid) -or
        ($_.LocalPath -eq (Join-Path "C:\Users" $ReturnUserName))
      } |
      Select-Object -First 1
    if ($match -and $match.LocalPath) {
      return [string]$match.LocalPath
    }
  } catch {}
  return (Join-Path "C:\Users" $ReturnUserName)
}

function Test-LocalAdministratorMember([string] $UserName, [string] $UserSid = "") {
  $principalSid = Resolve-PrincipalSid -UserName $UserName -UserSid $UserSid
  if ([string]::IsNullOrWhiteSpace($principalSid)) { return $false }
  $principalPattern = 'SID="' + [regex]::Escape($principalSid) + '"'
  try {
    foreach ($membership in @(Get-CimInstance Win32_GroupUser -ErrorAction SilentlyContinue)) {
      $groupComponent = [string]$membership.GroupComponent
      $partComponent = [string]$membership.PartComponent
      if ($groupComponent -match 'SID="S-1-5-32-544"' -and $partComponent -match $principalPattern) {
        return $true
      }
    }
  } catch {}
  return $false
}

function Resolve-UserSshBackupPath([string] $UsbRoot, [string] $ReturnUserName, $Manifest) {
  $candidates = New-Object "System.Collections.Generic.List[string]"
  if ($Manifest -and $Manifest.PSObject.Properties.Name -contains "users") {
    $entry = @($Manifest.users) |
      Where-Object {
        [string]$_.userName -eq $ReturnUserName -or
        [string]$_.profileDirName -eq $ReturnUserName
      } |
      Select-Object -First 1
    if ($entry) {
      $archivePath = if ($entry.PSObject.Properties.Name -contains "archivePath") { [string]$entry.archivePath } else { $null }
      if (-not [string]::IsNullOrWhiteSpace($archivePath)) {
        $archiveRoot = Join-Path $UsbRoot $archivePath
        $candidates.Add((Join-Path $archiveRoot "authorized_keys")) | Out-Null
        if ($archivePath -match '[\\/]\.ssh$') {
          $legacyRoot = Join-Path $UsbRoot ([System.IO.Path]::GetDirectoryName($archivePath))
          if (-not [string]::IsNullOrWhiteSpace($legacyRoot)) {
            $candidates.Add((Join-Path $legacyRoot "authorized_keys")) | Out-Null
          }
        }
      }
      $profileDirName = if ($entry.PSObject.Properties.Name -contains "profileDirName") { [string]$entry.profileDirName } else { $null }
      if (-not [string]::IsNullOrWhiteSpace($profileDirName)) {
        $candidates.Add((Join-Path (Join-Path (Join-Path $UsbRoot "backup\ssh\user_ssh") $profileDirName) "authorized_keys")) | Out-Null
      }
    }
  }
  $candidates.Add((Join-Path (Join-Path (Join-Path $UsbRoot "backup\ssh\user_ssh") $ReturnUserName) "authorized_keys")) | Out-Null
  foreach ($candidate in @($candidates | Select-Object -Unique)) {
    if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate)) {
      return $candidate
    }
  }
  return $candidates[-1]
}

$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$runRoot = Join-Path $WorkspaceRoot ("ssh-repair\" + $runId)
New-Dir $runRoot
$script:LogPath = Join-Path $runRoot "repair.log"

$usbRoot = Resolve-UsbRoot $UsbDriveLetter
if (-not $usbRoot) {
  throw "Soty-Reinstall USB root could not be found."
}
Log ("USB root resolved to " + $usbRoot)

$sshManifestPath = Join-Path $usbRoot "backup\manifests\ssh-manifest.json"
$sshManifest = $null
if (Test-Path -LiteralPath $sshManifestPath) {
  try {
    $sshManifest = Get-Content -LiteralPath $sshManifestPath -Raw | ConvertFrom-Json
    Log ("Loaded SSH manifest from " + $sshManifestPath)
  } catch {
    Log ("SSH manifest warning: " + $_.Exception.Message)
  }
}

$returnUserName = Resolve-ReturnUserName -Preferred $PreferredUserName -Manifest $sshManifest
$returnUserSid = Resolve-ReturnUserSid -ReturnUserName $returnUserName -Manifest $sshManifest
$returnUserProfile = Resolve-ReturnUserProfile -ReturnUserName $returnUserName -ReturnUserSid $returnUserSid
Log ("Preferred return user: " + $returnUserName)
Log ("Preferred return profile: " + $returnUserProfile)

Ensure-OpenSshServer

$programDataSshBackup = Join-Path $usbRoot "backup\ssh\programdata_ssh"
$programDataSshTarget = Join-Path $env:ProgramData "ssh"
New-Dir $programDataSshTarget
if (Test-Path -LiteralPath $programDataSshBackup) {
  Copy-Item -LiteralPath (Join-Path $programDataSshBackup "*") -Destination $programDataSshTarget -Recurse -Force -ErrorAction SilentlyContinue
  Log ("Copied ProgramData SSH state from " + $programDataSshBackup)
}

$adminAuthorizedKeysBackup = Join-Path $programDataSshBackup "administrators_authorized_keys"
$adminAuthorizedKeysTarget = Join-Path $programDataSshTarget "administrators_authorized_keys"
if (Merge-AuthorizedKeysFile -SourcePath $adminAuthorizedKeysBackup -DestinationPath $adminAuthorizedKeysTarget) {
  Log "Merged administrators_authorized_keys backup."
}

$returnUserSshRoot = Join-Path $returnUserProfile ".ssh"
$returnUserAuthorizedKeys = Join-Path $returnUserSshRoot "authorized_keys"
$returnUserBackup = Resolve-UserSshBackupPath -UsbRoot $usbRoot -ReturnUserName $returnUserName -Manifest $sshManifest
New-Dir $returnUserSshRoot
if (Merge-AuthorizedKeysFile -SourcePath $returnUserBackup -DestinationPath $returnUserAuthorizedKeys) {
  Log ("Merged user authorized_keys backup for " + $returnUserName + " from " + $returnUserBackup)
} elseif (Merge-AuthorizedKeysFile -SourcePath $adminAuthorizedKeysBackup -DestinationPath $returnUserAuthorizedKeys) {
  Log ("Fell back to administrators_authorized_keys for user authorized_keys of " + $returnUserName)
}

$usesAdminAuthorizedKeys = Test-SshdUsesAdministratorsAuthorizedKeys -ConfigPath (Join-Path $programDataSshTarget "sshd_config")
if ($usesAdminAuthorizedKeys -and (Test-LocalAdministratorMember -UserName $returnUserName -UserSid $returnUserSid) -and (Test-Path -LiteralPath $returnUserAuthorizedKeys)) {
  if (Merge-AuthorizedKeysFile -SourcePath $returnUserAuthorizedKeys -DestinationPath $adminAuthorizedKeysTarget) {
    Log "Mirrored return-user authorized_keys into administrators_authorized_keys."
  }
}

if (Test-Path -LiteralPath $returnUserSshRoot) {
  try {
    icacls $returnUserSshRoot /inheritance:r /grant:r ($returnUserSid + ":(OI)(CI)F") "*S-1-5-18:(OI)(CI)F" | Out-Null
  } catch {
    Log ("User .ssh ACL warning: " + $_.Exception.Message)
  }
}
if (Test-Path -LiteralPath $returnUserAuthorizedKeys) {
  try {
    icacls $returnUserAuthorizedKeys /inheritance:r /grant:r ($returnUserSid + ":F") "*S-1-5-18:F" | Out-Null
  } catch {
    Log ("authorized_keys ACL warning: " + $_.Exception.Message)
  }
}
if (Test-Path -LiteralPath $adminAuthorizedKeysTarget) {
  try {
    icacls $adminAuthorizedKeysTarget /inheritance:r /grant:r "*S-1-5-32-544:F" "*S-1-5-18:F" | Out-Null
  } catch {
    Log ("administrators_authorized_keys ACL warning: " + $_.Exception.Message)
  }
}

try {
  if (-not (Get-NetFirewallRule -Name OpenSSH-Server-In-TCP -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -Name OpenSSH-Server-In-TCP -DisplayName "OpenSSH Server (sshd)" -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22 -Profile Any | Out-Null
  } else {
    Set-NetFirewallRule -Name OpenSSH-Server-In-TCP -Enabled True -Profile Any -Action Allow | Out-Null
  }
} catch {
  Log ("OpenSSH firewall warning: " + $_.Exception.Message)
}

try { Set-Service -Name sshd -StartupType Automatic -ErrorAction Stop } catch { Log ("OpenSSH startup warning: " + $_.Exception.Message) }
try { Start-Service sshd -ErrorAction Stop } catch {}
try { Restart-Service sshd -ErrorAction Stop } catch { Log ("OpenSSH restart warning: " + $_.Exception.Message) }

$result = [ordered]@{
  status = "ssh_return_path_repaired"
  runRoot = $runRoot
  usbRoot = $usbRoot
  returnUserName = $returnUserName
  returnUserProfile = $returnUserProfile
  returnUserSid = $returnUserSid
  usesAdministratorsAuthorizedKeys = $usesAdminAuthorizedKeys
  adminAuthorizedKeysTarget = $adminAuthorizedKeysTarget
  returnUserAuthorizedKeys = $returnUserAuthorizedKeys
  logPath = $script:LogPath
}
$resultPath = Join-Path $runRoot "result.json"
Set-Content -LiteralPath $resultPath -Value ($result | ConvertTo-Json -Depth 12) -Encoding UTF8
Write-Output ("SSH_RETURN_PATH_REPAIR_RESULT=" + $resultPath)
