param(
  [string] $BootWimPath = "",
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall"
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Invoke-CliStrict([string] $FilePath, [string[]] $ArgumentList) {
  & $FilePath @ArgumentList | Out-Null
  if ($LASTEXITCODE -ne 0) {
    throw ($FilePath + " failed with exit code " + $LASTEXITCODE)
  }
}

if ([string]::IsNullOrWhiteSpace($BootWimPath)) {
  throw "BootWimPath is required."
}
if (-not (Test-Path -LiteralPath $BootWimPath)) {
  throw "Boot WIM path not found: $BootWimPath"
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw "This script must run as Administrator."
}

$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$runRoot = Join-Path $WorkspaceRoot ("bootwim-verify\" + $runId)
$mountDir = Join-Path $runRoot "mount"
$copyPath = Join-Path $runRoot "boot.wim"
New-Dir $runRoot
New-Dir $mountDir
$script:LogPath = Join-Path $runRoot "verify.log"

$issues = New-Object 'System.Collections.Generic.List[string]'
$result = [ordered]@{
  status = "verifying"
  bootWimPath = $BootWimPath
  runRoot = $runRoot
  logPath = $script:LogPath
}

Copy-Item -LiteralPath $BootWimPath -Destination $copyPath -Force
Log ("Mounting boot.wim copy for worker verification: " + $copyPath)

try {
  Invoke-CliStrict -FilePath "dism.exe" -ArgumentList @("/Mount-Image", "/ImageFile:$copyPath", "/Index:1", "/MountDir:$mountDir", "/ReadOnly")

  $startnetPath = Join-Path $mountDir "Windows\System32\startnet.cmd"
  $launchPath = Join-Path $mountDir "Windows\System32\soty-launch.cmd"
  $winpeshlPath = Join-Path $mountDir "Windows\System32\winpeshl.ini"

  $startnet = if (Test-Path -LiteralPath $startnetPath) { Get-Content -LiteralPath $startnetPath -Raw } else { "" }
  $launch = if (Test-Path -LiteralPath $launchPath) { Get-Content -LiteralPath $launchPath -Raw } else { "" }
  $winpeshl = if (Test-Path -LiteralPath $winpeshlPath) { Get-Content -LiteralPath $winpeshlPath -Raw } else { "" }

  $hasWorkerReference = $startnet -match 'Soty-Reinstall\\reinstall\\winre-reinstall\.cmd'
  $hasArmedFlagReference = $startnet -match 'armed\.flag'
  $hasLaunchWrapper = $launch -match 'startnet\.cmd'
  $hasWinpeshlWrapper = $winpeshl -match 'soty-launch\.cmd'

  $result.startnetPath = $startnetPath
  $result.launchPath = $launchPath
  $result.winpeshlPath = $winpeshlPath
  $result.hasWorkerReference = $hasWorkerReference
  $result.hasArmedFlagReference = $hasArmedFlagReference
  $result.hasLaunchWrapper = $hasLaunchWrapper
  $result.hasWinpeshlWrapper = $hasWinpeshlWrapper

  if (-not (Test-Path -LiteralPath $startnetPath)) {
    $issues.Add("Missing Windows\\System32\\startnet.cmd") | Out-Null
  }
  if (-not $hasWorkerReference) {
    $issues.Add("startnet.cmd does not reference the Soty worker script") | Out-Null
  }
  if (-not $hasArmedFlagReference) {
    $issues.Add("startnet.cmd does not guard on armed.flag") | Out-Null
  }
  if (-not (Test-Path -LiteralPath $launchPath)) {
    $issues.Add("Missing Windows\\System32\\soty-launch.cmd") | Out-Null
  }
  if (-not $hasLaunchWrapper) {
    $issues.Add("soty-launch.cmd does not delegate to startnet.cmd") | Out-Null
  }
  if (-not (Test-Path -LiteralPath $winpeshlPath)) {
    $issues.Add("Missing Windows\\System32\\winpeshl.ini") | Out-Null
  }
  if (-not $hasWinpeshlWrapper) {
    $issues.Add("winpeshl.ini does not launch soty-launch.cmd") | Out-Null
  }

  if ($issues.Count -gt 0) {
    $result.status = "failed"
    $result.issues = @($issues.ToArray())
    Save-Json -Path (Join-Path $runRoot "result.json") -Value $result
    throw ("Boot WIM is not worker-ready." + [Environment]::NewLine + (($issues.ToArray()) -join [Environment]::NewLine))
  }

  $result.status = "ok"
  Save-Json -Path (Join-Path $runRoot "result.json") -Value $result
  Log "Boot WIM worker verification passed."
  Write-Output ("CUSTOM_BOOTWIM_VERIFY_RESULT=" + (Join-Path $runRoot "result.json"))
} finally {
  try {
    & dism.exe /Unmount-Image "/MountDir:$mountDir" /Discard | Out-Null
  } catch {}
  Remove-Item -LiteralPath $mountDir -Recurse -Force -ErrorAction SilentlyContinue
}
