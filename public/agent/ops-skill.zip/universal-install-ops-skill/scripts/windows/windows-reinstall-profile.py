from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))

from skill_paths import skill_root as find_skill_root

PRIVATE_IPV4_RE = re.compile(
    r"\b(?:10(?:\.\d{1,3}){3}|127(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})\b"
)
MAC_RE = re.compile(r"\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b")
PRIVATE_PATH_RE = re.compile(
    r"(?:\b[A-Za-z]:\\+(?:Users|Documents and Settings)\\+[^|\s]+|(?:^|[\s=])(?:~[/\\]|/(?:home|Users)/)[^|\s]+|\\{2,}[^\\\s|]+\\+[^|\s]+)",
    re.IGNORECASE,
)
GATE_CHOICES = ("unknown", "proven", "blocked", "na")
DOCTOR_GATES = (
    ("exact_target", "exact target/device profile", "Prove the exact target identity or store a sanitized device profile."),
    ("data_boundary", "data boundary or backup", "Decide what may be erased and where personal-file backup proof lives."),
    ("trusted_media", "trusted official media or worker", "Use prepared official media, a verified mounted ISO, or a proven worker image."),
    ("bitlocker_safe", "BitLocker state safe", "Check BitLocker status and recovery-key safety before reboot or wipe."),
    ("return_path_proven", "control plane or return path", "Prove machine-scope Soty Worker, SSH return, out-of-band console, or local operator path."),
    ("machine_worker", "managed machine worker", "Install or verify the elevated worker/handoff that can survive the destructive phase."),
    ("operator_handoff", "operator handoff", "State the one physical operator action or confirm no operator is required."),
    ("destructive_confirmation", "explicit destructive confirmation", "Collect the exact confirmation phrase before any wipe, reset, BCD arm, or reboot-to-recovery action."),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Store or read a sanitized Windows reinstall route profile.")
    parser.add_argument("--action", choices=["upsert", "get", "summary", "doctor"], default="summary")
    parser.add_argument("--profile-id", default="", help="Sanitized stable profile id, not a private hostname.")
    parser.add_argument("--device-family", default="")
    parser.add_argument("--control-plane", default="")
    parser.add_argument("--return-path", default="")
    parser.add_argument("--media-state", default="")
    parser.add_argument("--working-route", default="")
    parser.add_argument("--proof", default="")
    parser.add_argument("--exact-target", choices=GATE_CHOICES, default="unknown")
    parser.add_argument("--data-boundary", choices=GATE_CHOICES, default="unknown")
    parser.add_argument("--trusted-media", choices=GATE_CHOICES, default="unknown")
    parser.add_argument("--bitlocker-safe", choices=GATE_CHOICES, default="unknown")
    parser.add_argument("--return-path-proven", choices=GATE_CHOICES, default="unknown")
    parser.add_argument("--machine-worker", choices=GATE_CHOICES, default="unknown")
    parser.add_argument("--operator-handoff", choices=GATE_CHOICES, default="unknown")
    parser.add_argument("--destructive-confirmation", choices=GATE_CHOICES, default="unknown")
    parser.add_argument("--store", default="", help="Override JSONL store path.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def skill_root() -> Path:
    return find_skill_root(__file__).resolve()


def default_store() -> Path:
    return skill_root() / ".skill-memory" / "windows-reinstall-profiles.jsonl"


def store_path(raw: str) -> Path:
    return Path(raw).expanduser().resolve() if raw.strip() else default_store()


def compact(value: str) -> str:
    return " ".join(value.strip().split())


def reject_sensitive(value: str) -> None:
    text = compact(value)
    if not text:
        return
    for pattern, label in [
        (PRIVATE_IPV4_RE, "private IPv4 address"),
        (MAC_RE, "MAC address"),
        (PRIVATE_PATH_RE, "private path"),
    ]:
        match = pattern.search(text)
        if match:
            raise ValueError(f"refusing private {label}: {match.group(0)}")


def validate_profile_id(value: str) -> str:
    profile_id = compact(value)
    if not profile_id:
        raise ValueError("--profile-id is required for upsert/get")
    reject_sensitive(profile_id)
    if not re.fullmatch(r"[A-Za-z0-9_.+-]{2,80}", profile_id):
        raise ValueError("profile id must be 2-80 chars: letters, digits, dot, underscore, plus, or hyphen")
    return profile_id


def read_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict):
            rows.append(row)
    return rows


def append_row(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True))
        handle.write("\n")


def latest_by_profile(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for row in rows:
        profile_id = str(row.get("profile_id", ""))
        if profile_id:
            latest[profile_id] = row
    return latest


def build_profile(args: argparse.Namespace) -> dict[str, Any]:
    profile_id = validate_profile_id(args.profile_id)
    fields = {
        "device_family": compact(args.device_family),
        "control_plane": compact(args.control_plane),
        "return_path": compact(args.return_path),
        "media_state": compact(args.media_state),
        "working_route": compact(args.working_route),
        "proof": compact(args.proof),
    }
    for key, value in fields.items():
        if not value:
            raise ValueError(f"--{key.replace('_', '-')} is required for upsert")
        reject_sensitive(value)
    return {"updated_at": now_utc(), "profile_id": profile_id, **fields}


def inferred_gate(args: argparse.Namespace, profile: dict[str, Any] | None, name: str) -> str:
    value = str(getattr(args, name))
    if value != "unknown":
        return value
    if name == "exact_target" and profile:
        return "proven"
    return "unknown"


def gate_passes(name: str, value: str) -> bool:
    if value == "proven":
        return True
    return name in {"bitlocker_safe", "machine_worker", "operator_handoff"} and value == "na"


def build_doctor(args: argparse.Namespace, latest: dict[str, dict[str, Any]], path: Path) -> dict[str, Any]:
    profile_id = ""
    profile = None
    if compact(args.profile_id):
        profile_id = validate_profile_id(args.profile_id)
        profile = latest.get(profile_id)
    gates = {
        name: {
            "label": label,
            "state": inferred_gate(args, profile, name),
            "next": next_step,
        }
        for name, label, next_step in DOCTOR_GATES
    }
    missing = [
        {"gate": name, **gate}
        for name, gate in gates.items()
        if not gate_passes(name, str(gate["state"]))
    ]
    blocked = [item for item in missing if item["state"] == "blocked"]
    high_risk_names = {"data_boundary", "trusted_media", "bitlocker_safe", "return_path_proven", "machine_worker"}
    high_risk_blocked = any(item["gate"] in high_risk_names and item["state"] == "blocked" for item in blocked)
    lane = "fast_lane" if not missing else ("recovery_or_risky" if high_risk_blocked else "readiness_building")
    first_missing = missing[0] if missing else None
    if lane == "fast_lane":
        route = compact(str(profile.get("working_route", ""))) if profile else "the proven route"
        next_action = f"Use one proven start command/operator action from {route}; do not branch into new scripts."
    else:
        next_action = (
            f"Stop before destructive work. Next prove: {first_missing['label']}. {first_missing['next']}"
            if first_missing
            else "Stop before destructive work and refresh the case profile."
        )
    return {
        "action": "doctor",
        "store": str(path),
        "profile_id": profile_id,
        "profile_found": profile is not None,
        "lane": lane,
        "gates": gates,
        "missing_gates": missing,
        "next_action": next_action,
        "ok": lane == "fast_lane",
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    path = store_path(args.store)
    rows = read_rows(path)
    latest = latest_by_profile(rows)
    if args.action == "upsert":
        row = build_profile(args)
        append_row(path, row)
        latest[row["profile_id"]] = row
        return {"action": "upsert", "store": str(path), "profile": row, "profile_count": len(latest), "ok": True}
    if args.action == "get":
        profile_id = validate_profile_id(args.profile_id)
        profile = latest.get(profile_id)
        return {"action": "get", "store": str(path), "profile": profile, "found": profile is not None, "ok": profile is not None}
    if args.action == "doctor":
        return build_doctor(args, latest, path)
    return {
        "action": "summary",
        "store": str(path),
        "profile_count": len(latest),
        "profiles": sorted(latest.values(), key=lambda item: str(item.get("profile_id", ""))),
        "ok": True,
    }


def print_text(report: dict[str, Any]) -> None:
    print("Windows Reinstall Profiles")
    print(f"- action: {report['action']}")
    print(f"- store: {report['store']}")
    if report["action"] == "summary":
        print(f"- profile_count: {report['profile_count']}")
        for profile in report["profiles"]:
            print(f"  - {profile['profile_id']}: route={profile['working_route']} proof={profile['proof']}")
    elif report["action"] == "get":
        print(f"- found: {report['found']}")
        if report["profile"]:
            print(f"- profile: {json.dumps(report['profile'], ensure_ascii=False, sort_keys=True)}")
    elif report["action"] == "doctor":
        print(f"- lane: {report['lane']}")
        print(f"- profile_found: {report['profile_found']}")
        if report["missing_gates"]:
            print("- missing_gates:")
            for item in report["missing_gates"]:
                print(f"  - {item['gate']}: {item['state']} ({item['label']})")
        else:
            print("- missing_gates: none")
        print(f"- next_action: {report['next_action']}")
    else:
        print(f"- profile_id: {report['profile']['profile_id']}")
        print(f"- profile_count: {report['profile_count']}")


def main() -> int:
    args = parse_args()
    try:
        report = run(args)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
