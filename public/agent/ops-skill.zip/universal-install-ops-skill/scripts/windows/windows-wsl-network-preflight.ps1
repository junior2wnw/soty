param(
    [string]$Distro = "Ubuntu-24.04",
    [string]$LogPath = "",
    [string[]]$Urls = @(
        "https://github.com",
        "https://gitlab.com",
        "https://gitlab.postmarketos.org",
        "https://docs.postmarketos.org",
        "http://archive.ubuntu.com/ubuntu",
        "https://archive.ubuntu.com/ubuntu"
    )
)

$ErrorActionPreference = "Continue"
$lines = [System.Collections.Generic.List[string]]::new()

function Add-Line {
    param([string]$Text = "")
    $lines.Add($Text) | Out-Null
}

Add-Line "# WSL network preflight"
Add-Line "timestamp: $(Get-Date -Format o)"
Add-Line "distro: $Distro"
Add-Line

Add-Line "## Windows adapters"
Get-NetIPInterface |
    Sort-Object InterfaceMetric |
    Select-Object InterfaceAlias, AddressFamily, InterfaceMetric, Dhcp, ConnectionState |
    Format-Table -AutoSize |
    Out-String -Width 240 |
    ForEach-Object { Add-Line $_.TrimEnd() }

Add-Line "## Windows source reachability"
foreach ($url in $Urls) {
    $uri = [Uri]$url
    $port = if ($uri.Scheme -eq "http") { 80 } else { 443 }
    Add-Line "### $url"
    try {
        $test = Test-NetConnection -ComputerName $uri.Host -Port $port -WarningAction SilentlyContinue
        Add-Line "remote: $($test.RemoteAddress):$port"
        Add-Line "interface: $($test.InterfaceAlias)"
        $source = $test.SourceAddress
        if ($source -and $source.PSObject.Properties.Name -contains "IPAddress") {
            $source = $source.IPAddress
        }
        Add-Line "source: $source"
        Add-Line "tcp: $($test.TcpTestSucceeded)"
    } catch {
        Add-Line "error: $($_.Exception.Message)"
    }
}

Add-Line
Add-Line "## WSL status"
try {
    wsl --status 2>&1 | ForEach-Object { Add-Line ([string]$_) }
} catch {
    Add-Line "wsl status error: $($_.Exception.Message)"
}

Add-Line
Add-Line "## WSL route and DNS"
try {
    wsl -d $Distro -- bash -lc 'set +e; ip route; echo "--- resolv.conf"; tr -d "\000" < /etc/resolv.conf; echo "--- ip addr"; ip addr show eth0' 2>&1 |
        ForEach-Object { Add-Line ([string]$_) }
} catch {
    Add-Line "wsl route error: $($_.Exception.Message)"
}

Add-Line
Add-Line "## WSL URL checks"
foreach ($url in $Urls) {
    Add-Line "### $url"
    $escaped = $url.Replace("'", "'\''")
    try {
        wsl -d $Distro -- bash -lc "curl -I -L --connect-timeout 5 --max-time 15 '$escaped' 2>&1 | sed -n '1,12p'" 2>&1 |
            ForEach-Object { Add-Line ([string]$_) }
    } catch {
        Add-Line "wsl curl error: $($_.Exception.Message)"
    }
}

if ($LogPath) {
    $parent = Split-Path -Parent $LogPath
    if ($parent) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }
    Set-Content -Path $LogPath -Value $lines -Encoding utf8
}

$lines -join [Environment]::NewLine
