param(
  [string] $UsbDriveLetter = "E",
  [string] $ControllerPublicKeyPath = "",
  [string] $ControllerAuthorizedKeysPath = "",
  [string] $SkillRoot = ""
)

$ErrorActionPreference = "Stop"

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Resolve-SkillRoot([string] $Hint) {
  if (-not [string]::IsNullOrWhiteSpace($Hint)) {
    return $Hint
  }
  return (Split-Path -Parent $PSScriptRoot)
}

function Resolve-UsbRoot([string] $DriveLetter) {
  $letter = $DriveLetter.TrimEnd(":").ToUpperInvariant()
  $root = $letter + ":\"
  if (-not (Test-Path -LiteralPath $root)) {
    throw "USB drive $root not found."
  }
  return $root
}

function Resolve-KeyMaterial([string] $AuthorizedKeysPath, [string] $PublicKeyPath) {
  if (-not [string]::IsNullOrWhiteSpace($AuthorizedKeysPath) -and (Test-Path -LiteralPath $AuthorizedKeysPath)) {
    return (Get-Content -LiteralPath $AuthorizedKeysPath -Raw)
  }
  if (-not [string]::IsNullOrWhiteSpace($PublicKeyPath) -and (Test-Path -LiteralPath $PublicKeyPath)) {
    return ((Get-Content -LiteralPath $PublicKeyPath -Raw).Trim() + [Environment]::NewLine)
  }
  $defaultPub = Join-Path $env:USERPROFILE ".ssh\id_ed25519.pub"
  if (Test-Path -LiteralPath $defaultPub) {
    return ((Get-Content -LiteralPath $defaultPub -Raw).Trim() + [Environment]::NewLine)
  }
  throw "No controller public key was found."
}

function Copy-ItemStrict([string] $Source, [string] $Destination) {
  if (-not (Test-Path -LiteralPath $Source)) {
    throw "Source file not found: $Source"
  }
  Copy-Item -LiteralPath $Source -Destination $Destination -Force
}

$resolvedSkillRoot = Resolve-SkillRoot $SkillRoot
$usbRoot = Resolve-UsbRoot $UsbDriveLetter
$bundleRoot = Join-Path $usbRoot "Soty-Reinstall"
$recoveryRoot = Join-Path $bundleRoot "recovery"
$payloadRoot = Join-Path $bundleRoot "payload"
$resultsRoot = Join-Path $bundleRoot "results"
$backupProgramDataRoot = Join-Path $bundleRoot "backup\ssh\programdata_ssh"

foreach ($path in @($bundleRoot, $recoveryRoot, $payloadRoot, $resultsRoot, $backupProgramDataRoot)) {
  New-Dir $path
}

$keyMaterial = Resolve-KeyMaterial -AuthorizedKeysPath $ControllerAuthorizedKeysPath -PublicKeyPath $ControllerPublicKeyPath
$controllerKeysPath = Join-Path $payloadRoot "controller-authorized_keys"
$adminAuthorizedKeysBackup = Join-Path $backupProgramDataRoot "administrators_authorized_keys"

Set-Content -LiteralPath $controllerKeysPath -Value $keyMaterial -Encoding ASCII
Set-Content -LiteralPath $adminAuthorizedKeysBackup -Value $keyMaterial -Encoding ASCII

$recoveryScript = Join-Path $resolvedSkillRoot "scripts\windows\windows-usb-diagnose-and-open-ssh.ps1"
$repairScript = Join-Path $resolvedSkillRoot "scripts\windows\windows-repair-ssh-return-path.ps1"
$stageScript = Join-Path $resolvedSkillRoot "scripts\windows\windows-stage-bundle.ps1"
$launcherTemplate = Join-Path $resolvedSkillRoot "scripts\windows\windows-usb-run-on-laptop.cmd"

Copy-ItemStrict -Source $recoveryScript -Destination (Join-Path $recoveryRoot "windows-usb-diagnose-and-open-ssh.ps1")
Copy-ItemStrict -Source $repairScript -Destination (Join-Path $recoveryRoot "windows-repair-ssh-return-path.ps1")
Copy-ItemStrict -Source $stageScript -Destination (Join-Path $recoveryRoot "windows-stage-bundle.ps1")
Copy-ItemStrict -Source $launcherTemplate -Destination (Join-Path $usbRoot "RUN-ON-LAPTOP.cmd")

$manifest = [ordered]@{
  createdAt = (Get-Date).ToString("o")
  usbRoot = $usbRoot
  bundleRoot = $bundleRoot
  controllerPublicKeyPath = if ([string]::IsNullOrWhiteSpace($ControllerPublicKeyPath)) { $null } else { $ControllerPublicKeyPath }
  controllerAuthorizedKeysPath = if ([string]::IsNullOrWhiteSpace($ControllerAuthorizedKeysPath)) { $null } else { $ControllerAuthorizedKeysPath }
  launcher = (Join-Path $usbRoot "RUN-ON-LAPTOP.cmd")
  recoveryScript = (Join-Path $recoveryRoot "windows-usb-diagnose-and-open-ssh.ps1")
}

Set-Content -LiteralPath (Join-Path $bundleRoot "bundle-manifest.json") -Value ($manifest | ConvertTo-Json -Depth 12) -Encoding UTF8

Write-Output ("USB_RECOVERY_BUNDLE_READY=" + (Join-Path $usbRoot "RUN-ON-LAPTOP.cmd"))
