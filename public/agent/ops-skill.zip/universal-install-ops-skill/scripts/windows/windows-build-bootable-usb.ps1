param(
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string] $StageBundleRoot = "",
  [string] $UsbDriveLetter = "D",
  [string] $UsbLabel = "SOTYWIN",
  [string] $SourceMediaRoot = "",
  [string] $ComputerName = "",
  [string] $ManagedUserName = "Soty",
  [string] $ManagedUserPassword = "",
  [string] $PanelSiteUrl = "https://xn--n1afe0b.online",
  [string] $PanelSiteFallbackIp = "95.105.53.126",
  [string] $PanelSiteFallbackHost = "xn--n1afe0b.online",
  [string] $UsbFileSystem = "Auto",
  [string] $InstallImageLayout = "Auto"
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  if ($Path.Trim() -match '^[A-Za-z]:\\?$') {
    return
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Invoke-Cli {
  param(
    [string] $FilePath,
    [string[]] $ArgumentList
  )

  & $FilePath @ArgumentList | Out-Null
  if ($LASTEXITCODE -ne 0) {
    throw ($FilePath + " failed with exit code " + $LASTEXITCODE)
  }
}

function Invoke-Robocopy {
  param(
    [string] $Source,
    [string] $Destination
  )

  New-Dir $Destination
  & robocopy.exe $Source $Destination /E /ZB /R:1 /W:1 /FFT /NFL /NDL /NJH /NJS /NP /XJ /COPY:DAT /XD "System Volume Information" "`$RECYCLE.BIN" | Out-Null
  if ($LASTEXITCODE -ge 8) {
    throw ("robocopy failed for " + $Source + " -> " + $Destination + " with exit code " + $LASTEXITCODE)
  }
}

function Copy-ItemWithRetry {
  param(
    [string] $SourcePath,
    [string] $DestinationPath,
    [int] $Attempts = 20,
    [int] $DelaySeconds = 2
  )

  $destinationParent = Split-Path -Parent $DestinationPath
  $destinationQualifier = Split-Path -Qualifier $DestinationPath
  $destinationDriveLetter = if ([string]::IsNullOrWhiteSpace($destinationQualifier)) { $null } else { $destinationQualifier.TrimEnd(":\") }
  $lastError = $null

  for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
    try {
      if ($destinationDriveLetter) {
        Wait-DriveReady -DriveLetter $destinationDriveLetter
      }
      if (-not [string]::IsNullOrWhiteSpace($destinationParent)) {
        New-Dir $destinationParent
      }
      Remove-Item -LiteralPath $DestinationPath -Force -ErrorAction SilentlyContinue
      Copy-Item -LiteralPath $SourcePath -Destination $DestinationPath -Force -ErrorAction Stop
      return
    } catch {
      $lastError = $_
      Remove-Item -LiteralPath $DestinationPath -Force -ErrorAction SilentlyContinue
      if ($attempt -lt $Attempts) {
        Log ("Retrying file copy (" + $attempt + "/" + $Attempts + "): " + $SourcePath + " -> " + $DestinationPath + " :: " + $_.Exception.Message)
        Start-Sleep -Seconds $DelaySeconds
      }
    }
  }

  if ($lastError) {
    throw $lastError
  }
  throw ("Copy-ItemWithRetry failed for " + $SourcePath + " -> " + $DestinationPath)
}

function Wait-DriveReady {
  param(
    [string] $DriveLetter,
    [int] $Attempts = 60,
    [int] $DelaySeconds = 2
  )

  $normalizedLetter = $DriveLetter.TrimEnd(":").ToUpperInvariant()
  $root = $normalizedLetter + ":\"
  $lastError = $null

  for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
    try {
      $null = Get-PSDrive -Name $normalizedLetter -PSProvider FileSystem -ErrorAction Stop
      if (Test-Path -LiteralPath $root) {
        $probePath = Join-Path $root (".soty-probe-" + [Guid]::NewGuid().ToString("N") + ".tmp")
        Set-Content -LiteralPath $probePath -Value "ready" -Encoding ASCII -ErrorAction Stop
        Remove-Item -LiteralPath $probePath -Force -ErrorAction SilentlyContinue
        return
      }
    } catch {
      $lastError = $_
    }
    Start-Sleep -Seconds $DelaySeconds
  }

  if ($lastError) {
    throw ("Drive " + $normalizedLetter + ": is not ready after format. " + $lastError.Exception.Message)
  }
  throw ("Drive " + $normalizedLetter + ": is not ready after format.")
}

function Assert-RemovableLikeTargetDrive {
  param(
    [string] $DriveLetter
  )

  $normalizedLetter = $DriveLetter.TrimEnd(":").ToUpperInvariant()
  $systemLetter = $env:SystemDrive.TrimEnd(":").ToUpperInvariant()
  if ($normalizedLetter -eq $systemLetter) {
    throw ("Refusing to use the system drive " + $normalizedLetter + ": as the reinstall USB target.")
  }

  $driveInfo = [System.IO.DriveInfo]::new($normalizedLetter + ":\")
  if ($driveInfo.DriveType -ne [System.IO.DriveType]::Removable) {
    throw ("Target drive " + $normalizedLetter + ": is not removable-like. DriveType=" + $driveInfo.DriveType)
  }
}

function Get-VolumeInfoText {
  param(
    [string] $DriveLetter
  )

  $normalizedLetter = $DriveLetter.TrimEnd(":").ToUpperInvariant()
  $output = & cmd.exe /c ("fsutil fsinfo volumeinfo " + $normalizedLetter + ":") 2>&1
  if ($LASTEXITCODE -ne 0) {
    throw ("fsutil volumeinfo failed for " + $normalizedLetter + ": " + (($output | ForEach-Object { $_.ToString() }) -join " | "))
  }
  return (($output | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine)
}

function Clear-UsbRootContents {
  param(
    [string] $DriveLetter
  )

  $normalizedLetter = $DriveLetter.TrimEnd(":").ToUpperInvariant()
  $root = $normalizedLetter + ":\"
  foreach ($item in @(Get-ChildItem -LiteralPath $root -Force -ErrorAction Stop)) {
    if ($item.Name -in @("System Volume Information", '$RECYCLE.BIN')) {
      continue
    }
    Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction Stop
  }
}

function Resolve-UsbFileSystem {
  param(
    [string] $DriveLetter,
    [string] $Mode
  )

  $normalizedLetter = $DriveLetter.TrimEnd(":").ToUpperInvariant()
  $current = ""
  try {
    $volume = Get-Volume -DriveLetter $normalizedLetter -ErrorAction Stop
    $current = [string]$volume.FileSystem
  } catch {}

  if ([string]::IsNullOrWhiteSpace($Mode) -or $Mode -ieq "Auto") {
    if (-not [string]::IsNullOrWhiteSpace($current)) {
      return $current
    }
    return "FAT32"
  }
  if ($Mode -ieq "Preserve") {
    if ([string]::IsNullOrWhiteSpace($current)) {
      throw ("Cannot preserve unknown USB filesystem on " + $normalizedLetter + ":")
    }
    return $current
  }

  return $Mode
}

function Test-FileSystemLikelySupportsLargeFiles {
  param(
    [string] $FileSystem
  )

  $normalized = ([string]$FileSystem).Trim().ToUpperInvariant()
  if ($normalized -match '^FAT(12|16|32)?$') {
    return $false
  }
  return $true
}

function Resolve-InstallImageLayout {
  param(
    [string] $Mode,
    [string] $TargetFileSystem
  )

  if ([string]::IsNullOrWhiteSpace($Mode) -or $Mode -ieq "Auto") {
    if (Test-FileSystemLikelySupportsLargeFiles -FileSystem $TargetFileSystem) {
      return "Direct"
    }
    return "Split"
  }
  if ($Mode -ieq "Direct" -or $Mode -ieq "Split") {
    return (Get-Culture).TextInfo.ToTitleCase($Mode.ToLowerInvariant())
  }
  throw ("Unsupported InstallImageLayout '" + $Mode + "'. Use Auto, Direct, or Split.")
}

function Set-DriveLabel {
  param(
    [string] $DriveLetter,
    [string] $Label
  )

  $normalizedLetter = $DriveLetter.TrimEnd(":").ToUpperInvariant()
  if ([string]::IsNullOrWhiteSpace($Label)) {
    return
  }

  & cmd.exe /c ("label " + $normalizedLetter + ": " + $Label) | Out-Null
  if ($LASTEXITCODE -ne 0) {
    throw ("Failed to set volume label on " + $normalizedLetter + ":")
  }
}

function Get-AssertCustomBootWimScriptPath {
  $candidate = Join-Path $PSScriptRoot "windows-assert-custom-winpe-worker.ps1"
  if (Test-Path -LiteralPath $candidate) {
    return $candidate
  }
  return $null
}

function Get-LatestStageBundleRoot([string] $Root) {
  $bundleRoot = Join-Path $Root "stage-bundles"
  $latest = Get-ChildItem -LiteralPath $bundleRoot -Directory -ErrorAction Stop | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (-not $latest) {
    throw "No stage bundle run root exists under $bundleRoot."
  }
  return $latest.FullName
}

function Escape-Xml([string] $Value) {
  return [System.Security.SecurityElement]::Escape($Value)
}

function Write-UnattendXml {
  param(
    [string] $Path,
    [string] $UserName,
    [string] $Password,
    [string] $ComputerNameValue
  )

  $u = Escape-Xml $UserName
  $p = Escape-Xml $Password
  $c = Escape-Xml $ComputerNameValue
  $content = @"
<?xml version="1.0" encoding="utf-8"?>
<unattend xmlns="urn:schemas-microsoft-com:unattend" xmlns:wcm="http://schemas.microsoft.com/WMIConfig/2002/State">
  <settings pass="specialize">
    <component name="Microsoft-Windows-Shell-Setup" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS">
      <ComputerName>$c</ComputerName>
      <TimeZone>Ekaterinburg Standard Time</TimeZone>
    </component>
  </settings>
  <settings pass="oobeSystem">
    <component name="Microsoft-Windows-International-Core" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS">
      <InputLocale>ru-RU</InputLocale>
      <SystemLocale>ru-RU</SystemLocale>
      <UILanguage>ru-RU</UILanguage>
      <UserLocale>ru-RU</UserLocale>
    </component>
    <component name="Microsoft-Windows-Shell-Setup" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS">
      <AutoLogon>
        <Password>
          <Value>$p</Value>
          <PlainText>true</PlainText>
        </Password>
        <Enabled>true</Enabled>
        <LogonCount>1</LogonCount>
        <Username>$u</Username>
      </AutoLogon>
      <OOBE>
        <HideEULAPage>true</HideEULAPage>
        <HideLocalAccountScreen>true</HideLocalAccountScreen>
        <HideOEMRegistrationScreen>true</HideOEMRegistrationScreen>
        <HideOnlineAccountScreens>true</HideOnlineAccountScreens>
        <HideWirelessSetupInOOBE>true</HideWirelessSetupInOOBE>
        <NetworkLocation>Home</NetworkLocation>
        <ProtectYourPC>3</ProtectYourPC>
      </OOBE>
      <UserAccounts>
        <LocalAccounts>
          <LocalAccount wcm:action="add">
            <Password>
              <Value>$p</Value>
              <PlainText>true</PlainText>
            </Password>
            <Description>Soty recovery operator</Description>
            <DisplayName>$u</DisplayName>
            <Group>Administrators</Group>
            <Name>$u</Name>
          </LocalAccount>
        </LocalAccounts>
      </UserAccounts>
      <FirstLogonCommands>
        <SynchronousCommand wcm:action="add">
          <Order>1</Order>
          <Description>Soty first logon restore</Description>
          <CommandLine>cmd.exe /c C:\ProgramData\Soty\WindowsReinstall\restore\soty-firstlogon.cmd</CommandLine>
        </SynchronousCommand>
      </FirstLogonCommands>
    </component>
  </settings>
</unattend>
"@
  Set-Content -LiteralPath $Path -Value $content -Encoding UTF8
}

function Write-WinreStartnetCmd {
  param(
    [string] $Path
  )

  $content = @'
@echo off
setlocal enableextensions enabledelayedexpansion
set INTERNALROOT=
set TARGETROOT=
for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%d:\Soty-Boot\boot.wim" set "INTERNALROOT=%%d:\Soty-Boot"
  if exist "%%d:\Soty-Reinstall-Target.marker" set "TARGETROOT=%%d:"
)
if not exist X:\Soty mkdir X:\Soty >nul 2>nul
set LOG_PATH=X:\Soty\soty-startnet.log
if defined INTERNALROOT (
  if not exist "%INTERNALROOT%\logs" mkdir "%INTERNALROOT%\logs" >nul 2>nul
  set LOG_PATH=%INTERNALROOT%\logs\startnet.log
)
if not defined INTERNALROOT if defined TARGETROOT (
  if not exist "%TARGETROOT%\ProgramData\Soty\WindowsReinstall\logs" mkdir "%TARGETROOT%\ProgramData\Soty\WindowsReinstall\logs" >nul 2>nul
  set LOG_PATH=%TARGETROOT%\ProgramData\Soty\WindowsReinstall\logs\winre-startnet.log
)
>>"%LOG_PATH%" echo [%DATE% %TIME%] startnet entered
wpeinit >>"%LOG_PATH%" 2>&1
>>"%LOG_PATH%" echo [%DATE% %TIME%] wpeinit finished
if defined INTERNALROOT >>"%LOG_PATH%" echo [%DATE% %TIME%] internal root found at %INTERNALROOT%
if defined TARGETROOT >>"%LOG_PATH%" echo [%DATE% %TIME%] target root found at %TARGETROOT%
set USBROOT=
for /L %%i in (1,1,120) do (
  set "USBROOT="
  for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%d:\Soty-Reinstall\reinstall\winre-reinstall.cmd" if exist "%%d:\Soty-Reinstall\reinstall\config.cmd" set "USBROOT=%%d:\Soty-Reinstall"
  )
  if defined USBROOT goto usb_found
  >>"%LOG_PATH%" echo [%DATE% %TIME%] probe %%i: usb root not found yet
  timeout /t 2 /nobreak >nul
)
>>"%LOG_PATH%" echo [%DATE% %TIME%] usb root was not found after retries
wpeutil reboot
exit /b 1

:usb_found
>>"%LOG_PATH%" echo [%DATE% %TIME%] usb root found at %USBROOT%
if defined USBROOT (
  if not exist "%USBROOT%\reinstall\logs" mkdir "%USBROOT%\reinstall\logs" >nul 2>nul
  type "%LOG_PATH%" >> "%USBROOT%\reinstall\logs\startnet.log" 2>nul
  set LOG_PATH=%USBROOT%\reinstall\logs\startnet.log
  >>"%LOG_PATH%" echo [%DATE% %TIME%] invoking worker, usbroot=%USBROOT%
  if exist "%USBROOT%\reinstall\armed.flag" (
    call "%USBROOT%\reinstall\winre-reinstall.cmd"
    set WORKER_EXIT=!ERRORLEVEL!
    >>"%LOG_PATH%" echo [%DATE% %TIME%] worker exit code=!WORKER_EXIT!
    exit /b !WORKER_EXIT!
  ) else (
    >>"%LOG_PATH%" echo [%DATE% %TIME%] armed.flag missing, not invoking worker
    wpeutil reboot
    exit /b 1
  )
)
'@

  Set-Content -LiteralPath $Path -Value $content -Encoding ASCII
}

function Write-WinpeLaunchCmd {
  param(
    [string] $Path
  )

  $content = @'
@echo off
call %SYSTEMROOT%\System32\startnet.cmd
exit /b %ERRORLEVEL%
'@

  Set-Content -LiteralPath $Path -Value $content -Encoding ASCII
}

function Write-WinpeshlIni {
  param(
    [string] $Path
  )

  $content = @'
[LaunchApps]
%SYSTEMROOT%\System32\cmd.exe, /c %SYSTEMROOT%\System32\soty-launch.cmd
'@

  Set-Content -LiteralPath $Path -Value $content -Encoding ASCII
}

function Write-SetupCompleteCmd {
  param(
    [string] $Path
  )

  $content = @'
@echo off
setlocal enableextensions
set USBROOT=
for %%d in (D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%d:\Soty-Reinstall\restore\postinstall.ps1" set USBROOT=%%d:\Soty-Reinstall
)
if not defined USBROOT exit /b 1
set RESTORE_LOCAL=C:\ProgramData\Soty\WindowsReinstall\restore
mkdir "%RESTORE_LOCAL%" >nul 2>nul
xcopy "%USBROOT%\restore\*" "%RESTORE_LOCAL%\" /E /I /Y >nul
if not exist "%RESTORE_LOCAL%\postinstall.ps1" exit /b 1
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%RESTORE_LOCAL%\postinstall.ps1"
set RESTORE_EXIT=%ERRORLEVEL%
exit /b %RESTORE_EXIT%
'@

  Set-Content -LiteralPath $Path -Value $content -Encoding ASCII
}

function Write-FirstLogonRestoreScripts {
  param(
    [string] $RestoreRoot,
    [string] $UserName,
    [bool] $ResetPasswordToBlank
  )

  New-Dir $RestoreRoot
  $resetLiteral = if ($ResetPasswordToBlank) { '$true' } else { '$false' }
  $userLiteral = $UserName.Replace("'", "''")
  $cmd = @'
@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0soty-firstlogon.ps1"
exit /b %ERRORLEVEL%
'@
  Set-Content -LiteralPath (Join-Path $RestoreRoot "soty-firstlogon.cmd") -Value $cmd -Encoding ASCII

  $ps = @"
`$ErrorActionPreference = 'Continue'
`$ProgressPreference = 'SilentlyContinue'
`$managedUserName = '$userLiteral'
`$resetPasswordToBlank = $resetLiteral
`$logRoot = 'C:\ProgramData\Soty\WindowsReinstall\logs'
New-Item -ItemType Directory -Force -Path `$logRoot | Out-Null
`$log = Join-Path `$logRoot 'firstlogon.log'
function Log([string]`$Message) { Add-Content -LiteralPath `$log -Value ('[' + (Get-Date).ToString('o') + '] ' + `$Message) -Encoding UTF8 }
Log 'first logon started'
try {
  reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' /v AutoAdminLogon /t REG_SZ /d 0 /f | Out-Null
  reg.exe delete 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' /v DefaultPassword /f | Out-Null
  reg.exe delete 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' /v AutoLogonCount /f | Out-Null
} catch { Log ('autologon cleanup warning: ' + `$_.Exception.Message) }
try {
  `$du = Get-LocalUser -Name 'defaultuser0' -ErrorAction SilentlyContinue
  if (`$du) {
    Disable-LocalUser -Name 'defaultuser0' -ErrorAction SilentlyContinue
    Remove-LocalUser -Name 'defaultuser0' -ErrorAction SilentlyContinue
    Log 'removed defaultuser0'
  }
} catch { Log ('defaultuser0 cleanup warning: ' + `$_.Exception.Message) }
if (`$resetPasswordToBlank) {
  try {
    & net.exe user "`$managedUserName" "" | Out-Null
    Log 'managed user password reset to blank'
  } catch { Log ('managed password cleanup warning: ' + `$_.Exception.Message) }
}
try {
  `$custom = Join-Path `$PSScriptRoot 'firstlogon-custom.ps1'
  if (Test-Path -LiteralPath `$custom) { & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `$custom }
} catch { Log ('custom firstlogon warning: ' + `$_.Exception.ToString()) }
try {
  Start-Process 'msedge.exe' -ArgumentList '--app=https://xn--n1afe0b.online/?pwa=1'
} catch {
  try { Start-Process 'https://xn--n1afe0b.online/?pwa=1' } catch { Log ('PWA launch warning: ' + `$_.Exception.Message) }
}
Log 'first logon finished'
"@
  Set-Content -LiteralPath (Join-Path $RestoreRoot "soty-firstlogon.ps1") -Value $ps -Encoding UTF8
}

function Add-DriversToMountedImage {
  param(
    [string] $MountDir,
    [string] $DriverRoot
  )

  if ([string]::IsNullOrWhiteSpace($DriverRoot) -or -not (Test-Path -LiteralPath $DriverRoot)) {
    return
  }

  $driverInfCount = @(Get-ChildItem -LiteralPath $DriverRoot -Recurse -Filter *.inf -File -ErrorAction SilentlyContinue).Count
  if ($driverInfCount -le 0) {
    return
  }

  Log ("Injecting " + $driverInfCount + " exported driver INF files into the WinPE image.")
  try {
    Invoke-Cli -FilePath "dism.exe" -ArgumentList @("/Image:$MountDir", "/Add-Driver", "/Driver:$DriverRoot", "/Recurse")
  } catch {
    Log ("Warning: WinPE driver injection did not fully complete: " + $_.Exception.Message)
  }
}

function Get-PreferredSetupBootImage {
  param(
    [object[]] $Images
  )

  foreach ($pattern in @(
    "^Microsoft Windows PE \(amd64\)$",
    "^Microsoft Windows PE",
    "^Microsoft Windows Setup \(amd64\)$",
    "^Microsoft Windows Setup",
    "Windows PE",
    "Windows Setup"
  )) {
    $match = $Images | Where-Object { ([string]$_.ImageName) -match $pattern } | Select-Object -First 1
    if ($match) {
      return $match
    }
  }
  return ($Images | Select-Object -First 1)
}

function Copy-SourceMediaLayout {
  param(
    [string] $SourceRoot,
    [string] $DestinationRoot
  )

  foreach ($folderName in @("boot", "EFI")) {
    $sourcePath = Join-Path $SourceRoot $folderName
    if (Test-Path -LiteralPath $sourcePath) {
      Invoke-Robocopy -Source $sourcePath -Destination (Join-Path $DestinationRoot $folderName)
    }
  }

  $destinationSourcesRoot = Join-Path $DestinationRoot "sources"
  New-Dir $destinationSourcesRoot
  $sourceSourcesRoot = Join-Path $SourceRoot "sources"

  foreach ($file in @(Get-ChildItem -LiteralPath $sourceSourcesRoot -File -Force -ErrorAction Stop)) {
    if ($file.Name -match '^install(\..+)?$' -or $file.Name -match '^install\d*\.swm$') {
      continue
    }
    Copy-ItemWithRetry -SourcePath $file.FullName -DestinationPath (Join-Path $destinationSourcesRoot $file.Name)
  }
  foreach ($directory in @(Get-ChildItem -LiteralPath $sourceSourcesRoot -Directory -Force -ErrorAction Stop)) {
    Invoke-Robocopy -Source $directory.FullName -Destination (Join-Path $destinationSourcesRoot $directory.Name)
  }

  foreach ($fileName in @("setup.exe", "autorun.inf", "bootmgr", "bootmgr.efi")) {
    $sourceFile = Join-Path $SourceRoot $fileName
    if (Test-Path -LiteralPath $sourceFile) {
      Copy-ItemWithRetry -SourcePath $sourceFile -DestinationPath (Join-Path $DestinationRoot $fileName)
    }
  }
}

function Promote-WorkerPayloadToUsb {
  param(
    [string] $BackupRoot,
    [string] $RestoreRoot,
    [string] $SetupCompletePath,
    [string] $UsbRoot
  )

  $workerRoot = Join-Path $UsbRoot "Soty-Reinstall"
  $workerBackupRoot = Join-Path $workerRoot "backup"
  $workerRestoreRoot = Join-Path $workerRoot "restore"
  $workerSetupHooksRoot = Join-Path $workerRoot "setup-hooks"

  foreach ($path in @($workerRoot, $workerBackupRoot, $workerRestoreRoot, $workerSetupHooksRoot)) {
    New-Dir $path
  }

  if (Test-Path -LiteralPath $BackupRoot) {
    Invoke-Robocopy -Source $BackupRoot -Destination $workerBackupRoot
  }
  if (Test-Path -LiteralPath $RestoreRoot) {
    Invoke-Robocopy -Source $RestoreRoot -Destination $workerRestoreRoot
  }
  if (Test-Path -LiteralPath $SetupCompletePath) {
    Copy-ItemWithRetry -SourcePath $SetupCompletePath -DestinationPath (Join-Path $workerSetupHooksRoot "setupcomplete.cmd")
  }
}

function Ensure-BcdRamdiskOptions {
  param(
    [string] $StorePath
  )

  & bcdedit.exe /store $StorePath /enum "{ramdiskoptions}" | Out-Null
  if ($LASTEXITCODE -eq 0) {
    return
  }

  $output = & bcdedit.exe /store $StorePath /create "{ramdiskoptions}" /d "Soty Ramdisk Options" 2>&1
  if ($LASTEXITCODE -ne 0) {
    $joined = ($output | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine
    if ($joined -notmatch "already") {
      throw ("Failed to create {ramdiskoptions} in store " + $StorePath + "." + [Environment]::NewLine + $joined)
    }
  }
}

function Invoke-BcdStoreEdit {
  param(
    [string] $StorePath,
    [string[]] $Arguments,
    [int] $Attempts = 10,
    [int] $DelaySeconds = 2
  )

  $lastOutput = @()
  $lastExitCode = 0
  for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
    $lastOutput = & bcdedit.exe /store $StorePath @Arguments 2>&1
    $lastExitCode = $LASTEXITCODE
    if ($lastExitCode -eq 0) {
      return
    }
    if ($attempt -lt $Attempts) {
      Start-Sleep -Seconds $DelaySeconds
    }
  }

  $joined = ($lastOutput | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine
  throw ("bcdedit.exe failed with exit code " + $lastExitCode + "." + [Environment]::NewLine + $joined)
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw "This script must run as Administrator."
}

if ([string]::IsNullOrWhiteSpace($StageBundleRoot)) {
  $StageBundleRoot = Get-LatestStageBundleRoot -Root $WorkspaceRoot
}
if (-not (Test-Path -LiteralPath $StageBundleRoot)) {
  throw "Stage bundle root not found: $StageBundleRoot"
}
if ([string]::IsNullOrWhiteSpace($SourceMediaRoot)) {
  throw "SourceMediaRoot is required. Mount the official Windows 10 ISO and pass its drive root."
}
if (-not (Test-Path -LiteralPath $SourceMediaRoot)) {
  throw "Source media root not found: $SourceMediaRoot"
}

$sourceRoot = (Resolve-Path -LiteralPath $SourceMediaRoot).Path
$sourceBootWimPath = Join-Path $sourceRoot "sources\boot.wim"
if (-not (Test-Path -LiteralPath $sourceBootWimPath)) {
  throw ("Source media root is missing sources\boot.wim: " + $sourceRoot)
}

$sourceInstallPath = $null
$sourceInstallKind = $null
$installSourceRelative = ""
$installSwmRelative = ""
if (Test-Path -LiteralPath (Join-Path $sourceRoot "sources\install.swm")) {
  $sourceInstallPath = Join-Path $sourceRoot "sources\install.swm"
  $sourceInstallKind = "swm"
  $installSourceRelative = "sources\install.swm"
  $installSwmRelative = "sources\install*.swm"
} elseif (Test-Path -LiteralPath (Join-Path $sourceRoot "sources\install.wim")) {
  $sourceInstallPath = Join-Path $sourceRoot "sources\install.wim"
  $sourceInstallKind = "wim"
  $installSourceRelative = "sources\install.wim"
  $installSwmRelative = ""
} elseif (Test-Path -LiteralPath (Join-Path $sourceRoot "sources\install.esd")) {
  $sourceInstallPath = Join-Path $sourceRoot "sources\install.esd"
  $sourceInstallKind = "esd"
  $installSourceRelative = "sources\install.esd"
  $installSwmRelative = ""
} else {
  throw ("Source media root does not contain install.swm, install.wim, or install.esd under sources: " + $sourceRoot)
}

$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$runRoot = Join-Path $WorkspaceRoot ("usb-bootable\" + $runId)
$stageRoot = Join-Path $runRoot "staging"
$logRoot = Join-Path $runRoot "logs"
foreach ($path in @($runRoot, $stageRoot, $logRoot)) {
  New-Dir $path
}
$script:LogPath = Join-Path $logRoot "build.log"

Log ("Using stage bundle root: " + $StageBundleRoot)
Log ("Using source media root: " + $sourceRoot)
Log ("Detected install source kind: " + $sourceInstallKind)

$restoreRoot = Join-Path $StageBundleRoot "restore"
$restoreConfigPath = Join-Path $restoreRoot "restore-config.json"
$setupHooksRoot = Join-Path $runRoot "setup-hooks"
New-Dir $setupHooksRoot
if (-not (Test-Path -LiteralPath $restoreRoot)) {
  throw "Stage bundle restore root is missing. Refusing to fall back to workspace restore because it may contain stale or unsafe postinstall logic."
}

$config = if (Test-Path -LiteralPath $restoreConfigPath) {
  Get-Content -LiteralPath $restoreConfigPath -Raw | ConvertFrom-Json
} else {
  [pscustomobject]@{}
}
$preferredProbeUrls = @(
  ($PanelSiteUrl.TrimEnd("/") + "/api/downloads"),
  "https://xn--n1afe0b.online/api/downloads",
  "https://xn--h1aaocew5a7b.online/api/downloads"
)
$config | Add-Member -NotePropertyName preferredPanelProbeUrls -NotePropertyValue $preferredProbeUrls -Force
$config | Add-Member -NotePropertyName panelSiteUrl -NotePropertyValue $PanelSiteUrl -Force
$config | Add-Member -NotePropertyName hostsEntries -NotePropertyValue @(@{ host = $PanelSiteFallbackHost; ip = $PanelSiteFallbackIp }) -Force
Save-Json -Path $restoreConfigPath -Value $config

$effectiveManagedUserPassword = $ManagedUserPassword
$managedUserPasswordGenerated = $false
if ([string]::IsNullOrEmpty($effectiveManagedUserPassword)) {
  $effectiveManagedUserPassword = "Soty-" + ([Guid]::NewGuid().ToString("N"))
  $managedUserPasswordGenerated = $true
}
Write-FirstLogonRestoreScripts -RestoreRoot $restoreRoot -UserName $ManagedUserName -ResetPasswordToBlank $managedUserPasswordGenerated

$postInstallPath = Join-Path $restoreRoot "postinstall.ps1"
if (Test-Path -LiteralPath $postInstallPath) {
  $postInstallContent = Get-Content -LiteralPath $postInstallPath -Raw
  $postInstallUpdated = [regex]::Replace($postInstallContent, 'ConvertFrom-Json\s+-Depth\s+\d+', 'ConvertFrom-Json')
  if ($postInstallUpdated -ne $postInstallContent) {
    Set-Content -LiteralPath $postInstallPath -Value $postInstallUpdated -Encoding UTF8
  }
}

$bootWimPath = Join-Path $stageRoot "boot.wim"
if (Test-Path -LiteralPath $bootWimPath) {
  Remove-Item -LiteralPath $bootWimPath -Force
}
$bootImages = @(Get-WindowsImage -ImagePath $sourceBootWimPath -ErrorAction Stop)
$setupBootImage = Get-PreferredSetupBootImage -Images $bootImages
if (-not $setupBootImage) {
  throw ("Source media boot.wim does not expose a usable boot image: " + $sourceBootWimPath)
}
$setupBootIndex = [int]$setupBootImage.ImageIndex
Log ("Exporting setup boot image index " + $setupBootIndex + " => " + $setupBootImage.ImageName)
Invoke-Cli -FilePath "dism.exe" -ArgumentList @("/Export-Image", "/SourceImageFile:$sourceBootWimPath", "/SourceIndex:$setupBootIndex", "/DestinationImageFile:$bootWimPath", "/Compress:max", "/CheckIntegrity")

$bootMountDir = Join-Path $stageRoot "mount-boot"
New-Dir $bootMountDir
Log "Injecting custom WinPE launcher into the staged Setup boot.wim."
Invoke-Cli -FilePath "dism.exe" -ArgumentList @("/Mount-Image", "/ImageFile:$bootWimPath", "/Index:1", "/MountDir:$bootMountDir")
try {
  $system32Dir = Join-Path $bootMountDir "Windows\System32"
  Write-WinreStartnetCmd -Path (Join-Path $system32Dir "startnet.cmd")
  Write-WinpeLaunchCmd -Path (Join-Path $system32Dir "soty-launch.cmd")
  Write-WinpeshlIni -Path (Join-Path $system32Dir "winpeshl.ini")
  Add-DriversToMountedImage -MountDir $bootMountDir -DriverRoot (Join-Path $StageBundleRoot "backup\drivers")
} finally {
  Invoke-Cli -FilePath "dism.exe" -ArgumentList @("/Unmount-Image", "/MountDir:$bootMountDir", "/Commit")
}

$usbLetter = $UsbDriveLetter.TrimEnd(":").ToUpperInvariant()
$null = Get-PSDrive -Name $usbLetter -PSProvider FileSystem -ErrorAction Stop
Assert-RemovableLikeTargetDrive -DriveLetter $usbLetter

try {
  $volumeInfoText = Get-VolumeInfoText -DriveLetter $usbLetter
} catch {
  $volumeInfoText = ""
  Log ("Warning: could not inspect current USB filesystem before formatting: " + $_.Exception.Message)
}

$targetUsbFileSystem = Resolve-UsbFileSystem -DriveLetter $usbLetter -Mode $UsbFileSystem
$installImageLayout = Resolve-InstallImageLayout -Mode $InstallImageLayout -TargetFileSystem $targetUsbFileSystem
Log ("Using USB filesystem target " + $targetUsbFileSystem + " (mode=" + $UsbFileSystem + "); install image layout=" + $installImageLayout + ".")

$currentUsbFileSystem = ""
try {
  $currentUsbFileSystem = [string](Get-Volume -DriveLetter $usbLetter -ErrorAction Stop).FileSystem
} catch {}

if (-not [string]::IsNullOrWhiteSpace($currentUsbFileSystem) -and $currentUsbFileSystem -ieq $targetUsbFileSystem) {
  Log ("USB " + $usbLetter + ": is already " + $targetUsbFileSystem + "; clearing existing contents instead of full format.")
  Clear-UsbRootContents -DriveLetter $usbLetter
  try {
    Set-DriveLabel -DriveLetter $usbLetter -Label $UsbLabel
  } catch {
    Log ("Warning: could not refresh USB label on " + $usbLetter + ": " + $_.Exception.Message)
  }
} else {
  Log ("Formatting USB " + $usbLetter + ": as " + $targetUsbFileSystem + " with label " + $UsbLabel)
  Format-Volume -DriveLetter $usbLetter -FileSystem $targetUsbFileSystem -NewFileSystemLabel $UsbLabel -Confirm:$false -Force | Out-Null
}
Log ("Waiting for USB " + $usbLetter + ": to become writable after format.")
Wait-DriveReady -DriveLetter $usbLetter
$usbRoot = $usbLetter + ":\"

Log "Copying official media layout onto the USB."
Copy-SourceMediaLayout -SourceRoot $sourceRoot -DestinationRoot $usbRoot

Log "Replacing USB sources\\boot.wim with the custom worker-aware boot.wim before install image processing."
Copy-ItemWithRetry -SourcePath $bootWimPath -DestinationPath (Join-Path $usbRoot "sources\boot.wim")
$assertBootWimScript = Get-AssertCustomBootWimScriptPath
if (-not [string]::IsNullOrWhiteSpace($assertBootWimScript)) {
  Log "Verifying that USB sources\\boot.wim is worker-ready before arm."
  & $assertBootWimScript -BootWimPath (Join-Path $usbRoot "sources\boot.wim") -WorkspaceRoot $WorkspaceRoot | Out-Null
} else {
  Log "Warning: worker boot.wim verification script is missing next to the builder."
}

$destinationSourcesRoot = Join-Path $usbRoot "sources"
if ($sourceInstallKind -eq "swm") {
  foreach ($swmFile in @(Get-ChildItem -LiteralPath (Join-Path $sourceRoot "sources") -Filter "install*.swm" -File -ErrorAction Stop)) {
    Copy-ItemWithRetry -SourcePath $swmFile.FullName -DestinationPath (Join-Path $destinationSourcesRoot $swmFile.Name)
  }
} elseif ($sourceInstallKind -eq "wim") {
  if ($installImageLayout -eq "Split") {
    $installSourceRelative = "sources\install.swm"
    $installSwmRelative = "sources\install*.swm"
    $splitRoot = Join-Path $stageRoot "split-install"
    New-Dir $splitRoot
    foreach ($existingSplit in @(Get-ChildItem -LiteralPath $splitRoot -Filter "install*.swm" -File -ErrorAction SilentlyContinue)) {
      Remove-Item -LiteralPath $existingSplit.FullName -Force -ErrorAction SilentlyContinue
    }
    Log ("Splitting source install.wim into local install.swm chunks before copying them onto the " + $targetUsbFileSystem + " USB.")
    $splitSwmPath = Join-Path $splitRoot "install.swm"
    & dism.exe /Split-Image "/ImageFile:$sourceInstallPath" "/SWMFile:$splitSwmPath" /FileSize:3800
    if ($LASTEXITCODE -ne 0) {
      throw ("dism.exe failed with exit code " + $LASTEXITCODE)
    }
    foreach ($swmFile in @(Get-ChildItem -LiteralPath $splitRoot -Filter "install*.swm" -File -ErrorAction Stop | Sort-Object Name)) {
      Copy-ItemWithRetry -SourcePath $swmFile.FullName -DestinationPath (Join-Path $destinationSourcesRoot $swmFile.Name)
    }
  } else {
    $installSourceRelative = "sources\install.wim"
    $installSwmRelative = ""
    Log ("Copying source install.wim directly onto the " + $targetUsbFileSystem + " USB.")
    Copy-ItemWithRetry -SourcePath $sourceInstallPath -DestinationPath (Join-Path $destinationSourcesRoot "install.wim")
  }
} else {
  if ($installImageLayout -eq "Split") {
    throw "Source install.esd cannot be split directly. Export a one-index install.wim and let this builder split it, or use a filesystem/layout that supports direct large files."
  }
  Copy-ItemWithRetry -SourcePath $sourceInstallPath -DestinationPath (Join-Path $destinationSourcesRoot "install.esd")
}

foreach ($path in @(
  (Join-Path $usbRoot "boot"),
  (Join-Path $usbRoot "sources"),
  (Join-Path $usbRoot "Soty-Reinstall"),
  (Join-Path $usbRoot "Soty-Reinstall\reinstall"),
  (Join-Path $usbRoot "Soty-Reinstall\logs"),
  (Join-Path $usbRoot "Soty-Reinstall\backup")
)) {
  New-Dir $path
}

if (-not (Test-Path -LiteralPath (Join-Path $usbRoot "EFI\Microsoft\Boot\BCD"))) {
  Log "BCD store missing after media copy; initializing UEFI boot files on the USB with BCDBoot."
  Invoke-Cli -FilePath "bcdboot.exe" -ArgumentList @("C:\Windows", "/s", ($usbLetter + ":"), "/f", "UEFI")
}
if (-not (Test-Path -LiteralPath (Join-Path $usbRoot "boot\boot.sdi"))) {
  Copy-ItemWithRetry -SourcePath "C:\Windows\Boot\DVD\EFI\boot.sdi" -DestinationPath (Join-Path $usbRoot "boot\boot.sdi")
}
Copy-ItemWithRetry -SourcePath $bootWimPath -DestinationPath (Join-Path $usbRoot "sources\boot.wim")

$bcdStore = Join-Path $usbRoot "EFI\Microsoft\Boot\BCD"
try {
  Log ("Repointing USB BCD store to boot WinPE from " + (Join-Path $usbRoot "sources\boot.wim"))
  Start-Sleep -Seconds 3
  Ensure-BcdRamdiskOptions -StorePath $bcdStore
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{ramdiskoptions}", "ramdisksdidevice", "partition=" + $usbLetter + ":")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{ramdiskoptions}", "ramdisksdipath", "\boot\boot.sdi")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "device", "ramdisk=[boot]\sources\boot.wim,{ramdiskoptions}")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "osdevice", "ramdisk=[boot]\sources\boot.wim,{ramdiskoptions}")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "path", "\windows\system32\boot\winload.efi")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "systemroot", "\windows")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "winpe", "yes")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "detecthal", "yes")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "nx", "OptIn")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "description", "Soty WinPE Reinstall")
  Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{bootmgr}", "timeout", "3")
} catch {
  Log ("Warning: USB BCD repoint was skipped: " + $_.Exception.Message)
}

$setupCompletePath = Join-Path $setupHooksRoot "setupcomplete.cmd"
Write-SetupCompleteCmd -Path $setupCompletePath
Log "Promoting backup, restore, and setup hooks to the rebuilt USB workspace."
Promote-WorkerPayloadToUsb -BackupRoot (Join-Path $StageBundleRoot "backup") -RestoreRoot $restoreRoot -SetupCompletePath $setupCompletePath -UsbRoot $usbRoot

$reinstallRoot = Join-Path $usbRoot "Soty-Reinstall\reinstall"
$unattendPath = Join-Path $reinstallRoot "unattend.xml"
$setupCompleteSource = Join-Path $usbRoot "Soty-Reinstall\setup-hooks\setupcomplete.cmd"
$targetComputerName = if ([string]::IsNullOrWhiteSpace($ComputerName)) { $env:COMPUTERNAME } else { $ComputerName }
Write-UnattendXml -Path $unattendPath -UserName $ManagedUserName -Password $effectiveManagedUserPassword -ComputerNameValue $targetComputerName
Set-Content -LiteralPath (Join-Path $reinstallRoot "config.cmd") -Value ("@echo off`r`nset IMAGE_INDEX=1`r`nset INSTALL_SOURCE_REL=" + $installSourceRelative + "`r`nset INSTALL_SWM_REL=" + $installSwmRelative + "`r`n") -Encoding ASCII
Set-Content -LiteralPath (Join-Path $reinstallRoot "winre-reinstall.cmd") -Value @'
@echo off
setlocal enableextensions enabledelayedexpansion
set SCRIPT_ROOT=%~dp0
set LOG_ROOT=%SCRIPT_ROOT%logs
if not exist "%LOG_ROOT%" mkdir "%LOG_ROOT%"
set LOG_PATH=%LOG_ROOT%\winre-reinstall.log
call "%SCRIPT_ROOT%config.cmd"
set FAIL_STEP=
set FAIL_CODE=
echo [%DATE% %TIME%] Worker started.>>"%LOG_PATH%"
if not exist "%SCRIPT_ROOT%armed.flag" (
  echo [%DATE% %TIME%] armed.flag missing, exiting without work.>>"%LOG_PATH%"
  exit /b 0
)
ren "%SCRIPT_ROOT%armed.flag" armed.started >nul 2>nul
echo [%DATE% %TIME%] armed.started created.>>"%LOG_PATH%"
set USBROOT=
set USBDRIVE=
for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%d:\Soty-Reinstall\reinstall\config.cmd" (
    set USBROOT=%%d:\Soty-Reinstall
    set USBDRIVE=%%d:
  )
)
set TARGETDRIVE=
for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%d:\Soty-Reinstall-Target.marker" set TARGETDRIVE=%%d:
)
echo [%DATE% %TIME%] Resolved USBROOT=!USBROOT! USBDRIVE=!USBDRIVE! TARGETDRIVE=!TARGETDRIVE!.>>"%LOG_PATH%"
if not defined USBROOT (
  set FAIL_STEP=resolve-usbroot
  set FAIL_CODE=101
  goto fail
)
if not defined USBDRIVE (
  set FAIL_STEP=resolve-usbdrive
  set FAIL_CODE=102
  goto fail
)
if not defined TARGETDRIVE (
  set FAIL_STEP=resolve-targetdrive
  set FAIL_CODE=103
  goto fail
)
if /I "%TARGETDRIVE%"=="%USBDRIVE%" (
  set FAIL_STEP=targetdrive-is-usbdrive
  set FAIL_CODE=104
  goto fail
)
set INSTALL_SOURCE=%USBDRIVE%\%INSTALL_SOURCE_REL%
set INSTALL_SWM=
if defined INSTALL_SWM_REL set INSTALL_SWM=%USBDRIVE%\%INSTALL_SWM_REL%
echo [%DATE% %TIME%] Install source=%INSTALL_SOURCE% swm=%INSTALL_SWM% image_index=%IMAGE_INDEX%.>>"%LOG_PATH%"
if not exist "%INSTALL_SOURCE%" (
  set FAIL_STEP=resolve-install-source
  set FAIL_CODE=105
  goto fail
)
if exist S:\ mountvol S: /D >nul 2>nul
echo [%DATE% %TIME%] Mounting EFI system partition to S:.>>"%LOG_PATH%"
mountvol S: /S >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=mount-efi
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
echo [%DATE% %TIME%] Formatting %TARGETDRIVE% as NTFS.>>"%LOG_PATH%"
echo.|format %TARGETDRIVE% /fs:ntfs /q /x /y /v:Windows >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=format-target
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
echo [%DATE% %TIME%] Applying Windows image to %TARGETDRIVE% from %INSTALL_SOURCE%.>>"%LOG_PATH%"
if defined INSTALL_SWM (
  dism.exe /Apply-Image /ImageFile:"%INSTALL_SOURCE%" /SWMFile:"%INSTALL_SWM%" /Index:%IMAGE_INDEX% /ApplyDir:%TARGETDRIVE%\ >>"%LOG_PATH%" 2>&1
) else (
  dism.exe /Apply-Image /ImageFile:"%INSTALL_SOURCE%" /Index:%IMAGE_INDEX% /ApplyDir:%TARGETDRIVE%\ >>"%LOG_PATH%" 2>&1
)
if errorlevel 1 (
  set FAIL_STEP=apply-image
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
echo [%DATE% %TIME%] Copying restore bundle.>>"%LOG_PATH%"
mkdir "%TARGETDRIVE%\ProgramData\Soty\WindowsReinstall\restore" >nul 2>nul
robocopy "%USBROOT%\restore" "%TARGETDRIVE%\ProgramData\Soty\WindowsReinstall\restore" /E /ZB /R:1 /W:1 /NFL /NDL /NJH /NJS /NP /XJ /COPY:DAT >>"%LOG_PATH%" 2>&1
if errorlevel 8 (
  set FAIL_STEP=copy-restore
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
echo [%DATE% %TIME%] Copying unattend files.>>"%LOG_PATH%"
mkdir "%TARGETDRIVE%\Windows\Panther\Unattend" >nul 2>nul
copy /y "%USBROOT%\reinstall\unattend.xml" "%TARGETDRIVE%\Windows\Panther\Unattend\Unattend.xml" >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=copy-unattend-panther-subdir
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
copy /y "%USBROOT%\reinstall\unattend.xml" "%TARGETDRIVE%\Windows\Panther\unattend.xml" >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=copy-unattend-panther-root
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
copy /y "%USBROOT%\reinstall\unattend.xml" "%TARGETDRIVE%\Windows\System32\Sysprep\unattend.xml" >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=copy-unattend-sysprep
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
if exist "%USBROOT%\setup-hooks\setupcomplete.cmd" (
  echo [%DATE% %TIME%] Copying SetupComplete.cmd.>>"%LOG_PATH%"
  mkdir "%TARGETDRIVE%\Windows\Setup\Scripts" >nul 2>nul
  copy /y "%USBROOT%\setup-hooks\setupcomplete.cmd" "%TARGETDRIVE%\Windows\Setup\Scripts\SetupComplete.cmd" >>"%LOG_PATH%" 2>&1
  if errorlevel 1 (
    set FAIL_STEP=copy-setupcomplete
    set FAIL_CODE=!ERRORLEVEL!
    goto fail
  )
)
echo [%DATE% %TIME%] Rebuilding EFI boot files.>>"%LOG_PATH%"
bcdboot.exe %TARGETDRIVE%\Windows /s S: /f UEFI >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=bcdboot
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
del /f /q "%TARGETDRIVE%\Soty-Reinstall-Target.marker" >nul 2>nul
echo [%DATE% %TIME%] Worker finished successfully, rebooting WinPE.>>"%LOG_PATH%"
wpeutil reboot
exit /b 0
:fail
if not defined FAIL_STEP set FAIL_STEP=unknown
if not defined FAIL_CODE set FAIL_CODE=%ERRORLEVEL%
if exist "%SCRIPT_ROOT%armed.started" ren "%SCRIPT_ROOT%armed.started" armed.flag >nul 2>nul
echo [%DATE% %TIME%] FAILURE step=%FAIL_STEP% code=%FAIL_CODE%.>>"%LOG_PATH%"
echo [%DATE% %TIME%] Automatic reboot to the existing Windows installation in 15 seconds.>>"%LOG_PATH%"
timeout /t 15 /nobreak >nul
wpeutil reboot
exit /b %FAIL_CODE%
'@ -Encoding ASCII
Set-Content -LiteralPath (Join-Path $reinstallRoot "armed.flag") -Value ("armed-at=" + (Get-Date).ToString("o")) -Encoding ASCII
Set-Content -LiteralPath (Join-Path $env:SystemDrive "Soty-Reinstall-Target.marker") -Value ("prepared-at=" + (Get-Date).ToString("o")) -Encoding ASCII
if (-not (Test-Path -LiteralPath $setupCompleteSource)) {
  Log "Warning: setupcomplete.cmd was not promoted to the USB; postinstall will lose its primary fast path and may require scheduled retry or manual restore."
}

$result = [ordered]@{
  status = "bootable_usb_ready"
  runRoot = $runRoot
  stageBundleRoot = $StageBundleRoot
  usbDriveLetter = $usbLetter
  usbLabel = $UsbLabel
  usbFileSystem = $targetUsbFileSystem
  installImageLayout = $installImageLayout
  usbRoot = $usbRoot
  sourceMediaRoot = $sourceRoot
  sourceInstallKind = $sourceInstallKind
  bcdStore = $bcdStore
  installSource = (Join-Path $usbRoot $installSourceRelative)
  bootWim = (Join-Path $usbRoot "sources\boot.wim")
  managedUserName = $ManagedUserName
  managedUserPasswordIsEmpty = [string]::IsNullOrEmpty($ManagedUserPassword)
  managedUserPasswordEffectiveEmpty = [string]::IsNullOrEmpty($effectiveManagedUserPassword)
  managedUserPasswordGenerated = $managedUserPasswordGenerated
  logPath = $script:LogPath
  nextAction = "Run windows-arm-internal-winpe-boot.ps1 and reboot."
}
Save-Json -Path (Join-Path $runRoot "result.json") -Value $result
Write-Output ("BOOTABLE_USB_RESULT=" + (Join-Path $runRoot "result.json"))
