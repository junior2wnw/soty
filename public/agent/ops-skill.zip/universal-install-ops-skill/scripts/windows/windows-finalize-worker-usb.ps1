param(
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string] $StageBundleRoot = "",
  [string] $UsbDriveLetter = "D",
  [string] $UsbLabel = "SOTYWIN",
  [string] $ComputerName = "",
  [string] $ManagedUserName = "Soty",
  [string] $ManagedUserPassword = "",
  [string] $PanelSiteUrl = "https://xn--n1afe0b.online",
  [string] $PanelSiteFallbackIp = "95.105.53.126",
  [string] $PanelSiteFallbackHost = "xn--n1afe0b.online"
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  if ($Path.Trim() -match '^[A-Za-z]:\\?$') {
    return
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Get-LatestStageBundleRoot([string] $Root) {
  $bundleRoot = Join-Path $Root "stage-bundles"
  $latest = Get-ChildItem -LiteralPath $bundleRoot -Directory -ErrorAction Stop | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (-not $latest) {
    throw "No stage bundle run root exists under $bundleRoot."
  }
  return $latest.FullName
}

function Escape-Xml([string] $Value) {
  return [System.Security.SecurityElement]::Escape($Value)
}

function Write-UnattendXml {
  param(
    [string] $Path,
    [string] $UserName,
    [string] $Password,
    [string] $ComputerNameValue
  )

  $u = Escape-Xml $UserName
  $p = Escape-Xml $Password
  $c = Escape-Xml $ComputerNameValue
  $content = @"
<?xml version="1.0" encoding="utf-8"?>
<unattend xmlns="urn:schemas-microsoft-com:unattend" xmlns:wcm="http://schemas.microsoft.com/WMIConfig/2002/State">
  <settings pass="specialize">
    <component name="Microsoft-Windows-Shell-Setup" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS">
      <ComputerName>$c</ComputerName>
      <TimeZone>Ekaterinburg Standard Time</TimeZone>
    </component>
  </settings>
  <settings pass="oobeSystem">
    <component name="Microsoft-Windows-International-Core" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS">
      <InputLocale>ru-RU</InputLocale>
      <SystemLocale>ru-RU</SystemLocale>
      <UILanguage>ru-RU</UILanguage>
      <UserLocale>ru-RU</UserLocale>
    </component>
    <component name="Microsoft-Windows-Shell-Setup" processorArchitecture="amd64" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS">
      <AutoLogon>
        <Password>
          <Value>$p</Value>
          <PlainText>true</PlainText>
        </Password>
        <Enabled>true</Enabled>
        <LogonCount>1</LogonCount>
        <Username>$u</Username>
      </AutoLogon>
      <OOBE>
        <HideEULAPage>true</HideEULAPage>
        <HideLocalAccountScreen>true</HideLocalAccountScreen>
        <HideOEMRegistrationScreen>true</HideOEMRegistrationScreen>
        <HideOnlineAccountScreens>true</HideOnlineAccountScreens>
        <HideWirelessSetupInOOBE>true</HideWirelessSetupInOOBE>
        <NetworkLocation>Home</NetworkLocation>
        <ProtectYourPC>3</ProtectYourPC>
      </OOBE>
      <UserAccounts>
        <LocalAccounts>
          <LocalAccount wcm:action="add">
            <Password>
              <Value>$p</Value>
              <PlainText>true</PlainText>
            </Password>
            <Description>Soty recovery operator</Description>
            <DisplayName>$u</DisplayName>
            <Group>Administrators</Group>
            <Name>$u</Name>
          </LocalAccount>
        </LocalAccounts>
      </UserAccounts>
      <FirstLogonCommands>
        <SynchronousCommand wcm:action="add">
          <Order>1</Order>
          <Description>Soty first logon restore</Description>
          <CommandLine>cmd.exe /c C:\ProgramData\Soty\WindowsReinstall\restore\soty-firstlogon.cmd</CommandLine>
        </SynchronousCommand>
      </FirstLogonCommands>
    </component>
  </settings>
</unattend>
"@
  Set-Content -LiteralPath $Path -Value $content -Encoding UTF8
}

function Write-SetupCompleteCmd {
  param(
    [string] $Path
  )

  $content = @'
@echo off
setlocal enableextensions
set USBROOT=
for %%d in (D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%d:\Soty-Reinstall\restore\postinstall.ps1" set USBROOT=%%d:\Soty-Reinstall
)
if not defined USBROOT exit /b 1
set RESTORE_LOCAL=C:\ProgramData\Soty\WindowsReinstall\restore
mkdir "%RESTORE_LOCAL%" >nul 2>nul
xcopy "%USBROOT%\restore\*" "%RESTORE_LOCAL%\" /E /I /Y >nul
if not exist "%RESTORE_LOCAL%\postinstall.ps1" exit /b 1
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%RESTORE_LOCAL%\postinstall.ps1"
set RESTORE_EXIT=%ERRORLEVEL%
exit /b %RESTORE_EXIT%
'@

  Set-Content -LiteralPath $Path -Value $content -Encoding ASCII
}

function Write-FirstLogonRestoreScripts {
  param(
    [string] $RestoreRoot,
    [string] $UserName,
    [bool] $ResetPasswordToBlank
  )

  New-Dir $RestoreRoot
  $resetLiteral = if ($ResetPasswordToBlank) { '$true' } else { '$false' }
  $userLiteral = $UserName.Replace("'", "''")
  $cmd = @'
@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0soty-firstlogon.ps1"
exit /b %ERRORLEVEL%
'@
  Set-Content -LiteralPath (Join-Path $RestoreRoot "soty-firstlogon.cmd") -Value $cmd -Encoding ASCII

  $ps = @"
`$ErrorActionPreference = 'Continue'
`$ProgressPreference = 'SilentlyContinue'
`$managedUserName = '$userLiteral'
`$resetPasswordToBlank = $resetLiteral
`$logRoot = 'C:\ProgramData\Soty\WindowsReinstall\logs'
New-Item -ItemType Directory -Force -Path `$logRoot | Out-Null
`$log = Join-Path `$logRoot 'firstlogon.log'
function Log([string]`$Message) { Add-Content -LiteralPath `$log -Value ('[' + (Get-Date).ToString('o') + '] ' + `$Message) -Encoding UTF8 }
Log 'first logon started'
try {
  reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' /v AutoAdminLogon /t REG_SZ /d 0 /f | Out-Null
  reg.exe delete 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' /v DefaultPassword /f | Out-Null
  reg.exe delete 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' /v AutoLogonCount /f | Out-Null
} catch { Log ('autologon cleanup warning: ' + `$_.Exception.Message) }
try {
  `$du = Get-LocalUser -Name 'defaultuser0' -ErrorAction SilentlyContinue
  if (`$du) {
    Disable-LocalUser -Name 'defaultuser0' -ErrorAction SilentlyContinue
    Remove-LocalUser -Name 'defaultuser0' -ErrorAction SilentlyContinue
    Log 'removed defaultuser0'
  }
} catch { Log ('defaultuser0 cleanup warning: ' + `$_.Exception.Message) }
if (`$resetPasswordToBlank) {
  try {
    & net.exe user "`$managedUserName" "" | Out-Null
    Log 'managed user password reset to blank'
  } catch { Log ('managed password cleanup warning: ' + `$_.Exception.Message) }
}
try {
  `$custom = Join-Path `$PSScriptRoot 'firstlogon-custom.ps1'
  if (Test-Path -LiteralPath `$custom) { & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File `$custom }
} catch { Log ('custom firstlogon warning: ' + `$_.Exception.ToString()) }
try {
  Start-Process 'msedge.exe' -ArgumentList '--app=https://xn--n1afe0b.online/?pwa=1'
} catch {
  try { Start-Process 'https://xn--n1afe0b.online/?pwa=1' } catch { Log ('PWA launch warning: ' + `$_.Exception.Message) }
}
Log 'first logon finished'
"@
  Set-Content -LiteralPath (Join-Path $RestoreRoot "soty-firstlogon.ps1") -Value $ps -Encoding UTF8
}

function Invoke-Robocopy {
  param(
    [string] $Source,
    [string] $Destination
  )

  New-Dir $Destination
  & robocopy.exe $Source $Destination /E /ZB /R:1 /W:1 /FFT /NFL /NDL /NJH /NJS /NP /XJ /COPY:DAT /XD "System Volume Information" "`$RECYCLE.BIN" | Out-Null
  if ($LASTEXITCODE -ge 8) {
    throw ("robocopy failed for " + $Source + " -> " + $Destination + " with exit code " + $LASTEXITCODE)
  }
}

function Promote-WorkerPayloadToUsb {
  param(
    [string] $BackupRoot,
    [string] $RestoreRoot,
    [string] $SetupCompletePath,
    [string] $UsbRoot
  )

  $workerRoot = Join-Path $UsbRoot "Soty-Reinstall"
  $workerBackupRoot = Join-Path $workerRoot "backup"
  $workerRestoreRoot = Join-Path $workerRoot "restore"
  $workerSetupHooksRoot = Join-Path $workerRoot "setup-hooks"

  foreach ($path in @($workerRoot, $workerBackupRoot, $workerRestoreRoot, $workerSetupHooksRoot)) {
    New-Dir $path
  }

  if (Test-Path -LiteralPath $BackupRoot) {
    Invoke-Robocopy -Source $BackupRoot -Destination $workerBackupRoot
  }
  if (Test-Path -LiteralPath $RestoreRoot) {
    Invoke-Robocopy -Source $RestoreRoot -Destination $workerRestoreRoot
  }
  if (Test-Path -LiteralPath $SetupCompletePath) {
    Copy-Item -LiteralPath $SetupCompletePath -Destination (Join-Path $workerSetupHooksRoot "setupcomplete.cmd") -Force
  }
}

function Get-LatestUsbBuildRoot([string] $Root) {
  $buildRoot = Join-Path $Root "usb-bootable"
  $latest = Get-ChildItem -LiteralPath $buildRoot -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($latest) {
    return $latest.FullName
  }
  return $null
}

function Ensure-BcdRamdiskOptions {
  param(
    [string] $StorePath
  )

  & bcdedit.exe /store $StorePath /enum "{ramdiskoptions}" | Out-Null
  if ($LASTEXITCODE -eq 0) {
    return
  }

  $output = & bcdedit.exe /store $StorePath /create "{ramdiskoptions}" /d "Soty Ramdisk Options" 2>&1
  if ($LASTEXITCODE -ne 0) {
    $joined = ($output | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine
    if ($joined -notmatch "already") {
      throw ("Failed to create {ramdiskoptions} in store " + $StorePath + "." + [Environment]::NewLine + $joined)
    }
  }
}

function Invoke-BcdStoreEdit {
  param(
    [string] $StorePath,
    [string[]] $Arguments,
    [int] $Attempts = 10,
    [int] $DelaySeconds = 2
  )

  $lastOutput = @()
  $lastExitCode = 0
  for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
    $lastOutput = & bcdedit.exe /store $StorePath @Arguments 2>&1
    $lastExitCode = $LASTEXITCODE
    if ($lastExitCode -eq 0) {
      return
    }
    if ($attempt -lt $Attempts) {
      Start-Sleep -Seconds $DelaySeconds
    }
  }

  $joined = ($lastOutput | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine
  throw ("bcdedit.exe failed with exit code " + $lastExitCode + "." + [Environment]::NewLine + $joined)
}

function Get-AssertCustomBootWimScriptPath {
  $candidate = Join-Path $PSScriptRoot "windows-assert-custom-winpe-worker.ps1"
  if (Test-Path -LiteralPath $candidate) {
    return $candidate
  }
  return $null
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw "This script must run as Administrator."
}

if ([string]::IsNullOrWhiteSpace($StageBundleRoot)) {
  $StageBundleRoot = Get-LatestStageBundleRoot -Root $WorkspaceRoot
}
if (-not (Test-Path -LiteralPath $StageBundleRoot)) {
  throw "Stage bundle root not found: $StageBundleRoot"
}

$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$runRoot = Join-Path $WorkspaceRoot ("usb-finalize\" + $runId)
$logRoot = Join-Path $runRoot "logs"
$setupHooksRoot = Join-Path $runRoot "setup-hooks"
foreach ($path in @($runRoot, $logRoot, $setupHooksRoot)) {
  New-Dir $path
}
$script:LogPath = Join-Path $logRoot "finalize.log"

$usbLetter = $UsbDriveLetter.TrimEnd(":").ToUpperInvariant()
$usbRoot = $usbLetter + ":\"
$usbVolume = Get-Volume -DriveLetter $usbLetter -ErrorAction Stop
if ($usbVolume.FileSystemLabel -ne $UsbLabel) {
  throw ("USB label mismatch. Expected " + $UsbLabel + " but found " + $usbVolume.FileSystemLabel)
}

$bootWimPath = Join-Path $usbRoot "sources\boot.wim"
if (-not (Test-Path -LiteralPath $bootWimPath)) {
  throw "USB boot.wim is missing."
}

$latestBuildRoot = Get-LatestUsbBuildRoot -Root $WorkspaceRoot
$stagedBootWim = if ($latestBuildRoot) { Join-Path $latestBuildRoot "staging\boot.wim" } else { $null }
if (-not [string]::IsNullOrWhiteSpace($stagedBootWim) -and (Test-Path -LiteralPath $stagedBootWim)) {
  Log ("Refreshing USB sources\\boot.wim from staged custom boot.wim: " + $stagedBootWim)
  Copy-Item -LiteralPath $stagedBootWim -Destination $bootWimPath -Force
}
$assertBootWimScript = Get-AssertCustomBootWimScriptPath
if (-not [string]::IsNullOrWhiteSpace($assertBootWimScript)) {
  Log "Verifying that USB sources\\boot.wim is worker-ready before handoff."
  & $assertBootWimScript -BootWimPath $bootWimPath -WorkspaceRoot $WorkspaceRoot | Out-Null
} else {
  Log "Warning: worker boot.wim verification script is missing next to the finalizer."
}

$installSourceRelative = ""
$installSwmRelative = ""
if (-not (Test-Path -LiteralPath (Join-Path $usbRoot "sources\install.swm")) -and -not (Test-Path -LiteralPath (Join-Path $usbRoot "sources\install.esd")) -and -not (Test-Path -LiteralPath (Join-Path $usbRoot "sources\install.wim"))) {
  $latestSplitRoot = if ($latestBuildRoot) { Join-Path $latestBuildRoot "staging\split-install" } else { $null }
  if (-not [string]::IsNullOrWhiteSpace($latestSplitRoot) -and (Test-Path -LiteralPath $latestSplitRoot)) {
    $stagedSwmFiles = @(Get-ChildItem -LiteralPath $latestSplitRoot -Filter "install*.swm" -File -ErrorAction SilentlyContinue | Sort-Object Name)
    if ($stagedSwmFiles.Count -gt 0) {
      Log ("Restoring staged install*.swm chunks onto the USB from " + $latestSplitRoot)
      foreach ($swmFile in $stagedSwmFiles) {
        Copy-Item -LiteralPath $swmFile.FullName -Destination (Join-Path $usbRoot ("sources\" + $swmFile.Name)) -Force
      }
    }
  }
}
if (Test-Path -LiteralPath (Join-Path $usbRoot "sources\install.swm")) {
  $installSourceRelative = "sources\install.swm"
  $installSwmRelative = "sources\install*.swm"
} elseif (Test-Path -LiteralPath (Join-Path $usbRoot "sources\install.esd")) {
  $installSourceRelative = "sources\install.esd"
  $installSwmRelative = ""
} elseif (Test-Path -LiteralPath (Join-Path $usbRoot "sources\install.wim")) {
  $installSourceRelative = "sources\install.wim"
  $installSwmRelative = ""
} else {
  throw "USB does not contain install.swm, install.esd, or install.wim."
}

$restoreRoot = Join-Path $StageBundleRoot "restore"
$restoreConfigPath = Join-Path $restoreRoot "restore-config.json"
if (-not (Test-Path -LiteralPath $restoreRoot)) {
  throw "Stage bundle restore root is missing. Refusing to fall back to workspace restore because it may contain stale or unsafe postinstall logic."
}

$config = if (Test-Path -LiteralPath $restoreConfigPath) {
  Get-Content -LiteralPath $restoreConfigPath -Raw | ConvertFrom-Json
} else {
  [pscustomobject]@{}
}
$preferredProbeUrls = @(
  ($PanelSiteUrl.TrimEnd("/") + "/api/downloads"),
  "https://xn--n1afe0b.online/api/downloads",
  "https://xn--h1aaocew5a7b.online/api/downloads"
)
$config | Add-Member -NotePropertyName preferredPanelProbeUrls -NotePropertyValue $preferredProbeUrls -Force
$config | Add-Member -NotePropertyName panelSiteUrl -NotePropertyValue $PanelSiteUrl -Force
$config | Add-Member -NotePropertyName hostsEntries -NotePropertyValue @(@{ host = $PanelSiteFallbackHost; ip = $PanelSiteFallbackIp }) -Force
Save-Json -Path $restoreConfigPath -Value $config

$effectiveManagedUserPassword = $ManagedUserPassword
$managedUserPasswordGenerated = $false
if ([string]::IsNullOrEmpty($effectiveManagedUserPassword)) {
  $effectiveManagedUserPassword = "Soty-" + ([Guid]::NewGuid().ToString("N"))
  $managedUserPasswordGenerated = $true
}
Write-FirstLogonRestoreScripts -RestoreRoot $restoreRoot -UserName $ManagedUserName -ResetPasswordToBlank $managedUserPasswordGenerated

$setupCompletePath = Join-Path $setupHooksRoot "setupcomplete.cmd"
Write-SetupCompleteCmd -Path $setupCompletePath
Log "Promoting backup, restore, and setup hooks to the USB workspace."
Promote-WorkerPayloadToUsb -BackupRoot (Join-Path $StageBundleRoot "backup") -RestoreRoot $restoreRoot -SetupCompletePath $setupCompletePath -UsbRoot $usbRoot

$bcdStore = Join-Path $usbRoot "EFI\Microsoft\Boot\BCD"
if (Test-Path -LiteralPath $bcdStore) {
  try {
    Log ("Repointing USB BCD store to boot WinPE from " + $bootWimPath)
    Start-Sleep -Seconds 3
    Ensure-BcdRamdiskOptions -StorePath $bcdStore
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{ramdiskoptions}", "ramdisksdidevice", "partition=" + $usbLetter + ":")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{ramdiskoptions}", "ramdisksdipath", "\boot\boot.sdi")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "device", "ramdisk=[boot]\sources\boot.wim,{ramdiskoptions}")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "osdevice", "ramdisk=[boot]\sources\boot.wim,{ramdiskoptions}")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "path", "\windows\system32\boot\winload.efi")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "systemroot", "\windows")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "winpe", "yes")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "detecthal", "yes")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "nx", "OptIn")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{default}", "description", "Soty WinPE Reinstall")
    Invoke-BcdStoreEdit -StorePath $bcdStore -Arguments @("/set", "{bootmgr}", "timeout", "3")
  } catch {
    Log ("Warning: USB BCD repoint was skipped: " + $_.Exception.Message)
  }
}

$reinstallRoot = Join-Path $usbRoot "Soty-Reinstall\reinstall"
New-Dir $reinstallRoot
$targetComputerName = if ([string]::IsNullOrWhiteSpace($ComputerName)) { $env:COMPUTERNAME } else { $ComputerName }
Write-UnattendXml -Path (Join-Path $reinstallRoot "unattend.xml") -UserName $ManagedUserName -Password $effectiveManagedUserPassword -ComputerNameValue $targetComputerName
Set-Content -LiteralPath (Join-Path $reinstallRoot "config.cmd") -Value ("@echo off`r`nset IMAGE_INDEX=1`r`nset INSTALL_SOURCE_REL=" + $installSourceRelative + "`r`nset INSTALL_SWM_REL=" + $installSwmRelative + "`r`n") -Encoding ASCII
Set-Content -LiteralPath (Join-Path $reinstallRoot "winre-reinstall.cmd") -Value @'
@echo off
setlocal enableextensions enabledelayedexpansion
set SCRIPT_ROOT=%~dp0
set LOG_ROOT=%SCRIPT_ROOT%logs
if not exist "%LOG_ROOT%" mkdir "%LOG_ROOT%"
set LOG_PATH=%LOG_ROOT%\winre-reinstall.log
call "%SCRIPT_ROOT%config.cmd"
set FAIL_STEP=
set FAIL_CODE=
echo [%DATE% %TIME%] Worker started.>>"%LOG_PATH%"
if not exist "%SCRIPT_ROOT%armed.flag" (
  echo [%DATE% %TIME%] armed.flag missing, exiting without work.>>"%LOG_PATH%"
  exit /b 0
)
ren "%SCRIPT_ROOT%armed.flag" armed.started >nul 2>nul
echo [%DATE% %TIME%] armed.started created.>>"%LOG_PATH%"
set USBROOT=
set USBDRIVE=
for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%d:\Soty-Reinstall\reinstall\config.cmd" (
    set USBROOT=%%d:\Soty-Reinstall
    set USBDRIVE=%%d:
  )
)
set TARGETDRIVE=
for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%d:\Soty-Reinstall-Target.marker" set TARGETDRIVE=%%d:
)
echo [%DATE% %TIME%] Resolved USBROOT=!USBROOT! USBDRIVE=!USBDRIVE! TARGETDRIVE=!TARGETDRIVE!.>>"%LOG_PATH%"
if not defined USBROOT (
  set FAIL_STEP=resolve-usbroot
  set FAIL_CODE=101
  goto fail
)
if not defined USBDRIVE (
  set FAIL_STEP=resolve-usbdrive
  set FAIL_CODE=102
  goto fail
)
if not defined TARGETDRIVE (
  set FAIL_STEP=resolve-targetdrive
  set FAIL_CODE=103
  goto fail
)
if /I "%TARGETDRIVE%"=="%USBDRIVE%" (
  set FAIL_STEP=targetdrive-is-usbdrive
  set FAIL_CODE=104
  goto fail
)
set INSTALL_SOURCE=%USBDRIVE%\%INSTALL_SOURCE_REL%
set INSTALL_SWM=
if defined INSTALL_SWM_REL set INSTALL_SWM=%USBDRIVE%\%INSTALL_SWM_REL%
echo [%DATE% %TIME%] Install source=%INSTALL_SOURCE% swm=%INSTALL_SWM% image_index=%IMAGE_INDEX%.>>"%LOG_PATH%"
if not exist "%INSTALL_SOURCE%" (
  set FAIL_STEP=resolve-install-source
  set FAIL_CODE=105
  goto fail
)
if exist S:\ mountvol S: /D >nul 2>nul
echo [%DATE% %TIME%] Mounting EFI system partition to S:.>>"%LOG_PATH%"
mountvol S: /S >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=mount-efi
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
echo [%DATE% %TIME%] Formatting %TARGETDRIVE% as NTFS.>>"%LOG_PATH%"
echo.|format %TARGETDRIVE% /fs:ntfs /q /x /y /v:Windows >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=format-target
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
echo [%DATE% %TIME%] Applying Windows image to %TARGETDRIVE% from %INSTALL_SOURCE%.>>"%LOG_PATH%"
if defined INSTALL_SWM (
  dism.exe /Apply-Image /ImageFile:"%INSTALL_SOURCE%" /SWMFile:"%INSTALL_SWM%" /Index:%IMAGE_INDEX% /ApplyDir:%TARGETDRIVE%\ >>"%LOG_PATH%" 2>&1
) else (
  dism.exe /Apply-Image /ImageFile:"%INSTALL_SOURCE%" /Index:%IMAGE_INDEX% /ApplyDir:%TARGETDRIVE%\ >>"%LOG_PATH%" 2>&1
)
if errorlevel 1 (
  set FAIL_STEP=apply-image
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
echo [%DATE% %TIME%] Copying restore bundle.>>"%LOG_PATH%"
mkdir "%TARGETDRIVE%\ProgramData\Soty\WindowsReinstall\restore" >nul 2>nul
robocopy "%USBROOT%\restore" "%TARGETDRIVE%\ProgramData\Soty\WindowsReinstall\restore" /E /ZB /R:1 /W:1 /NFL /NDL /NJH /NJS /NP /XJ /COPY:DAT >>"%LOG_PATH%" 2>&1
if errorlevel 8 (
  set FAIL_STEP=copy-restore
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
echo [%DATE% %TIME%] Copying unattend files.>>"%LOG_PATH%"
mkdir "%TARGETDRIVE%\Windows\Panther\Unattend" >nul 2>nul
copy /y "%USBROOT%\reinstall\unattend.xml" "%TARGETDRIVE%\Windows\Panther\Unattend\Unattend.xml" >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=copy-unattend-panther-subdir
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
copy /y "%USBROOT%\reinstall\unattend.xml" "%TARGETDRIVE%\Windows\Panther\unattend.xml" >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=copy-unattend-panther-root
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
copy /y "%USBROOT%\reinstall\unattend.xml" "%TARGETDRIVE%\Windows\System32\Sysprep\unattend.xml" >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=copy-unattend-sysprep
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
if exist "%USBROOT%\setup-hooks\setupcomplete.cmd" (
  echo [%DATE% %TIME%] Copying SetupComplete.cmd.>>"%LOG_PATH%"
  mkdir "%TARGETDRIVE%\Windows\Setup\Scripts" >nul 2>nul
  copy /y "%USBROOT%\setup-hooks\setupcomplete.cmd" "%TARGETDRIVE%\Windows\Setup\Scripts\SetupComplete.cmd" >>"%LOG_PATH%" 2>&1
  if errorlevel 1 (
    set FAIL_STEP=copy-setupcomplete
    set FAIL_CODE=!ERRORLEVEL!
    goto fail
  )
)
echo [%DATE% %TIME%] Rebuilding EFI boot files.>>"%LOG_PATH%"
bcdboot.exe %TARGETDRIVE%\Windows /s S: /f UEFI >>"%LOG_PATH%" 2>&1
if errorlevel 1 (
  set FAIL_STEP=bcdboot
  set FAIL_CODE=!ERRORLEVEL!
  goto fail
)
del /f /q "%TARGETDRIVE%\Soty-Reinstall-Target.marker" >nul 2>nul
echo [%DATE% %TIME%] Worker finished successfully, rebooting WinPE.>>"%LOG_PATH%"
wpeutil reboot
exit /b 0
:fail
if not defined FAIL_STEP set FAIL_STEP=unknown
if not defined FAIL_CODE set FAIL_CODE=%ERRORLEVEL%
if exist "%SCRIPT_ROOT%armed.started" ren "%SCRIPT_ROOT%armed.started" armed.flag >nul 2>nul
echo [%DATE% %TIME%] FAILURE step=%FAIL_STEP% code=%FAIL_CODE%.>>"%LOG_PATH%"
echo [%DATE% %TIME%] Automatic reboot to the existing Windows installation in 15 seconds.>>"%LOG_PATH%"
timeout /t 15 /nobreak >nul
wpeutil reboot
exit /b %FAIL_CODE%
'@ -Encoding ASCII
Set-Content -LiteralPath (Join-Path $reinstallRoot "armed.flag") -Value ("armed-at=" + (Get-Date).ToString("o")) -Encoding ASCII
Set-Content -LiteralPath (Join-Path $env:SystemDrive "Soty-Reinstall-Target.marker") -Value ("prepared-at=" + (Get-Date).ToString("o")) -Encoding ASCII

$result = [ordered]@{
  status = "worker_usb_finalized"
  runRoot = $runRoot
  stageBundleRoot = $StageBundleRoot
  usbDriveLetter = $usbLetter
  usbLabel = $UsbLabel
  usbRoot = $usbRoot
  installSource = (Join-Path $usbRoot $installSourceRelative)
  bootWim = $bootWimPath
  managedUserName = $ManagedUserName
  managedUserPasswordIsEmpty = [string]::IsNullOrEmpty($ManagedUserPassword)
  managedUserPasswordEffectiveEmpty = [string]::IsNullOrEmpty($effectiveManagedUserPassword)
  managedUserPasswordGenerated = $managedUserPasswordGenerated
  logPath = $script:LogPath
  nextAction = "Run windows-arm-internal-winpe-boot.ps1 and reboot."
}
Save-Json -Path (Join-Path $runRoot "result.json") -Value $result
Write-Output ("USB_WORKER_FINALIZE_RESULT=" + (Join-Path $runRoot "result.json"))
