param(
  [string] $SourceEsdPath = "C:\ProgramData\Soty\WindowsReinstall\media\Windows11-26200-Pro-ru-RU.esd",
  [string] $ExpectedEsdSha256 = "",
  [string] $BuilderRunRoot = "C:\ProgramData\Soty\WindowsReinstall\usb-bootable\current",
  [string] $UsbDriveLetter = "D",
  [string] $UsbLabel = "SOTYWIN",
  [string] $InternalBootRoot = "C:\Soty-Boot",
  [switch] $SkipEsdHashValidation
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Invoke-CliStrict([string] $FilePath, [string[]] $ArgumentList) {
  & $FilePath @ArgumentList | Out-Null
  if ($LASTEXITCODE -ne 0) {
    throw ($FilePath + " failed with exit code " + $LASTEXITCODE)
  }
}

function Log([string] $Message) {
  Add-Content -LiteralPath $script:LogPath -Value ("[" + (Get-Date).ToString("o") + "] " + $Message) -Encoding UTF8
  Write-Output ("[" + (Get-Date).ToString("o") + "] " + $Message)
}

function Get-StartnetContent {
  return @'
@echo off
setlocal enableextensions enabledelayedexpansion
set INTERNALROOT=
set TARGETROOT=
for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if exist "%%d:\Soty-Boot\boot.wim" set "INTERNALROOT=%%d:\Soty-Boot"
  if exist "%%d:\Soty-Reinstall-Target.marker" set "TARGETROOT=%%d:"
)
if not exist X:\Soty mkdir X:\Soty >nul 2>nul
set LOG_PATH=X:\Soty\soty-startnet.log
if defined INTERNALROOT (
  if not exist "%INTERNALROOT%\logs" mkdir "%INTERNALROOT%\logs" >nul 2>nul
  set LOG_PATH=%INTERNALROOT%\logs\startnet.log
)
if not defined INTERNALROOT if defined TARGETROOT (
  if not exist "%TARGETROOT%\ProgramData\Soty\WindowsReinstall\logs" mkdir "%TARGETROOT%\ProgramData\Soty\WindowsReinstall\logs" >nul 2>nul
  set LOG_PATH=%TARGETROOT%\ProgramData\Soty\WindowsReinstall\logs\winre-startnet.log
)
>>"%LOG_PATH%" echo [%DATE% %TIME%] startnet entered
wpeinit >>"%LOG_PATH%" 2>&1
>>"%LOG_PATH%" echo [%DATE% %TIME%] wpeinit finished
if defined INTERNALROOT >>"%LOG_PATH%" echo [%DATE% %TIME%] internal root found at %INTERNALROOT%
if defined TARGETROOT >>"%LOG_PATH%" echo [%DATE% %TIME%] target root found at %TARGETROOT%
set USBROOT=
for /L %%i in (1,1,120) do (
  set "USBROOT="
  for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%d:\Soty-Reinstall\reinstall\winre-reinstall.cmd" if exist "%%d:\Soty-Reinstall\reinstall\config.cmd" set "USBROOT=%%d:\Soty-Reinstall"
  )
  if defined USBROOT goto usb_found
  >>"%LOG_PATH%" echo [%DATE% %TIME%] probe %%i: usb root not found yet
  timeout /t 2 /nobreak >nul
)
>>"%LOG_PATH%" echo [%DATE% %TIME%] usb root was not found after retries
wpeutil reboot
exit /b 1

:usb_found
>>"%LOG_PATH%" echo [%DATE% %TIME%] usb root found at %USBROOT%
if defined USBROOT (
  if not exist "%USBROOT%\reinstall\logs" mkdir "%USBROOT%\reinstall\logs" >nul 2>nul
  type "%LOG_PATH%" >> "%USBROOT%\reinstall\logs\startnet.log" 2>nul
  set LOG_PATH=%USBROOT%\reinstall\logs\startnet.log
  >>"%LOG_PATH%" echo [%DATE% %TIME%] invoking worker, usbroot=%USBROOT%
  if exist "%USBROOT%\reinstall\armed.flag" (
    call "%USBROOT%\reinstall\winre-reinstall.cmd"
    set WORKER_EXIT=!ERRORLEVEL!
    >>"%LOG_PATH%" echo [%DATE% %TIME%] worker exit code=!WORKER_EXIT!
    exit /b !WORKER_EXIT!
  ) else (
    >>"%LOG_PATH%" echo [%DATE% %TIME%] armed.flag missing, not invoking worker
    wpeutil reboot
    exit /b 1
  )
)
'@
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw "This script must run as Administrator."
}

$usbLetter = $UsbDriveLetter.TrimEnd(":").ToUpperInvariant()
$usbVolume = Get-Volume -DriveLetter $usbLetter -ErrorAction Stop
if ($usbVolume.FileSystemLabel -ne $UsbLabel) {
  throw ("USB label mismatch. Expected " + $UsbLabel + " but found " + $usbVolume.FileSystemLabel)
}
if (-not (Test-Path -LiteralPath $SourceEsdPath)) {
  throw "Source ESD path not found: $SourceEsdPath"
}
if (-not $SkipEsdHashValidation -and -not [string]::IsNullOrWhiteSpace($ExpectedEsdSha256)) {
  $actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $SourceEsdPath).Hash.ToLowerInvariant()
  if ($actualHash -ne $ExpectedEsdSha256.Trim().ToLowerInvariant()) {
    throw ("ESD SHA256 mismatch. expected=" + $ExpectedEsdSha256 + " actual=" + $actualHash)
  }
}

$logRoot = Join-Path $BuilderRunRoot "logs"
New-Dir $logRoot
$script:LogPath = Join-Path $logRoot "refresh-setup-bootwim.log"

$images = @(Get-WindowsImage -ImagePath $SourceEsdPath -ErrorAction Stop)
$setupImage = $images | Where-Object { ([string]$_.ImageName) -match "^Microsoft Windows Setup \(amd64\)$" } | Select-Object -First 1
if (-not $setupImage) {
  $setupImage = $images | Where-Object { ([string]$_.ImageName) -match "^Microsoft Windows Setup" } | Select-Object -First 1
}
if (-not $setupImage) {
  $setupImage = $images | Where-Object { ([string]$_.ImageName) -match "Setup \(amd64\)" } | Select-Object -First 1
}
if (-not $setupImage) {
  $setupImage = $images | Where-Object { ([string]$_.ImageName) -match "Windows Setup" } | Select-Object -First 1
}
if (-not $setupImage) {
  throw "No Setup boot image found in the ESD."
}
$setupIndex = [int]$setupImage.ImageIndex
Log ("Selected Setup boot image index " + $setupIndex + " => " + $setupImage.ImageName)

$stagingBootWim = Join-Path (Join-Path $BuilderRunRoot "staging") "boot.wim"
$mountDir = Join-Path (Join-Path $BuilderRunRoot "staging") "mount-setup-boot"
New-Dir (Split-Path -Parent $stagingBootWim)
New-Dir $mountDir
if (Test-Path -LiteralPath $stagingBootWim) {
  Remove-Item -LiteralPath $stagingBootWim -Force
}

Log ("Exporting Setup boot image to " + $stagingBootWim)
Invoke-CliStrict -FilePath "dism.exe" -ArgumentList @("/Export-Image", "/SourceImageFile:$SourceEsdPath", "/SourceIndex:$setupIndex", "/DestinationImageFile:$stagingBootWim", "/Compress:max", "/CheckIntegrity")

Log "Injecting retrying startnet.cmd into Setup boot.wim."
Invoke-CliStrict -FilePath "dism.exe" -ArgumentList @("/Mount-Image", "/ImageFile:$stagingBootWim", "/Index:1", "/MountDir:$mountDir")
try {
  Set-Content -LiteralPath (Join-Path $mountDir "Windows\System32\startnet.cmd") -Value (Get-StartnetContent) -Encoding ASCII
} finally {
  Invoke-CliStrict -FilePath "dism.exe" -ArgumentList @("/Unmount-Image", "/MountDir:$mountDir", "/Commit")
}

$usbBootWim = Join-Path ($usbLetter + ":\sources") "boot.wim"
New-Dir (Split-Path -Parent $usbBootWim)
if (Test-Path -LiteralPath $usbBootWim) {
  try { & attrib.exe -r -s -h $usbBootWim | Out-Null } catch {}
  Remove-Item -LiteralPath $usbBootWim -Force
}
Copy-Item -LiteralPath $stagingBootWim -Destination $usbBootWim -Force
New-Dir $InternalBootRoot
$internalBootWim = Join-Path $InternalBootRoot "boot.wim"
if (Test-Path -LiteralPath $internalBootWim) {
  try { & attrib.exe -r -s -h $internalBootWim | Out-Null } catch {}
  Remove-Item -LiteralPath $internalBootWim -Force
}
Copy-Item -LiteralPath $stagingBootWim -Destination $internalBootWim -Force

Log "Updated both USB and internal boot.wim with the official Setup boot image."
