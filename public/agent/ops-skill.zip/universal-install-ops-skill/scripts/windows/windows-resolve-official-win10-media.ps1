param(
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\WindowsReinstall",
  [string[]] $FwlinkIds = @("2156295", "2265055"),
  [switch] $DownloadTool,
  [string] $DownloadDirectory = ""
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}
Add-Type -AssemblyName System.Net.Http

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Invoke-HeaderProbe {
  param(
    [System.Net.Http.HttpClient] $Client,
    [string] $Url
  )

  $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Head, $Url)
  try {
    return $Client.SendAsync($request, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
  } catch {
    $request.Dispose()
    $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Get, $Url)
    return $Client.SendAsync($request, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
  }
}

function Resolve-FwlinkCandidate {
  param(
    [System.Net.Http.HttpClient] $Client,
    [string] $LinkId
  )

  $fwlinkUrl = "https://go.microsoft.com/fwlink/?linkid=" + $LinkId
  $fwlinkResponse = Invoke-HeaderProbe -Client $Client -Url $fwlinkUrl
  try {
    $redirectLocation = $null
    if ($fwlinkResponse.Headers.Location) {
      $redirectLocation = $fwlinkResponse.Headers.Location.ToString()
    }

    $targetStatusCode = $null
    $targetStatusText = $null
    if ($redirectLocation) {
      $targetResponse = Invoke-HeaderProbe -Client $Client -Url $redirectLocation
      try {
        $targetStatusCode = [int]$targetResponse.StatusCode
        $targetStatusText = [string]$targetResponse.ReasonPhrase
      } finally {
        $targetResponse.Dispose()
      }
    }

    return [pscustomobject]@{
      fwlinkId = $LinkId
      fwlinkUrl = $fwlinkUrl
      fwlinkStatusCode = [int]$fwlinkResponse.StatusCode
      fwlinkStatusText = [string]$fwlinkResponse.ReasonPhrase
      redirectLocation = $redirectLocation
      targetStatusCode = $targetStatusCode
      targetStatusText = $targetStatusText
      isLiveMediaTarget = [bool]($redirectLocation -and $targetStatusCode -ge 200 -and $targetStatusCode -lt 300)
    }
  } finally {
    $fwlinkResponse.Dispose()
  }
}

$resolverRoot = Join-Path $WorkspaceRoot "media-resolution"
$runRoot = Join-Path $resolverRoot (Get-Date -Format "yyyyMMdd-HHmmss")
New-Dir $runRoot

$handler = [System.Net.Http.HttpClientHandler]::new()
$handler.AllowAutoRedirect = $false
$client = [System.Net.Http.HttpClient]::new($handler)
$client.Timeout = [TimeSpan]::FromSeconds(60)
$client.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) CodexWin10Resolver/1.0")

try {
  $candidates = @()
  foreach ($linkId in $FwlinkIds) {
    $candidates += Resolve-FwlinkCandidate -Client $client -LinkId $linkId
  }

  $selected = $candidates | Where-Object { $_.isLiveMediaTarget } | Select-Object -First 1
  $downloadPath = $null

  if ($DownloadTool) {
    if (-not $selected) {
      throw "No live Windows 10 media tool target was resolved from the provided fwlinks."
    }
    if ([string]::IsNullOrWhiteSpace($DownloadDirectory)) {
      $DownloadDirectory = Join-Path $runRoot "downloads"
    }
    New-Dir $DownloadDirectory
    $downloadPath = Join-Path $DownloadDirectory "MediaCreationTool.exe"
    & curl.exe -L --fail --output $downloadPath $selected.fwlinkUrl
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $downloadPath)) {
      throw "curl.exe failed to download the Windows 10 media creation tool."
    }
  }

  $result = [ordered]@{
    status = if ($selected) { "resolved" } else { "unresolved" }
    createdAt = (Get-Date).ToString("o")
    runRoot = $runRoot
    candidates = $candidates
    selected = $selected
    downloadPath = $downloadPath
  }

  $resultPath = Join-Path $runRoot "result.json"
  Save-Json -Path $resultPath -Value $result
  Write-Output ("WINDOWS_10_MEDIA_RESULT=" + $resultPath)
} finally {
  $client.Dispose()
  $handler.Dispose()
}
