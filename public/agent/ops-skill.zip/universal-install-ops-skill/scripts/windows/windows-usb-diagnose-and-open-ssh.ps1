param(
  [string] $WorkspaceRoot = "C:\ProgramData\Soty\UsbRecovery",
  [switch] $CollectStageBundle = $false
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

function New-Dir([string] $Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) {
    throw "Directory path cannot be empty."
  }
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

function Save-Json([string] $Path, $Value) {
  Set-Content -LiteralPath $Path -Value ($Value | ConvertTo-Json -Depth 12) -Encoding UTF8
}

function Log([string] $Message) {
  $line = "[" + (Get-Date).ToString("o") + "] " + $Message
  Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
  Write-Output $line
}

function Capture-CommandOutput([string] $LiteralPath, [scriptblock] $Block) {
  try {
    $result = & $Block 2>&1 | Out-String
    Set-Content -LiteralPath $LiteralPath -Value $result -Encoding UTF8
  } catch {
    Set-Content -LiteralPath $LiteralPath -Value $_.Exception.ToString() -Encoding UTF8
  }
}

function Test-IsAdmin {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Resolve-BundleRoot {
  $root = Split-Path -Parent $PSScriptRoot
  if (-not (Test-Path -LiteralPath $root)) {
    throw "Bundle root not found."
  }
  return $root
}

function Write-LatestRunPointer([string] $BundleRoot, [string] $RunRoot) {
  $pointerPath = Join-Path $BundleRoot "results\LATEST-RUN.txt"
  Set-Content -LiteralPath $pointerPath -Value @(
    "Latest USB recovery run:"
    $RunRoot
  ) -Encoding UTF8
}

function Get-LeafUserName([string] $Identity) {
  if ([string]::IsNullOrWhiteSpace($Identity)) {
    return ""
  }
  $leaf = [string]$Identity
  if ($leaf.Contains("\")) {
    $leaf = $leaf.Split("\")[-1]
  }
  if ($leaf.Contains("/")) {
    $leaf = $leaf.Split("/")[-1]
  }
  return $leaf.Trim()
}

function Write-ConnectHints([string] $BundleRoot, [string] $RunRoot, [string] $CurrentUser) {
  $leafUser = Get-LeafUserName $CurrentUser
  $lines = @(
    "Soty USB Recovery SSH hints",
    "",
    "Current Windows user:",
    $CurrentUser,
    "",
    "Try this user first when old SSH aliases fail after reinstall:",
    $leafUser,
    "",
    "Template from the controller machine:",
    "ssh -b <controller-lan-ip> -i <controller-private-key> -l `"$leafUser`" <target-ip-or-host>",
    "",
    "This file intentionally does not contain passwords or private keys."
  )
  Set-Content -LiteralPath (Join-Path $RunRoot "CONNECT-INFO.txt") -Value $lines -Encoding UTF8
  Set-Content -LiteralPath (Join-Path $BundleRoot "CONNECT-INFO.txt") -Value $lines -Encoding UTF8
}

function Invoke-RepairScript([string] $RepairScriptPath, [string] $UsbDriveLetter) {
  if (-not (Test-Path -LiteralPath $RepairScriptPath)) {
    throw "Repair script not found at $RepairScriptPath"
  }
  Log ("Invoking SSH repair helper from " + $RepairScriptPath)
  $output = & $RepairScriptPath -UsbDriveLetter $UsbDriveLetter 2>&1 | Out-String
  Set-Content -LiteralPath (Join-Path $script:RunRoot "repair-script-output.txt") -Value $output -Encoding UTF8
  return $output
}

if (-not (Test-IsAdmin)) {
  throw "Please run this script from an elevated Administrator shell."
}

$bundleRoot = Resolve-BundleRoot
$usbDrive = ([System.IO.Path]::GetPathRoot($bundleRoot)).TrimEnd("\")
$usbDriveLetter = $usbDrive.TrimEnd(":")
$runId = Get-Date -Format "yyyyMMdd-HHmmss"
$script:RunRoot = Join-Path $bundleRoot ("results\" + $runId)
$localRunRoot = Join-Path $WorkspaceRoot $runId
New-Dir $script:RunRoot
New-Dir $localRunRoot
$script:LogPath = Join-Path $script:RunRoot "run.log"

$summary = [ordered]@{
  status = "started"
  createdAt = (Get-Date).ToString("o")
  bundleRoot = $bundleRoot
  usbDrive = $usbDrive
  usbDriveLetter = $usbDriveLetter
  runRoot = $script:RunRoot
  localRunRoot = $localRunRoot
  currentUser = [string][Security.Principal.WindowsIdentity]::GetCurrent().Name
  hostName = $env:COMPUTERNAME
  collectStageBundle = [bool]$CollectStageBundle
}

Log ("USB bundle root: " + $bundleRoot)
Log ("Local workspace root: " + $localRunRoot)

$preDir = Join-Path $script:RunRoot "pre"
$postDir = Join-Path $script:RunRoot "post"
New-Dir $preDir
New-Dir $postDir

Capture-CommandOutput -LiteralPath (Join-Path $preDir "whoami.txt") -Block { whoami /all }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "computer-info.txt") -Block { powershell -NoProfile -Command "Get-ComputerInfo | Format-List CsName,WindowsProductName,WindowsVersion,OsBuildNumber,OsHardwareAbstractionLayer,OsArchitecture" }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "ipconfig-all.txt") -Block { ipconfig /all }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "route-print.txt") -Block { route print }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "arp.txt") -Block { arp -a }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "net-adapter.txt") -Block { powershell -NoProfile -Command "Get-NetAdapter | Sort-Object Status,Name | Format-Table -AutoSize" }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "net-ipconfiguration.txt") -Block { powershell -NoProfile -Command "Get-NetIPConfiguration | Format-List *" }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "net-connection-profile.txt") -Block { powershell -NoProfile -Command "Get-NetConnectionProfile | Format-Table -AutoSize" }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "firewall-openssh.txt") -Block { powershell -NoProfile -Command "Get-NetFirewallRule -Name OpenSSH-Server-In-TCP -ErrorAction SilentlyContinue | Format-List *" }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "service-sshd.txt") -Block { powershell -NoProfile -Command "Get-Service sshd -ErrorAction SilentlyContinue | Format-List *" }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "wlan-interfaces.txt") -Block { netsh wlan show interfaces }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "wlan-profiles.txt") -Block { netsh wlan show profiles }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "powercfg-requests.txt") -Block { powercfg /requests }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "tcp-listen-22.txt") -Block { powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 22 -ErrorAction SilentlyContinue | Format-Table -AutoSize" }
Capture-CommandOutput -LiteralPath (Join-Path $preDir "openssh-event-log.txt") -Block {
  powershell -NoProfile -Command "$log='Microsoft-Windows-OpenSSH/Operational'; if (Get-WinEvent -ListLog $log -ErrorAction SilentlyContinue) { Get-WinEvent -LogName $log -MaxEvents 100 | Format-List TimeCreated,Id,LevelDisplayName,Message }"
}

$repairScriptPath = Join-Path $PSScriptRoot "windows-repair-ssh-return-path.ps1"
$repairOutput = $null
$repairError = $null
try {
  $repairOutput = Invoke-RepairScript -RepairScriptPath $repairScriptPath -UsbDriveLetter $usbDriveLetter
} catch {
  $repairError = $_.Exception.ToString()
  Set-Content -LiteralPath (Join-Path $script:RunRoot "repair-script-error.txt") -Value $repairError -Encoding UTF8
  Log ("SSH repair helper failed: " + $_.Exception.Message)
}

if ($CollectStageBundle) {
  $stageScriptPath = Join-Path $PSScriptRoot "windows-stage-bundle.ps1"
  if (Test-Path -LiteralPath $stageScriptPath) {
    try {
      Log "Collecting compact stage bundle."
      $archivePath = Join-Path $script:RunRoot "stage-bundle.zip"
      $stageOutput = & $stageScriptPath -WorkspaceRoot $localRunRoot -RunLabel "usb-recovery" -IncludeUserFiles:$false -ArchivePath $archivePath 2>&1 | Out-String
      Set-Content -LiteralPath (Join-Path $script:RunRoot "stage-bundle-output.txt") -Value $stageOutput -Encoding UTF8
    } catch {
      Log ("Stage bundle warning: " + $_.Exception.Message)
    }
  }
}

Capture-CommandOutput -LiteralPath (Join-Path $postDir "service-sshd.txt") -Block { powershell -NoProfile -Command "Get-Service sshd -ErrorAction SilentlyContinue | Format-List *" }
Capture-CommandOutput -LiteralPath (Join-Path $postDir "firewall-openssh.txt") -Block { powershell -NoProfile -Command "Get-NetFirewallRule -Name OpenSSH-Server-In-TCP -ErrorAction SilentlyContinue | Format-List *" }
Capture-CommandOutput -LiteralPath (Join-Path $postDir "tcp-listen-22.txt") -Block { powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 22 -ErrorAction SilentlyContinue | Format-Table -AutoSize" }
Capture-CommandOutput -LiteralPath (Join-Path $postDir "net-connection-profile.txt") -Block { powershell -NoProfile -Command "Get-NetConnectionProfile | Format-Table -AutoSize" }
Capture-CommandOutput -LiteralPath (Join-Path $postDir "ipconfig-all.txt") -Block { ipconfig /all }
Capture-CommandOutput -LiteralPath (Join-Path $postDir "route-print.txt") -Block { route print }
Capture-CommandOutput -LiteralPath (Join-Path $postDir "openssh-event-log.txt") -Block {
  powershell -NoProfile -Command "$log='Microsoft-Windows-OpenSSH/Operational'; if (Get-WinEvent -ListLog $log -ErrorAction SilentlyContinue) { Get-WinEvent -LogName $log -MaxEvents 100 | Format-List TimeCreated,Id,LevelDisplayName,Message }"
}

$summary["repairScriptPath"] = $repairScriptPath
$summary["repairOutputCaptured"] = [bool]$repairOutput
$summary["repairError"] = $repairError
$summary["completedAt"] = (Get-Date).ToString("o")
$summary["status"] = if ($repairError) { "completed_with_repair_error" } else { "completed" }
$summary["currentUserLeaf"] = Get-LeafUserName $summary.currentUser

$resultPath = Join-Path $script:RunRoot "result.json"
Save-Json -Path $resultPath -Value $summary
Copy-Item -LiteralPath $resultPath -Destination (Join-Path $localRunRoot "result.json") -Force
Write-LatestRunPointer -BundleRoot $bundleRoot -RunRoot $script:RunRoot
Write-ConnectHints -BundleRoot $bundleRoot -RunRoot $script:RunRoot -CurrentUser $summary.currentUser

Write-Output ""
Write-Output "DONE"
Write-Output ("Logs: " + $script:RunRoot)
Write-Output ("Result JSON: " + $resultPath)
