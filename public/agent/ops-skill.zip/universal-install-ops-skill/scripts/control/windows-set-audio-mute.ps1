[CmdletBinding()]
param(
  [ValidateSet("Mute", "Unmute", "Toggle", "Get")]
  [string]$Action = "Get"
)

$typeName = "UniversalInstallOps.AudioControl.EndpointVolume"
if (-not ([type]::GetType($typeName, $false))) {
  Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

namespace UniversalInstallOps.AudioControl {
  [Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IAudioEndpointVolume {
    int RegisterControlChangeNotify(IntPtr pNotify);
    int UnregisterControlChangeNotify(IntPtr pNotify);
    int GetChannelCount(out uint pnChannelCount);
    int SetMasterVolumeLevel(float fLevelDB, Guid pguidEventContext);
    int SetMasterVolumeLevelScalar(float fLevel, Guid pguidEventContext);
    int GetMasterVolumeLevel(out float pfLevelDB);
    int GetMasterVolumeLevelScalar(out float pfLevel);
    int SetChannelVolumeLevel(uint nChannel, float fLevelDB, Guid pguidEventContext);
    int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, Guid pguidEventContext);
    int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
    int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
    int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, Guid pguidEventContext);
    int GetMute(out bool pbMute);
    int GetVolumeStepInfo(out uint pnStep, out uint pnStepCount);
    int VolumeStepUp(Guid pguidEventContext);
    int VolumeStepDown(Guid pguidEventContext);
    int QueryHardwareSupport(out uint pdwHardwareSupportMask);
    int GetVolumeRange(out float pflVolumeMindB, out float pflVolumeMaxdB, out float pflVolumeIncrementdB);
  }

  [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IMMDevice {
    int Activate(ref Guid iid, int dwClsCtx, IntPtr pActivationParams, [MarshalAs(UnmanagedType.Interface)] out object ppInterface);
  }

  [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IMMDeviceEnumerator {
    int NotImpl1();
    int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice ppDevice);
  }

  public static class EndpointVolume {
    private static IAudioEndpointVolume Open() {
      Type enumeratorType = Type.GetTypeFromCLSID(new Guid("BCDE0395-E52F-467C-8E3D-C4579291692E"));
      IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)Activator.CreateInstance(enumeratorType);
      IMMDevice device;
      Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(0, 1, out device));
      Guid iid = typeof(IAudioEndpointVolume).GUID;
      object endpoint;
      Marshal.ThrowExceptionForHR(device.Activate(ref iid, 23, IntPtr.Zero, out endpoint));
      return (IAudioEndpointVolume)endpoint;
    }

    public static bool GetMute() {
      bool muted;
      Marshal.ThrowExceptionForHR(Open().GetMute(out muted));
      return muted;
    }

    public static bool SetMute(bool mute) {
      var endpoint = Open();
      Marshal.ThrowExceptionForHR(endpoint.SetMute(mute, Guid.Empty));
      bool muted;
      Marshal.ThrowExceptionForHR(endpoint.GetMute(out muted));
      return muted;
    }
  }
}
"@
}

$muted = switch ($Action) {
  "Mute" { [UniversalInstallOps.AudioControl.EndpointVolume]::SetMute($true) }
  "Unmute" { [UniversalInstallOps.AudioControl.EndpointVolume]::SetMute($false) }
  "Toggle" { [UniversalInstallOps.AudioControl.EndpointVolume]::SetMute(-not [UniversalInstallOps.AudioControl.EndpointVolume]::GetMute()) }
  default { [UniversalInstallOps.AudioControl.EndpointVolume]::GetMute() }
}

[pscustomobject]@{
  Action = $Action
  Muted = $muted
} | ConvertTo-Json -Compress
