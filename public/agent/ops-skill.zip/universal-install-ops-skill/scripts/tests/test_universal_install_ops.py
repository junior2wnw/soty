from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path


def find_skill_root() -> Path:
    for candidate in Path(__file__).resolve().parents:
        if (candidate / "SKILL.md").exists():
            return candidate
    raise RuntimeError("Could not find skill root")


SKILL_ROOT = find_skill_root()
SCRIPTS = SKILL_ROOT / "scripts"
CASE = SCRIPTS / "case"
LEARNING = SCRIPTS / "learning"
ROUTING = SCRIPTS / "routing"
SKILL = SCRIPTS / "skill"
WINDOWS = SCRIPTS / "windows"


def run_script(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        [sys.executable, *args],
        cwd=str(SKILL_ROOT),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if check and result.returncode != 0:
        raise AssertionError(
            f"command failed: {args}\nexit={result.returncode}\nstdout={result.stdout}\nstderr={result.stderr}"
        )
    return result


def test_case_validator() -> None:
    with tempfile.TemporaryDirectory() as temp:
        workspace = Path(temp)
        created = run_script(
            str(CASE / "init_case.py"),
            "--workspace",
            str(workspace),
            "--title",
            "Validator Smoke",
            "--platform",
            "linux",
            "--intent",
            "repair",
            "--target-kind",
            "service",
            "--transport",
            "ssh",
            "--environment",
            "linux service repair over ssh",
        ).stdout.strip()
        case_dir = Path(created)
        loose = run_script(str(CASE / "validate_case.py"), str(case_dir), check=True)
        assert "warnings:" in loose.stdout

        strict_fail = run_script(str(CASE / "validate_case.py"), str(case_dir), "--strict", check=False)
        assert strict_fail.returncode == 1
        assert "rollback_route" in strict_fail.stdout
        assert "decision_facts" in strict_fail.stdout

        case_json = case_dir / "case.json"
        data = json.loads(case_json.read_text(encoding="utf-8"))
        data.update(
            {
                "active_owner": "agent",
                "allowed_next_state_change": "restart service after config syntax check",
                "handoff_proof": "systemctl status returns healthy",
                "return_path": "ssh remains connected",
                "rollback_route": "restore previous config export",
                "abort_triggers": ["config test fails"],
                "artifact_provenance": ["local config backup before change"],
                "last_verified_fact": "service exists",
                "decision_facts": [
                    {
                        "statement": "Config syntax check passes on the exact service host",
                        "scope": "hard-gate",
                        "evidence_quality": "live-observed",
                        "freshness": "current",
                        "target_fit": "exact",
                        "goal_fit": "controlling",
                        "polarity": "supports",
                        "source_ref": "journalctl and configtest output",
                    }
                ],
            }
        )
        data["environment"]["transport_next"] = "ssh"
        data["route_selection"]["primary"] = "native service repair"
        data["route_selection"]["evidence_quality"] = "live-observed"
        case_json.write_text(f"{json.dumps(data, indent=2)}\n", encoding="utf-8")

        score = run_script(str(CASE / "score_case_facts.py"), str(case_dir), "--write", check=True)
        assert "top_supporting:" in score.stdout

        strict_ok = run_script(str(CASE / "validate_case.py"), str(case_dir), "--strict", check=True)
        assert "ok" in strict_ok.stdout


def test_score_case_facts() -> None:
    with tempfile.TemporaryDirectory() as temp:
        workspace = Path(temp)
        created = run_script(
            str(CASE / "init_case.py"),
            "--workspace",
            str(workspace),
            "--title",
            "Fact Score Smoke",
            "--platform",
            "network",
            "--intent",
            "configure",
            "--target-kind",
            "network",
            "--transport",
            "ssh",
            "--environment",
            "router policy update over ssh",
        ).stdout.strip()
        case_dir = Path(created)
        case_json = case_dir / "case.json"
        data = json.loads(case_json.read_text(encoding="utf-8"))
        data["decision_facts"] = [
            {
                "statement": "Current config export succeeded on the exact router",
                "scope": "hard-gate",
                "evidence_quality": "live-observed",
                "freshness": "current",
                "target_fit": "exact",
                "goal_fit": "controlling",
                "polarity": "supports",
                "source_ref": "scp export",
            },
            {
                "statement": "A similar managed-family model accepted the same command last week",
                "scope": "platform-or-family",
                "evidence_quality": "case-observed",
                "freshness": "recent",
                "target_fit": "same-family",
                "goal_fit": "direct",
                "polarity": "supports",
                "source_ref": "recent family case note",
            },
            {
                "statement": "The change window is almost over and rollback would be manual",
                "scope": "hard-gate",
                "evidence_quality": "case-observed",
                "freshness": "current",
                "target_fit": "exact",
                "goal_fit": "controlling",
                "polarity": "blocks",
                "source_ref": "operator note",
            },
        ]
        case_json.write_text(f"{json.dumps(data, indent=2)}\n", encoding="utf-8")

        result = run_script(str(CASE / "score_case_facts.py"), str(case_dir), "--write", check=True)
        assert "has_unmet_hard_gate: True" in result.stdout
        assert "route_status: blocked" in result.stdout
        assert "transfer-scope-missing-shared-dimensions" in result.stdout
        assert "record-shared-dimensions" in result.stdout
        updated = json.loads(case_json.read_text(encoding="utf-8"))
        facts = updated["decision_facts"]
        assert facts[0]["computed_weight"] > facts[1]["computed_weight"]
        assert updated["weighted_fact_summary"]["top_blocking"][0]["statement"].startswith("The change window")
        assert updated["weighted_fact_summary"]["review_flags"]
        assert updated["weighted_fact_summary"]["recommended_actions"]


def test_record_case_fact() -> None:
    with tempfile.TemporaryDirectory() as temp:
        workspace = Path(temp)
        created = run_script(
            str(CASE / "init_case.py"),
            "--workspace",
            str(workspace),
            "--title",
            "Fact Record Smoke",
            "--platform",
            "linux",
            "--intent",
            "configure",
            "--target-kind",
            "service",
            "--transport",
            "ssh",
            "--environment",
            "service config over ssh",
        ).stdout.strip()
        case_dir = Path(created)

        first = run_script(
            str(CASE / "record_case_fact.py"),
            str(case_dir),
            "--statement",
            "Exact host config lint passes",
            "--scope",
            "exact-target",
            "--evidence-quality",
            "live-observed",
            "--freshness",
            "current",
            "--target-fit",
            "exact",
            "--goal-fit",
            "controlling",
            "--polarity",
            "supports",
            "--source-ref",
            "configtest output",
            "--shared-dimensions",
            "same distro family, same systemd manager",
            check=True,
        )
        assert "fact_count: 1" in first.stdout

        second = run_script(
            str(CASE / "record_case_fact.py"),
            str(case_dir),
            "--statement",
            "Rollback still depends on a manual operator",
            "--scope",
            "case-local",
            "--evidence-quality",
            "case-observed",
            "--freshness",
            "current",
            "--target-fit",
            "exact",
            "--goal-fit",
            "direct",
            "--polarity",
            "caution",
            "--source-ref",
            "operator handoff note",
            check=True,
        )
        assert "fact_count: 2" in second.stdout

        updated = json.loads((case_dir / "case.json").read_text(encoding="utf-8"))
        assert len(updated["decision_facts"]) == 2
        assert updated["decision_facts"][0]["shared_dimensions"] == ["same distro family", "same systemd manager"]
        assert updated["weighted_fact_summary"]["top_caution"][0]["statement"].startswith("Rollback still depends")
        assert updated["weighted_fact_summary"]["route_status"] in {"supported", "tentative"}


def test_record_route_property_and_adjustment() -> None:
    with tempfile.TemporaryDirectory() as temp:
        workspace = Path(temp)
        created = run_script(
            str(CASE / "init_case.py"),
            "--workspace",
            str(workspace),
            "--title",
            "Route Property Smoke",
            "--platform",
            "windows",
            "--intent",
            "prepare_media",
            "--target-kind",
            "media",
            "--transport",
            "local-shell",
            "--environment",
            "windows usb media preparation",
        ).stdout.strip()
        case_dir = Path(created)

        predicted = run_script(
            str(CASE / "record_route_property.py"),
            str(case_dir),
            "--name",
            "usb.supports_large_files",
            "--expected-value",
            "true",
            "--chance",
            "0.8",
            "--scope",
            "exact-target",
            "--evidence-quality",
            "live-observed",
            "--freshness",
            "current",
            "--target-fit",
            "exact",
            "--goal-fit",
            "direct",
            "--source-ref",
            "volume filesystem probe",
            "--probe",
            "read filesystem and large-file capability",
            "--route-when-expected",
            "use direct install.wim",
            "--route-when-unexpected",
            "split install.wim",
            check=True,
        )
        assert "result: unchecked" in predicted.stdout
        assert "route_decision: use direct install.wim" in predicted.stdout

        observed = run_script(
            str(CASE / "record_route_property.py"),
            str(case_dir),
            "--name",
            "usb.supports_large_files",
            "--expected-value",
            "true",
            "--chance",
            "0.8",
            "--scope",
            "exact-target",
            "--evidence-quality",
            "live-observed",
            "--freshness",
            "current",
            "--target-fit",
            "exact",
            "--goal-fit",
            "direct",
            "--source-ref",
            "volume filesystem probe",
            "--probe",
            "read filesystem and large-file capability",
            "--observed-value",
            "false",
            "--proof",
            "target volume reported FAT32",
            "--route-when-expected",
            "use direct install.wim",
            "--route-when-unexpected",
            "split install.wim",
            check=True,
        )
        assert "result: disconfirmed" in observed.stdout
        assert "route_decision: split install.wim" in observed.stdout
        assert "route_property_count: 1" in observed.stdout

        score = run_script(str(CASE / "score_case_facts.py"), str(case_dir), "--write", check=True)
        assert "top_route_properties:" in score.stdout
        assert "route-property-disconfirmed" in score.stdout

        updated = json.loads((case_dir / "case.json").read_text(encoding="utf-8"))
        prop = updated["route_properties"][0]
        assert prop["result"] == "disconfirmed"
        assert prop["adjusted_chance"] < 0.2
        assert updated["route_property_summary"]["top_likely_unexpected"][0]["route_decision"] == "split install.wim"


def test_record_control_fact_and_surface_summary() -> None:
    with tempfile.TemporaryDirectory() as temp:
        workspace = Path(temp)
        created = run_script(
            str(CASE / "init_case.py"),
            "--workspace",
            str(workspace),
            "--title",
            "Control Record Smoke",
            "--platform",
            "linux",
            "--intent",
            "configure",
            "--target-kind",
            "service",
            "--transport",
            "local-shell",
            "--environment",
            "desktop media control with repeated audio actions",
        ).stdout.strip()
        case_dir = Path(created)

        first = run_script(
            str(CASE / "record_control_fact.py"),
            str(case_dir),
            "--action",
            "stop music",
            "--target",
            "system media session",
            "--control-plane",
            "gui",
            "--method",
            "open player widget and press pause",
            "--observable-success",
            "playback widget shows paused",
            "--result",
            "works",
            "--step-count",
            "3",
            "--friction",
            "medium",
            "--scope",
            "platform-or-family",
            "--evidence-quality",
            "case-observed",
            "--freshness",
            "recent",
            "--target-fit",
            "same-family",
            "--goal-fit",
            "direct",
            "--source-ref",
            "prior desktop runbook",
            check=True,
        )
        assert "chat_marker: control-memory:" in first.stdout

        second = run_script(
            str(CASE / "record_control_fact.py"),
            str(case_dir),
            "--action",
            "stop music",
            "--target",
            "system media session",
            "--control-plane",
            "local-shell",
            "--method",
            "playerctl pause",
            "--observable-success",
            "playerctl metadata reports paused state",
            "--result",
            "works",
            "--step-count",
            "1",
            "--friction",
            "low",
            "--scope",
            "exact-target",
            "--evidence-quality",
            "live-observed",
            "--freshness",
            "current",
            "--target-fit",
            "exact",
            "--goal-fit",
            "direct",
            "--source-ref",
            "playerctl output",
            check=True,
        )
        assert "control_fact_count: 2" in second.stdout

        score = run_script(str(CASE / "score_case_facts.py"), str(case_dir), "--write", check=True)
        assert "top_control_routes:" in score.stdout
        assert "control-transfer-missing-shared-dimensions" in score.stdout
        assert "record-control-shared-dimensions" in score.stdout

        updated = json.loads((case_dir / "case.json").read_text(encoding="utf-8"))
        assert len(updated["control_facts"]) == 2
        assert updated["control_fact_summary"]["top_surface_routes"][0]["method"] == "playerctl pause"
        assert updated["control_fact_summary"]["best_by_action"][0]["best_control_plane"] == "local-shell"
        assert updated["control_fact_summary"]["best_by_action"][0]["chat_marker"].startswith("control-memory:")


def test_record_learning_scope_and_sanitization() -> None:
    with tempfile.TemporaryDirectory() as temp:
        notes = Path(temp) / "field-notes.md"
        notes.write_text("# Field Notes\n\n## Proven\n\n## Failed\n\n## Unclear\n", encoding="utf-8")
        result = run_script(
            str(LEARNING / "record_learning.py"),
            "--bucket",
            "proven",
            "--domain",
            "universal-test",
            "--route-role",
            "primary",
            "--scope",
            "universal-pattern",
            "--evidence-quality",
            "case-observed",
            "--shared-dimensions",
            "same package manager, same runtime",
            "--pattern",
            "test learning works",
            "--environment",
            "temporary test notes",
            "--rationale",
            "keeps helper aligned with note schema",
            "--notes-file",
            str(notes),
        )
        assert "scope: universal-pattern" in result.stdout
        assert "evidence: case-observed" in notes.read_text(encoding="utf-8")
        assert "shared: same package manager, same runtime" in notes.read_text(encoding="utf-8")

        rejected = run_script(
            str(LEARNING / "record_learning.py"),
            "--bucket",
            "failed",
            "--domain",
            "universal-test",
            "--pattern",
            "private address should fail",
            "--environment",
            "host at 192.168.1.5",
            "--rationale",
            "sanitization",
            "--notes-file",
            str(notes),
            check=False,
        )
        assert rejected.returncode != 0
        assert "private IPv4" in rejected.stderr

        rejected_mac = run_script(
            str(LEARNING / "record_learning.py"),
            "--bucket",
            "failed",
            "--domain",
            "universal-test",
            "--pattern",
            "mac address should fail",
            "--environment",
            "nic 00:11:22:33:44:55",
            "--rationale",
            "sanitization",
            "--notes-file",
            str(notes),
            check=False,
        )
        assert rejected_mac.returncode != 0
        assert "MAC address" in rejected_mac.stderr

        rejected_path = run_script(
            str(LEARNING / "record_learning.py"),
            "--bucket",
            "failed",
            "--domain",
            "universal-test",
            "--pattern",
            "private path should fail",
            "--environment",
            r"workspace C:\Users\Alice\secret",
            "--rationale",
            "sanitization",
            "--notes-file",
            str(notes),
            check=False,
        )
        assert rejected_path.returncode != 0
        assert "private path" in rejected_path.stderr


def test_validate_case_requires_hard_gate_for_database_scale_work() -> None:
    with tempfile.TemporaryDirectory() as temp:
        workspace = Path(temp)
        created = run_script(
            str(CASE / "init_case.py"),
            "--workspace",
            str(workspace),
            "--title",
            "Database Validator Smoke",
            "--platform",
            "linux",
            "--intent",
            "configure",
            "--target-kind",
            "database",
            "--transport",
            "ssh",
            "--environment",
            "database failover configuration over ssh",
        ).stdout.strip()
        case_dir = Path(created)
        case_json = case_dir / "case.json"
        data = json.loads(case_json.read_text(encoding="utf-8"))
        data.update(
            {
                "status": "ready",
                "active_owner": "agent",
                "allowed_next_state_change": "apply replication config after exact validation",
                "handoff_proof": "replication health checks pass",
                "return_path": "ssh remains connected",
                "rollback_route": "restore previous replication config snapshot",
                "abort_triggers": ["replication validation fails"],
                "artifact_provenance": ["database config export before edit"],
                "destructive_scope": "service interruption possible during failover reconfiguration",
                "last_verified_fact": "cluster members reachable",
                "decision_facts": [
                    {
                        "statement": "A similar cluster revision accepted this replication mode last month",
                        "scope": "platform-or-family",
                        "evidence_quality": "case-observed",
                        "freshness": "recent",
                        "target_fit": "same-family",
                        "goal_fit": "supporting",
                        "polarity": "supports",
                        "source_ref": "prior cluster case",
                        "shared_dimensions": ["same database engine", "same replication topology"],
                    }
                ],
            }
        )
        data["environment"]["transport_next"] = "ssh"
        data["route_selection"]["primary"] = "native cluster reconfiguration"
        data["route_selection"]["evidence_quality"] = "case-observed"
        case_json.write_text(f"{json.dumps(data, indent=2)}\n", encoding="utf-8")

        run_script(str(CASE / "score_case_facts.py"), str(case_dir), "--write", check=True)
        strict_fail = run_script(str(CASE / "validate_case.py"), str(case_dir), "--strict", check=False)
        assert strict_fail.returncode == 1
        assert "decision_facts.hard-gate" in strict_fail.stdout

        updated = json.loads(case_json.read_text(encoding="utf-8"))
        updated["decision_facts"].append(
            {
                "statement": "Exact cluster preflight validates config on the current primary",
                "scope": "hard-gate",
                "evidence_quality": "live-observed",
                "freshness": "current",
                "target_fit": "exact",
                "goal_fit": "controlling",
                "polarity": "supports",
                "source_ref": "db config test output",
            }
        )
        case_json.write_text(f"{json.dumps(updated, indent=2)}\n", encoding="utf-8")
        run_script(str(CASE / "score_case_facts.py"), str(case_dir), "--write", check=True)
        strict_ok = run_script(str(CASE / "validate_case.py"), str(case_dir), "--strict", check=True)
        assert "ok" in strict_ok.stdout


def test_field_notes_maintenance() -> None:
    with tempfile.TemporaryDirectory() as temp:
        notes = Path(temp) / "field-notes.md"
        notes.write_text(
            "\n".join(
                [
                    "# Field Notes",
                    "",
                    "## Proven",
                    "",
                    "- 2026-01-01 | proven | test | duplicate body | env: test env | why",
                    "- 2026-01-01 | proven | test | duplicate body | env: test env | why",
                    "",
                    "## Failed",
                    "orphan fragment without note prefix",
                    "",
                    "## Unclear",
                    "",
                    "- 2025-01-01 | unclear | test | old unclear | env: test env | why",
                    "",
                ]
            ),
            encoding="utf-8",
        )
        result = run_script(
            str(LEARNING / "maintain_field_notes.py"),
            "--notes-file",
            str(notes),
            "--stale-days",
            "30",
            "--fail-on-findings",
            check=False,
        )
        assert result.returncode == 2
        assert "Duplicate signatures" in result.stdout
        assert "Orphan note fragments" in result.stdout
        assert "Stale `unclear`" in result.stdout


def test_skill_factory_scaffold_and_validation() -> None:
    with tempfile.TemporaryDirectory() as temp:
        created = run_script(
            str(SKILL / "scaffold_skill.py"),
            temp,
            "--name",
            "proxy-normalizer",
            "--trigger",
            "the user asks to normalize a proxy list into a reusable file workflow",
            "--outcome",
            "a normalized proxy output with no network calls",
            "--with-script",
            check=True,
        )
        skill_dir = Path(created.stdout.strip())
        assert (skill_dir / "SKILL.md").exists()
        assert (skill_dir / "scripts" / "main.py").exists()

        validation = run_script(
            str(SKILL / "validate_skill_package.py"),
            str(skill_dir),
            "--strict",
            check=True,
        )
        assert "Skill Package Validation" in validation.stdout
        assert "errors:\n  - none" in validation.stdout


def test_route_shelf_selects_skill_factory() -> None:
    result = run_script(
        str(ROUTING / "route_shelf.py"),
        "создай тулз из текущего диалога и опубликуй skill repo",
        "--top",
        "1",
        check=True,
    )
    assert "skill-tool-factory" in result.stdout
    assert "references/skill-factory.md" in result.stdout


def test_route_hot_and_activation_eval() -> None:
    one_command = run_script(
        str(SCRIPTS / "ops.py"),
        "выключи звук",
        "--json",
        check=True,
    )
    one_command_data = json.loads(one_command.stdout)
    assert one_command_data["shelf"]["id"] == "control-surfaces"
    assert one_command_data["hot_route"]["id"] == "windows-audio-mute"
    assert one_command_data["helper"]["id"] == "windows-audio-mute"
    assert one_command_data["helper_fit"] == "run"
    assert one_command_data["source_state"] in {"canonical-repo", "installed-only"}
    assert one_command_data["route_metrics"]["has_hot_route"] is True
    assert one_command_data["route_metrics"]["read_count"] <= 3
    assert one_command_data["route_metrics"]["helper_fit"] == "run"
    assert "-Action Mute" in one_command_data["helper"]["run"]
    assert one_command_data["reflex_card"]["first"].startswith("run ops.py")
    assert "learning_delta" in one_command_data["reflex_card"]["done"]
    voice_text = "\n".join(one_command_data["voice"])
    assert "quality:" in voice_text
    assert "reflex:" in voice_text
    assert "probability:" in voice_text
    assert "--remember" in voice_text
    ready_gate_text = "\n".join(one_command_data["ready_gate"])
    assert "stop:" in ready_gate_text
    assert "reusable fact appeared" in ready_gate_text
    assert "lower-probability outcome" in ready_gate_text
    assert "write:" in ready_gate_text
    assert one_command_data["action_packet"]["do_now"].startswith("run helper")
    assert "--checkpoint" in one_command_data["action_packet"]["checkpoint"]
    assert "--remember" in one_command_data["action_packet"]["remember"]
    assert "--proof" in one_command_data["action_packet"]["remember"]
    assert "learning_delta=no-op" in one_command_data["action_packet"]["remember"]
    assert "--close" in one_command_data["action_packet"]["close"]
    assert "final_line" in one_command_data["action_packet"]["close"]
    assert "checkpoint_gate" in one_command_data

    token_route = run_script(
        str(SCRIPTS / "ops.py"),
        "optimize ops skill token usage without losing quality",
        check=True,
    )
    assert "- route: shelf=agent-runtime-skill-ops hot=ops-mission-optimization" in token_route.stdout
    assert "- read_first:" in token_route.stdout
    assert "- reflex: do_now first;" in token_route.stdout
    assert "- do_now: follow hot route ops-mission-optimization" in token_route.stdout
    assert "- close:" in token_route.stdout
    assert "final_line" in token_route.stdout
    assert "- voice:" not in token_route.stdout
    assert "- ready_gate:" not in token_route.stdout
    assert "- more: use --detail or --json" in token_route.stdout
    assert len(token_route.stdout.splitlines()) <= 14
    assert max(len(line) for line in token_route.stdout.splitlines()) <= 260

    detail_route = run_script(
        str(SCRIPTS / "ops.py"),
        "optimize ops skill token usage without losing quality",
        "--detail",
        check=True,
    )
    assert "- voice:" in detail_route.stdout
    assert "- ready_gate:" in detail_route.stdout
    assert "- action_packet:" in detail_route.stdout

    not_best_route = run_script(
        str(SCRIPTS / "ops.py"),
        "сделай скилл гораздо лучше как будто для себя, до этого были не самые лучшие решения",
        "--json",
        check=True,
    )
    not_best_data = json.loads(not_best_route.stdout)
    assert not_best_data["hot_route"]["id"] == "ops-mission-optimization"
    assert not_best_data["helper_fit"] in {"candidate", "none"}
    assert not_best_data["action_packet"]["do_now"].startswith("follow hot route ops-mission-optimization")

    candidate_helper = run_script(
        str(SCRIPTS / "ops.py"),
        "make ops skill better with genius simplicity, the simplest solution with maximum result",
        check=True,
    )
    assert "fit=candidate" in candidate_helper.stdout
    assert "- run:" not in candidate_helper.stdout
    assert "do_now: follow hot route ops-mission-optimization" in candidate_helper.stdout

    broad_quality = run_script(
        str(SCRIPTS / "ops.py"),
        "why is the ops skill not working as needed; assess its behavior and fix the desire mismatch",
        "--json",
        check=True,
    )
    broad_quality_data = json.loads(broad_quality.stdout)
    assert broad_quality_data["hot_route"]["id"] == "ops-mission-optimization"
    assert broad_quality_data["route_profile"] is None or broad_quality_data["route_profile"]["profile_id"] == "ops-universal-improvement-contract"

    reflex_mismatch = run_script(
        str(SCRIPTS / "ops.py"),
        "Почему же скилл ops не работает так как нужно? Оцени рефлексы всех аспектов скилла",
        "--json",
        check=True,
    )
    reflex_mismatch_data = json.loads(reflex_mismatch.stdout)
    assert reflex_mismatch_data["hot_route"]["id"] == "ops-mission-optimization"
    assert reflex_mismatch_data["reflex_card"]["learn"].startswith("patch")

    self_improvement = run_script(
        str(SCRIPTS / "ops.py"),
        "why does the ops skill not improve after each Windows reinstall, what if we are in another repo or only have an installed-only skill; make the self-improvement sink happen in the skill without saving raw dialogs",
        "--json",
        check=True,
    )
    self_improvement_data = json.loads(self_improvement.stdout)
    assert self_improvement_data["shelf"]["id"] == "agent-runtime-skill-ops"
    assert self_improvement_data["hot_route"]["id"] == "ops-self-improvement-sink"
    assert self_improvement_data["action_packet"]["do_now"].startswith("follow hot route ops-self-improvement-sink")
    assert not self_improvement_data["guards"]
    assert self_improvement_data["source_state"] in {"canonical-repo", "installed-only"}
    assert self_improvement_data["route_metrics"]["has_hot_route"] is True
    assert self_improvement_data["route_profile"]["profile_id"] == "ops-universal-improvement-contract"

    session_locator_route = run_script(
        str(SCRIPTS / "ops.py"),
        "find Codex chat links from local session files and avoid useless line 1 links",
        "--json",
        check=True,
    )
    session_locator_data = json.loads(session_locator_route.stdout)
    assert session_locator_data["shelf"]["id"] == "agent-runtime-skill-ops"
    assert session_locator_data["hot_route"]["id"] == "codex-session-locator"
    assert session_locator_data["helper"]["id"] == "codex-session-locator"
    assert session_locator_data["helper_fit"] == "run"
    assert session_locator_data["action_packet"]["do_now"].startswith("run helper codex-session-locator")

    soty_windows_fast_lane = run_script(
        str(SCRIPTS / "ops.py"),
        "make Windows reinstall through Soty faster without reinventing the route",
        "--json",
        check=True,
    )
    soty_windows_fast_lane_data = json.loads(soty_windows_fast_lane.stdout)
    assert soty_windows_fast_lane_data["shelf"]["id"] == "windows-reinstall-recovery"
    assert soty_windows_fast_lane_data["hot_route"]["id"] == "windows-reinstall-fast-lane"
    assert soty_windows_fast_lane_data["helper"]["id"] == "windows-reinstall-profile"
    assert soty_windows_fast_lane_data["helper_fit"] == "run"

    soty_encoded_fallback = run_script(
        str(SCRIPTS / "ops.py"),
        "Большой preflight-командный блок не прошел через PWA как один EncodedCommand; разбиваю на короткие чтения",
        "--json",
        check=True,
    )
    soty_encoded_fallback_data = json.loads(soty_encoded_fallback.stdout)
    assert soty_encoded_fallback_data["shelf"]["id"] == "agent-runtime-skill-ops"
    assert soty_encoded_fallback_data["hot_route"]["id"] == "soty-operator-bridge"
    assert "remember" in soty_encoded_fallback_data["action_packet"]

    with tempfile.TemporaryDirectory() as temp:
        profile_store = Path(temp) / "route-profiles.jsonl"
        run_script(
            str(LEARNING / "route_profile.py"),
            "--action",
            "upsert",
            "--profile-id",
            "service-repair-fast-lane",
            "--shelf",
            "package-service-stack",
            "--task-family",
            "service repair",
            "--platform-family",
            "Linux service runtime",
            "--control-plane",
            "SSH shell",
            "--route",
            "check status, restart service, verify health",
            "--proof",
            "service reports healthy",
            "--transfer-boundary",
            "same service manager and health endpoint pattern",
            "--store",
            str(profile_store),
            check=True,
        )
        stale_profile = {
            "updated_at": "2000-01-01T00:00:00Z",
            "profile_id": "service-repair-fast-lane",
            "shelf": "package-service-stack",
            "task_family": "service repair",
            "platform_family": "Linux service runtime",
            "control_plane": "SSH shell",
            "route": "stale broad rediscovery route",
            "proof": "old proof",
            "transfer_boundary": "old boundary",
            "metrics": {"minutes": {"known": False}, "steps": {"known": False}, "tokens": {"known": False}},
        }
        with profile_store.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(stale_profile, ensure_ascii=False, sort_keys=True) + "\n")
        profiled_route = run_script(
            str(SCRIPTS / "ops.py"),
            "repair linux service through ssh",
            "--profile-store",
            str(profile_store),
            "--json",
            check=True,
        )
        profiled_route_data = json.loads(profiled_route.stdout)
        assert profiled_route_data["route_profile"]["profile_id"] == "service-repair-fast-lane"
        assert profiled_route_data["route_profile"]["route"].startswith("check status")
        assert "service-repair-fast-lane" in profiled_route_data["action_packet"]["profile"]
        assert profiled_route_data["optimization_contract"]["reuse"].endswith("service-repair-fast-lane")

    with tempfile.TemporaryDirectory() as temp:
        close_queue = Path(temp) / "close-candidates.jsonl"
        close = run_script(
            str(SCRIPTS / "ops.py"),
            "skill self improvement close gate",
            "--close",
            "--actual",
            "patched ops.py close gate and tests",
            "--success",
            "regression test proves final line",
            "--env",
            "canonical ops skill repo",
            "--queue",
            str(close_queue),
            check=True,
        )
        assert "Ops Close" in close.stdout
        assert "learning_delta:" in close.stdout
        assert "- final_line: learning_delta=" in close.stdout
        assert "regression test proves final line" in close.stdout

        close_json = run_script(
            str(SCRIPTS / "ops.py"),
            "skill self improvement close gate",
            "--close",
            "--actual",
            "patched ops.py close gate and tests",
            "--success",
            "regression test proves final line",
            "--env",
            "canonical ops skill repo",
            "--queue",
            str(close_queue),
            "--json",
            check=True,
        )
        close_data = json.loads(close_json.stdout)
        assert close_data["mode"] == "close"
        assert close_data["final_line"].startswith("learning_delta=")

        explicit_close = run_script(
            str(SCRIPTS / "ops.py"),
            "skill explicit patch close gate",
            "--close",
            "--actual",
            "patch",
            "--success",
            "finish_skill_edit passed",
            "--env",
            "canonical ops skill repo",
            "--queue",
            str(close_queue),
            check=True,
        )
        assert "learning_delta: patch" in explicit_close.stdout
        assert "final_line: learning_delta=patch" in explicit_close.stdout
        assert "written: False" in explicit_close.stdout

    close_missing = run_script(
        str(SCRIPTS / "ops.py"),
        "skill self improvement close gate",
        "--close",
        "--actual",
        "missing proof should fail",
        "--env",
        "canonical ops skill repo",
        check=False,
    )
    assert close_missing.returncode == 2
    assert "--close requires" in close_missing.stderr

    universal = run_script(
        str(SCRIPTS / "ops.py"),
        "доведи ops skill до идеала и универсальности",
        "--json",
        check=True,
    )
    universal_data = json.loads(universal.stdout)
    assert universal_data["shelf"]["id"] == "agent-runtime-skill-ops"
    assert universal_data["hot_route"]["id"] == "ops-universalization-gate"
    assert universal_data["action_packet"]["do_now"].startswith("follow hot route ops-universalization-gate")
    assert "branch_gate" in universal_data
    assert "--branch" in universal_data["branch_gate"]["record"]

    not_universal = run_script(
        str(SCRIPTS / "ops.py"),
        "что-то не то и почему-то не универсально все в скилле",
        "--json",
        check=True,
    )
    not_universal_data = json.loads(not_universal.stdout)
    assert not_universal_data["shelf"]["id"] == "agent-runtime-skill-ops"
    assert not_universal_data["hot_route"]["id"] == "ops-universalization-gate"

    reconsider = run_script(
        str(SCRIPTS / "ops.py"),
        "memory became dogma; the remembered best route is not best anymore",
        "--json",
        check=True,
    )
    reconsider_data = json.loads(reconsider.stdout)
    assert reconsider_data["shelf"]["id"] == "learning-memory"
    assert reconsider_data["hot_route"]["id"] == "memory-reconsideration-gate"
    assert reconsider_data["action_packet"]["do_now"].startswith("follow hot route memory-reconsideration-gate")

    branch_route = run_script(
        str(SCRIPTS / "ops.py"),
        "current situation proves written rule is not best; make a controlled branch",
        "--json",
        check=True,
    )
    branch_route_data = json.loads(branch_route.stdout)
    assert branch_route_data["shelf"]["id"] == "learning-memory"
    assert branch_route_data["hot_route"]["id"] == "situational-branch-gate"
    assert branch_route_data["action_packet"]["do_now"].startswith("follow hot route situational-branch-gate")
    assert "ops.py" in branch_route_data["action_packet"]["branch"]
    assert "--branch" in branch_route_data["action_packet"]["branch"]

    continuity = run_script(
        str(SCRIPTS / "ops.py"),
        "агент по мере работы забывает про скилл и перестает им пользоваться и улучшать ветки",
        "--json",
        check=True,
    )
    continuity_data = json.loads(continuity.stdout)
    assert continuity_data["shelf"]["id"] == "agent-runtime-skill-ops"
    assert continuity_data["hot_route"]["id"] == "ops-continuity-checkpoint"
    assert continuity_data["helper_fit"] == "run"
    assert continuity_data["helper"]["id"] == "ops-checkpoint"
    assert "<task>" not in continuity_data["helper"]["run"]
    assert continuity_data["task"] in continuity_data["helper"]["run"]
    assert continuity_data["action_packet"]["do_now"].startswith("run helper ops-checkpoint")

    checkpoint = run_script(
        str(SCRIPTS / "ops.py"),
        "repair docker service on remote linux host",
        "--checkpoint",
        "--json",
        check=True,
    )
    checkpoint_data = json.loads(checkpoint.stdout)
    assert checkpoint_data["mode"] == "checkpoint"
    assert checkpoint_data["checkpoint"]["status"] == "skill-continuity-active"
    assert "branch" in checkpoint_data["checkpoint"]["branch_check"]
    assert "memory" in checkpoint_data["checkpoint"]["memory_check"]
    assert "branch_gate" in checkpoint_data

    with tempfile.TemporaryDirectory() as checkpoint_temp:
        checkpoint_queue = Path(checkpoint_temp) / "candidate-facts.jsonl"
        checkpoint_capture = run_script(
            str(SCRIPTS / "ops.py"),
            "repair docker service on remote linux host",
            "--checkpoint",
            "--expected",
            "foreground repair command",
            "--actual",
            "background job artifact is required after HTTP timeout",
            "--success",
            "artifact contains healthy service status",
            "--env",
            "remote Linux service repair",
            "--route-changed",
            "--queue",
            str(checkpoint_queue),
            "--write",
            "--json",
            check=True,
        )
        checkpoint_capture_data = json.loads(checkpoint_capture.stdout)
        assert checkpoint_capture_data["mode"] == "checkpoint"
        assert checkpoint_capture_data["checkpoint_memory"]["should_record"] is True
        assert checkpoint_capture_data["checkpoint_memory"]["written"] is True
        assert checkpoint_queue.exists()

    script = run_script(
        str(SCRIPTS / "find_script.py"),
        "need to check skill health and installed copy sync",
        "--top",
        "1",
        check=True,
    )
    assert "skill-health" in script.stdout
    assert "scripts/skill/skill_health.py" in script.stdout

    compiler_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "compile memory queue before pruning candidate facts",
        "--shelf",
        "learning-memory",
        "--top",
        "1",
        check=True,
    )
    assert "compile-memory-queue" in compiler_script.stdout
    assert "scripts/learning/compile_memory_queue.py" in compiler_script.stdout

    conveyor_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "run learning conveyor health gate",
        "--shelf",
        "learning-memory",
        "--top",
        "1",
        check=True,
    )
    assert "learning-conveyor" in conveyor_script.stdout
    assert "scripts/learning/learning_conveyor.py" in conveyor_script.stdout

    learning_review_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "show what the skill learned recently and profile token savings",
        "--shelf",
        "learning-memory",
        "--top",
        "1",
        check=True,
    )
    assert "learning-review" in learning_review_script.stdout
    assert "scripts/learning/learning_review.py" in learning_review_script.stdout

    teacher_query = "\u0442\u0438\u0447\u0435\u0440 \u0440\u0435\u0432\u044c\u044e \u0438 \u043c\u0435\u0440\u0436 \u0432 ops"
    teacher_route = run_script(str(SCRIPTS / "ops.py"), teacher_query, "--json", check=True)
    teacher_route_data = json.loads(teacher_route.stdout)
    assert teacher_route_data["shelf"]["id"] == "learning-memory"
    assert teacher_route_data["hot_route"]["id"] == "soty-teacher-review-gate"
    assert teacher_route_data["helper_fit"] == "run"
    assert teacher_route_data["helper"]["id"] == "ingest-teacher-report"
    assert "teacher-report.json" in teacher_route_data["helper"]["run"]

    teacher_script = run_script(
        str(SCRIPTS / "find_script.py"),
        teacher_query,
        "--shelf",
        "learning-memory",
        "--top",
        "1",
        "--json",
        check=True,
    )
    teacher_script_data = json.loads(teacher_script.stdout)
    assert teacher_script_data["scripts"][0]["id"] == "ingest-teacher-report"
    assert "scripts/learning/ingest_teacher_report.py" in teacher_script_data["scripts"][0]["run"].replace("\\", "/")

    profile_generic_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "store reusable route profile with token savings",
        "--shelf",
        "learning-memory",
        "--top",
        "1",
        check=True,
    )
    assert "route-profile" in profile_generic_script.stdout
    assert "scripts/learning/route_profile.py" in profile_generic_script.stdout

    review_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "review memory because the remembered best route is not best anymore",
        "--shelf",
        "learning-memory",
        "--top",
        "1",
        check=True,
    )
    assert "review-memory" in review_script.stdout
    assert "scripts/learning/review_memory.py" in review_script.stdout

    branch_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "make a controlled branch because the written rule is not best here",
        "--shelf",
        "learning-memory",
        "--top",
        "1",
        check=True,
    )
    assert "route-branch" in branch_script.stdout
    assert "scripts/learning/route_branch.py" in branch_script.stdout

    sync_doctor_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "run sync doctor before one way skill copy sync",
        "--shelf",
        "agent-runtime-skill-ops",
        "--top",
        "1",
        check=True,
    )
    assert "sync-doctor" in sync_doctor_script.stdout
    assert "scripts/skill/sync_doctor.py" in sync_doctor_script.stdout

    checkpoint_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "agent forgets ops skill during long work",
        "--shelf",
        "agent-runtime-skill-ops",
        "--top",
        "1",
        "--json",
        check=True,
    )
    checkpoint_script_data = json.loads(checkpoint_script.stdout)
    checkpoint_run = checkpoint_script_data["scripts"][0]["run"]
    assert checkpoint_script_data["scripts"][0]["id"] == "ops-checkpoint"
    assert "<task>" not in checkpoint_run
    assert "agent forgets ops skill during long work" in checkpoint_run

    finish_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "не гениально и не просто, с трудом; заверши правку скилла одной командой",
        "--shelf",
        "agent-runtime-skill-ops",
        "--top",
        "1",
        "--json",
        check=True,
    )
    finish_script_data = json.loads(finish_script.stdout)
    assert finish_script_data["scripts"][0]["id"] == "finish-skill-edit"
    assert "scripts/skill/finish_skill_edit.py" in finish_script_data["scripts"][0]["run"].replace("\\", "/")

    profile_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "read the windows reinstall profile before fast lane work",
        "--shelf",
        "windows-reinstall-recovery",
        "--top",
        "1",
        check=True,
    )
    assert "windows-reinstall-profile" in profile_script.stdout
    assert "scripts/windows/windows-reinstall-profile.py" in profile_script.stdout

    mute_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "выключи звук",
        "--shelf",
        "control-surfaces",
        "--top",
        "1",
        check=True,
    )
    assert "windows-audio-mute" in mute_script.stdout
    assert "run:" in mute_script.stdout
    assert "absolute_path:" in mute_script.stdout
    assert "scripts/control/windows-set-audio-mute.ps1" in mute_script.stdout
    assert "-Action Mute" in mute_script.stdout
    assert "-Muted" not in mute_script.stdout

    unmute_script = run_script(
        str(SCRIPTS / "find_script.py"),
        "ты не включил звук, верни звук",
        "--shelf",
        "control-surfaces",
        "--top",
        "1",
        check=True,
    )
    assert "windows-audio-unmute" in unmute_script.stdout
    assert "-Action Unmute" in unmute_script.stdout
    assert "windows-audio-mute score" not in unmute_script.stdout

    no_match = run_script(
        str(SCRIPTS / "find_script.py"),
        "zzqv unmatched qqqx",
        "--top",
        "1",
        check=True,
    )
    assert "- no scripts matched" in no_match.stdout

    long_package = run_script(
        str(SCRIPTS / "ops.py"),
        "почини docker stack на удаленном сервере, задача может быть долгой",
        "--json",
        check=True,
    )
    long_package_data = json.loads(long_package.stdout)
    assert long_package_data["hot_route"]["id"] == "package-service-repair"
    assert long_package_data["guards"]
    assert "awake-preflight" in long_package_data["guards"][0]
    assert any(item.startswith("guard:") for item in long_package_data["voice"])

    long_local = run_script(
        str(SCRIPTS / "ops.py"),
        "установи большой пакет на удаленном ноутбуке",
        "--json",
        check=True,
    )
    long_local_data = json.loads(long_local.stdout)
    assert long_local_data["hot_route"]["id"] == "package-service-repair"
    assert long_local_data["guards"]
    assert "awake-preflight" in long_local_data["guards"][0]

    safe_concurrency = run_script(
        str(SCRIPTS / "ops.py"),
        "make helper scripts async where safe but do not risk ordered state changes",
        "--json",
        check=True,
    )
    safe_concurrency_data = json.loads(safe_concurrency.stdout)
    assert safe_concurrency_data["shelf"]["id"] == "general-routing"
    assert safe_concurrency_data["hot_route"]["id"] == "safe-concurrency"
    assert not safe_concurrency_data["guards"]

    route = run_script(
        str(ROUTING / "route_hot.py"),
        "переустанови Windows и сохрани путь возврата по SSH",
        "--top",
        "1",
        check=True,
    )
    assert "windows-reinstall-safe-branch" in route.stdout
    assert "windows-reinstall-recovery" in route.stdout

    sleep_route = run_script(
        str(ROUTING / "route_hot.py"),
        "задача большая на удаленном компе, сначала проверь что он не уснет",
        "--top",
        "1",
        check=True,
    )
    assert "sleep-preflight" in sleep_route.stdout
    assert "general-routing" in sleep_route.stdout

    unmute_route = run_script(
        str(ROUTING / "route_hot.py"),
        "unmute audio",
        "--top",
        "1",
        check=True,
    )
    assert "windows-audio-unmute" in unmute_route.stdout
    assert "windows-audio-mute" not in unmute_route.stdout

    activation = run_script(str(ROUTING / "evaluate_activation.py"), check=True)
    assert "Activation Eval" in activation.stdout
    assert "failure_count: 0" in activation.stdout

    self_check = run_script(str(SKILL / "self_check.py"), check=True)
    assert "Ops Self Check" in self_check.stdout
    assert "failure_count: 0" in self_check.stdout


def test_memory_queue_scripts() -> None:
    with tempfile.TemporaryDirectory() as temp:
        memory_dir = Path(temp)
        candidate_queue = memory_dir / "candidate-facts.jsonl"
        missed_queue = memory_dir / "missed-invocations.jsonl"

        queued = run_script(
            str(LEARNING / "ingest_memory_marker.py"),
            "ops-memory: goal=skill routing default failed; winning=add activation eval; success=evaluate_activation passes; env=codex skill repo",
            "--queue",
            str(candidate_queue),
            "--source",
            "test",
            check=True,
        )
        assert "queued:" in queued.stdout
        candidate = json.loads(candidate_queue.read_text(encoding="utf-8").splitlines()[0])
        assert candidate["type"] == "ops-memory"
        assert candidate["shelf"]

        rejected = run_script(
            str(LEARNING / "ingest_memory_marker.py"),
            "ops-memory: host at 192.168.1.5 should not be shared",
            "--queue",
            str(candidate_queue),
            check=False,
        )
        assert rejected.returncode == 1
        assert "private IPv4" in rejected.stderr

        rejected_path = run_script(
            str(LEARNING / "ingest_memory_marker.py"),
            r"ops-memory: actual=python C:\Users\Alice\secret\tool.py",
            "--queue",
            str(candidate_queue),
            check=False,
        )
        assert rejected_path.returncode == 1
        assert "private path" in rejected_path.stderr

        teacher_report = memory_dir / "teacher-report.json"
        clean_marker = (
            "ops-memory: goal=teacher review route | "
            "actual=ingest teacher report queues sanitized candidates | "
            "success=compile queue sees candidate | env=ops skill repo"
        )
        profile_marker = (
            "ops-memory: goal=windows profile gate | "
            "actual=teacher suggested doctor route | "
            "success=doctor blocks missing gates | env=ops skill repo"
        )
        teacher_report.write_text(
            json.dumps(
                {
                    "teacher": {
                        "schema": "soty.teacher.v1",
                        "receipts": 4,
                        "candidates": [
                            {"scope": "promote", "family": r"C:\\Users\\Alice\\secret", "marker": clean_marker},
                            {"scope": "promote", "family": "duplicate", "marker": clean_marker},
                            {"scope": "profile", "family": "windows reinstall profile", "marker": profile_marker},
                            {"scope": "candidate", "family": "unsafe", "marker": "ops-memory: host at 192.168.1.5 should not be shared"},
                        ],
                    }
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        teacher_dry = run_script(
            str(LEARNING / "ingest_teacher_report.py"),
            str(teacher_report),
            "--queue",
            str(candidate_queue),
            "--json",
            check=True,
        )
        teacher_dry_data = json.loads(teacher_dry.stdout)
        assert teacher_dry_data["mode"] == "dry-run"
        assert teacher_dry_data["accepted_count"] == 2
        assert teacher_dry_data["skipped_count"] == 2
        assert teacher_dry_data["rows"][0]["record"]["teacher_family"] == ""
        assert any(row.get("reason") == "already queued" for row in teacher_dry_data["rows"])
        assert any("private IPv4" in row.get("reason", "") for row in teacher_dry_data["rows"])

        teacher_write = run_script(
            str(LEARNING / "ingest_teacher_report.py"),
            str(teacher_report),
            "--queue",
            str(candidate_queue),
            "--write",
            "--json",
            check=True,
        )
        teacher_write_data = json.loads(teacher_write.stdout)
        assert teacher_write_data["mode"] == "write"
        assert teacher_write_data["accepted_count"] == 2
        queue_rows = [json.loads(line) for line in candidate_queue.read_text(encoding="utf-8").splitlines()]
        assert any(row.get("source") == "soty.teacher" and row.get("marker") == clean_marker for row in queue_rows)

        missed = run_script(
            str(LEARNING / "record_missed_invocation.py"),
            "создай маленький workflow skill из диалога",
            "--expected-shelf",
            "skill-tool-factory",
            "--reason",
            "test prompt miss",
            "--queue",
            str(missed_queue),
            check=True,
        )
        assert "fix_hint:" in missed.stdout
        missed_row = json.loads(missed_queue.read_text(encoding="utf-8").splitlines()[0])
        assert missed_row["expected_shelf"] == "skill-tool-factory"
        assert missed_row["trigger_terms"]

        summary = run_script(
            str(LEARNING / "summarize_memory_queue.py"),
            "--memory-dir",
            str(memory_dir),
            check=True,
        )
        assert "candidate_count: 3" in summary.stdout
        assert "missed_invocation_count: 1" in summary.stdout

        compile_dir = memory_dir / "compile"
        compile_dir.mkdir()
        compile_queue = compile_dir / "candidate-facts.jsonl"
        notes = compile_dir / "field-notes.md"
        covered_marker = (
            "ops-memory: goal=skill close gate | "
            "actual=ops close final learning delta proof route stays concrete | "
            "success=final line printed | env=canonical skill repo"
        )
        keep_marker = (
            "ops-memory: goal=audio route | "
            "actual=windows-audio-mute helper from catalog | "
            "success=Muted true | env=Windows local PowerShell"
        )
        compile_rows = [
            {"type": "ops-memory", "shelf": "agent-runtime-skill-ops", "marker": covered_marker},
            {"type": "ops-memory", "shelf": "control-surfaces", "marker": keep_marker},
        ]
        compile_queue.write_text(
            "\n".join(json.dumps(row, ensure_ascii=False) for row in compile_rows) + "\n",
            encoding="utf-8",
        )
        notes.write_text(
            "# Field Notes\n\n## Proven\n\n"
            "- 2026-05-04 | proven | agent-runtime-skill-ops | "
            "ops close final learning delta proof route stays concrete | "
            "env: canonical skill repo | scope: universal-pattern | evidence: case-observed\n",
            encoding="utf-8",
        )
        compiled = run_script(
            str(LEARNING / "compile_memory_queue.py"),
            "--memory-dir",
            str(compile_dir),
            "--notes-file",
            str(notes),
            "--json",
            check=True,
        )
        compiled_data = json.loads(compiled.stdout)
        assert compiled_data["decision_counts"]["covered"] == 1
        assert compiled_data["decision_counts"]["keep"] == 1

        written_compile = run_script(
            str(LEARNING / "compile_memory_queue.py"),
            "--memory-dir",
            str(compile_dir),
            "--notes-file",
            str(notes),
            "--write-reviewed",
            check=True,
        )
        assert "wrote_reviewed: True" in written_compile.stdout
        remaining_rows = compile_queue.read_text(encoding="utf-8").splitlines()
        assert len(remaining_rows) == 1
        assert "windows-audio-mute helper" in remaining_rows[0]
        assert (compile_dir / "reviewed-candidate-facts.jsonl").exists()

        reviewed_memory = run_script(
            str(LEARNING / "review_memory.py"),
            "--belief",
            "audio route default",
            "--old-best",
            "hand-written audio control snippet",
            "--new-best",
            "cataloged windows-audio-mute helper",
            "--reason",
            "helper is shorter and returns JSON proof",
            "--proof",
            "Muted true returned",
            "--env",
            "Windows local PowerShell default audio endpoint",
            "--store",
            str(compile_dir / "memory-revisions.jsonl"),
            "--json",
            check=True,
        )
        reviewed_memory_data = json.loads(reviewed_memory.stdout)
        assert reviewed_memory_data["revision"]["decision"] == "supersede"
        assert reviewed_memory_data["revision_count"] == 1

        rejected_memory = run_script(
            str(LEARNING / "review_memory.py"),
            "--belief",
            "private route should fail",
            "--old-best",
            "ssh to 192.168.1.5",
            "--new-best",
            "cataloged helper",
            "--reason",
            "sanitization",
            "--proof",
            "blocked",
            "--env",
            "test",
            "--store",
            str(compile_dir / "memory-revisions.jsonl"),
            check=False,
        )
        assert rejected_memory.returncode == 1
        assert "private IPv4" in rejected_memory.stderr

        recorded_branch = run_script(
            str(LEARNING / "route_branch.py"),
            "--parent-rule",
            "always follow the cataloged helper first",
            "--branch",
            "use hot route only because helper is candidate in this exact case",
            "--conditions",
            "helper fit is candidate and hot route has exact proof",
            "--reason",
            "branch avoids running a near-match helper",
            "--proof",
            "route_hot selected exact gate",
            "--env",
            "canonical ops skill repo",
            "--rollback",
            "return to parent rule if exact proof is absent",
            "--store",
            str(compile_dir / "route-branches.jsonl"),
            "--json",
            check=True,
        )
        recorded_branch_data = json.loads(recorded_branch.stdout)
        assert recorded_branch_data["branch"]["status"] == "candidate"
        assert recorded_branch_data["branch_count"] == 1

        ops_branch = run_script(
            str(SCRIPTS / "ops.py"),
            "use hot route only because helper is candidate in this exact case",
            "--branch",
            "--parent-rule",
            "always follow the cataloged helper first",
            "--conditions",
            "helper fit is candidate and hot route has exact proof",
            "--success",
            "route_hot selected exact gate",
            "--env",
            "canonical ops skill repo",
            "--rollback",
            "return to parent rule if exact proof is absent",
            "--branch-store",
            str(compile_dir / "route-branches.jsonl"),
            "--json",
            check=True,
        )
        ops_branch_data = json.loads(ops_branch.stdout)
        assert ops_branch_data["mode"] == "branch"
        assert ops_branch_data["learning_delta"] == "branch-candidate"
        assert ops_branch_data["final_line"].startswith("learning_delta=branch-candidate")
        assert ops_branch_data["branch_count"] == 2

        missing_rollback_branch = run_script(
            str(LEARNING / "route_branch.py"),
            "--parent-rule",
            "default safe rule",
            "--branch",
            "risky branch",
            "--conditions",
            "test",
            "--reason",
            "test",
            "--proof",
            "test",
            "--env",
            "test",
            "--risk",
            "high",
            "--store",
            str(compile_dir / "route-branches.jsonl"),
            check=False,
        )
        assert missing_rollback_branch.returncode == 1
        assert "--rollback is required" in missing_rollback_branch.stderr

        rejected_branch = run_script(
            str(LEARNING / "route_branch.py"),
            "--parent-rule",
            "ssh route",
            "--branch",
            "connect to 192.168.1.5",
            "--conditions",
            "test",
            "--reason",
            "sanitization",
            "--proof",
            "blocked",
            "--env",
            "test",
            "--risk",
            "low",
            "--store",
            str(compile_dir / "route-branches.jsonl"),
            check=False,
        )
        assert rejected_branch.returncode == 1
        assert "private IPv4" in rejected_branch.stderr

        profile_store = compile_dir / "route-profiles.jsonl"
        conveyor = run_script(
            str(LEARNING / "learning_conveyor.py"),
            "--memory-dir",
            str(compile_dir),
            "--notes-file",
            str(notes),
            "--profile-store",
            str(profile_store),
            "--json",
            check=True,
        )
        conveyor_data = json.loads(conveyor.stdout)
        assert conveyor_data["compile"]["ok"] is True
        assert conveyor_data["compile"]["decision_counts"]["keep"] == 1
        assert conveyor_data["revisions"]["revision_count"] == 1
        assert conveyor_data["revisions"]["decision_counts"]["supersede"] == 1
        assert conveyor_data["branches"]["branch_count"] == 2
        assert conveyor_data["branches"]["status_counts"]["candidate"] == 2
        assert conveyor_data["profiles"]["profile_count"] == 0
        assert any("route profiles" in item for item in conveyor_data["recommendations"])
        assert any("route branches" in item for item in conveyor_data["recommendations"])

        learning_review_without_profile = run_script(
            str(LEARNING / "learning_review.py"),
            "--memory-dir",
            str(compile_dir),
            "--notes-file",
            str(notes),
            "--profile-store",
            str(profile_store),
            "--json",
            check=True,
        )
        learning_review_without_profile_data = json.loads(learning_review_without_profile.stdout)
        assert learning_review_without_profile_data["action_required"] is True
        assert any("route profiles" in item for item in learning_review_without_profile_data["review_actions"])

        profile_for_review = run_script(
            str(LEARNING / "route_profile.py"),
            "--action",
            "upsert",
            "--profile-id",
            "audio-mute-fast-lane",
            "--shelf",
            "learning-memory",
            "--task-family",
            "audio mute",
            "--platform-family",
            "Windows default endpoint",
            "--control-plane",
            "local PowerShell",
            "--route",
            "windows-audio-mute helper",
            "--proof",
            "JSON output contains Muted true",
            "--transfer-boundary",
            "same Windows audio endpoint model",
            "--baseline-steps",
            "5",
            "--actual-steps",
            "1",
            "--baseline-tokens",
            "1000",
            "--actual-tokens",
            "200",
            "--baseline-quality",
            "6",
            "--actual-quality",
            "8",
            "--baseline-safety",
            "7",
            "--actual-safety",
            "9",
            "--baseline-simplicity",
            "4",
            "--actual-simplicity",
            "8",
            "--baseline-universality",
            "5",
            "--actual-universality",
            "7",
            "--store",
            str(profile_store),
            "--json",
            check=True,
        )
        profile_for_review_data = json.loads(profile_for_review.stdout)
        assert profile_for_review_data["profile_count"] == 1

        learning_review = run_script(
            str(LEARNING / "learning_review.py"),
            "--memory-dir",
            str(compile_dir),
            "--notes-file",
            str(notes),
            "--profile-store",
            str(profile_store),
            "--json",
            check=True,
        )
        learning_review_data = json.loads(learning_review.stdout)
        assert learning_review_data["counts"]["route_profiles"] == 1
        assert learning_review_data["counts"]["route_branches"] == 2
        assert learning_review_data["savings"]["steps"]["saved"] == 4.0
        assert learning_review_data["savings"]["tokens"]["saved"] == 800.0
        assert learning_review_data["savings"]["quality"]["gained"] == 2.0
        assert learning_review_data["savings"]["safety"]["gained"] == 2.0
        assert learning_review_data["savings"]["simplicity"]["gained"] == 4.0
        assert learning_review_data["savings"]["universality"]["gained"] == 2.0
        assert learning_review_data["action_required"] is True
        assert any("candidate route branch" in item for item in learning_review_data["review_actions"])

        advice = run_script(
            str(LEARNING / "memory_loop.py"),
            "mute audio without wasting route lookup",
            "--result",
            "works",
            "--expected",
            "hand-written CoreAudio snippet",
            "--actual",
            "windows-audio-mute helper from find_script run line",
            "--success",
            "JSON output contains Muted true",
            "--env",
            "Windows local PowerShell with default render endpoint",
            "--queue",
            str(candidate_queue),
            "--write",
            check=True,
        )
        assert "should_record: True" in advice.stdout
        assert "written: True" in advice.stdout
        assert "ops-memory:" in advice.stdout

        lookup = run_script(
            str(LEARNING / "memory_loop.py"),
            "mute audio route",
            "--mode",
            "before",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "candidate-queue" in lookup.stdout
        assert "windows-audio-mute helper" in lookup.stdout

        during = run_script(
            str(LEARNING / "memory_loop.py"),
            "repair service while discovering route associations",
            "--mode",
            "during",
            "--result",
            "partial",
            "--expected",
            "restart service first",
            "--actual",
            "config lint failure -> fix config -> restart service should transfer to same service manager",
            "--success",
            "config lint now passes",
            "--env",
            "Linux systemd service repair over SSH",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "mode: during" in during.stdout
        assert "should_record: True" in during.stdout
        assert "written: True" in during.stdout
        assert "during-work fact" in during.stdout

        ops_during = run_script(
            str(SCRIPTS / "ops.py"),
            "repair service while discovering route associations",
            "--during",
            "--result",
            "partial",
            "--expected",
            "restart service first",
            "--actual",
            "config lint failure -> fix config -> restart service should transfer to same service manager",
            "--success",
            "config lint now passes",
            "--env",
            "Linux systemd service repair over SSH",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "mode: during" in ops_during.stdout
        assert "should_record: True" in ops_during.stdout
        assert "learning_delta: marker-present" in ops_during.stdout
        assert "written: False" in ops_during.stdout

        remember_shortcut = run_script(
            str(SCRIPTS / "ops.py"),
            "repair service while discovering route associations",
            "--remember",
            "config lint failure -> fix config -> restart service should transfer to same service manager",
            "--proof",
            "config lint now passes",
            "--env",
            "Linux systemd service repair over SSH",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "mode: during" in remember_shortcut.stdout
        assert "should_record: True" in remember_shortcut.stdout
        assert "written: True" in remember_shortcut.stdout
        assert "config lint failure" in remember_shortcut.stdout

        audio_lookup = run_script(
            str(LEARNING / "memory_loop.py"),
            "проверить звук через ops",
            "--mode",
            "before",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "windows-control-audio" in audio_lookup.stdout

        proved_success = run_script(
            str(LEARNING / "memory_loop.py"),
            "routine read-only route check",
            "--result",
            "works",
            "--expected",
            "route_shelf",
            "--actual",
            "route_shelf",
            "--success",
            "shelf printed",
            "--env",
            "local skill repo",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "should_record: True" in proved_success.stdout
        assert "proved success" in proved_success.stdout
        assert "written: True" in proved_success.stdout

        before_duplicate = candidate_queue.read_text(encoding="utf-8").splitlines()
        duplicate_success = run_script(
            str(LEARNING / "memory_loop.py"),
            "routine read-only route check",
            "--result",
            "works",
            "--expected",
            "route_shelf",
            "--actual",
            "route_shelf",
            "--success",
            "shelf printed",
            "--env",
            "local skill repo",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        after_duplicate = candidate_queue.read_text(encoding="utf-8").splitlines()
        assert "learning_delta: marker-present" in duplicate_success.stdout
        assert "written: False" in duplicate_success.stdout
        assert len(after_duplicate) == len(before_duplicate)

        prediction_error = run_script(
            str(LEARNING / "memory_loop.py"),
            "choose the route with highest success chance",
            "--mode",
            "during",
            "--expected",
            "large command should work",
            "--actual",
            "lower-probability fallback happened and short probes worked",
            "--success",
            "short probes returned stable state",
            "--env",
            "Soty PWA command transport",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "prediction-error outcome" in prediction_error.stdout
        assert "written: True" in prediction_error.stdout

        no_record = run_script(
            str(LEARNING / "memory_loop.py"),
            "routine read-only route check",
            "--result",
            "works",
            "--expected",
            "route_shelf",
            "--actual",
            "route_shelf",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "should_record: False" in no_record.stdout

        auto_cache = run_script(
            str(LEARNING / "memory_loop.py"),
            "install package without rediscovering the command",
            "--result",
            "works",
            "--actual",
            "python -m pip install rich && python -c import rich",
            "--success",
            "import rich succeeded",
            "--env",
            "Windows PowerShell Python venv",
            "--queue",
            str(candidate_queue),
            "--write",
            check=True,
        )
        assert "should_record: True" in auto_cache.stdout
        assert "reusable command/helper route" in auto_cache.stdout
        assert "written: True" in auto_cache.stdout

        solved_dialog = run_script(
            str(LEARNING / "memory_loop.py"),
            "ты много нового узнал в этом диалоге, почему не записываешь для следующего раза и других ОС",
            "--result",
            "works",
            "--actual",
            "default failed, same-family fallback worked and should transfer to other OS when package manager and privilege model match",
            "--success",
            "health check passed after fallback",
            "--env",
            "Windows PowerShell package workflow with same-family CLI fallback",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "should_record: True" in solved_dialog.stdout
        assert "solved-dialog transfer" in solved_dialog.stdout

        sink = run_script(
            str(LEARNING / "memory_loop.py"),
            "why does the skill not improve after each Windows reinstall",
            "--result",
            "works",
            "--expected",
            "raw dialog links",
            "--actual",
            "self-improvement sink ladder: module patch, field note, candidate marker, final marker",
            "--success",
            "activation route resolves to ops-self-improvement-sink",
            "--env",
            "canonical ops skill repo",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "should_record: True" in sink.stdout
        assert ("source_state: canonical-repo" in sink.stdout) or ("source_state: installed-or-bundled-skill" in sink.stdout)
        assert "learning_delta: patch-required" in sink.stdout
        assert (
            "learning_sink: canonical-repo: patch the relevant module/script/hot route or case fact" in sink.stdout
        ) or (
            "learning_sink: installed-or-bundled-skill: patch the relevant module/script/hot route or case fact" in sink.stdout
        )

        no_op = run_script(
            str(LEARNING / "memory_loop.py"),
            "routine route check with no reusable learning",
            "--result",
            "works",
            "--expected",
            "route_shelf",
            "--actual",
            "route_shelf",
            "--queue",
            str(candidate_queue),
            check=True,
        )
        assert "should_record: False" in no_op.stdout
        assert "learning_delta: no-op" in no_op.stdout


def test_windows_reinstall_profile_helper() -> None:
    with tempfile.TemporaryDirectory() as temp:
        store = Path(temp) / "profiles.jsonl"
        upsert = run_script(
            str(WINDOWS / "windows-reinstall-profile.py"),
            "--action",
            "upsert",
            "--profile-id",
            "lab-laptop-family",
            "--device-family",
            "generic UEFI laptop",
            "--control-plane",
            "local operator plus key-based SSH after setup",
            "--return-path",
            "OpenSSH service verified after first boot",
            "--media-state",
            "official Windows 11 USB prepared and labeled",
            "--working-route",
            "boot USB, custom install, then restore SSH worker",
            "--proof",
            "previous run reached Windows desktop and SSH login",
            "--store",
            str(store),
            "--json",
            check=True,
        )
        upsert_data = json.loads(upsert.stdout)
        assert upsert_data["ok"] is True
        assert upsert_data["profile"]["profile_id"] == "lab-laptop-family"

        fetched = run_script(
            str(WINDOWS / "windows-reinstall-profile.py"),
            "--action",
            "get",
            "--profile-id",
            "lab-laptop-family",
            "--store",
            str(store),
            "--json",
            check=True,
        )
        fetched_data = json.loads(fetched.stdout)
        assert fetched_data["found"] is True
        assert fetched_data["profile"]["working_route"].startswith("boot USB")

        summary = run_script(
            str(WINDOWS / "windows-reinstall-profile.py"),
            "--action",
            "summary",
            "--store",
            str(store),
            check=True,
        )
        assert "profile_count: 1" in summary.stdout
        assert "lab-laptop-family" in summary.stdout

        doctor_needs_explicit_gates = run_script(
            str(WINDOWS / "windows-reinstall-profile.py"),
            "--action",
            "doctor",
            "--profile-id",
            "lab-laptop-family",
            "--data-boundary",
            "proven",
            "--bitlocker-safe",
            "na",
            "--machine-worker",
            "na",
            "--operator-handoff",
            "na",
            "--destructive-confirmation",
            "proven",
            "--store",
            str(store),
            "--json",
            check=False,
        )
        doctor_needs_explicit_gates_data = json.loads(doctor_needs_explicit_gates.stdout)
        assert doctor_needs_explicit_gates.returncode == 1
        assert doctor_needs_explicit_gates_data["lane"] == "readiness_building"
        assert doctor_needs_explicit_gates_data["gates"]["exact_target"]["state"] == "proven"
        assert doctor_needs_explicit_gates_data["gates"]["trusted_media"]["state"] == "unknown"
        assert doctor_needs_explicit_gates_data["gates"]["return_path_proven"]["state"] == "unknown"

        doctor_fast_lane = run_script(
            str(WINDOWS / "windows-reinstall-profile.py"),
            "--action",
            "doctor",
            "--profile-id",
            "lab-laptop-family",
            "--data-boundary",
            "proven",
            "--trusted-media",
            "proven",
            "--bitlocker-safe",
            "na",
            "--return-path-proven",
            "proven",
            "--machine-worker",
            "na",
            "--operator-handoff",
            "na",
            "--destructive-confirmation",
            "proven",
            "--store",
            str(store),
            "--json",
            check=True,
        )
        doctor_fast_lane_data = json.loads(doctor_fast_lane.stdout)
        assert doctor_fast_lane_data["lane"] == "fast_lane"
        assert doctor_fast_lane_data["missing_gates"] == []

        rejected = run_script(
            str(WINDOWS / "windows-reinstall-profile.py"),
            "--action",
            "upsert",
            "--profile-id",
            "bad-profile",
            "--device-family",
            "generic UEFI laptop",
            "--control-plane",
            "ssh to 192.168.1.25",
            "--return-path",
            "OpenSSH",
            "--media-state",
            "official Windows 11 USB",
            "--working-route",
            "boot USB",
            "--proof",
            "blocked",
            "--store",
            str(store),
            check=False,
        )
        assert rejected.returncode == 1
        assert "private IPv4" in rejected.stderr


def test_universal_route_profile_helper() -> None:
    with tempfile.TemporaryDirectory() as temp:
        store = Path(temp) / "route-profiles.jsonl"
        upsert = run_script(
            str(LEARNING / "route_profile.py"),
            "--action",
            "upsert",
            "--profile-id",
            "service-repair-systemd",
            "--shelf",
            "package-service-stack",
            "--task-family",
            "systemd service repair",
            "--platform-family",
            "Linux systemd service host",
            "--control-plane",
            "key-based SSH shell",
            "--route",
            "route shelf, run config lint, repair config, restart service, verify health",
            "--proof",
            "service status healthy and app command succeeds",
            "--transfer-boundary",
            "same service manager and package family",
            "--baseline-minutes",
            "20",
            "--actual-minutes",
            "7",
            "--baseline-steps",
            "12",
            "--actual-steps",
            "5",
            "--baseline-tokens",
            "3000",
            "--actual-tokens",
            "1200",
            "--baseline-quality",
            "5",
            "--actual-quality",
            "8",
            "--baseline-safety",
            "6",
            "--actual-safety",
            "9",
            "--baseline-simplicity",
            "4",
            "--actual-simplicity",
            "8",
            "--baseline-universality",
            "5",
            "--actual-universality",
            "7",
            "--store",
            str(store),
            "--json",
            check=True,
        )
        upsert_data = json.loads(upsert.stdout)
        assert upsert_data["ok"] is True
        assert upsert_data["profile"]["shelf"] == "package-service-stack"
        assert upsert_data["profile"]["metrics"]["minutes"]["saved"] == 13.0
        assert upsert_data["profile"]["metrics"]["tokens"]["percent"] == 60.0
        assert upsert_data["profile"]["metrics"]["quality"]["gained"] == 3.0
        assert upsert_data["profile"]["metrics"]["safety"]["gained"] == 3.0
        assert upsert_data["profile"]["metrics"]["simplicity"]["gained"] == 4.0
        assert upsert_data["profile"]["metrics"]["universality"]["gained"] == 2.0

        summary = run_script(
            str(LEARNING / "route_profile.py"),
            "--action",
            "summary",
            "--store",
            str(store),
            "--json",
            check=True,
        )
        summary_data = json.loads(summary.stdout)
        assert summary_data["profile_count"] == 1
        assert summary_data["profiles_by_shelf"]["package-service-stack"] == 1

        stale_profile = dict(upsert_data["profile"])
        stale_profile["updated_at"] = "2000-01-01T00:00:00Z"
        stale_profile["route"] = "stale broad rediscovery route"
        stale_profile["metrics"] = {"minutes": {"known": False}, "steps": {"known": False}, "tokens": {"known": False}}
        with store.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(stale_profile, ensure_ascii=False, sort_keys=True) + "\n")

        fetched = run_script(
            str(LEARNING / "route_profile.py"),
            "--action",
            "get",
            "--profile-id",
            "service-repair-systemd",
            "--store",
            str(store),
            "--json",
            check=True,
        )
        fetched_data = json.loads(fetched.stdout)
        assert fetched_data["found"] is True
        assert fetched_data["profile"]["route"].startswith("route shelf")
        assert fetched_data["profile"]["metrics"]["quality"]["gained"] == 3.0

        summary_after_stale = run_script(
            str(LEARNING / "route_profile.py"),
            "--action",
            "summary",
            "--store",
            str(store),
            "--json",
            check=True,
        )
        summary_after_stale_data = json.loads(summary_after_stale.stdout)
        assert summary_after_stale_data["profile_count"] == 1
        assert summary_after_stale_data["profiles"][0]["route"].startswith("route shelf")

        rejected = run_script(
            str(LEARNING / "route_profile.py"),
            "--action",
            "upsert",
            "--profile-id",
            "bad-service-profile",
            "--shelf",
            "package-service-stack",
            "--task-family",
            "systemd service repair",
            "--platform-family",
            "Linux systemd service host",
            "--control-plane",
            "ssh to 10.0.0.5",
            "--route",
            "restart service",
            "--proof",
            "blocked",
            "--transfer-boundary",
            "same service manager",
            "--store",
            str(store),
            check=False,
        )
        assert rejected.returncode == 1
        assert "private IPv4" in rejected.stderr

        rejected_score = run_script(
            str(LEARNING / "route_profile.py"),
            "--action",
            "upsert",
            "--profile-id",
            "bad-quality-score",
            "--shelf",
            "package-service-stack",
            "--task-family",
            "systemd service repair",
            "--platform-family",
            "Linux systemd service host",
            "--control-plane",
            "key-based SSH shell",
            "--route",
            "restart service",
            "--proof",
            "blocked",
            "--transfer-boundary",
            "same service manager",
            "--baseline-quality",
            "11",
            "--actual-quality",
            "12",
            "--store",
            str(store),
            check=False,
        )
        assert rejected_score.returncode == 1
        assert "between 0 and 10" in rejected_score.stderr


def test_skill_copy_sync_and_required_gate() -> None:
    with tempfile.TemporaryDirectory() as temp:
        target = Path(temp) / "universal-install-ops"
        sync = run_script(str(SKILL / "sync_skill_copy.py"), "--target", str(target), check=True)
        assert "synced:" in sync.stdout
        assert (target / "SKILL.md").exists()
        assert (target / "scripts" / "catalog.json").exists()
        assert not (target / "README.md").exists()

        health = run_script(
            str(SKILL / "skill_health.py"),
            "--skip-powershell",
            "--copy-root",
            str(target),
            check=True,
        )
        assert "checked_copies:" in health.stdout
        assert "matches=True" in health.stdout

        doctor_clean = run_script(
            str(SKILL / "sync_doctor.py"),
            "--copy-root",
            str(target),
            "--json",
            check=True,
        )
        doctor_clean_data = json.loads(doctor_clean.stdout)
        assert doctor_clean_data["drift_count"] == 0
        assert doctor_clean_data["copies"][0]["status"] == "match"

        skill_text = target / "SKILL.md"
        skill_text.write_text(skill_text.read_text(encoding="utf-8") + "\ncopy-only note\n", encoding="utf-8")
        doctor_drift = run_script(
            str(SKILL / "sync_doctor.py"),
            "--copy-root",
            str(target),
            "--json",
            check=False,
        )
        assert doctor_drift.returncode == 2
        doctor_drift_data = json.loads(doctor_drift.stdout)
        assert doctor_drift_data["drift_count"] == 1
        assert doctor_drift_data["copies"][0]["status"] == "drift"
        assert doctor_drift_data["commands"]


def test_skill_copy_sync_preserves_local_memory() -> None:
    with tempfile.TemporaryDirectory() as temp:
        target = Path(temp) / "universal-install-ops"
        memory = target / ".skill-memory" / "candidate-facts.jsonl"
        memory.parent.mkdir(parents=True)
        memory.write_text('{"marker":"ops-memory: local copy fact","source":"copy"}\n', encoding="utf-8")
        (target / "SKILL.md").write_text("# Runtime copy\n", encoding="utf-8")
        (target / "stale.txt").write_text("remove me\n", encoding="utf-8")

        refused = run_script(str(SKILL / "sync_skill_copy.py"), "--target", str(target), check=False)
        assert refused.returncode == 1
        assert "refusing to overwrite divergent target" in refused.stderr

        sync = run_script(
            str(SKILL / "sync_skill_copy.py"),
            "--target",
            str(target),
            "--force-canonical",
            check=True,
        )
        assert "synced:" in sync.stdout
        assert "backup:" in sync.stdout
        assert memory.exists()
        assert "local copy fact" in memory.read_text(encoding="utf-8")
        assert not (target / "stale.txt").exists()
        backups = list((target / ".skill-memory" / "package-backups").glob("*"))
        assert backups
        assert (backups[0] / "stale.txt").exists()


def test_skill_memory_merge_helper() -> None:
    with tempfile.TemporaryDirectory() as temp:
        source = Path(temp) / "source-skill"
        copy = Path(temp) / "universal-install-ops"
        (source / ".skill-memory").mkdir(parents=True)
        (copy / ".skill-memory").mkdir(parents=True)
        (source / "SKILL.md").write_text("# Source\n", encoding="utf-8")
        (copy / "SKILL.md").write_text("# Copy\n", encoding="utf-8")
        (source / ".skill-memory" / "candidate-facts.jsonl").write_text(
            '{"marker":"ops-memory: canonical fact","source":"source"}\n',
            encoding="utf-8",
        )
        (source / ".skill-memory" / "route-profiles.jsonl").write_text(
            '{"profile_id":"shared-fast-lane","updated_at":"2026-05-04T00:00:00Z","route":"fresh route","metrics":{"quality":{"known":true,"gained":2}}}\n',
            encoding="utf-8",
        )
        (copy / ".skill-memory" / "candidate-facts.jsonl").write_text(
            '{"source":"copy","marker":"ops-memory: copy fact"}\n'
            '{"created_at":"later","marker":"ops-memory: canonical fact","source":"copy"}\n',
            encoding="utf-8",
        )
        (copy / ".skill-memory" / "route-profiles.jsonl").write_text(
            '{"profile_id":"shared-fast-lane","updated_at":"2026-05-03T00:00:00Z","route":"stale route","metrics":{"minutes":{"known":false}}}\n',
            encoding="utf-8",
        )
        (copy / ".skill-memory" / "route-branches.jsonl").write_text(
            '{"branch":"copy branch","status":"candidate"}\n',
            encoding="utf-8",
        )

        merged = run_script(
            str(SKILL / "merge_skill_memory.py"),
            "--source-root",
            str(source),
            "--copy-root",
            str(copy),
            "--write",
            "--json",
            check=True,
        )
        data = json.loads(merged.stdout)
        assert data["merged_counts"]["candidate-facts.jsonl"] == 2
        assert data["merged_counts"]["route-branches.jsonl"] == 1
        assert data["merged_counts"]["route-profiles.jsonl"] == 1
        for root in [source, copy]:
            candidate_text = (root / ".skill-memory" / "candidate-facts.jsonl").read_text(encoding="utf-8")
            assert candidate_text.count("ops-memory: canonical fact") == 1
            assert candidate_text.count("ops-memory: copy fact") == 1
            profile_text = (root / ".skill-memory" / "route-profiles.jsonl").read_text(encoding="utf-8")
            assert "fresh route" in profile_text
            assert "stale route" not in profile_text
            assert (root / ".skill-memory" / "route-branches.jsonl").exists()


def test_skill_package_merge_is_disabled_and_copy_drift_is_read_only() -> None:
    with tempfile.TemporaryDirectory() as temp:
        copy = Path(temp) / "universal-install-ops"
        run_script(str(SKILL / "sync_skill_copy.py"), "--target", str(copy), check=True)
        skill_text = copy / "SKILL.md"
        skill_text.write_text(skill_text.read_text(encoding="utf-8") + "\ncopy-only package edit\n", encoding="utf-8")

        removed_merge = run_script(
            str(SKILL / "merge_skill_copy.py"),
            "--copy-root",
            str(copy),
            "--write",
            "--smart-json",
            check=False,
        )
        assert removed_merge.returncode == 1
        assert "Skill package merge is removed" in removed_merge.stdout
        assert "copy-only package edit" in skill_text.read_text(encoding="utf-8")

        doctor = run_script(
            str(SKILL / "sync_doctor.py"),
            "--copy-root",
            str(copy),
            "--json",
            check=False,
        )
        assert doctor.returncode == 2
        data = json.loads(doctor.stdout)
        assert data["drift_count"] == 1
        assert data["copies"][0]["drift_probe"]["only_canonical"] == 0
        assert data["copies"][0]["drift_probe"]["only_copy"] == 0
        assert data["copies"][0]["drift_probe"]["different"] == 1
        assert data["copies"][0]["drift_probe"]["local_package_edits"] is True
        assert data["manual_steps"]
        assert all("merge_skill_copy.py" not in command for command in data["commands"])


def test_codex_session_locator_helper() -> None:
    with tempfile.TemporaryDirectory() as temp:
        home = Path(temp) / ".codex"
        session_dir = home / "sessions" / "2026" / "05" / "04"
        session_dir.mkdir(parents=True)
        session_id = "019deff1-975f-7172-9475-17eabec03a49"
        session_path = session_dir / f"rollout-2026-05-04T03-24-40-{session_id}.jsonl"
        (home / "session_index.jsonl").write_text(
            json.dumps(
                {
                    "id": session_id,
                    "thread_name": "Переустановить Windows на ррр соты",
                    "updated_at": "2026-05-03T22:24:51Z",
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        rows = [
            {"timestamp": "2026-05-03T22:24:40Z", "type": "session_meta", "payload": {"id": session_id, "base_instructions": {"text": "RAW BASE INSTRUCTIONS SHOULD NOT PRINT"}}},
            {"timestamp": "2026-05-03T22:24:41Z", "type": "event_msg", "payload": {"type": "thread_name_updated", "thread_id": session_id, "thread_name": "Переустановить Windows на ррр соты"}},
            {"timestamp": "2026-05-03T22:24:42Z", "type": "event_msg", "payload": {"type": "user_message", "message": "Нужно переустановить Windows на ррр через Соты"}},
        ]
        session_path.write_text(
            "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows),
            encoding="utf-8",
        )

        located = run_script(
            str(SKILL / "codex_session_locator.py"),
            "--codex-home",
            str(home),
            "--id",
            session_id,
            "--json",
            check=True,
        )
        data = json.loads(located.stdout)
        assert data["web_links_available"] is False
        assert data["matches"][0]["index_line"] == 1
        assert data["matches"][0]["session_meta_line"] == 1
        assert data["matches"][0]["thread_name_line"] == 2
        assert data["matches"][0]["session_line"] == 2

        queried = run_script(
            str(SKILL / "codex_session_locator.py"),
            "--codex-home",
            str(home),
            "ррр",
            "--include-snippets",
            check=True,
        )
        assert "session_index.jsonl:1" in queried.stdout
        assert f"{session_path}:3" in queried.stdout
        assert "RAW BASE INSTRUCTIONS SHOULD NOT PRINT" not in queried.stdout
        assert "line 1 is usually session metadata" in queried.stdout


def test_skill_health_smoke() -> None:
    result = run_script(str(SKILL / "skill_health.py"), "--skip-powershell", check=True)
    assert "Universal Install Ops Health" in result.stdout
    assert "shelf_count:" in result.stdout
    assert "hot_route_count:" in result.stdout
    assert "Malformed note lines: 0" in result.stdout
    assert "Orphan note fragments: 0" in result.stdout
    assert "Missing `env:`: 0" in result.stdout
    assert "Missing `scope:` or `evidence:`: 0" in result.stdout


def test_finish_skill_edit_dry_run() -> None:
    result = run_script(str(SKILL / "finish_skill_edit.py"), "--dry-run", "--json", check=True)
    data = json.loads(result.stdout)
    labels = [step["label"] for step in data["steps"]]
    assert data["ok"] is True
    assert "validate package" in labels
    assert "self check" in labels
    assert "activation eval" in labels
    assert "full regression" in labels
    if data.get("copy_roots"):
        assert "merge memory queues" in labels
        assert "update metadata" in labels
        assert "sync copies" in labels
        assert "final sync doctor" in labels


def main() -> int:
    test_case_validator()
    test_score_case_facts()
    test_record_case_fact()
    test_record_route_property_and_adjustment()
    test_record_control_fact_and_surface_summary()
    test_record_learning_scope_and_sanitization()
    test_validate_case_requires_hard_gate_for_database_scale_work()
    test_field_notes_maintenance()
    test_skill_factory_scaffold_and_validation()
    test_route_shelf_selects_skill_factory()
    test_route_hot_and_activation_eval()
    test_memory_queue_scripts()
    test_windows_reinstall_profile_helper()
    test_universal_route_profile_helper()
    test_skill_copy_sync_and_required_gate()
    test_skill_copy_sync_preserves_local_memory()
    test_skill_memory_merge_helper()
    test_skill_package_merge_is_disabled_and_copy_drift_is_read_only()
    test_codex_session_locator_helper()
    test_skill_health_smoke()
    test_finish_skill_edit_dry_run()
    print("ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
