param(
    [string]$LogPath = ""
)

$ErrorActionPreference = "Continue"

function Add-Line {
    param(
        [System.Collections.Generic.List[string]]$Lines,
        [string]$Text = ""
    )
    $Lines.Add($Text) | Out-Null
}

function Add-ToolResult {
    param(
        [System.Collections.Generic.List[string]]$Lines,
        [string]$Name,
        [string[]]$Arguments
    )

    Add-Line $Lines "## $Name $($Arguments -join ' ')"
    $tool = Get-Command $Name -ErrorAction SilentlyContinue
    if (-not $tool) {
        Add-Line $Lines "missing: $Name"
        Add-Line $Lines
        return
    }

    Add-Line $Lines "path: $($tool.Source)"
    try {
        $output = & $tool.Source @Arguments 2>&1
        if ($output) {
            foreach ($line in $output) {
                Add-Line $Lines ([string]$line)
            }
        }
    } catch {
        Add-Line $Lines "error: $($_.Exception.Message)"
    }
    Add-Line $Lines
}

$lines = [System.Collections.Generic.List[string]]::new()
Add-Line $lines "# Android USB preflight"
Add-Line $lines "timestamp: $(Get-Date -Format o)"

$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
if ($os) {
    Add-Line $lines "host: $($os.Caption) $($os.Version) build $($os.BuildNumber) $($os.OSArchitecture)"
}
Add-Line $lines

Add-ToolResult $lines "adb" @("devices", "-l")
Add-ToolResult $lines "fastboot" @("devices", "-l")
Add-ToolResult $lines "heimdall" @("detect")

Add-Line $lines "## Windows PnP Android/Samsung evidence"
$devices = Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue |
    Where-Object {
        $_.Name -match "Samsung|Android|ADB|MTP|Portable|Galaxy" -or
        $_.PNPDeviceID -match "VID_04E8|VID_18D1"
    } |
    Select-Object Name, PNPClass, Status, PNPDeviceID

if ($devices) {
    $devices | Format-List | Out-String -Width 240 |
        ForEach-Object {
            foreach ($line in $_.TrimEnd() -split [Environment]::NewLine) {
                Add-Line $lines $line
            }
        }
} else {
    Add-Line $lines "no matching live PnP entities found"
}

if ($LogPath) {
    $parent = Split-Path -Parent $LogPath
    if ($parent) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }
    Set-Content -Path $LogPath -Value $lines -Encoding utf8
}

$lines -join [Environment]::NewLine
