from __future__ import annotations

import argparse
import re
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create a minimal Codex skill folder.")
    parser.add_argument("output_root", help="Directory where the new skill folder should be created.")
    parser.add_argument("--name", required=True, help="Skill name, for example proxy-normalizer.")
    parser.add_argument("--trigger", required=True, help="Plain trigger sentence in the user's words.")
    parser.add_argument("--outcome", required=True, help="Reusable outcome this skill should produce.")
    parser.add_argument("--with-script", action="store_true", help="Create scripts/main.py as a deterministic stub.")
    parser.add_argument("--script-name", default="main.py", help="Script name to create when --with-script is used.")
    parser.add_argument("--force", action="store_true", help="Allow writing into an existing empty skill folder.")
    return parser.parse_args()


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    slug = re.sub(r"-{2,}", "-", slug)
    if not slug:
        raise ValueError("skill name must contain at least one ASCII letter or digit")
    return slug[:80]


def titleize(slug: str) -> str:
    return " ".join(part.capitalize() for part in slug.split("-") if part)


def compact_description(trigger: str, outcome: str) -> str:
    trigger = " ".join(trigger.split())
    outcome = " ".join(outcome.split())
    description = f"Use when {trigger}. Produce {outcome} with the smallest validated workflow."
    if len(description) <= 900:
        return description
    return description[:897].rstrip() + "..."


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")


def main() -> int:
    args = parse_args()
    name = slugify(args.name)
    output_root = Path(args.output_root).expanduser().resolve()
    skill_dir = output_root / name

    if skill_dir.exists() and any(skill_dir.iterdir()) and not args.force:
        raise SystemExit(f"refusing to overwrite non-empty skill folder: {skill_dir}")

    skill_dir.mkdir(parents=True, exist_ok=True)
    display_name = titleize(name)
    description = compact_description(args.trigger, args.outcome)

    resources = "- No bundled scripts yet. Add one only when it makes a repeated step deterministic."
    if args.with_script:
        script_path = Path("scripts") / args.script_name
        resources = f"- Use `scripts/{script_path.name}` for the deterministic part of the workflow."

    skill_md = f"""---
name: {name}
description: >-
  {description}
---

# {display_name}

Use this skill when the user asks for this repeatable outcome:

{args.trigger.strip()}

## Workflow

1. Confirm the current input and expected output.
2. Use the smallest safe route that can produce the result.
3. Run bundled scripts only when they are more reliable than prose.
4. Verify the observable success sign before finalizing.
5. Capture a reusable note only when the route or environment boundary will help later.

## Resources

{resources}
"""
    write_text(skill_dir / "SKILL.md", skill_md)

    openai_yaml = f"""interface:
  display_name: "{display_name}"
  short_description: "{args.outcome.strip()[:90]}"
  default_prompt: "Use ${name} when {args.trigger.strip()} Produce {args.outcome.strip()} with the smallest validated workflow."

policy:
  allow_implicit_invocation: true
"""
    write_text(skill_dir / "agents" / "openai.yaml", openai_yaml)

    if args.with_script:
        script_name = Path(args.script_name).name
        if not script_name.endswith(".py"):
            raise SystemExit("--script-name must end with .py")
        script = '''from __future__ import annotations

import argparse
import json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the deterministic part of this skill.")
    parser.add_argument("--input", default="", help="Input value or path for the workflow.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    print(json.dumps({"ok": True, "input": args.input}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
'''
        write_text(skill_dir / "scripts" / script_name, script)

    print(skill_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
