from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))

from skill_paths import skill_root as find_skill_root
import copy_drift

SKILL_NAME = "universal-install-ops"
EXCLUDED_NAMES = {".git", ".skill-memory", "__pycache__", ".gitignore", "README.md"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}
PRESERVED_TARGET_NAMES = {".git", ".skill-memory"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Sync the canonical skill into runtime or bundled copies.")
    parser.add_argument("--target", action="append", default=[], help="Explicit skill copy directory to replace.")
    parser.add_argument(
        "--project-root",
        action="append",
        default=[],
        help="Project root whose tools/mcp and bundled machine-skill copies should be replaced.",
    )
    parser.add_argument("--codex", action="store_true", help="Sync into CODEX_HOME/PANEL_CODEX_HOME or ~/.codex.")
    parser.add_argument("--codex-home", default="", help="Override Codex home when using --codex.")
    parser.add_argument(
        "--force-canonical",
        action="store_true",
        help="Replace a divergent copy after manual review/safety proof; a package backup is kept unless --no-backup is set.",
    )
    parser.add_argument("--no-backup", action="store_true", help="Do not save a pre-sync package snapshot on forced replace.")
    parser.add_argument("--dry-run", action="store_true", help="Show planned targets without writing.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser.parse_args()


def canonical_root() -> Path:
    return find_skill_root(__file__).resolve()


def codex_home(args: argparse.Namespace) -> Path:
    if args.codex_home.strip():
        return Path(args.codex_home).expanduser().resolve()
    import os

    return Path(os.environ.get("CODEX_HOME") or os.environ.get("PANEL_CODEX_HOME") or Path.home() / ".codex").resolve()


def planned_targets(args: argparse.Namespace) -> list[Path]:
    targets: list[Path] = []
    for value in args.target:
        targets.append(Path(value).expanduser().resolve())
    for value in args.project_root:
        root = Path(value).expanduser().resolve()
        targets.append(root / "tools" / "mcp" / "skills" / SKILL_NAME)
        bundled_parent = root / "apps" / "agent" / "bundled-core" / "machine-skills"
        if bundled_parent.exists():
            targets.append(bundled_parent / SKILL_NAME)
    if args.codex:
        targets.append(codex_home(args) / "skills" / SKILL_NAME)
    return dedupe_paths(targets)


def dedupe_paths(paths: list[Path]) -> list[Path]:
    seen: set[str] = set()
    result: list[Path] = []
    for path in paths:
        key = str(path).casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(path)
    return result


def validate_target(source: Path, target: Path) -> None:
    if target.name != SKILL_NAME:
        raise ValueError(f"refusing nonstandard target name: {target}")
    if target == source:
        raise ValueError("refusing to sync the canonical source onto itself")
    try:
        source.relative_to(target)
        raise ValueError(f"refusing to sync into a parent of the canonical source: {target}")
    except ValueError as error:
        if "refusing" in str(error):
            raise
    try:
        target.relative_to(source)
        raise ValueError(f"refusing to sync into a child of the canonical source: {target}")
    except ValueError as error:
        if "refusing" in str(error):
            raise
    if target.anchor == str(target):
        raise ValueError(f"refusing to sync into a filesystem root: {target}")


def should_copy(path: Path) -> bool:
    if any(part in EXCLUDED_NAMES for part in path.parts):
        return False
    if path.is_file() and path.suffix in EXCLUDED_SUFFIXES:
        return False
    return True


def clear_target(target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    for child in target.iterdir():
        if child.name in PRESERVED_TARGET_NAMES:
            continue
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()


def drift_report(source: Path, target: Path) -> dict[str, Any]:
    if not (target / "SKILL.md").exists():
        return {"has_drift": False, "only_canonical": 0, "only_copy": 0, "different": 0, "local_package_edits": False}
    report = copy_drift.compare_roots(source, target)
    return {
        "has_drift": bool(report.get("only_canonical") or report.get("only_copy") or report.get("different")),
        "only_canonical": len(report.get("only_canonical", [])),
        "only_copy": len(report.get("only_copy", [])),
        "different": len(report.get("different", [])),
        "local_package_edits": not bool(report.get("copy_clean_applied")),
        "copy_applied_hash": report.get("copy_applied_hash", ""),
        "copy_package_hash": report.get("copy_package_hash", ""),
    }


def backup_target(target: Path) -> str:
    if not target.exists() or not any(child.name not in PRESERVED_TARGET_NAMES for child in target.iterdir()):
        return ""
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = target / ".skill-memory" / "package-backups" / stamp
    backup.mkdir(parents=True, exist_ok=True)
    manifest = {
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "source": str(target),
        "purpose": "pre-sync package snapshot before force-canonical replace",
    }
    for child in target.iterdir():
        if child.name in PRESERVED_TARGET_NAMES:
            continue
        destination = backup / child.name
        if child.is_dir():
            shutil.copytree(child, destination, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"))
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(child, destination)
    (backup / "_backup.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return str(backup)


def copy_payload(source: Path, target: Path, backup: bool) -> dict[str, Any]:
    backup_path = backup_target(target) if backup else ""
    clear_target(target)
    file_count = 0
    dir_count = 0
    for item in sorted(source.rglob("*"), key=lambda path: path.relative_to(source).as_posix()):
        relative = item.relative_to(source)
        if not should_copy(relative):
            continue
        destination = target / relative
        if item.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            dir_count += 1
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, destination)
        file_count += 1
    return {"files": file_count, "directories": dir_count, "backup": backup_path}


def sync_targets(args: argparse.Namespace) -> dict[str, Any]:
    source = canonical_root()
    targets = planned_targets(args)
    if not targets:
        raise ValueError("no target selected; use --codex, --project-root, or --target")

    results: list[dict[str, Any]] = []
    for target in targets:
        validate_target(source, target)
        drift = drift_report(source, target) if target.exists() else {"has_drift": False}
        blocked_local_edits = drift.get("has_drift") and drift.get("local_package_edits")
        if blocked_local_edits and not args.force_canonical and not args.dry_run:
            raise ValueError(
                "refusing to overwrite divergent target without --force-canonical; "
                f"review sync_doctor.py output and port useful package edits manually first: {target}"
            )
        result: dict[str, Any] = {"target": str(target), "dry_run": bool(args.dry_run), "drift": drift}
        if args.dry_run:
            result.update({"synced": False, "files": 0, "directories": 0, "backup": ""})
        else:
            result.update(copy_payload(source, target, backup=bool(drift.get("has_drift")) and not args.no_backup))
            result["synced"] = True
        results.append(result)
    return {"source": str(source), "targets": results}


def print_text(report: dict[str, Any]) -> None:
    print(f"source: {report['source']}")
    for target in report["targets"]:
        action = "would sync" if target["dry_run"] else "synced"
        print(f"- {action}: {target['target']}")
        if not target["dry_run"]:
            print(f"  files: {target['files']}")
            print(f"  directories: {target['directories']}")
            if target.get("backup"):
                print(f"  backup: {target['backup']}")


def main() -> int:
    args = parse_args()
    try:
        report = sync_targets(args)
    except Exception as error:
        print(f"error: {error}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print_text(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
