from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

METADATA_FILE = ".klava-canonical-skill.json"
GENERATED_DIRS = {"__pycache__", ".skill-memory"}
GENERATED_SUFFIXES = {".pyc", ".pyo"}
REPO_WRAPPER_FILES = {".gitignore", "README.md"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Update the canonical skill metadata hash.")
    parser.add_argument("skill_root", nargs="?", default=".", help="Skill root directory.")
    parser.add_argument("--source-relative-path", default="", help="Optional sourceRelativePath override.")
    return parser.parse_args()


def collect_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for item in root.rglob("*"):
        if ".git" in item.parts:
            continue
        if item.name == METADATA_FILE or item.name in REPO_WRAPPER_FILES:
            continue
        if any(part in GENERATED_DIRS for part in item.parts):
            continue
        if item.is_file() and item.suffix in GENERATED_SUFFIXES:
            continue
        if item.is_file():
            files.append(item)
    return sorted(files, key=lambda item: item.relative_to(root).as_posix())


def hash_skill(root: Path) -> str:
    digest = hashlib.sha256()
    for file_path in collect_files(root):
        relative = file_path.relative_to(root).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(file_path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def read_skill_name(root: Path) -> str:
    skill_md = root / "SKILL.md"
    if not skill_md.exists():
        return root.name
    for line in skill_md.read_text(encoding="utf-8").splitlines():
        if line.startswith("name:"):
            value = line.split(":", 1)[1].strip().strip("\"'")
            if value:
                return value
    return root.name


def read_existing_source_relative_path(root: Path) -> str:
    metadata_path = root / METADATA_FILE
    if not metadata_path.exists():
        return ""
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    except Exception:
        return ""
    value = metadata.get("sourceRelativePath")
    return value.strip() if isinstance(value, str) else ""


def main() -> int:
    args = parse_args()
    root = Path(args.skill_root).expanduser().resolve()
    source_relative_path = (
        args.source_relative_path.strip()
        or read_existing_source_relative_path(root)
        or read_skill_name(root)
    )
    metadata = {
        "managedBy": "klava-canonical-skills",
        "sourceRelativePath": source_relative_path,
        "appliedHash": hash_skill(root),
        "syncedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    (root / METADATA_FILE).write_text(f"{json.dumps(metadata, indent=2)}\n", encoding="utf-8", newline="\n")
    print(json.dumps(metadata, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
