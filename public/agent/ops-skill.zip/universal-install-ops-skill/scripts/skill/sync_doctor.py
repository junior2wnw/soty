from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "skill"))

from skill_paths import skill_root as find_skill_root
import copy_drift
import skill_health

SKILL_NAME = "universal-install-ops"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Diagnose skill copy drift before one-way sync or release.")
    parser.add_argument("--copy-root", action="append", default=[], help="Skill copy root to check. Repeatable.")
    parser.add_argument("--project-root", action="append", default=[], help="Project root with tools/mcp or bundled skill copies.")
    parser.add_argument("--codex", action="store_true", help="Check the installed Codex skill copy.")
    parser.add_argument("--codex-home", default="", help="Override Codex home when using --codex.")
    parser.add_argument("--json", action="store_true")
    return parser.parse_args()


def canonical_root() -> Path:
    return find_skill_root(__file__).resolve()


def codex_home(args: argparse.Namespace) -> Path:
    if args.codex_home.strip():
        return Path(args.codex_home).expanduser().resolve()
    return Path(os.environ.get("CODEX_HOME") or os.environ.get("PANEL_CODEX_HOME") or Path.home() / ".codex").resolve()


def workspace_root(root: Path) -> Path | None:
    for candidate in root.parents:
        if (candidate / "tools" / "mcp" / "skills").exists() or (candidate / "apps" / "agent" / "bundled-core").exists():
            return candidate
    return None


def dedupe(paths: list[Path]) -> list[Path]:
    seen: set[str] = set()
    result: list[Path] = []
    for path in paths:
        key = str(path).casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(path)
    return result


def planned_copies(args: argparse.Namespace, source: Path) -> list[Path]:
    copies: list[Path] = [Path(item).expanduser().resolve() for item in args.copy_root if item.strip()]
    for item in args.project_root:
        root = Path(item).expanduser().resolve()
        copies.append(root / "tools" / "mcp" / "skills" / SKILL_NAME)
        bundled_parent = root / "apps" / "agent" / "bundled-core" / "machine-skills"
        if bundled_parent.exists():
            copies.append(bundled_parent / SKILL_NAME)
    if args.codex:
        copies.append(codex_home(args) / "skills" / SKILL_NAME)
    if not copies:
        workspace = workspace_root(source)
        if workspace is not None:
            copies.append(workspace / "tools" / "mcp" / "skills" / SKILL_NAME)
            bundled = workspace / "apps" / "agent" / "bundled-core" / "machine-skills" / SKILL_NAME
            if bundled.exists():
                copies.append(bundled)
        copies.append(Path(os.environ.get("CODEX_HOME") or os.environ.get("PANEL_CODEX_HOME") or Path.home() / ".codex").resolve() / "skills" / SKILL_NAME)
    return [path for path in dedupe(copies) if path != source]


def drift_probe(source: Path, copy: Path) -> dict[str, Any]:
    if not (copy / "SKILL.md").exists():
        return {"ok": False, "reason": "missing skill copy", "only_canonical": 0, "only_copy": 0, "different": 0, "local_package_edits": False}
    report = copy_drift.compare_roots(source, copy)
    return {
        "ok": not bool(report.get("has_drift")),
        "only_canonical": len(report.get("only_canonical", [])),
        "only_copy": len(report.get("only_copy", [])),
        "different": len(report.get("different", [])),
        "local_package_edits": not bool(report.get("copy_clean_applied")),
        "copy_applied_hash": report.get("copy_applied_hash", ""),
        "copy_package_hash": report.get("copy_package_hash", ""),
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    source = canonical_root()
    source_hash = skill_health.hash_skill(source)
    copies: list[dict[str, Any]] = []
    for copy in planned_copies(args, source):
        comparison = skill_health.compare_copy(source_hash, copy)
        probe = drift_probe(source, copy) if comparison.get("exists") else {"ok": False, "reason": "missing skill copy", "local_package_edits": False}
        status = "missing" if not comparison.get("exists") else ("match" if comparison.get("matches") else "drift")
        copies.append({**comparison, "status": status, "drift_probe": probe})
    drift = [copy for copy in copies if copy["status"] != "match"]
    commands: list[str] = []
    manual_steps: list[str] = []
    for copy in drift:
        path = copy["path"]
        if copy["status"] == "drift":
            commands.append(f'git diff --no-index --stat -- "{source}" "{path}"')
            if copy.get("drift_probe", {}).get("local_package_edits"):
                manual_steps.append(
                    f"Review {path}; port useful package edits into the canonical source with an explicit patch before any one-way sync."
                )
            else:
                commands.append(f'python "{source / "scripts" / "skill" / "sync_skill_copy.py"}" --target "{path}"')
        elif copy["status"] == "missing":
            commands.append(f'python "{source / "scripts" / "skill" / "sync_skill_copy.py"}" --target "{path}"')
    if drift:
        if manual_steps:
            manual_steps.append("Merge only .skill-memory queues automatically; package files require explicit reviewed edits.")
        commands.append(f'python "{source / "scripts" / "skill" / "update_skill_metadata.py"}" "{source}"')
        commands.append(f'python "{source / "scripts" / "skill" / "skill_health.py"}" --strict')
    return {
        "source": str(source),
        "source_hash": source_hash,
        "copy_count": len(copies),
        "drift_count": len(drift),
        "copies": copies,
        "commands": commands,
        "manual_steps": manual_steps,
        "ok": not drift,
    }


def print_text(report: dict[str, Any]) -> None:
    print("Skill Sync Doctor")
    print(f"- source: {report['source']}")
    print(f"- copy_count: {report['copy_count']}")
    print(f"- drift_count: {report['drift_count']}")
    for copy in report["copies"]:
        probe = copy.get("drift_probe", {})
        print(f"- copy: {copy['path']}")
        print(f"  status: {copy['status']}")
        print(f"  matches: {copy.get('matches')}")
        if copy["status"] == "drift":
            print(
                "  drift: "
                f"only_canonical={probe.get('only_canonical', 0)} "
                f"only_copy={probe.get('only_copy', 0)} "
                f"different={probe.get('different', 0)}"
            )
            print(f"  local_package_edits: {probe.get('local_package_edits')}")
    if report.get("manual_steps"):
        print("- manual:")
        for step in report["manual_steps"]:
            print(f"  - {step}")
    if report["commands"]:
        print("- next:")
        for command in report["commands"]:
            print(f"  - {command}")


def main() -> int:
    args = parse_args()
    try:
        report = run(args)
    except Exception as error:
        print(f"error: {error}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_text(report)
    return 0 if report["ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
