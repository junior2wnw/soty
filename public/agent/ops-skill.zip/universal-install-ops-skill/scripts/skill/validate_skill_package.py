from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

DESCRIPTION_LIMIT = 1024
BODY_LINE_SOFT_LIMIT = 500
LARGE_FILE_LIMIT = 10 * 1024 * 1024
GENERATED_DIRS = {"__pycache__"}
LOCAL_STATE_DIRS = {".skill-memory"}
GENERATED_SUFFIXES = {".pyc", ".pyo"}
REPO_WRAPPER_FILES = {".gitignore", "README.md"}
SHELF_INDEX = "references/shelf-index.json"
HOT_ROUTES = "references/hot-routes.json"
SCRIPT_CATALOG = "scripts/catalog.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate a Codex skill package.")
    parser.add_argument("skill_root", nargs="?", default=".", help="Skill root directory.")
    parser.add_argument("--strict", action="store_true", help="Return non-zero for warnings.")
    parser.add_argument("--json", action="store_true", help="Print JSON instead of text.")
    return parser.parse_args()


def parse_frontmatter(skill_md: Path) -> tuple[dict[str, str], str]:
    raw = skill_md.read_text(encoding="utf-8")
    if not raw.startswith("---"):
        return {}, raw
    parts = raw.split("---", 2)
    if len(parts) < 3:
        return {}, raw

    metadata: dict[str, str] = {}
    current_key = ""
    current_value: list[str] = []
    for line in parts[1].splitlines():
        if re.match(r"^[A-Za-z0-9_-]+:", line):
            if current_key:
                metadata[current_key] = " ".join(current_value).strip()
            current_key, value = line.split(":", 1)
            value = value.strip()
            current_value = [] if value in {">", ">-", "|", "|-"} else [value.strip("\"'")]
            continue
        if current_key and line.startswith("  "):
            current_value.append(line.strip().strip("\"'"))
    if current_key:
        metadata[current_key] = " ".join(current_value).strip()
    return metadata, parts[2]


def find_markdown_links(skill_md: Path) -> list[str]:
    raw = skill_md.read_text(encoding="utf-8")
    links: list[str] = []
    for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", raw):
        target = match.group(1).strip()
        if not target or "://" in target or target.startswith("#"):
            continue
        links.append(target.split("#", 1)[0])
    return links


def validate_shelf_index(root: Path) -> tuple[set[str], list[str], list[str]]:
    index_path = root / SHELF_INDEX
    errors: list[str] = []
    warnings: list[str] = []
    if not index_path.exists():
        return set(), errors, warnings
    try:
        parsed = json.loads(index_path.read_text(encoding="utf-8"))
    except Exception as error:
        return set(), [f"{SHELF_INDEX} is not valid JSON: {error}"], warnings
    shelves = parsed.get("shelves")
    if not isinstance(shelves, list) or not shelves:
        return set(), [f"{SHELF_INDEX} has no shelves"], warnings
    seen: set[str] = set()
    for shelf in shelves:
        if not isinstance(shelf, dict):
            errors.append("shelf entry is not an object")
            continue
        shelf_id = shelf.get("id")
        if not isinstance(shelf_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,80}", shelf_id):
            errors.append(f"invalid shelf id: {shelf_id!r}")
            continue
        if shelf_id in seen:
            errors.append(f"duplicate shelf id: {shelf_id}")
        seen.add(shelf_id)
        if not shelf.get("keywords"):
            warnings.append(f"shelf has no keywords: {shelf_id}")
        for key in ["read", "scripts"]:
            values = shelf.get(key, [])
            if not isinstance(values, list):
                errors.append(f"shelf {shelf_id} {key} is not a list")
                continue
            for value in values:
                if not isinstance(value, str):
                    errors.append(f"shelf {shelf_id} {key} item is not a string")
                    continue
                target = (root / value).resolve()
                try:
                    target.relative_to(root)
                except ValueError:
                    errors.append(f"shelf {shelf_id} {key} escapes skill root: {value}")
                    continue
                if not target.exists():
                    errors.append(f"shelf {shelf_id} {key} target is missing: {value}")
    if parsed.get("default_shelf") not in seen:
        errors.append(f"default_shelf is missing from shelves: {parsed.get('default_shelf')!r}")

    aliases = parsed.get("aliases", {})
    if aliases is None:
        aliases = {}
    if not isinstance(aliases, dict):
        errors.append("aliases is not an object")
        aliases = {}
    for alias, target in aliases.items():
        if not isinstance(alias, str) or not alias.strip():
            errors.append(f"invalid shelf alias: {alias!r}")
        if target not in seen:
            errors.append(f"shelf alias {alias!r} points to missing shelf: {target!r}")

    deprecated = parsed.get("deprecated_shelves", [])
    if deprecated is None:
        deprecated = []
    if not isinstance(deprecated, list):
        errors.append("deprecated_shelves is not a list")
        deprecated = []
    for shelf_id in deprecated:
        if shelf_id in seen:
            warnings.append(f"deprecated shelf is still active: {shelf_id}")
    return seen, errors, warnings


def validate_hot_routes(root: Path, shelf_ids: set[str]) -> tuple[list[str], list[str]]:
    routes_path = root / HOT_ROUTES
    errors: list[str] = []
    warnings: list[str] = []
    if not routes_path.exists():
        return errors, warnings
    try:
        parsed = json.loads(routes_path.read_text(encoding="utf-8"))
    except Exception as error:
        return [f"{HOT_ROUTES} is not valid JSON: {error}"], warnings
    routes = parsed.get("routes")
    if not isinstance(routes, list) or not routes:
        return [f"{HOT_ROUTES} has no routes"], warnings
    seen: set[str] = set()
    for route in routes:
        if not isinstance(route, dict):
            errors.append("hot route entry is not an object")
            continue
        route_id = route.get("id")
        if not isinstance(route_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,80}", route_id):
            errors.append(f"invalid hot route id: {route_id!r}")
            continue
        if route_id in seen:
            errors.append(f"duplicate hot route id: {route_id}")
        seen.add(route_id)
        shelf = route.get("shelf")
        if shelf_ids and shelf not in shelf_ids:
            errors.append(f"hot route {route_id} points to missing shelf: {shelf!r}")
        triggers = route.get("triggers")
        if not isinstance(triggers, list) or not triggers:
            warnings.append(f"hot route has no triggers: {route_id}")
        steps = route.get("steps")
        if not isinstance(steps, list) or not steps:
            errors.append(f"hot route has no steps: {route_id}")
        elif len(steps) > 5:
            warnings.append(f"hot route has more than five steps: {route_id}")
        for key in ["verify", "fallback"]:
            if not isinstance(route.get(key), str) or not route.get(key, "").strip():
                errors.append(f"hot route {route_id} missing {key}")
    return errors, warnings


def validate_script_catalog(root: Path, shelf_ids: set[str]) -> tuple[list[str], list[str]]:
    catalog_path = root / SCRIPT_CATALOG
    errors: list[str] = []
    warnings: list[str] = []
    if not catalog_path.exists():
        return errors, warnings
    try:
        parsed = json.loads(catalog_path.read_text(encoding="utf-8"))
    except Exception as error:
        return [f"{SCRIPT_CATALOG} is not valid JSON: {error}"], warnings
    categories = parsed.get("categories", {})
    if not isinstance(categories, dict) or not categories:
        errors.append(f"{SCRIPT_CATALOG} has no categories")
        categories = {}
    for category_id, category in categories.items():
        if not isinstance(category_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,80}", category_id):
            errors.append(f"invalid script category id: {category_id!r}")
        if not isinstance(category, dict):
            errors.append(f"script category is not an object: {category_id!r}")
            continue
        category_path = category.get("path")
        if not isinstance(category_path, str) or not (root / category_path).exists():
            errors.append(f"script category path is missing: {category_id!r} -> {category_path!r}")
    scripts = parsed.get("scripts", [])
    if not isinstance(scripts, list) or not scripts:
        errors.append(f"{SCRIPT_CATALOG} has no scripts")
        scripts = []
    seen: set[str] = set()
    cataloged_paths: set[str] = set()
    for script in scripts:
        if not isinstance(script, dict):
            errors.append("script catalog entry is not an object")
            continue
        script_id = script.get("id")
        if not isinstance(script_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,100}", script_id):
            errors.append(f"invalid script id: {script_id!r}")
            continue
        if script_id in seen:
            errors.append(f"duplicate script id: {script_id}")
        seen.add(script_id)
        category_id = script.get("category")
        if category_id not in categories:
            errors.append(f"script {script_id} points to missing category: {category_id!r}")
        shelf = script.get("shelf")
        if shelf and shelf_ids and shelf not in shelf_ids:
            errors.append(f"script {script_id} points to missing shelf: {shelf!r}")
        path_value = script.get("path")
        if not isinstance(path_value, str):
            errors.append(f"script {script_id} path is not a string")
            continue
        cataloged_paths.add(path_value.replace("\\", "/"))
        path = (root / path_value).resolve()
        try:
            path.relative_to(root)
        except ValueError:
            errors.append(f"script {script_id} path escapes skill root: {path_value}")
            continue
        if not path.exists():
            errors.append(f"script {script_id} path is missing: {path_value}")
        if not isinstance(script.get("purpose"), str) or not script.get("purpose", "").strip():
            warnings.append(f"script {script_id} has no purpose")
        command = script.get("command")
        if not isinstance(command, str) or not command.strip():
            warnings.append(f"script {script_id} has no command")
        else:
            for reference in re.findall(r"scripts[\\/][^\s\"']+\.(?:py|ps1|cmd|bat|sh)", command):
                command_target = (root / reference.replace("\\", "/")).resolve()
                try:
                    command_target.relative_to(root)
                except ValueError:
                    errors.append(f"script {script_id} command reference escapes skill root: {reference}")
                    continue
                if not command_target.exists():
                    errors.append(f"script {script_id} command references missing path: {reference}")

    executable_suffixes = {".py", ".ps1", ".cmd", ".bat", ".sh"}
    for path in sorted((root / "scripts").rglob("*")):
        if not path.is_file() or path.suffix.lower() not in executable_suffixes:
            continue
        relative = path.relative_to(root).as_posix()
        if relative.startswith("scripts/lib/"):
            continue
        if relative not in cataloged_paths:
            errors.append(f"script is missing from catalog: {relative}")
    return errors, warnings


def validate_agents_metadata(root: Path, skill_name: str) -> tuple[list[str], list[str]]:
    agents_yaml = root / "agents" / "openai.yaml"
    errors: list[str] = []
    warnings: list[str] = []
    if not agents_yaml.exists():
        return errors, ["agents/openai.yaml is missing; implicit invocation may be weaker in UI surfaces"]
    raw = agents_yaml.read_text(encoding="utf-8")
    for field in ["display_name:", "short_description:", "default_prompt:"]:
        if field not in raw:
            warnings.append(f"agents/openai.yaml missing {field.rstrip(':')}")
    if skill_name != "ops" and not (root / "scripts" / "ops.py").exists():
        return errors, warnings
    default_prompt = raw.split("default_prompt:", 1)[1] if "default_prompt:" in raw else ""
    for term in ["scripts/ops.py", "action_packet", "--checkpoint", "--branch", "--remember"]:
        if term not in default_prompt:
            warnings.append(f"agents/openai.yaml default_prompt does not mention {term}")
    return errors, warnings


def validate_skill_root(root: Path) -> dict[str, Any]:
    root = root.expanduser().resolve()
    errors: list[str] = []
    warnings: list[str] = []
    info: dict[str, Any] = {"skill_root": str(root)}

    skill_md = root / "SKILL.md"
    if not skill_md.exists():
        errors.append("missing SKILL.md")
        return {"ok": False, "errors": errors, "warnings": warnings, **info}

    metadata, body = parse_frontmatter(skill_md)
    name = metadata.get("name", "")
    description = metadata.get("description", "")
    info.update(
        {
            "name": name,
            "description_length": len(description),
            "body_lines": len(body.splitlines()),
        }
    )

    if not name:
        errors.append("frontmatter is missing name")
    elif not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,79}", name):
        errors.append("frontmatter name must be a lowercase slug")

    if not description:
        errors.append("frontmatter is missing description")
    elif len(description) > DESCRIPTION_LIMIT:
        errors.append(f"description is {len(description)} characters; limit is {DESCRIPTION_LIMIT}")
    elif len(description) < 40:
        warnings.append("description may be too short to trigger reliably")

    if info["body_lines"] > BODY_LINE_SOFT_LIMIT:
        warnings.append(f"SKILL.md body has {info['body_lines']} lines; prefer progressive disclosure")

    for target in find_markdown_links(skill_md):
        target_path = (root / target).resolve()
        try:
            target_path.relative_to(root)
        except ValueError:
            errors.append(f"SKILL.md link escapes skill root: {target}")
            continue
        if not target_path.exists():
            errors.append(f"SKILL.md link target is missing: {target}")

    shelf_ids, shelf_errors, shelf_warnings = validate_shelf_index(root)
    errors.extend(shelf_errors)
    warnings.extend(shelf_warnings)
    hot_errors, hot_warnings = validate_hot_routes(root, shelf_ids)
    errors.extend(hot_errors)
    warnings.extend(hot_warnings)
    catalog_errors, catalog_warnings = validate_script_catalog(root, shelf_ids)
    errors.extend(catalog_errors)
    warnings.extend(catalog_warnings)
    agents_errors, agents_warnings = validate_agents_metadata(root, name)
    errors.extend(agents_errors)
    warnings.extend(agents_warnings)

    generated: list[str] = []
    large_files: list[str] = []
    python_errors: list[str] = []
    for item in root.rglob("*"):
        if ".git" in item.parts:
            continue
        if any(part in LOCAL_STATE_DIRS for part in item.parts):
            continue
        if any(part in GENERATED_DIRS for part in item.parts):
            generated.append(str(item.relative_to(root)))
            continue
        if item.is_file() and item.suffix in GENERATED_SUFFIXES:
            generated.append(str(item.relative_to(root)))
        if item.is_file() and item.name not in REPO_WRAPPER_FILES and item.stat().st_size > LARGE_FILE_LIMIT:
            large_files.append(str(item.relative_to(root)))
        if item.is_file() and item.suffix == ".py" and item.name not in REPO_WRAPPER_FILES:
            try:
                compile(item.read_text(encoding="utf-8"), str(item), "exec")
            except SyntaxError as error:
                python_errors.append(f"{item.relative_to(root)}: {error.msg}")

    if generated:
        warnings.append(f"generated files are present: {', '.join(sorted(set(generated))[:5])}")
    if large_files:
        errors.append(f"large files are present: {', '.join(large_files[:5])}")
    if python_errors:
        errors.extend(python_errors)

    return {
        **info,
        "errors": errors,
        "warnings": warnings,
        "ok": not errors,
    }


def print_text(report: dict[str, Any]) -> None:
    print("Skill Package Validation")
    print(f"- skill_root: {report.get('skill_root', '')}")
    if report.get("name"):
        print(f"- name: {report['name']}")
    if "description_length" in report:
        print(f"- description_length: {report['description_length']}/{DESCRIPTION_LIMIT}")
    if "body_lines" in report:
        print(f"- body_lines: {report['body_lines']}")
    print("- errors:")
    if report["errors"]:
        for item in report["errors"]:
            print(f"  - {item}")
    else:
        print("  - none")
    print("- warnings:")
    if report["warnings"]:
        for item in report["warnings"]:
            print(f"  - {item}")
    else:
        print("  - none")


def main() -> int:
    args = parse_args()
    report = validate_skill_root(Path(args.skill_root))
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print_text(report)
    if report["errors"]:
        return 1
    if args.strict and report["warnings"]:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
