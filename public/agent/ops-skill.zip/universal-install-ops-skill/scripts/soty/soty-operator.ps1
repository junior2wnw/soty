param(
  [ValidateSet("list", "run", "run-encoded", "run-background", "job-status", "say", "agent-message", "export", "install-machine", "machine-status", "repair-machine")]
  [string] $Action = "list",
  [string] $Target = "",
  [string] $Command = "",
  [string] $JobId = "",
  [string] $Text = "",
  [string] $OutFile = "",
  [string] $SourceDevice = "",
  [string] $RelayBaseUrl = "",
  [int] $TailChars = 0,
  [ValidateSet("", "fast", "slow")]
  [string] $Speed = "",
  [int] $Port = 49424,
  [int] $TimeoutSec = 120
)

$ErrorActionPreference = "Stop"
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 > $null } catch {}

$origin = "https://xn--n1afe0b.online"
$base = "http://127.0.0.1:$Port"

function Invoke-AgentJson([string] $Path, [string] $Method = "GET", $Body = $null) {
  $params = @{ Uri = "$base$Path"; Method = $Method; Headers = @{ Origin = $origin }; TimeoutSec = $TimeoutSec }
  if ($null -ne $Body) {
    $params.ContentType = "application/json; charset=utf-8"
    $params.Body = ($Body | ConvertTo-Json -Depth 8)
  }
  Invoke-RestMethod @params
}

function ConvertTo-ProcessExitCode($ExitCodeValue) {
  if ($null -eq $ExitCodeValue) { return 0 }
  try {
    $code64 = [int64] $ExitCodeValue
    if ($code64 -eq 0) { return 0 }
    if ($code64 -gt [int]::MaxValue -or $code64 -lt [int]::MinValue) { return 1 }
    return [int] $code64
  } catch {
    return 1
  }
}

function Invoke-OperatorRun([string] $TargetValue, [string] $CommandValue, [int] $RunTimeoutSec = $TimeoutSec) {
  if ([string]::IsNullOrWhiteSpace($TargetValue) -or [string]::IsNullOrWhiteSpace($CommandValue)) {
    throw "run requires -Target and -Command."
  }
  $body = @{
    target = $TargetValue
    command = $CommandValue
    timeoutMs = [Math]::Max(1000, $RunTimeoutSec * 1000)
  }
  if (-not [string]::IsNullOrWhiteSpace($SourceDevice)) {
    $body.sourceDeviceId = $SourceDevice
  }
  $payload = Invoke-AgentJson -Path "/operator/run" -Method "POST" -Body $body
  if ($payload.text) { Write-Output ([string]$payload.text).TrimEnd() }
  exit (ConvertTo-ProcessExitCode $payload.exitCode)
}

function Get-AgentRelayConfig {
  $configPath = Join-Path $env:LOCALAPPDATA "soty-agent\agent-config.json"
  if (-not (Test-Path -LiteralPath $configPath)) { return $null }
  try {
    Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
  } catch {
    $null
  }
}

function Get-AgentSourceTargets {
  $config = Get-AgentRelayConfig
  $relayId = [string] $config.relayId
  if ([string]::IsNullOrWhiteSpace($relayId)) { return @() }
  $baseUrl = if (-not [string]::IsNullOrWhiteSpace($RelayBaseUrl)) {
    $RelayBaseUrl.TrimEnd("/")
  } elseif (-not [string]::IsNullOrWhiteSpace([string] $config.relayBaseUrl)) {
    ([string] $config.relayBaseUrl).TrimEnd("/")
  } else {
    $origin
  }
  try {
    $encodedRelayId = [uri]::EscapeDataString($relayId)
    $payload = Invoke-RestMethod -Uri "$baseUrl/api/agent/source/targets?relayId=$encodedRelayId" -Method GET -TimeoutSec $TimeoutSec
    @($payload.targets)
  } catch {
    @()
  }
}

function ConvertTo-PsEncodedCommand([string] $Value) {
  [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($Value))
}

function Get-SotyEncodedRunCommand([string] $CommandValue) {
  if ([string]::IsNullOrWhiteSpace($CommandValue)) {
    throw "run-encoded requires -Command."
  }
  "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + (ConvertTo-PsEncodedCommand $CommandValue)
}

function Get-SotyMachineInstallCommand {
  $launcher = @'
$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$dir = Join-Path $env:TEMP 'soty-agent-machine'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$script = Join-Path $dir 'install-windows.ps1'
Invoke-WebRequest -Uri 'https://xn--n1afe0b.online/agent/install-windows.ps1' -UseBasicParsing -OutFile $script
$args = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $script + '" -Scope Machine -LaunchAppAtLogon'
Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $args
'@
  $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($launcher))
  @(
    "`$ErrorActionPreference='Stop'",
    "Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList '-NoLogo -NoProfile -ExecutionPolicy Bypass -EncodedCommand $encoded'",
    "Write-Output 'soty-agent-machine:uac-launcher-started'"
  ) -join "; "
}

function Get-SotyMachineStatusCommand {
  @(
    "`$ErrorActionPreference='Stop'",
    "try {",
    "`$h=Invoke-RestMethod -Uri 'http://127.0.0.1:49424/health' -Headers @{ Origin='https://xn--n1afe0b.online' } -TimeoutSec 2",
    "`$h | ConvertTo-Json -Compress",
    "} catch {",
    "`$m=`$_.Exception.Message.Replace('`"','')",
    "Write-Output ('{`"ok`":false,`"error`":`"' + `$m + '`"}')",
    "exit 1",
    "}"
  ) -join "; "
}

function Get-SotyMachinePortRepairCommand {
  $repair = @'
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
$log = "C:\ProgramData\soty-agent\machine-port-repair.log"
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $log) | Out-Null
function Log([string]$Message) {
  Add-Content -LiteralPath $log -Value ("[" + (Get-Date).ToString("o") + "] " + $Message) -Encoding UTF8
}
Start-Sleep -Seconds 2
try {
  try { Stop-ScheduledTask -TaskName "soty-agent-machine" -ErrorAction SilentlyContinue } catch {}
  $processes = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object {
      $_.CommandLine -and
      $_.CommandLine -match "C:\\ProgramData\\soty-agent" -and
      (($_.CommandLine -match "soty-agent\.mjs") -or ($_.CommandLine -match "start-agent\.ps1"))
    }
  foreach ($process in @($processes)) {
    try {
      $ownerResult = Invoke-CimMethod -InputObject $process -MethodName GetOwner
      $owner = $ownerResult.Domain + [char]92 + $ownerResult.User
      Log ("stopping " + $process.ProcessId + " " + $owner + " " + $process.Name)
      Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    } catch {
      Log ("stop warning for " + $process.ProcessId + ": " + $_.Exception.Message)
    }
  }
  Start-ScheduledTask -TaskName "soty-agent-machine" -ErrorAction SilentlyContinue
  Log "started soty-agent-machine"
} catch {
  Log ("repair warning: " + $_.Exception.Message)
}
for ($i = 0; $i -lt 24; $i++) {
  try {
    $health = Invoke-RestMethod -Uri "http://127.0.0.1:49424/health" -Headers @{ Origin = "https://xn--n1afe0b.online" } -TimeoutSec 2
    Log ("health " + ($health | ConvertTo-Json -Compress))
    if ($health.scope -eq "Machine" -and $health.system -eq $true) { break }
  } catch {
    Log ("health wait: " + $_.Exception.Message)
  }
  Start-Sleep -Seconds 1
}
'@
  $encoded = ConvertTo-PsEncodedCommand $repair
  @(
    "`$ErrorActionPreference='Stop'",
    "Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList '-NoLogo -NoProfile -ExecutionPolicy Bypass -EncodedCommand $encoded'",
    "Write-Output 'soty-agent-machine:port-repair-launched'"
  ) -join "; "
}

function Get-SotyBackgroundRunCommand([string] $CommandValue) {
  if ([string]::IsNullOrWhiteSpace($CommandValue)) {
    throw "run-background requires -Command."
  }
  $payload = ConvertTo-PsEncodedCommand $CommandValue
  $launcher = @"
`$ErrorActionPreference = "Stop"
`$ProgressPreference = "SilentlyContinue"
`$root = "C:\ProgramData\soty-agent\ops\jobs"
New-Item -ItemType Directory -Force -Path `$root | Out-Null
`$jobId = (Get-Date -Format "yyyyMMdd-HHmmss") + "-" + ([Guid]::NewGuid().ToString("N").Substring(0, 8))
`$jobRoot = Join-Path `$root `$jobId
New-Item -ItemType Directory -Force -Path `$jobRoot | Out-Null
`$scriptPath = Join-Path `$jobRoot "job.ps1"
`$stdoutPath = Join-Path `$jobRoot "stdout.txt"
`$stderrPath = Join-Path `$jobRoot "stderr.txt"
`$resultPath = Join-Path `$jobRoot "result.json"
`$body = @'
`$ErrorActionPreference = "Continue"
`$ProgressPreference = "SilentlyContinue"
`$payload = [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String("$payload"))
`$stdoutPath = Join-Path `$PSScriptRoot "stdout.txt"
`$stderrPath = Join-Path `$PSScriptRoot "stderr.txt"
`$resultPath = Join-Path `$PSScriptRoot "result.json"
`$startedAt = (Get-Date).ToString("o")
`$exitCode = 0
try {
  `$output = & ([scriptblock]::Create(`$payload)) 2>&1
  `$output | Set-Content -LiteralPath `$stdoutPath -Encoding UTF8
  if (`$global:LASTEXITCODE -ne `$null) { `$exitCode = [int]`$global:LASTEXITCODE }
} catch {
  `$exitCode = 1
  `$_.Exception.ToString() | Set-Content -LiteralPath `$stderrPath -Encoding UTF8
}
`$result = [ordered]@{
  ok = (`$exitCode -eq 0)
  exitCode = `$exitCode
  startedAt = `$startedAt
  finishedAt = (Get-Date).ToString("o")
  stdoutPath = `$stdoutPath
  stderrPath = `$stderrPath
}
Set-Content -LiteralPath `$resultPath -Value (`$result | ConvertTo-Json -Depth 8) -Encoding UTF8
'@
Set-Content -LiteralPath `$scriptPath -Value `$body -Encoding UTF8
Start-Process -FilePath "powershell.exe" -WindowStyle Hidden -ArgumentList "-NoLogo -NoProfile -ExecutionPolicy Bypass -File ```"`$scriptPath```""
[pscustomobject]@{ ok = `$true; jobId = `$jobId; jobRoot = `$jobRoot; resultPath = `$resultPath; stdoutPath = `$stdoutPath; stderrPath = `$stderrPath } | ConvertTo-Json -Compress
"@
  "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + (ConvertTo-PsEncodedCommand $launcher)
}

function Get-SotyJobStatusCommand([string] $JobIdValue) {
  if ([string]::IsNullOrWhiteSpace($JobIdValue) -or $JobIdValue -notmatch '^[0-9A-Za-z_-]+$') {
    throw "job-status requires a safe -JobId value."
  }
  $script = @"
`$ErrorActionPreference = "Stop"
`$ProgressPreference = "SilentlyContinue"
`$jobRoot = Join-Path "C:\ProgramData\soty-agent\ops\jobs" "$JobIdValue"
`$resultPath = Join-Path `$jobRoot "result.json"
if (Test-Path -LiteralPath `$resultPath) {
  Get-Content -LiteralPath `$resultPath -Raw
} elseif (Test-Path -LiteralPath `$jobRoot) {
  [pscustomobject]@{ ok = `$true; status = "running"; jobId = "$JobIdValue"; jobRoot = `$jobRoot; resultPath = `$resultPath } | ConvertTo-Json -Compress
} else {
  [pscustomobject]@{ ok = `$false; status = "not-found"; jobId = "$JobIdValue"; jobRoot = `$jobRoot; resultPath = `$resultPath } | ConvertTo-Json -Compress
  exit 1
}
"@
  "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + (ConvertTo-PsEncodedCommand $script)
}

if ($Action -eq "list") {
  $payload = Invoke-AgentJson -Path "/operator/targets"
  $sourceTargets = Get-AgentSourceTargets
  if (-not $payload.attached -and @($sourceTargets).Count -eq 0) {
    throw "soty PWA bridge is not attached and no active agent-source target is registered. Open or refresh the controller PWA, or press LINK in the Agent dialog on the source device."
  }
  foreach ($item in @($sourceTargets)) { "{0}`t{1}`tsource" -f $item.label, $item.id }
  foreach ($item in @($payload.targets)) {
    $status = if ($item.access -eq $true) { "access" } elseif ($item.host -eq $true) { "host" } elseif ($item.access -eq $false) { "visible" } else { "unknown" }
    "{0}`t{1}`t{2}" -f $item.label, $item.id, $status
  }
  exit 0
}

if ($Action -eq "run") {
  Invoke-OperatorRun -TargetValue $Target -CommandValue $Command
}

if ($Action -eq "run-encoded") {
  Invoke-OperatorRun -TargetValue $Target -CommandValue (Get-SotyEncodedRunCommand -CommandValue $Command)
}

if ($Action -eq "run-background") {
  Invoke-OperatorRun -TargetValue $Target -CommandValue (Get-SotyBackgroundRunCommand -CommandValue $Command) -RunTimeoutSec 20
}

if ($Action -eq "job-status") {
  Invoke-OperatorRun -TargetValue $Target -CommandValue (Get-SotyJobStatusCommand -JobIdValue $JobId) -RunTimeoutSec 20
}

if ($Action -eq "say") {
  if ([string]::IsNullOrWhiteSpace($Target) -or [string]::IsNullOrWhiteSpace($Text)) { throw "say requires -Target and -Text." }
  $payload = Invoke-AgentJson -Path "/operator/chat" -Method "POST" -Body @{ target = $Target; text = $Text; speed = $Speed; persona = "sysadmin"; timeoutMs = [Math]::Max(1000, $TimeoutSec * 1000) }
  if ($payload.text) { Write-Output ([string]$payload.text).TrimEnd() }
  exit (ConvertTo-ProcessExitCode $payload.exitCode)
}

if ($Action -eq "agent-message") {
  if ([string]::IsNullOrWhiteSpace($Text)) { throw "agent-message requires -Text." }
  $body = @{ target = $Target; text = $Text; timeoutMs = [Math]::Max(1000, $TimeoutSec * 1000) }
  if (-not [string]::IsNullOrWhiteSpace($SourceDevice)) {
    $body.sourceDeviceId = $SourceDevice
  }
  $payload = Invoke-AgentJson -Path "/operator/agent-message" -Method "POST" -Body $body
  if ($payload.text) { Write-Output ([string]$payload.text).TrimEnd() }
  exit (ConvertTo-ProcessExitCode $payload.exitCode)
}

if ($Action -eq "export") {
  if (-not [string]::IsNullOrWhiteSpace($Target) -or $TailChars -gt 0) {
    $body = @{
      target = $Target
      tailChars = [Math]::Max(0, $TailChars)
    }
    $payload = Invoke-AgentJson -Path "/operator/export" -Method "POST" -Body $body
  } else {
    $payload = Invoke-AgentJson -Path "/operator/export"
  }
  if (-not $payload.ok) { throw $(if ($payload.text) { [string]$payload.text } else { "soty export failed" }) }
  $text = [string]$payload.text
  if ([string]::IsNullOrWhiteSpace($OutFile)) { Write-Output $text } else {
    $parent = Split-Path -Parent $OutFile
    if (-not [string]::IsNullOrWhiteSpace($parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    Set-Content -LiteralPath $OutFile -Value $text -Encoding UTF8
    Write-Output $OutFile
  }
  exit 0
}

if ($Action -eq "install-machine") {
  Invoke-OperatorRun -TargetValue $Target -CommandValue (Get-SotyMachineInstallCommand) -RunTimeoutSec 60
}

if ($Action -eq "machine-status") {
  Invoke-OperatorRun -TargetValue $Target -CommandValue (Get-SotyMachineStatusCommand) -RunTimeoutSec 20
}

if ($Action -eq "repair-machine") {
  Invoke-OperatorRun -TargetValue $Target -CommandValue (Get-SotyMachinePortRepairCommand) -RunTimeoutSec 20
}
