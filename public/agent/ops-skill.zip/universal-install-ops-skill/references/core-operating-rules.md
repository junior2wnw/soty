# Core Operating Rules

Use this module when the top-level router is too compact and the agent needs the universal rules without reading every shelf.

## Optimization Contract

The skill's product is not more procedure. The product is a verified result
with less waste than last time. Its runtime reflex is:

```text
Route -> Act -> Prove -> Learn -> Close
```

- Optimize for outcome, safety, speed, token cost, operator effort, and reuse.
- Prefer a proven helper, hot route, case/profile fact, or memory prior before
  writing new scripts or scanning broad state.
- Use the Expected-First Rule: choose the safe route with the highest expected
  chance of success, then record prediction errors when reality takes a less
  likely branch.
- Spend tokens only on facts that change the next decision, proof, rollback, or
  future reuse.
- Capture both failures and successes when they shorten the next similar run.
- Promote repeated improvements into routes, shelves, evals, or helpers so even
  a weak model can use them without rediscovery.

## Top-State Scorecard

Use this seven-point scorecard before every state change and final answer. It is
the skill's simple modern control system: small enough for a weak model, strong
enough for risky operations.

- `result`: the user-visible outcome that matters
- `target`: exact machine, account, console, control plane, and next control plane
- `route`: fastest safe shelf/helper/hot route with the least new code
- `bottleneck`: current reason for slowness, waiting, retrying, or uncertainty
- `proof`: observable success signal before claiming done
- `client`: plain-language status or correction in the user's language
- `memory`: sanitized blocker, correction, command, timing, or win to capture now

If any scorecard item is unknown and changes the next action, ask or probe that
one fact only.

## Ready Gate

Before each state change, classify the next move as `go` or `stop`.

`go` requires a clear target, current control plane, shortest safe route,
observable proof, and risk gate for the operation depth.

`stop` when the target machine/account/console/control plane is unclear, the
client challenged speed/source/machine and the bottleneck is unverified, a
risky step lacks rollback/provenance/permission/return path, or the next move
would be broad scanning, fresh scripting, or guesswork.

On `stop`, tell the client the correction in plain language, probe exactly one
route-changing fact, and record a sanitized memory tick if it will shorten
future work.

## Route Fork Ledger

A route fork is any moment where another reasonable next action would change
the target, control plane, user trust, risk, proof, rollback, learning sink, or
future route. Examples include ask-vs-probe, stop-vs-continue, helper-vs-new
script, foreground-vs-background, minimal identity probe-vs-full preflight,
patch-vs-note-vs-branch, and sync-vs-record-blocked-sync.

Do not log every shell command. Do record every fork that would make the next
comparable run choose differently. Before crossing such a fork, choose the
learning sink:

- case-only fork -> case journal, handoff marker, or proof artifact.
- scoped reusable fork -> `ops.py --branch` or a route/profile update.
- workflow-changing fork -> patch the module, hot route, helper, or eval.
- already-covered fork -> explicit no-op with proof of the covering rule.

Close-out must be able to answer which forks changed the run and where each
reusable one landed. If that answer is missing, learning is incomplete.

## Expected-First Rule

Do not try a low-probability branch just to be exhaustive. Use the safest route
with the best current evidence and highest expected success. If a less likely
failure mode, fallback, route, or user correction actually happens, record the
prediction error before continuing:

- `expected`: the default or most likely route you chose
- `actual`: the branch that happened or worked instead
- `proof`: the observable signal
- `env`: the smallest transfer boundary that explains when it may recur
- `decision`: keep default, add conditional branch, downgrade default, or patch
  the module/helper/eval

This is the main way the skill learns without becoming superstitious: defaults
remain fast, and rare outcomes become scoped route knowledge only after proof.

## Action Packet

After routing, reduce the next move to one compact packet:

- `do_now`: the one helper, hot route, shelf read, guard, or probe to execute first
- `profile`: the route profile to reuse, or the reason none matches
- `stop_if`: the Ready Gate condition that blocks action
- `prove`: the observable success signal
- `checkpoint`: when to refresh route/memory continuity
- `branch`: how to record proof that beats a written/default route
- `remember`: the exact correction or win to capture before the next state change
- `close`: how to finish with `learning_delta`

If the packet and a longer reference disagree, trust the packet for the next
move and use the reference only to execute that move safely.

Default route output should be brief: route, first read/run, packet, and the
hint to use `--detail` or `--json`. Full scorecards and memory
snippets are for uncertainty, higher risk, debugging, or route-changing priors.

The default route also prints one `reflex` line. Treat it as the shortest valid
loop: do_now first; proof before done; learn before the next state change; close
with proof plus `learning_delta`.

Done means `user-visible proof + learning_delta + --close final_line`. A
`no-op` learning delta is valid only after checking that no reusable blocker,
fallback, timing, command, lower-probability outcome, route fork, route, or
wording lesson appeared. The final user or handoff answer should carry the
`final_line` from `ops.py --close`; otherwise the learning decision is still
implicit.

## Helper Fit Gate

Treat a helper as executable only when it matches the selected hot route. If the
router marks it as `candidate`, it is background context, not the first command.
This prevents broad skill-quality, planning, or recovery prompts from running a
nearby smoke test or utility instead of doing the actual work.

## Execution Contour Correction

Use this when the client challenges speed, target, machine choice, source,
network quality, route choice, or why the agent is doing work in the wrong
place. Treat it as a high-signal correction, not annoyance.

The agent is the client's expert sysadmin: calm, plain-spoken, and responsible
for a complete result on the right computer.

Immediately:

1. Pause non-essential work.
2. Recheck the four facts: `target machine`, `control plane`, `fastest safe route`, `current bottleneck`.
3. Say the correction to the client in their language: what was wrong or unproven, what you will change, and what success looks like.
4. Record a sanitized memory tick now, not only at the end:
   `python scripts/ops.py "<task>" --remember "<contour correction>" --proof "<observed reason>" --env "<target/control-plane/bottleneck>"`
5. Continue only from the corrected route.

Examples:

- "Why download slowly here?" -> check whether the target machine should download directly, whether the official source is reachable, and whether Wi-Fi is the bottleneck.
- "Why are you doing this on this computer?" -> stop and move the work to the ordered target/control plane when safe.
- "We used to write the official Windows image straight to USB faster" -> compare that known route with the current route before continuing.

## Plain Language

- Start with the practical result, then give the technical reason.
- Say what the next step will and will not do.
- Use `ready`, `blocked`, `risky`, and `done` for multi-step handoffs.
- Translate jargon the first time it matters.
- For physical handoffs, give one action, one success sign, and one reply request.
- Say `unknown` or `not proven yet` instead of hiding uncertainty.

## Depth Ladder

- `info`: explain or inspect instructions only; do not create a case.
- `console-touch`: classify console, host, working directory, privilege, intent, and proof before commands.
- `skill-factory`: create or improve a reusable tool, script workflow, skill, or skill repo.
- `tiny-control`: reversible controls such as audio, media, Wi-Fi, Bluetooth, VPN, brightness, or app focus.
- `normal-lifecycle`: packages, runtimes, apps, services, dependencies, configs, or non-destructive repair.
- `risky-lifecycle`: destructive, rebooting, production, trust-affecting, network-affecting, firmware, OS, driver, boot, data, cloud, or multi-session work.

Escalate only when risk, ambiguity, duration, or handoff complexity rises.

## Scope

Use this skill when the task inspects, verifies, debugs, configures, installs, repairs, recovers, deploys, resets, updates, removes, migrates, flashes, images, wipes, or otherwise touches software state on a local machine, remote host, VM, container, cloud control plane, attached device, firmware surface, or agent runtime.

Pure code-only work can stay outside this skill unless it changes runtime, package, service, device, operating-system, console, MCP, skill, or memory state.

## Evidence

- Prefer live target evidence and primary sources over memory.
- Treat learned facts as scoped priors, not global commands.
- Attach the smallest environment fingerprint that explains the route.
- Keep raw logs, private paths, credentials, serial-heavy dumps, and one-off chat narration out of shared notes.
- For risky work, prove hard gates before action: identity, backup, checksum, return path, compatibility, privilege, unlock state, dependency, destructive approval, and reachability.

## Token And Step Budget

- Ask for or probe only the fact that changes the next decision.
- Prefer one deterministic probe over a broad inventory.
- Run independent read-only probes, downloads, checksum calculations, or health
  checks concurrently when their outputs do not change each other's inputs.
- Keep concurrency bounded and collect results deterministically.
- Serialize state changes, shared-resource writes, locks, package-manager
  operations, firmware/boot/reboot work, production changes, and steps where
  rollback or proof depends on order.
- Stop exploring weaker routes once a safe, verified, lower-cost route is supported.
- Choose the route with fewer operator steps, fewer commands, lower token cost, and clearer proof when safety and evidence are comparable.
- For user-facing manual handoffs, default to GUI/physical/no-command routes for
  nontechnical operators when safety and result quality are acceptable. Present
  command/console routes as the faster technical fallback, or as the recommended
  route only when the GUI path is absent, destructive, much less reliable, or
  cannot prove success. Give short pros/cons when both are viable.

## Console Boundary

Before a command, know:

- console type and host
- working directory or target context
- privilege boundary
- command intent: read-only, reversible, install/repair, destructive, or access-changing
- expected success sign and output worth preserving

## Awake Preflight

Before any long local or remote operation, classify whether sleep, lid close,
screen lock policy, battery saver, remote session timeout, or a suspended VM can
interrupt the work or hide its proof.

If sleep can break the task, make the smallest reversible guard before starting:

- plug into power or ask the operator to keep the lid open
- use the OS-native prevent-sleep/keep-awake control for the command window
- run the long job under a service, scheduled task, job runner, or terminal
  multiplexer that survives disconnect
- record how to restore the original power policy if it was changed

Do this for packages, builds, downloads, backups, restores, flashes, migrations,
reboots, health checks, and remote commands. A live shell or SSH command is not
proof that the target will stay awake.

## Environment Fingerprint

Capture only facts that change routing:

- host OS, distro, build, architecture, virtualization, or container boundary
- package manager, installer format, runtime, service manager, or lockfile
- privilege model, UAC, trust store, certificate, policy, or unlock gate
- current transport and predicted next transport
- network, proxy, offline, removable-media, or return-path shape
- power source, sleep policy, lid/session guard, and expected idle duration when long work may be interrupted
- device model, codename, boot mode, firmware family, driver identity, filesystem, or storage fact
- agent runtime, active session boundary, source path, installed/bundled copy, and discovery surface

## Done

A run is done only when the user-visible goal is verified, risky return paths are preserved or explicitly blocked, and reusable learning is captured in the cheapest durable place that helps the next run.
