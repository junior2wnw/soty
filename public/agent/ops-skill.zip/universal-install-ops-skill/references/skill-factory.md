# Skill Factory

Use this module when the user asks to create, update, publish, or repair a reusable Codex skill or a small script-backed tool from the current dialog.

## Core Shape

Prefer a skill repo over a generic tools repo.

The smallest useful unit is:

```text
skill-name/
  SKILL.md
  scripts/
    main.py        # optional, only when deterministic code helps
  agents/
    openai.yaml    # optional but useful for UI and default prompt routing
```

Do not start with a registry, plugin framework, CI pipeline, or abstract lifecycle unless a real repeated need appears. A good skill is a focused trigger, a short workflow, and optional scripts that make brittle steps deterministic.

## Creation Gate

Create a new skill only when all are true:

- The same task or decision is likely to repeat.
- The trigger can be described in one or two plain sentences.
- The output or success sign is observable.
- A script, checklist, or reference would save future steps or tokens.
- The skill can stay smaller than the problem it solves.

If the work is one-off, update field notes or an existing module instead of creating another skill.

## Existing-Skill Growth

When the user wants a skill to improve after repeated operations, do not create a
new skill or a raw-dialog index first. Update the existing skill's learning
contract:

- make the trigger route to the right shelf
- add or sharpen the hot route when the task shape is frequent
- patch the module or helper when the step order, gate, proof, or wording changes
- queue sanitized candidate facts for one-off evidence
- sync installed or bundled copies only after validation

The ideal artifact is a shorter future route, not a bigger archive.

## Default Route

1. Distill the user goal into a reusable trigger.
2. Decide whether this belongs in an existing skill, a new skill, or a case-local note.
3. If new, run `scripts/skill/scaffold_skill.py` to create the minimal folder.
4. Add deterministic scripts only for repeated fragile steps, and put them in the matching `scripts/<category>/` folder when updating this skill.
5. Keep detailed domain knowledge in `references/`, not in `SKILL.md`.
6. Put the skill into the right shelf by updating the parent repo's `shelf-index.json` or adding keywords that make it findable.
7. Add or update `scripts/catalog.json` for every executable helper so weak models can find it without browsing folders.
8. Validate with `scripts/skill/validate_skill_package.py <skill-dir> --strict`.
9. Commit only after generated files, private data, and oversized artifacts are absent.

## Trigger Quality

The frontmatter `description` is the activation surface. It must include the words a user will actually use, including synonyms and local language where needed.

Good trigger text names:

- the user request shape, such as "create a tool", "создай тулз", "turn this dialog into a reusable skill"
- the target artifact, such as Codex skill, script-backed workflow, skill repo, MCP helper, or agent runtime config
- the required behavior, such as scaffold, validate, sync, publish, repair activation, or update memory

Keep the description under the runtime limit checked by `skill_health.py`. Put detailed policy in the body or references, not in frontmatter.

## Script Rule

Use scripts when consistency matters more than prose:

- scaffolding folders and frontmatter
- validating package shape
- parsing or transforming files
- checking health, hashes, links, or generated artifacts
- repeating commands that are easy to mistype

Prefer Python for portable file and text automation. Prefer PowerShell only for Windows control surfaces. Do not add a script if a two-line instruction is clearer and safer.

## Anti-Clutter Rule

Avoid these until evidence proves they are needed:

- central registries for every small tool
- YAML manifests beyond skill frontmatter and optional agent UI metadata
- README or process docs inside installed skill payloads
- one-off scripts without a clear skill trigger
- auto-update that can silently change behavior during a task

For a standalone GitHub repo, wrapper files such as `.gitignore` or `README.md` can exist, but validators should ignore them as repo packaging, not skill behavior.

## Million-User Rule

Assume the raw corpus will become too large to read.

- Strong models compile dialog/case evidence into clean shelf facts.
- Smaller OSS models consume `shelf-index.json`, one reference module, and ready scripts.
- Every new skill must have trigger words that route it without reading old chats.
- Every new script must have a success sign and validation path.
- Every new module must be directly linked from the owning skill or shelf index.

This keeps the system simple: many users create evidence, but agents consume compact shelves.

## Update Existing Before Creating New

Before adding a new skill:

- Search existing skill names, descriptions, and `references/field-notes.md`.
- If an existing skill can handle the task with one module or script, update it.
- If the trigger would overlap, make the boundary explicit in both skills.
- If a route failed because a skill did not invoke, fix the trigger surface and record that as a failed activation pattern.

## Done Criteria

A skill/tool factory task is done when:

- `SKILL.md` has a clear trigger and short workflow.
- Optional scripts run or at least compile.
- Any new executable helper is in the right script category and listed in `scripts/catalog.json`.
- `validate_skill_package.py --strict` passes for the created or updated skill.
- `skill_health.py` passes for this skill after edits.
- The installed or shared copy path is updated or the activation limitation is explicitly named.
- Reusable lessons are captured as field notes or compact memory markers.
