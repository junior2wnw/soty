# Release And Sync

Use this module when the skill itself is being edited, synced, published, rolled out, or checked for drift across runtime copies.

## Source Of Truth

- Patch the canonical skill tree first.
- Treat installed, bundled, and project copies as artifacts unless the sync path is blocked.
- Do not claim the skill is active just because a folder exists; verify source, runtime copy, and active-session boundary separately.
- A running session may keep the old prompt/tool registry until a new session or runner restart.

## Copy Drift Gate

After skill edits:

```powershell
python scripts/skill/finish_skill_edit.py --project-root <project-root>
```

The finish gate merges `.skill-memory` JSONL queues before learning review and
preserves `.skill-memory` during package sync. If promoted knowledge was written
directly into an installed or project copy, do not merge package files. Run
`sync_doctor.py` for read-only drift proof, port reviewed package changes into
canonical source with an explicit patch, then one-way sync.

Direct `sync_skill_copy.py` refuses to overwrite an existing divergent copy
that has local package edits unless `--force-canonical` is passed. Forced sync
keeps a local pre-sync package snapshot under the target
`.skill-memory/package-backups/`.

If a required copy differs, fix the reviewed canonical patch or sync before
calling the release good.
`--project-root` updates `tools/mcp/skills/universal-install-ops` and, when present, `apps/agent/bundled-core/machine-skills/universal-install-ops`.

## Release Channels

- `candidate`: canonical tree changed, tests not yet trusted for broad use.
- `canary`: small user/runtime slice receives the hash after health, activation eval, and privacy checks.
- `stable`: canary has no trigger regressions, destructive-default regressions, or privacy leaks.
- `rollback`: previous stable hash and copy bundle remain available before a mass rollout.

## Server Conveyor

At scale, the server should publish only compact artifacts:

```text
raw evidence -> sanitized marker -> partitioned queue -> dedup/rank -> reviewed shelf fact -> eval -> candidate release -> canary -> stable
```

Keep raw evidence outside the published skill. Partition queues by `shelf_id`, task family, platform family, risk level, and date. Use prompt hashes, sanitized signatures, and environment fingerprints for dedup; never use private hostnames, paths, addresses, tokens, serials, IMEIs, or raw transcripts as keys.

## Promotion Gates

- A small model can emit sanitized markers and use hot routes.
- A stronger compiler model should merge duplicates, reject private facts, and promote only route-changing patterns.
- A human or trusted review gate is required for destructive defaults, security/trust changes, public releases, or rules learned from weak evidence.
- A fact that only helps one private environment stays case-local or dialog-marker.
- Repeated facts graduate from `field-notes.md` into shelf modules, hot routes, scripts, or activation eval cases.

## Anti-Poisoning Rules

- Never let a single weak or private case rewrite a broad default.
- Prefer scoped facts: exact target, platform family, hard gate, or hypothesis.
- Keep failed routes; they prevent repeated waste, but must not become blanket bans without scope.
- Expire stale unclear facts unless new evidence refreshes them.
- Test trigger changes with activation eval before rollout.

## Done Criteria

- Canonical metadata hash matches current source.
- Required copies match the canonical hash through `skill_health.py --copy-root`.
- Activation eval has `failure_count: 0`.
- The release channel and rollback hash are known for shared deployments.
- The next small model can find the changed route through `shelf-index.json`, `hot-routes.json`, or `scripts/find_script.py`.
