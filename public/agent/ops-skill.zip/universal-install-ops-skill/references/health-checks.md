# Health Checks

Use this module to prove that the user-visible outcome works after a lifecycle change.

## Core Rule

Do not treat command success as task success. Verify the actual behavior the user needed.

Every health check should say:

- what is being checked
- how it is measured
- what passes
- what fails
- what evidence is stored

## Generic Verification Ladder

From strongest to weakest:

1. user-visible workflow succeeds end to end
2. API or service health endpoint returns the expected result
3. service manager, process, or job state is healthy
4. logs show expected ready marker and no new critical errors
5. binary, package, driver, or artifact exists
6. installer or command exited zero

Do not stop at levels 5 or 6 when the user asked for working behavior.

## Domain Checks

- packages and apps
  - binary path, version, launch check, GUI or CLI smoke test
- services
  - config syntax, service state, port readiness, API health, log marker
- databases and queues
  - process state, connection test, schema or migration status, read/write smoke test when safe
- containers
  - image digest, container state, health check, volume mount, network reachability, logs
- OS and boot
  - boot completion, expected account or access path, device drivers, update state, reboot survival
- firmware and devices
  - exact mode, version, feature matrix, transport after reboot or flash, rollback visibility
- networks
  - route, DNS, firewall, VPN, source interface, latency, and application-level reachability
- cloud resources
  - resource state, identity, tags, policy, endpoint reachability, billing or quota blockers when relevant

## Health Check Design

- Prefer polling observable readiness over fixed sleeps.
- For long work, also prove the target stayed awake long enough for the result
  and that any temporary keep-awake guard is still intentional or has been
  restored.
- Use the cheapest reliable check first, then deepen only if the result is ambiguous.
- Keep checks read-only unless a write smoke test is necessary and safe.
- Store enough evidence for the next agent to know whether the result was real.
- When a check is noisy or slow, promote a faster equivalent if one is proven.
- When a health check changes the route or proves readiness, copy it into the active case as a weighted `decision_fact` instead of leaving it buried in logs.

## Reusable Learning

Promote:

- fastest reliable readiness probe
- misleading success markers
- error messages that point to a known blocker
- normal timing ranges
- health checks that save tokens or operator round trips
