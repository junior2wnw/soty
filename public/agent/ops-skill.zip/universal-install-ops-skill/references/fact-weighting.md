# Fact Weighting

Use this module when route choice depends on multiple facts, when facts conflict, or when facts are being transferred from similar but not identical targets.

## Core Rule

Facts should not compete by volume or confidence in prose. Put route-driving facts into a weighted structure and compare them on the same dimensions.

The weighted summary is not decoration.
It decides the next smallest safe action:

- if a hard gate blocks, clear that gate before adding more supporting trivia
- if support is weak or stale, collect one stronger current fact
- if two routes are comparable, choose the lower-step route with the cleaner success signal
- if a caution fact is strong, resolve it before a risky transition

Use weighted facts for:

- hardware versus family assumptions
- package and service diagnosis with mixed logs and docs
- network changes with multiple possible causes
- firmware, boot, or recovery work
- cloud and production decisions with conflicting evidence
- any case where a stale strong-sounding rule might override a fresh exact-target fact
- any case where tiny observations need to accumulate without turning into unstructured prose
- any recurring control problem where several methods exist and the agent must keep the shortest reliable route on the surface

## Weighted Fact Fields

Record route-driving facts as `decision_facts` in `case.json`.
For quick capture during live work, prefer:

```bash
python scripts/case/record_case_fact.py <case-dir> --statement "..." --scope exact-target --evidence-quality live-observed --freshness current --target-fit exact --goal-fit controlling --polarity supports --source-ref "command output"
```

Recommended fields:

- `statement`
  - the fact in plain language
- `scope`
  - `hard-gate`, `exact-target`, `platform-or-family`, `universal-pattern`, `case-local`, or `hypothesis`
- `evidence_quality`
  - `live-observed`, `primary-source`, `case-observed`, `maintainer-or-community`, `user-reported`, `inferred`, or `stale`
- `freshness`
  - `current`, `recent`, `stale`, or `unknown`
- `target_fit`
  - `exact`, `same-family`, `analogous`, `weak`, or `unknown`
- `goal_fit`
  - `controlling`, `direct`, `supporting`, `weak`, or `unknown`
- `polarity`
  - `supports`, `blocks`, `caution`, or `unknown`
- `source_ref`
  - short pointer to the log, command, doc, case note, or user-visible prompt
- `shared_dimensions`
  - optional list of the dimensions that make transfer reasonable, such as package manager, OS family, firmware family, runtime, service manager, transport, network shape, or privilege model
- `divergent_dimensions`
  - optional list of the dimensions that explain why a similar target still differs here

## Default Weights

Use these defaults unless better evidence shows a different distribution is safer:

- evidence quality
  - `live-observed`: `1.00`
  - `primary-source`: `0.95`
  - `case-observed`: `0.85`
  - `maintainer-or-community`: `0.70`
  - `user-reported`: `0.60`
  - `inferred`: `0.40`
  - `stale`: `0.25`
- scope
  - `hard-gate`: `1.00`
  - `exact-target`: `0.95`
  - `platform-or-family`: `0.75`
  - `universal-pattern`: `0.65`
  - `case-local`: `0.60`
  - `hypothesis`: `0.30`
- freshness
  - `current`: `1.00`
  - `recent`: `0.85`
  - `stale`: `0.50`
  - `unknown`: `0.65`
- target fit
  - `exact`: `1.00`
  - `same-family`: `0.85`
  - `analogous`: `0.60`
  - `weak`: `0.35`
  - `unknown`: `0.50`
- goal fit
  - `controlling`: `1.00`
  - `direct`: `0.90`
  - `supporting`: `0.70`
  - `weak`: `0.40`
  - `unknown`: `0.50`

## Score Rule

For ordinary facts, use the product of the five weights and convert it to a percentage.

Example:

- `0.95 * 1.00 * 1.00 * 1.00 * 1.00 = 95`

Interpretation:

- `85-100`: controlling or very strong
- `65-84`: strong
- `45-64`: medium
- `25-44`: weak
- `0-24`: very weak

## Hard-Gate Rule

Do not average away a hard gate.

- if a `hard-gate` fact with `polarity: blocks` is current enough and relevant enough, the route is blocked
- if a `hard-gate` fact is still missing, the route is unproven even if weaker facts support it
- if two hard-gate facts conflict, prefer the fresher exact-target fact and verify before risky work

## Conflict Rule

When facts disagree:

1. prefer `hard-gate`
2. prefer fresher fact
3. prefer closer target fit
4. prefer higher evidence quality
5. prefer safer rollback and control plane

Do not let a more general fact overrule an exact-target fact without a strong reason.
When a fact transfers across related targets, record the shared dimensions that made the transfer reasonable. When the transfer fails, record the divergent dimensions instead of leaving the mismatch implicit.

## Case Use

Run:

```bash
python scripts/case/score_case_facts.py <case-dir> --write
```

This updates `computed_weight` and `weighted_fact_summary` inside the case.

Use the summary to keep visible:

- strongest supporting facts
- strongest caution facts
- strongest blocking facts
- whether any hard gate is unmet
- whether the route is `blocked`, `contested`, `supported`, `tentative`, or `unproven`
- whether stale, weak, or low-fit facts are still steering the route
- which shared or divergent dimensions still need to be recorded before a family-level fact should steer a risky route
- the recommended next evidence to gather or blocker to clear

## Route Properties

Use `route_properties` when the route depends on a property that can be predicted,
then checked on the exact target. Decision facts explain why a belief is
credible; route properties keep the actual branch variable on the surface.

Each route property should record:

- `name`: a stable property key such as `usb.supports_large_files`
- `expected_value`: the value the current route expects
- `chance`: the prior chance that the expected value is true
- `probe`: the smallest read-only check that can verify the property
- `observed_value` and `proof`: the exact-target observation when available
- `route_when_expected` and `route_when_unexpected`: the next route hints

Score or update them with:

```bash
python scripts/case/record_route_property.py <case-dir> --name usb.supports_large_files --expected-value true --chance 0.8 --scope exact-target --evidence-quality live-observed --freshness current --target-fit exact --goal-fit direct --probe "Get-Volume plus filesystem capability check"
python scripts/case/score_case_facts.py <case-dir> --write
```

The update rule is deliberately simple:

- before live proof, prior chance is discounted by source strength
- when observed value matches expected value, chance moves toward `1.0`
- when observed value disagrees, chance moves toward `0.0`
- uncertain or unchecked properties recommend the next probe instead of hiding
  inside prose

Do not hard-code future variants into route logic when a property can express
the real split. Add the property, give it a prior, define the probe, then let the
exact target observation correct the route.

For recurring low-risk controls, keep a lighter parallel surface:

- use [everyday-control-memory.md](everyday-control-memory.md)
- record `control_facts`
- prefer the route with comparable evidence and lower step cost when safety is unchanged
- keep the best current method near the top instead of burying it under longer prose

## Promotion Rule

Promote only reusable weighting rules:

- when freshness mattered more than familiarity
- when exact-target fit beat family similarity
- when a current health check correctly outranked a stale note
- when a user-reported fact was good enough only after live confirmation
- when lower step count or lower operator friction safely beat a longer route with equal evidence quality

Do not promote full case-specific fact tables into shared notes.
