# Knowledge Loop

Run this loop at the end of every request that used this skill.
This loop is part of done, even for small app, package, runtime, or service changes.

## Goal

Grow the skill like a tree:

- new durable facts go into the shared notes
- new workflow rules patch the right module
- new domains become new modules
- environment boundaries stay attached so routes do not turn into cargo-cult advice
- operational quality improves over time: safer defaults, faster checks, lower token load, clearer operator wording, better validation, and fewer repeated dead ends
- high-volume repeated facts graduate into stable shelves in `shelf-index.json` instead of piling up forever in `field-notes.md`

This is a continuous loop, not only a close-out checklist. While executing a task, keep a running list of facts and decide as soon as each fact is verified whether it changes the active route, belongs in a module, belongs in shared notes, or should remain case-local.

Do not save only a couple of end-of-run microfacts. While work is active, run a
short `--mode during` tick whenever a fact changes the next action, explains why
something failed, proves a fallback, reveals an association, or defines where the
lesson transfers.

The router prints `voice` lines on every before-route. Treat them as the small
subconscious loop: do the work well, keep the target safe, and cache the first
proved reusable fact instead of waiting for the final answer.

## Portable Skill Sink Rule

Choose the best writable learning sink before done:

- `canonical repo`: patch the source tree, update metadata, sync required copies,
  and run the health/activation gates.
- `another repo`: do not bury ops lessons in the project by default; run this
  skill's scripts by absolute path and write to the loaded skill root, or to the
  project's bundled skill copy only when that copy is the release artifact.
- `installed-only skill`: patch the installed copy or queue memory there, label
  the result `installed-only`, and do not claim it is shared until a canonical
  sync or release path exists.
- `read-only or hosted skill`: emit one sanitized `ops-memory:` or
  `control-memory:` marker in the final or handoff so a later writable session
  can ingest it.

Every run that used this skill must end with `learning_delta`: `patch`, `note`,
`marker`, `handoff-marker`, or `no-op`. Use `no-op` only when the route was
routine, matched existing shelves/helpers, and no timing, wording, failure,
fallback, or proof change would make the next run faster or safer.

When the final state is easy to forget or the session is crossing handoff
boundaries, run `python scripts/ops.py "<task>" --close --actual "<delta>"
--success "<proof>" --env "<boundary>"` and use its `final_line`.

Saving all dialogs and linking them from the skill is a last-resort audit
strategy, not the operating memory path. Raw dialogs are private, noisy, too
large for weak models, and expensive to route through. The published skill
should contain compact shelf facts, hot routes, scripts, eval cases, and small
candidate markers with proof and environment boundaries.

For queued facts, run `scripts/learning/compile_memory_queue.py` before cleanup.
Promote repeated rows into shelves/routes/helpers/evals, move covered rows to
reviewed storage, keep scoped singletons, and leave review-needed rows queued.

For repeated task families, create a sanitized route profile with
`scripts/learning/route_profile.py`. A profile needs shelf, task family,
platform family, control plane, proven route, proof, and transfer boundary; add
time/step/token metrics when known. Run `scripts/learning/learning_conveyor.py`
as the universal health gate before claiming the skill is clean or ideal.

## What To Capture

Every request must capture both the route result and the environment that shaped it.
When the user points out that the agent learned a lot in the dialog, treat that
as an explicit after-capture request, not as a comment to apologize for.

Capture facts as scoped evidence for every hardware and software target. When the scope matters, label whether the fact is a `hard-gate`, `universal-pattern`, `platform-or-family`, `exact-target`, `case-local`, or `hypothesis`.

Use learned facts as priors, not commandments. A prior can generate a candidate route, suggest a preflight check, or warn about a failure mode; it must still be tested against the current target, user goal, and control plane before risky action.

Do not let memory become dogma. When a remembered "best" route loses to a
shorter, safer, better-proven, or better-fit route, record the revision with
`scripts/learning/review_memory.py` and update the route profile, hot route, or
module rule if the old memory would still mislead future agents.

Treat written rules as defaults, not prisons. When the exact current situation
proves a better route, record a controlled branch with
`scripts/learning/route_branch.py`: parent rule, branch, conditions, reason,
proof, env, risk, and rollback. Keep one-case branches scoped until repeated or
safety-changing proof justifies promotion into a shelf, hot route, helper, or
eval; reject branches whose conditions fail.

When several routes could be optimal, capture the constraints that made the chosen route win here. Do not promote "route A won" as a universal rejection of route B unless the evidence really supports that.

When facts transfer between related targets, capture the shared dimension that made the transfer reasonable: OS family, hardware family, firmware family, package manager, runtime, service manager, container engine, cloud provider, storage layout, network shape, privilege model, or transport. When facts do not transfer, capture the divergent dimension. Prefer recording these explicitly as `shared_dimensions` and `divergent_dimensions` instead of leaving them buried in prose.

Always classify route information into one or more buckets:

- `proven`
  - a safe path worked
  - a check predicted the right next step
  - a tool or package manager gave a reliable outcome
- `failed`
  - a path is consistently wrong, unsafe, brittle, or wasteful
  - a tool misled the workflow
  - a step order caused regression
- `unclear`
  - evidence is partial
  - the hardware or environment is unusual
  - a hypothesis is useful but not yet safe to promote

When a route competes with other legitimate routes, also capture the route role:

- `primary`
  - best available route for this user and environment
- `alternate`
  - viable, but weaker than the chosen route
- `situational`
  - good only under specific constraints
- `recovery-only`
  - useful to regain access, not the final desired state
- `experiment-only`
  - honest spare-device or lab workflow, not a dependable daily-driver answer
- `porting-only`
  - engineering path, not a normal end-user install
- `reject`
  - route should not be presented as the answer when better candidates exist

Always capture the smallest sanitized environment fingerprint that explains the route:

- host platform, version, build, distro, or recovery mode
- architecture and virtualization or container boundary
- package manager, installer format, runtime, or service manager
- privilege model, UAC, trust store, certificate, or policy gate
- current transport and expected next transport
- network, proxy, offline, or removable-media constraints
- power source, sleep policy, lid/session guard, session timeout, or VM suspend
  risk when long work might be interrupted
- device identity, codename, boot mode, firmware family, or driver identity
- agent runtime, active session boundary, skill source path, installed or bundled copy, and discovery surface when the target is a tool, MCP, skill, or operational-memory route
- console type, target host or container, working directory, privilege boundary, command intent, and proof output when a terminal, shell, command prompt, PowerShell, SSH shell, recovery shell, serial console, container exec, cloud shell, or comparable command surface is involved

Capture failures even when no state change succeeded. A blocked or failed route is still reusable learning when the environment is clear.

Also capture small optimization facts:

- faster preflights or probes
- defaults that failed before a fallback worked
- successful routes that should transfer to another OS, device family, package manager, runtime, transport, or privilege model
- discovered associations between facts, such as `long remote task -> sleep risk
  -> keep-awake guard`, or `same package manager -> transferable command`
- checks that saved token-heavy exploration
- short wording that reduced operator confusion
- stale or noisy evidence sources to avoid
- artifact caches that are safe to reuse
- timing ranges that distinguish normal slowness from a hang
- validation rules that prevented an unsafe or wasteful step
- weight rules that correctly promoted one fact above another
- conflict patterns where a fresh exact-target fact correctly overrode a stale stronger-sounding general rule
- memory-revision facts where a formerly good default became rejected, downgraded, situational, or superseded by a better route
- prediction-error facts where the most likely safe route was correct to try,
  but a less likely branch actually happened and now needs a scoped condition
- route-switch microfacts where the expected method failed, another method worked, or a shorter route proved reliable under the current environment
- small recurring control facts such as the shortest reliable sound, Wi-Fi, Bluetooth, media, VPN, or radio path in a given environment

## Before Promoting Shared Knowledge

1. Read the current case journal if one exists.
2. Prefer evidence-backed facts over memory from chat.
3. Keep the full environment detail in the case journal when it is too specific for shared notes.
4. Strip private hostnames, private addresses, credentials, personal files, and user-specific trivia.
5. Promote only the durable pattern and the environment boundary that explains it, not the one-off story.

## Where To Write It

- Add small reusable notes to [field-notes.md](field-notes.md).
- Keep richer environment detail, raw evidence, and one-off operator context in the case journal.
- If the note changes actual procedure, patch the relevant module file now.
- If the note is sensitive or user-specific, keep it out of the shared skill tree.
- If a note is about route choice, prefer promoting the selection rule plus the environment boundary, not only the winning tool name.
- Keep weighted `decision_facts` in the case journal while the run is active. Promote only the reusable weighting rule or conflict-resolution pattern, not the whole case-specific fact table.
- For recurring low-risk controls, prefer the light contour in [everyday-control-memory.md](everyday-control-memory.md): keep `control_facts` in the case when a case exists, or a compact sanitized `control-memory:` marker in the response or handoff when dialog history is the practical review corpus.
- For general software-state microfacts, use the same idea: if a case is too heavy, leave one compact sanitized `ops-memory:` marker in the response or handoff so later dialog-history review can grep it directly.

## Promotion Tiers

Use the cheapest durable storage that still protects quality:

- `case-local`: full evidence, logs, private details, and exact host/device notes stay in the case journal.
- `dialog-marker`: one sanitized `ops-memory:` or `control-memory:` line captures a reusable method switch, failure, or shorter route when a full case would be too heavy.
- `server-prior`: the server may store sanitized markers from many users as short operational priors; these reduce search and token cost, but still need current target verification.
- `field-note`: repeated or strongly sourced patterns graduate into [field-notes.md](field-notes.md) with `scope:`, `evidence:`, `role:`, and `env:`.
- `module-rule`: patterns that change phase order, hard gates, route choice, validation, or rollback must patch the relevant module or script.

Do not promote raw dialog text, personal paths, hostnames, private addresses, credentials, serial-heavy dumps, or anything that only worked because of one user's private setup.

## Marker Format

Keep markers grep-friendly and token-light.
Use them only when they will save a future route choice.

```text
ops-memory: goal=<short outcome> | expected=<default or failed method> | actual=<winning method> | success=<observable proof> | env=<small sanitized fingerprint>
control-memory: action=<control action> | target=<state target> | plane=<control plane> | result=<works|blocked|partial> | method=<short method> | success=<observable proof> | env=<small sanitized fingerprint>
```

If the fact is risky, destructive, trust-affecting, or source-dependent, prefer `record_case_fact.py` plus a case journal over a marker alone.

## Fast Path

Before work, query the smallest memory surface:

```bash
python scripts/learning/memory_loop.py "<task in one sentence>" --mode before
```

During work, capture route-changing facts before they fade into chat prose:

```bash
python scripts/learning/memory_loop.py "<task>" --mode during --result partial --expected "<old assumption>" --actual "<new fact, fallback, or association>" --success "<proof>" --env "<small sanitized fingerprint>"
python scripts/ops.py "<task>" --remember "<new fact, fallback, or association>" --proof "<proof>" --env "<small sanitized fingerprint>"
```

For prediction errors, keep the default visible:

```bash
python scripts/learning/memory_loop.py "<task>" --mode during --result partial --expected "<safest highest-probability route>" --actual "<less-likely branch that happened>" --success "<proof>" --env "<transfer boundary>"
```

After work, let the same helper decide whether a fact is worth saving:

```bash
python scripts/learning/memory_loop.py "<task>" --result works --expected "<default route>" --actual "<winning route>" --success "<proof>" --env "<small sanitized fingerprint>"
```

Put the exact command, helper name, script run line, or compact step order in
`--actual`. The helper treats those as cache candidates automatically and still
skips routine lookups when there is no reusable signal.

If it prints missing questions, answer only those. If it prints `should_record: False`, do not create memory just to create memory. If proof and env are present, a safe candidate marker writes automatically; otherwise pass the sanitized marker to `ingest_memory_marker.py` only when the skill tree is not writable.

Use the helper script when a single note is enough:

```bash
python scripts/learning/record_learning.py --bucket failed --domain windows-reinstall --route-role reject --scope hard-gate --evidence-quality live-observed --pattern "SSH-only reinstall must stop when no durable post-reboot control path exists." --environment "windows host reinstall over ssh with no out-of-band console" --rationale "Blind reboot handoff creates destructive guesswork."
```

The script appends a sanitized note with an environment fingerprint into [field-notes.md](field-notes.md), can include optional scope, evidence-quality, shared-dimension, and divergent-dimension labels, and refuses obvious private addresses and hardware identifiers such as MAC addresses.
For repeated control-state facts, pair the shared note with a short `control-memory:` marker only when that extra marker will make later dialog-history mining easier.
For generic route-switch microfacts, pair the shared note with a short `ops-memory:` marker only when that extra marker will make later dialog-history mining easier.

## Sanitization Rules

Do not write any of these into shared notes:

- passwords
- license keys
- BitLocker recovery keys
- private IPs unless the pattern depends on the address shape
- private hostnames unless the pattern is generic
- personal names, chat transcripts, or file contents

Write the pattern, not the private data.

## Note Format

Use short timestamped entries.
Prefer this shape:

- `YYYY-MM-DD | bucket | domain | role: optional-route-role | pattern | env: sanitized environment fingerprint | why it matters`

Older entries may use the legacy five-field shape. New entries should include the environment segment.
New scoped entries may also include `scope: ...`, `evidence: ...`, `shared: ...`, and `diff: ...` before the pattern.

Examples:

- `2026-04-20 | proven | windows-reinstall | role: primary | dedicated installer USB plus separate backup target is the safest default path | env: local Windows reinstall with removable installer media and separate backup storage | avoids self-destructive stage bundles`
- `2026-04-20 | failed | windows-reinstall | role: reject | restoring SSH keys only into the user profile breaks admin-key setups using administrators_authorized_keys | env: Windows OpenSSH configured for machine-level administrator keys | restore both paths when sshd_config requires it`
- `2026-04-20 | unclear | android-flashing | role: situational | USB visibility is stable only on one front-panel port on this hardware | env: Windows host with device-specific USB and driver variance | verify on a second host before promoting`

Example dialog-history marker for a reusable microfact:

```text
ops-memory: goal=restart user app | expected=systemctl --user restart failed | actual=pkill app && app-launcher worked | success=window relaunched and health check passed | env=linux desktop, user session, app installed outside systemd
```

## Graduation Rule

- Keep a pattern in `unclear` until repeated evidence appears.
- Move it to `proven` only after it survives more than one realistic case or is backed by strong primary-source documentation.
- Move a repeatable bad path to `failed` as soon as the evidence is strong enough to save the next run.

## Promotion Rule

- Use `field-notes.md` for compact durable facts.
- Patch the module file when the phase order, gates, or routing logic changed.
- Patch during the run when a verified fact changes the next risky action; do not defer safety-critical improvements to end-of-task cleanup.
- Promote facts with their scope and confidence. Prefer "under these constraints this route wins" over "this route is always best" unless the evidence is a true hard gate.
- When two reusable control methods are similarly strong, promote the shorter and lower-friction route as the surfaced default and keep the slower method as an alternate rather than rediscovering the tie every time.
- When a default method fails and an alternate method works, promote that pair as one reusable microfact with the environment boundary that explains why the switch mattered.
- Add a new reference module only when a new recurring domain cannot fit cleanly into an existing module.
- Keep environment fingerprints small in shared notes and richer in the case journal.
- Run [field-notes-maintenance.md](field-notes-maintenance.md) guidance and `scripts/learning/maintain_field_notes.py` when notes become repetitive, stale, or too broad.
- When weighted fact scoring repeatedly changes route choice or prevents wasted work, patch [fact-weighting.md](fact-weighting.md) or `scripts/case/score_case_facts.py` instead of leaving the rule hidden in one case.

## Shared-For-All Rule

This skill can help other users immediately only if the tree is shared.

- In a shared repo, commit the updated skill tree.
- In a shared machine-skill directory, save the updated skill there.
- If the environment is private, keep the structure ready for sync but do not pretend it is globally shared already.
