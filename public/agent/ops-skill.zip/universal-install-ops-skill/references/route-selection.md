# Route Selection

Use this file when there is more than one plausible path and the agent must choose the best available route for the user's real goal.

This module prevents a common failure mode:

- remembering one proven route
- treating it as the answer to every similar request
- skipping a better-supported or lower-risk option that fits this user better

## Core Rule

Choose the best available route for the user's outcome and constraints, not the first route that looks technically possible.

The skill tree is a source of candidates, warnings, and shortcuts.
It is not a hard-coded order that overrides better evidence.

Multiple routes can be equally good for the same broad task under different constraints. Choose the primary route for this user and this environment, keep useful alternates visible, and avoid converting a local winner into a global law.
When two routes are similarly safe and evidence-backed, prefer the one with fewer steps, lower friction, lower token cost, and a cleaner success signal.

Treat past facts as scoped priors for any hardware, software, system, network, or device target. They help generate candidates and preflight checks, but the current target, support reality, control plane, compatibility boundary, evidence quality, and user goal decide the route.

When the route depends on more than one nontrivial fact, keep a weighted decision-fact list in the case. Do not trust memory alone when the facts differ in freshness, target fit, or evidence quality.

## One-Pass Selection Loop

1. Restate the user's desired outcome in plain language.
2. Pick the lightest safe depth for the task: `info`, `tiny-control`, `normal-lifecycle`, or `risky-lifecycle`.
3. Capture the hard constraints that change the route:
   - data must be preserved or can be erased
   - daily-driver or spare device
   - official support required or community path acceptable
   - time budget
   - skill level of the operator near the device
   - return-path requirements
   - exact hardware, model, codename, or firmware family
4. Generate the shortest honest list of route candidates.
   - usually 2 to 5 candidates
5. Score the candidates against the same axes.
6. Score the current controlling facts as well as the route candidates.
7. Choose one primary route.
8. Keep at least one alternate or fallback route when the task is risky.
9. Record why the rejected routes lost.
10. If the chosen route is not the shortest safe route, write the reason so future agents do not re-litigate it.

## Candidate Sources

Build candidate routes from the strongest available evidence first:

1. official vendor recovery or install path
2. official project support matrix or exact device page
3. maintained generic family or SoC page
4. named maintainer documentation or upstream issue tracker
5. community guide with clear boundaries and current evidence
6. self-porting or engineering workflow

If the route comes only from step 5 or 6, say so clearly.

## Scoring Axes

Score each candidate on the dimensions that matter for this request:

- outcome fit
  - does it actually deliver what the user asked for
- support reality
  - official, maintained, testing, porting-only, or abandoned
- evidence quality
  - live-observed, primary-source, case-observed, maintainer/community, user-reported, inferred, or stale
- feature completeness
  - especially important on phones and tablets
- safety
  - data loss risk, brick risk, or irreversible state changes
- reversibility
  - how easy it is to roll back
- rollback proof
  - whether a real backup, snapshot, known-good artifact, exported policy, or recovery path exists now
- operator burden
  - number of physical steps, patience, and skill required
- control-plane strength
  - how strong the current and next transport are
- time to value
  - how quickly the user reaches a working result
- maintenance burden
  - how hard updates, fixes, and future recovery will be
- supply-chain trust
  - where images, packages, drivers, scripts, policies, or configs come from and how they are verified
- efficiency
  - route setup time, safe concurrency, repeated token cost, operator round trips, and future reuse
- action count
  - number of commands, physical steps, context loads, and follow-up questions needed to prove success

Parallelism is an efficiency bonus only when safety, evidence, rollback, and
proof are unchanged. Do not choose an async route just because it is faster.

Do not invent fake precision. A short verbal ranking is enough.

For the facts that control the chosen route, use [fact-weighting.md](fact-weighting.md) and prefer an explicit weighted summary over an implicit vibe.

## Route Roles

Classify each candidate into one of these roles:

- `primary`
  - best available route for this user right now
- `alternate`
  - viable, but weaker than the chosen route
- `situational`
  - good only under specific constraints
- `recovery-only`
  - useful to restore access, not as the final desired state
- `experiment-only`
  - acceptable for spare hardware or learning, not for dependable daily use
- `porting-only`
  - engineering path, not a normal end-user install
- `reject`
  - misleading, unsafe, or worse than the available alternatives

These roles are simple enough to reuse across phones, laptops, servers, media, and app installs.

## Default Decision Rules

- Prefer the least-destructive route that still satisfies the user's stated goal.
- Prefer a maintained exact-device route over a generic promise.
- Prefer a supported end-user install over a porting workflow when the user asked for a normal install.
- Prefer reproducible declarative tooling when the task is likely to repeat.
- Prefer the lower-step route when support reality, safety, rollback proof, and success visibility are materially equal.
- Prefer stronger feature completeness over ideological purity when the user needs the device to actually work.
- Prefer mainline-first or cleaner long-term paths when the user explicitly values openness, experimentation, or long-term hacking over immediate hardware completeness.
- If no candidate truly satisfies the goal, say that plainly and offer the closest honest alternative.
- For repeated lifecycle work, separate fast-lane execution from readiness-building. If reusable gates, profiles, media, and proof already exist, choose the path with the fewest new commands and operator round trips. If they do not exist, call the missing gate out directly instead of hiding discovery time inside new one-off scripts.

## Mobile Linux Heuristics

For Linux on phones or tablets, the best distro depends on the goal:

- daily-driver outcome
  - prefer the route with the best proven telephony, data, GPS, audio, suspend, and update story on that exact device
- spare device or experiment outcome
  - mainline-first or testing-grade ports may be the better fit
- Debian userland outcome
  - a Halium-based route such as Droidian can be the better fit if the device is truly supported
- Linux-first hardware outcome
  - a distro aligned with Linux-first devices may beat Android-adaptation stacks
- unsupported device outcome
  - porting-only is not the same thing as a normal install

Do not hard-code any distro as the answer to "install Linux".

## Case Journal Rule

When a case exists, store:

- the candidate list
- the chosen primary route
- the strongest alternate
- the strongest supporting facts and strongest blocking facts for the chosen route
- the rejected routes and the short reason each lost

This makes later handoff and future learning much better than a single irreversible narrative.

## Promotion Rule

Promote universal decision rules into shared knowledge.
Keep device-specific winners bounded by environment.

Good shared notes:

- how to compare routes
- what made one route safer
- what made another route porting-only
- which missing features downgrade a route from daily-driver to experiment-only
- which similarities transferred across targets and which exact-target facts still needed verification
- which route saved time or operator effort without reducing evidence quality
- which shorter control route stayed reliable enough to be surfaced as the new default

Bad shared notes:

- a single device conclusion promoted as if it were universal
- a one-off community guide treated like a default answer for every similar request
- a package, service, OS, network, hardware, or firmware route that lost under one user's constraints recorded as if it is always bad
