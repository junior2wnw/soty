# Script Organization

Use this module when adding, finding, or moving helper scripts.

The rule is simple:

```text
task -> shelf -> script catalog -> one category folder -> one command
```

## Fast Lookup

For weak or low-context agents, do not browse the tree.

1. Run `python scripts/find_script.py "<task in one sentence>"`.
2. If the task is already routed to a shelf, add `--shelf <shelf-id>`.
3. Use the top `run:` line when the purpose and shelf match the task.
4. Read the script only if you must patch it or verify risky behavior.

`run:` is absolute and safe from the caller's current directory.
`command_from_skill_root` is only for agents that have already changed directory to the printed `run_from`.
If no script matched, do not run a zero-score catalog neighbor; route the shelf or add a trigger.
For skill release confidence, use `python scripts/skill/self_check.py`; it runs from a temporary outside directory so relative-path mistakes cannot hide.

## Folders

- `scripts/routing`: choose shelves, hot routes, activation behavior, and script entry points.
- `scripts/learning`: sanitized memory queues, field notes, missed invocations, and compaction.
- `scripts/case`: case journals, decision facts, control facts, validation, and scoring.
- `scripts/skill`: skill scaffolding, package validation, metadata, sync, and health checks.
- `scripts/windows`: Windows reinstall, WinPE, USB, SSH return-path, and recovery helpers.
- `scripts/android`: Android USB, firmware, image, ADB, and fastboot helpers.
- `scripts/control`: small reversible control-surface helpers.
- `scripts/tests`: regression and smoke tests.
- `scripts/lib`: import-only shared code; do not put runnable task scripts here.

## Adding A Script

1. Choose the folder by what the script operates on, not by file extension.
2. Keep the script name verb-led and specific.
3. Add an entry to `scripts/catalog.json` with `id`, `category`, `shelf`, `path`, `purpose`, `triggers`, and `command`.
4. Add the path to `references/shelf-index.json` only when it is a safe reusable entry point for that shelf.
5. Run `python scripts/find_script.py "<realistic user task>"` and confirm the new script is discoverable.
6. Confirm the printed `run:` command points to an existing absolute path and uses the current script parameters.
7. Run `python scripts/skill/skill_health.py`; uncataloged runnable scripts are an error.

## Async And Parallel Scripts

Prefer async or parallel execution only when it makes the helper faster without
weakening proof or rollback.

Good candidates:

- independent read-only probes
- independent downloads or checksums
- independent health checks whose outputs are aggregated after all complete
- remote inventory across unrelated hosts when rate limits and transport are safe

Hard stops:

- ordered state changes
- package-manager writes or service restarts that share locks
- firmware, boot, reboot, partition, restore, or destructive work
- production changes without a transaction, rollback, and bounded concurrency
- UI or operator steps where parallel prompts would confuse the person

When using concurrency, set a small limit, timeouts, per-task error capture, and
a deterministic final summary. If those controls make the script harder to trust,
keep it synchronous.

## Do Not

- Do not add runnable scripts directly under root `scripts/`.
- Do not make one giant cross-domain script when two small category scripts are clearer.
- Do not rely on filename guessing; catalog the user words that should find the helper.
- Do not add private host paths, tokens, serials, or one-user assumptions to catalog text.
