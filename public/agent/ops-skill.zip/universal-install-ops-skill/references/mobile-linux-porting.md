# Mobile Linux Porting

Use this module when the user wants to start or continue a phone/tablet Linux port and there is no maintained end-user install image for the exact device.

This is not a normal install flow. Treat it as an engineering project with small proof milestones and a hard recovery gate before destructive phone actions.

## User Explanation Shape

When reporting a phone porting project to the user, use this order:

1. Plain status
   - "We are not installing yet; we are building the first safe Linux path."
2. Why
   - "No ready-made Linux image exists for this exact model."
3. What we know
   - exact model, firmware, bootloader state, source evidence, working cable/control link
4. What blocks us
   - one or two blockers in ordinary words
5. What is next
   - the next safe step that does not erase data
6. Where the full detail lives
   - case runbook, dossier, logs

Avoid dumping a long tool list first. The user needs a safe map before the machinery.

## Simple Terms

- Ready image: a tested file that can be flashed now.
- Porting: creating the missing support for this exact phone.
- Build machine: the computer or Linux VM that creates the phone image.
- Source package: code from Samsung or a ROM project that helps us build.
- Rollback package: a known-good stock or ROM package used to recover the phone.
- First boot artifact: the first exact file we might test on the phone.
- Bring-up matrix: the checklist of what works after boot, such as display, touch, Wi-Fi, modem, calls, and charging.

## Entry Rule

Only call the route a porting project after all are true:

- exact model/codename is proven from host-visible or device-visible evidence
- normal supported-device matrices do not provide a maintained install route
- the user accepts that the first target is experiment-only, not a daily-driver phone
- a case journal exists for the project

If the exact device has an official custom Android ROM but no mobile-Linux image, keep that Android ROM as a fallback or evidence source, not as proof that Linux is supported.

## Evidence Layers

Capture these layers before building or flashing:

1. Device identity
   - model, codename, product, architecture, firmware build, security patch
   - ADB/fastboot/Download Mode visibility
   - bootloader, AVB/vbmeta, and warranty state
2. Partition and boot facts
   - `/dev/block/by-name`, boot/recovery/vbmeta/dtbo/super/userdata partitions
   - boot image format and expected flash tool or slot
3. Source authority
   - vendor open-source kernel package for the exact firmware when available
   - maintained Android ROM kernel/device trees as implementation evidence
   - pmaports or distro device package absence/presence
4. Build control plane
   - Linux host, WSL, VM, or remote builder identity
   - package/network access, free space, RAM, and tool versions
   - where logs and artifacts are stored
5. Recovery path
   - stock firmware or official custom ROM recovery baseline
   - tool path for returning to stock/custom Android
   - expected post-flash transport

Keep all intermediate findings in the case journal:

- successful checks
- failed downloads or blocked networks
- source pages checked and rejected
- small device facts such as firmware build, partition names, and cable mode
- human-visible prompts and exact user-facing wording that worked

When promoting to the skill tree, compress these into reusable rules and environment fingerprints.

## Cross-Device Reuse Rule

Use earlier phone or tablet ports as templates, not as proof. A close device, shared SoC, shared firmware family, similar bootloader flow, or related kernel generation can provide package structure, likely tool choices, and preflight checks, but exact-target evidence still owns destructive decisions.

Separate reusable facts from variant facts:

- reusable candidates: SoC family, kernel generation, boot image format, Android version family, bootloader mode, host tool behavior, distro build workflow, and common partition naming patterns
- exact-target gates: model suffix, codename, region or carrier variant, bootloader unlock state, partition names on the live device, rollback package, maintained image or package presence, panel or touchscreen variant, modem stack, and bring-up matrix

When two devices share a fact, record the shared dimension. When they diverge, record the divergence so the next agent can reuse the comparison instead of copying the wrong route.

## Vendor Source Access Rule

For vendor source packages, separate "listed" from "downloaded".

- Listed means the official page or search result names the exact model, firmware version, and source filename.
- Downloaded means the archive exists locally, has a recorded size, and has a checksum.
- Usable means the archive has been extracted and the kernel source, defconfig, dtb/dtbo paths, and build toolchain assumptions are identified.

Do not advance a port beyond the skeleton stage on listing evidence alone. If an official vendor site blocks automation with a browser or security check, record that as a source-acquisition blocker and use a human browser or another official channel instead of guessing from mirrors.

## Sensitive Device IDs Rule

Some firmware tools ask for a device IMEI or serial-like identifier.

- Prefer model, codename, CSC/region, build number, and product code first.
- Do not store real IMEI values in case logs, skill notes, shell transcripts, or chat.
- If an IMEI is truly required to download a rollback package, use a transient variable and mask tool output before writing logs.
- If the agent cannot obtain or use the ID without exposing it, stop at a clear blocker and ask for a manual GUI/human-browser step.
- A dummy or test IMEI may prove whether the tool works, but it does not prove the download path for the user's exact phone.

Plain wording:

- "The server is asking for a private phone number-like identifier. I will not save it in the logs."

## Route Ranking

Rank porting candidates in this order unless device evidence says otherwise:

1. postmarketOS exact-device or family port already in pmaports
2. postmarketOS downstream-kernel port using vendor kernel source
3. postmarketOS mainline or close-to-mainline effort when SoC support exists
4. Halium/Droidian-style Android adaptation when the device has a useful Android tree and the goal is phone UX
5. self-porting from scattered community repositories

LineageOS, crDroid, and other Android ROMs are not Linux replacements. They can still be valuable as:

- bootloader/recovery/firmware flow evidence
- kernel/device tree references
- rollback or sanity-check targets
- a practical Android base for VPN/proxy workloads

## Milestone Contract

Do not jump from "we found sources" to "flash the phone".

Use these milestones:

- M0: Preserve recovery facts
  - export ADB properties, partition names, firmware, battery, current transport
  - identify stock rollback package and source package
- M1: Build control plane
  - install or clone current build tools
  - prove package and source fetches work from the builder
  - record free space and where artifacts will live
- M2: Device package skeleton
  - create or generate device package metadata
  - decide downstream vs mainline kernel route
  - build device package without phone flashing
- M3: Kernel package baseline
  - acquire source, identify defconfig/dtb/dtbo/boot image format
  - compile or document the first compiler blocker
- M4: First boot artifact
  - produce a named artifact and checksum it
  - name the exact partition/tool before any flash
- M5: Bring-up matrix
  - measure display, touch, USB networking, buttons, charging, storage, Wi-Fi, Bluetooth, audio, modem, SMS, calls, camera, GPS, suspend
  - keep the route experiment-only until the matrix supports a stronger claim

## Skeleton Rule

For an unsupported phone, a local device/kernel package skeleton is a map, not a road.

It may capture:

- exact model, codename, firmware, architecture, screen, USB IDs, and partition names
- draft package names and pmaports file shape
- TODO markers copied from live evidence gaps

It must stay case-local or draft-only until these are proven:

- vendor source package and checksum
- stock rollback package and checksum
- boot or recovery image header version, cmdline, pagesize, offsets, and dtb/dtbo handling
- working defconfig or the next exact compiler blocker
- exact flash tool, partition or slot, and expected next transport

Never present a skeleton as "Linux is ready". Say plainly:

- "We have the outline for a port."
- "We do not yet have a file that is safe to flash."

## Destructive Gate

No bootloader unlock, Download Mode flash, vbmeta change, userdata erase, or partition write until all are true:

- exact artifact is named and checksummed
- exact target partition or Odin/Heimdall slot is named
- stock or known-good rollback package is present and verified
- current mode visibility is proven
- next expected transport is named
- user understands what will be erased by this specific step

## Build-Control-Plane Rule

Treat the build machine as a control plane. A porting project is blocked when the phone is ready but the builder cannot fetch sources or packages.

For WSL:

- prove outbound from inside WSL, not only from Windows
- capture active VPN/tunnel adapters when Windows works but WSL times out
- run `scripts/windows/windows-wsl-network-preflight.ps1` when WSL networking is confusing
- do not install build tools repeatedly when the real issue is WSL NAT, DNS, proxy, firewall, or VPN routing
- prefer fixing or replacing the build host before unlocking the phone

## A21s Fingerprint

Reusable boundary from a Samsung Galaxy A21s start:

- device: Samsung Galaxy A21s `SM-A217F/DSN`, ADB model `SM-A217F`, codename `a21s`, product `a21snsser`
- firmware: Android 12 `A217FXXSCDXE2`, security patch `2024-05-01`
- boot state: locked bootloader and locked vbmeta
- source evidence: Samsung Open Source lists `SM-A217F_CIS_12_Opensource.zip` for `A217FXXSCDXE2`
- Android evidence: LineageOS has active A21s/device-common/Exynos850 branches through `lineage-23.2`
- mobile-Linux evidence: no A21s/A217 pmaports package found in checked main/community/testing/archived categories
- route role: porting-only, with postmarketOS downstream-kernel experiment as the first honest Linux route
- build blocker observed: Windows outbound worked through VPN, while WSL2 Ubuntu timed out to GitHub, postmarketOS docs, and Ubuntu mirrors
- builder recovery observed: WSL 2.6 outbound worked after `.wslconfig` enabled mirrored networking, DNS tunneling, auto proxy, and firewall, followed by `wsl --shutdown`
- tooling staged: `pmbootstrap 3.10.1` from upstream git, local pmaports clone, `kpartx`, and basic `pmbootstrap init`
- pmaports evidence after local clone: commit `0def725` had no exact `a21s`, `a217`, `exynos850`, or `universal3830` support; nearby Samsung downstream ports are templates only
- draft skeleton status: a case-local `device-samsung-a21s`/`linux-samsung-a21s` skeleton can record known facts, but it is explicitly not flash-ready before Samsung source, rollback firmware, boot image analysis, defconfig, and checksums

This fingerprint is not a finished port. It is a bounded starting point for the next agent.

## Redmi A5 Fingerprint

Reusable boundary from a connected Redmi A5 start:

- device: Redmi A5 global variant `25028RN03A`, ADB model `25028RN03A`, codename `serenity`
- firmware: Android 15, security patch `2025-08-01`
- boot state: `ro.boot.verifiedbootstate=green`, `ro.boot.flash.locked=1`
- platform facts: Treble enabled (`ro.treble.enabled=true`)
- control plane: authorized `adb` on Windows host, no `fastboot` device yet because the phone is still in Android
- support evidence: checked official Ubuntu Touch codename catalog does not list `serenity`; checked official Droidian guidance says non-listed devices must follow the porting guide
- route role: blocked for normal install, porting-only for native mobile Linux until an exact-device image or a proven porting baseline exists
- safe next step: stop before unlock or wipe, then decide between a userland Linux path inside Android and a true porting project

This fingerprint is not an install route. It is a bounded proof that the exact phone is visible, locked, and not yet supported by a normal end-user Linux image.
