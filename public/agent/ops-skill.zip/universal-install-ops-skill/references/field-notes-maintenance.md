# Field Notes Maintenance

Use this module when shared notes become repetitive, stale, too broad, or expensive to scan.

## Core Rule

The skill should get sharper over time, not only larger.

Field notes are useful when they help the next route choice, preflight, verification, safety gate, speed, token cost, or operator wording. Notes that no longer do that should be narrowed, graduated, archived, or removed from the active path.

## Maintenance Loop

Run periodically, especially after several lifecycle tasks in the same domain:

```bash
python scripts/learning/maintain_field_notes.py
```

Use `--fail-on-findings` only when a CI or release gate should fail on maintenance debt.

Use the report to find:

- malformed notes
- orphan text inside a note bucket that is not attached to a timestamped note
- duplicates
- notes missing `env:`
- notes missing `scope:` or `evidence:` when those labels matter
- stale `unclear` notes
- overly broad device, OS, package, or network conclusions

## Aging Rules

- `unclear` notes should be reviewed first. Promote, narrow, or archive them when they age without new evidence.
- `failed` notes can stay active when they prevent repeated waste, but should include the smallest environment boundary that explains the failure.
- `proven` notes should graduate into module rules or scripts when they repeatedly change workflow.
- Device-specific, host-specific, version-specific, or service-specific notes should not sit near universal rules unless their boundary is obvious.

## Compaction Rules

Prefer one strong scoped note over many near-duplicates.

Keep:

- the shared dimension that transfers
- the divergent dimension that blocks transfer
- the evidence quality
- the route role
- the reason the note saves time, risk, tokens, or operator effort

Remove or archive:

- raw case narration
- private details
- stale source URLs without current verification value
- repeated notes that say the same thing with different private facts

## Done Criteria

Maintenance is done when:

- there are no orphan note fragments in active buckets
- duplicate or stale clusters have an action
- unclear notes either remain justified or are promoted/narrowed
- reusable workflow changes are patched into modules or scripts
- the active notes are shorter or easier to route from
