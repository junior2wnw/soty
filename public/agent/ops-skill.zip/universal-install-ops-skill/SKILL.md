---
name: ops
description: >-
  Use $ops as the default fast, token-efficient operating loop for computer and
  system work: terminal, PowerShell, SSH, packages, apps, services, runtimes,
  containers, OS, firmware, devices, MCP, Codex skills, skill sync, operational
  memory, audio/Wi-Fi/VPN controls, or reusable tool/skill work. Route to one
  shelf/helper, do the smallest safe action, verify success, protect rollback,
  record sanitized problems and successes, and promote reusable improvements so
  future agents do the same work faster and better.
metadata:
  aliases:
    - universal-install-ops
    - system-ops
    - computer-ops
---

# Ops

Ops is the baseline operating loop for computer/software work: finish safely
with low step/token cost, reuse known routes, and improve the next run.

## One Reflex

Route -> Act -> Prove -> Learn -> Close. That is the whole skill: run the router first, obey `do_now`, stop on the Ready Gate, learn before drift, and close with proof plus `learning_delta`. A final answer without a `--close` receipt or named blocker is unfinished.

Before each state change and final answer, check:

- result: the visible outcome the client needs.
- target: the right machine, user, console, and control plane.
- route: one shelf/helper/hot route, or one deterministic probe.
- proof: the exact signal that shows success or the blocker.
- learn: patch, note, marker, branch, handoff marker, or explicit no-op.
- client: plain language when the contour changed.

Route forks are learnable events. If ask-vs-probe, stop-vs-continue,
helper-vs-new-script, foreground-vs-background, or patch-vs-note-vs-branch
changes the next comparable run, give it a sink before the next state change.
Use [core-operating-rules.md](references/core-operating-rules.md) when subtle.
Default to the safest highest-probability route; if a less likely outcome
happens, record `expected`, `actual`, `proof`, and `env`.

## Ready Gate

Proceed only when target, route, proof, risk, and learning sink are clear enough.
Stop for one fact when target/control plane, bottleneck, proof, rollback, or
route-fork sink is unclear, or when the next move is broad scanning, fresh
scripting, guesswork, or a reusable lesson with no patch/marker/branch/no-op.

Done means `user-visible proof + learning_delta + --close final_line`.
`learning_delta=no-op` is valid only when no blocker, fallback, timing, command,
lower-probability outcome, route fork, route, or wording lesson would make the
next comparable run faster or safer.

## One Command First

Run this from the skill root, or by absolute path from an installed copy:

```powershell
python scripts/ops.py "<task in one sentence>"
```

Follow its output:

- `action_packet`: do this first; it compresses the route into do/stop/prove/remember/close.
- `helper` / `run`: use the printed command only when it exactly matches.
- `helper_fit`: run a helper only when this says `run`; `candidate` is context.
- `read`: open only the listed shelf file if no helper fits or risk is higher.
- default text output is brief; use `--detail` or `--json` only when the route is unclear, risk is higher, or memory snippets change the next action.

Fallback only if `scripts/ops.py` is unavailable: run `memory_loop.py --mode before`, `route_shelf.py --top 1`, `route_hot.py --top 1`, then `find_script.py --top 1`; in Soty LINK-only sessions with no local shell but `soty_run` / `soty_script`, do not read skill files or run ops.py on the source device, use one direct LINK command+readback as the only command plane, never the controller computer.

## Hard Rules

- Prefer the router and cataloged scripts over hand-written shell glue.
- Keep default routing output token-light; full checklists belong behind `--detail` or `--json`.
- Never scan `scripts/` by eye; use `scripts/ops.py` or `scripts/find_script.py`.
- Run the printed absolute `run:` line; do not guess paths from memory.
- If a helper is only a `candidate`, follow the hot route; do not run it first.
- Prefer one deterministic probe over broad inventories.
- For low-risk reversible Soty Agent source tasks, use one exact `agent-source:<device-id>` action+readback command; skip repeated `whoami`/`hostname` unless fresh, ambiguous, failed, privileged, or destructive; record successful nontrivial route families too.
- Run independent safe probes in parallel when useful; serialize risky or ordered work.
- Before long work, prove the target will stay awake; apply the lightest keep-awake/power/lid/session guard or stop with that blocker.
- For risky work, prove identity, backup, rollback, provenance, and return path
  before irreversible action.
- For human handoffs, default to safe no-command GUI/physical steps for nontechnical operators; keep command paths as technical fallback.
- For Soty/PWA, the browser is the operator surface and the local companion is the OS executor; require machine-worker proof before privileged work.
- For Soty Agent Windows reinstall/reset, do not offer Windows Settings reset as the primary path; use source-scoped LINK, safe preflight, machine-worker proof, backup/return path, then exact destructive confirmation.
- Use `scripts/soty/soty-operator.ps1` for Soty list/run/background/say/export and machine-worker checks.
- Never store passwords, tokens, license keys, private hostnames, private paths,
  raw logs, serial dumps, MACs, IMEIs, or chat transcripts in shared memory.
- If exact proof beats a written/default route, take the better safe path and record it with `ops.py --branch`; one case must not overwrite the parent rule.
- Treat skill growth as part of done: each use ends with a visible `--close` reusable-learning receipt.
- When editing this skill or any route module, audit the live work for route
  forks before final validation; patch, branch, note, marker, or no-op each
  reusable fork instead of fixing only the most obvious final error.
- Preserve `.skill-memory` as local state; merge only its JSONL queues before review/sync.
- Do not merge package files between skill copies. Use `sync_doctor.py` for read-only drift proof, port reviewed package edits into canonical source explicitly, then one-way sync.
- For skill edits, patch canonical source first, update metadata, sync required copies, then run health and activation gates.

## Self-Improvement Sink

Do not save raw dialogs as the default memory path. Use the strongest writable
sink: patch module/hot/helper/eval, `ops.py --branch`, field note,
`ops.py --during/--after` with proof/env, or one sanitized marker when no skill
tree is writable. Label installed-copy edits `installed-only` until sync is proven.

Learning is a reflex: every reusable failure, fallback, timing, command, lower-probability outcome, route fork, or wording win must become patch, auto-written marker, branch, or explicit no-op before the next state change.
For Soty Agent successes/failures, `--remember` expected/actual/proof/env before broad retry or final, and keep receipts out of user chat unless asked. Before final, close with `ops.py --close` and carry its `final_line` forward.

## Learn During/After

Do not wait until the end. Run `--checkpoint` after waits/resumes/route changes.
Use `--remember "<fact>" --proof "<proof>" --env "<env>"` for route-changing
facts, fallbacks, blockers, associations, tool failures, clearer wording, and
winning routes; promote repeated or safety-changing facts into shelf/hot/eval/helper.

## Universal Improvement Contract
Improve the next comparable run or name why it cannot. Reuse a surfaced route
profile before new exploration; if none matches repeated work, create/update one
with proof, transfer boundary, and metrics when known. Do not claim ideal
improvement from a note alone: finish with profile/patch/branch/marker/no-op.
## Skill Edit Gate

For this skill, finish with:

```powershell
python scripts/skill/finish_skill_edit.py
```

## Done

End only when the outcome is verified or one blocker is named, required copies
match for skill-sync work, and the smallest safe reusable `learning_delta`
receipt is complete: patch, note, marker, handoff marker, or no-op.
